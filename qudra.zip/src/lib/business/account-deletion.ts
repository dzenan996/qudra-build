// @polsia:user-owned — idempotent, tenant-safe cleanup before Better Auth deletion.
import 'server-only';

import { prisma } from '@/lib/db';

/**
 * Detaches only the authenticated account identity. QUDRA customer, device,
 * entitlement, source, ledger and audit records remain intact for an Owner/legal
 * retention decision. The updateMany calls make retries safe.
 */
export async function prepareAccountDeletion(userId: string): Promise<void> {
  const pseudonym = `deleted:${userId}`;

  await prisma.$transaction([
    prisma.qudraAccount.updateMany({
      where: { userId },
      data: { userId: null },
    }),
    prisma.qudraPartnerMembership.updateMany({
      where: { userId },
      data: { userId: pseudonym, active: false },
    }),
  ]);
}
