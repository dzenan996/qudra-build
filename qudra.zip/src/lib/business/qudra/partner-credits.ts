// @polsia:user-owned
import 'server-only';

import type { Prisma } from '@prisma/client';
import { prisma } from '@/lib/db';
import { appendTrustedAudit } from './audit-t7';
import { QudraAuthorizationError } from './authority';

type CreditKind = 'GRANT' | 'ADJUSTMENT' | 'REVERSAL' | 'ACTIVATION_DEBIT';

export async function ensureCreditAccount(tx: Prisma.TransactionClient, partnerId: string) {
  return tx.qudraPartnerCreditAccount.upsert({
    where: { partnerId },
    update: {},
    create: { partnerId },
  });
}

export async function applyPartnerCreditOperation(input: {
  partnerId: string;
  actorId: string;
  delta: number;
  kind: CreditKind;
  operationKey: string;
  reference?: string | null;
  correlationId?: string;
}) {
  if (!Number.isInteger(input.delta) || input.delta === 0)
    throw new QudraAuthorizationError('Credit delta must be a non-zero integer', 400);
  if (input.kind === 'ACTIVATION_DEBIT' && input.delta >= 0)
    throw new QudraAuthorizationError('Activation debit must be negative', 400);
  if (input.kind !== 'ACTIVATION_DEBIT' && input.delta < 0 && input.kind === 'GRANT')
    throw new QudraAuthorizationError('Grant cannot be negative', 400);
  return prisma.$transaction(async (tx) => {
    const account = await ensureCreditAccount(tx, input.partnerId);
    const existing = await tx.qudraPartnerCreditLedgerEntry.findUnique({
      where: { operationKey: input.operationKey },
    });
    if (existing) {
      if (
        existing.partnerId !== input.partnerId ||
        existing.delta !== input.delta ||
        existing.kind !== input.kind ||
        existing.reference !== (input.reference ?? null)
      )
        throw new QudraAuthorizationError('Credit operation key payload conflict', 409);
      return {
        account: await tx.qudraPartnerCreditAccount.findUniqueOrThrow({
          where: { id: account.id },
        }),
        entry: existing,
        replay: true,
      };
    }
    if (input.kind === 'REVERSAL') {
      if (!input.reference)
        throw new QudraAuthorizationError('Reversal reference is required', 400);
      const original = await tx.qudraPartnerCreditLedgerEntry.findFirst({
        where: { id: input.reference, partnerId: input.partnerId },
      });
      if (!original || original.kind === 'REVERSAL')
        throw new QudraAuthorizationError('Reversal reference is invalid', 409);
    }
    const updated = await tx.qudraPartnerCreditAccount.updateMany({
      where: { id: account.id, balance: { gte: input.delta < 0 ? Math.abs(input.delta) : 0 } },
      data: { balance: { increment: input.delta }, version: { increment: 1 } },
    });
    if (updated.count !== 1) throw new QudraAuthorizationError('Insufficient Partner credits', 409);
    const entry = await tx.qudraPartnerCreditLedgerEntry.create({
      data: {
        partnerId: input.partnerId,
        accountId: account.id,
        delta: input.delta,
        kind: input.kind,
        actorId: input.actorId,
        reference: input.reference ?? null,
        operationKey: input.operationKey,
        metadata: {},
      },
    });
    await appendTrustedAudit(tx, {
      action:
        input.kind === 'GRANT'
          ? 'partner.credit_granted'
          : input.kind === 'REVERSAL'
            ? 'partner.credit_reversed'
            : input.kind === 'ADJUSTMENT'
              ? 'partner.credit_adjusted'
              : 'activation.completed',
      actorId: input.actorId,
      actorType: input.kind === 'ACTIVATION_DEBIT' ? 'PARTNER' : 'SUPER_ADMIN',
      partnerId: input.partnerId,
      entityType: 'PartnerCreditLedgerEntry',
      entityId: entry.id,
      correlationId: input.correlationId ?? input.operationKey,
      metadata: { kind: input.kind, delta: input.delta, reference: input.reference ?? null },
    });
    return {
      account: await tx.qudraPartnerCreditAccount.findUniqueOrThrow({ where: { id: account.id } }),
      entry,
      replay: false,
    };
  });
}

export async function listPartnerCredits(partnerId: string) {
  const account = await prisma.qudraPartnerCreditAccount.upsert({
    where: { partnerId },
    update: {},
    create: { partnerId },
  });
  const entries = await prisma.qudraPartnerCreditLedgerEntry.findMany({
    where: { partnerId },
    orderBy: { createdAt: 'desc' },
    take: 100,
  });
  return { account, entries };
}
