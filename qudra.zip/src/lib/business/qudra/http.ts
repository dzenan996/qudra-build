// @polsia:user-owned — common safe route-handler helpers.
import { NextResponse } from 'next/server';
import { QudraAuthorizationError } from './authority';
import { redact } from './redaction';

function safeMessage(error: QudraAuthorizationError) {
  const value = redact(error.message);
  return typeof value === 'string' ? value : 'Request rejected';
}

export function errorResponse(error: unknown) {
  if (error instanceof QudraAuthorizationError)
    return NextResponse.json({ error: safeMessage(error) }, { status: error.status });
  return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
}

export function parseJson<T>(
  body: unknown,
  parser: { safeParse: (value: unknown) => { success: boolean; data?: T; error?: unknown } },
): T {
  const result = parser.safeParse(body);
  if (!result.success || result.data === undefined)
    throw new QudraAuthorizationError('Invalid request', 403);
  return result.data;
}

export function validationResponse(message = 'Invalid request') {
  return NextResponse.json({ error: message }, { status: 400 });
}
