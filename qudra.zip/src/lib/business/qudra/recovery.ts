// @polsia:user-owned — bounded recovery foundation with explicit evidence classes.
import 'server-only';

import { prisma } from '@/lib/db';
import {
  authorizeDevice,
  type QudraAuthority,
  QudraAuthorizationError,
  requireSuperAdmin,
} from './authority';

export async function createRecovery(
  authority: QudraAuthority,
  deviceId: string,
  evidenceCategory: 'ACCOUNT' | 'PARTNER_CUSTOMER_RECORD' | 'SUPER_ADMIN_SUPPORT',
  idempotencyKey?: string,
) {
  const device = await authorizeDevice(authority, deviceId);
  if (authority.kind === 'device')
    throw new QudraAuthorizationError('Device ID/proof alone cannot request recovery');
  if (idempotencyKey) {
    const existing = await prisma.qudraRecoveryChallenge.findFirst({
      where: { deviceId, idempotencyKey, state: 'PENDING' },
    });
    if (existing) return existing;
  }
  return prisma.qudraRecoveryChallenge.create({
    data: {
      customerId: device.customerId,
      deviceId,
      factorRef: `evidence:${evidenceCategory}`,
      evidenceCategory,
      idempotencyKey,
      expiresAt: new Date(Date.now() + 15 * 60 * 1000),
      maxAttempts: 5,
    },
  });
}

export async function decideRecovery(
  authority: QudraAuthority,
  challengeId: string,
  decision: 'APPROVED' | 'REJECTED' | 'CANCELLED',
) {
  const challenge = await prisma.qudraRecoveryChallenge.findUnique({ where: { id: challengeId } });
  if (!challenge) throw new QudraAuthorizationError('Recovery challenge not found', 404);
  if (challenge.state !== 'PENDING')
    throw new QudraAuthorizationError('Recovery challenge is terminal', 409);
  if (challenge.attemptCount >= 5)
    throw new QudraAuthorizationError('Recovery attempts exhausted', 429);
  if (challenge.evidenceCategory === 'SUPER_ADMIN_SUPPORT') requireSuperAdmin(authority);
  else await authorizeDevice(authority, challenge.deviceId);
  return prisma.qudraRecoveryChallenge.update({
    where: { id: challengeId },
    data: { state: decision, resolvedAt: new Date(), attemptCount: { increment: 1 } },
  });
}
