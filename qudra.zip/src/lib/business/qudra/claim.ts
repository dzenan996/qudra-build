// @polsia:user-owned — proof-checked optional account claim/link service.
import 'server-only';

import { createHash } from 'node:crypto';
import type { Prisma } from '@prisma/client';
import { prisma } from '@/lib/db';
import { constantTimeStringEqual, type QudraAuthority, QudraAuthorizationError } from './authority';
import { PAIRING_MAX_ATTEMPTS } from './pairing';
import { redactMetadata } from './redaction';

export async function claimPairingChallenge(
  authority: Extract<QudraAuthority, { kind: 'session' }>,
  challengeId: string,
  response: string,
) {
  const challenge = await prisma.qudraPairingChallenge.findUnique({ where: { id: challengeId } });
  if (!challenge) throw new QudraAuthorizationError('Pairing challenge not found', 404);
  if (challenge.kind !== 'PAIRING')
    throw new QudraAuthorizationError('Bootstrap challenge cannot be claimed by an account', 409);
  const existingAccount = await prisma.qudraAccount.findFirst({
    where: { userId: authority.userId },
  });
  if (existingAccount && existingAccount.customerId !== challenge.customerId)
    throw new QudraAuthorizationError('Cross-Customer account merge rejected', 403);
  const customerOwner = await prisma.qudraAccount.findFirst({
    where: { customerId: challenge.customerId, userId: { not: null } },
  });
  if (customerOwner && customerOwner.userId !== authority.userId)
    throw new QudraAuthorizationError('Customer is already linked to another account', 403);
  await prisma.$transaction(async (tx) => {
    const device = await tx.qudraDevice.findUnique({ where: { id: challenge.deviceId } });
    if (!device || device.customerId !== challenge.customerId)
      throw new QudraAuthorizationError('Customer authority mismatch', 403);
    const current = await tx.qudraPairingChallenge.findUnique({ where: { id: challengeId } });
    if (!current || current.state !== 'PAIRING_PENDING')
      throw new QudraAuthorizationError('Pairing challenge replay rejected', 409);
    if (current.expiresAt <= new Date()) {
      await tx.qudraPairingChallenge.update({
        where: { id: challengeId },
        data: { state: 'EXPIRED' },
      });
      throw new QudraAuthorizationError('Pairing challenge expired', 409);
    }
    const attempt = await tx.qudraPairingChallenge.updateMany({
      where: {
        id: challengeId,
        state: 'PAIRING_PENDING',
        attemptCount: { lt: PAIRING_MAX_ATTEMPTS },
      },
      data: { attemptCount: { increment: 1 } },
    });
    if (attempt.count !== 1) throw new QudraAuthorizationError('Pairing attempts exhausted', 429);
    if (
      !constantTimeStringEqual(
        createHash('sha256').update(response).digest('hex'),
        current.challengeDigest,
      )
    )
      throw new QudraAuthorizationError('Pairing proof rejected', 403);
    const now = new Date();
    await tx.qudraPairingChallenge.update({
      where: { id: challengeId },
      data: { state: 'PAIRED', consumedAt: now },
    });
    await tx.qudraDevice.update({
      where: { id: challenge.deviceId },
      data: { status: 'PAIRED', lastChallengeAt: now },
    });
    if (existingAccount) {
      await tx.qudraAccount.update({
        where: { id: existingAccount.id },
        data: { lastSeenAt: now },
      });
    } else {
      await tx.qudraAccount.create({
        data: {
          customerId: challenge.customerId,
          userId: authority.userId,
          provider: 'better-auth',
          externalIdentityRef: authority.userId,
          lastSeenAt: now,
        },
      });
    }
    await tx.qudraAuditEvent.create({
      data: {
        customerId: challenge.customerId,
        deviceId: challenge.deviceId,
        actorType: 'CUSTOMER',
        actorId: authority.userId,
        action: 'pairing.completed',
        eventType: 'pairing.completed',
        entityType: 'QudraPairingChallenge',
        entityId: challengeId,
        correlationId: `claim:${challengeId}`,
        metadata: redactMetadata({ linked: true }) as Prisma.InputJsonObject,
        occurredAt: now,
      },
    });
  });
  return {
    challengeId,
    deviceId: challenge.deviceId,
    customerId: challenge.customerId,
    state: 'PAIRED' as const,
    linked: true,
  };
}
