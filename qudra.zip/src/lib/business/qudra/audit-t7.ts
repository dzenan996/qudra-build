// @polsia:user-owned
import 'server-only';

import type { Prisma } from '@prisma/client';
import { prisma } from '@/lib/db';
import { AUDIT_ACTIONS, safeMetadata } from './domain';
import { redact } from './redaction';

export type T7AuditInput = {
  action: string;
  actorId?: string | null;
  actorType: 'PARTNER' | 'SUPER_ADMIN' | 'SYSTEM';
  partnerId?: string | null;
  customerId?: string | null;
  deviceId?: string | null;
  entityType: string;
  entityId: string;
  correlationId: string;
  metadata?: Record<string, unknown>;
};

export async function appendTrustedAudit(tx: Prisma.TransactionClient, input: T7AuditInput) {
  if (!AUDIT_ACTIONS.has(input.action)) throw new Error('Audit action is not allowlisted');
  return tx.qudraTrustedAuditEvent.create({
    data: {
      action: input.action,
      actorId: input.actorId ?? null,
      actorType: input.actorType,
      partnerId: input.partnerId ?? null,
      customerId: input.customerId ?? null,
      deviceId: input.deviceId ?? null,
      entityType: input.entityType,
      entityId: input.entityId,
      correlationId: input.correlationId,
      occurredAt: new Date(),
      metadata: safeMetadata(input.metadata ?? {}) as Prisma.InputJsonObject,
    },
  });
}

export async function writeTrustedAudit(input: T7AuditInput) {
  return prisma.$transaction((tx) => appendTrustedAudit(tx, input));
}

export function safeAuditEvent(event: {
  id: string;
  action: string;
  actorType: string;
  partnerId: string | null;
  customerId: string | null;
  deviceId: string | null;
  entityType: string;
  entityId: string;
  metadata: Prisma.JsonValue;
  occurredAt: Date;
}) {
  return {
    ...event,
    metadata: redact(safeMetadata((event.metadata ?? {}) as Record<string, unknown>)) as Record<
      string,
      unknown
    >,
    occurredAt: event.occurredAt.toISOString(),
  };
}
