// @polsia:user-owned — QUDRA route boundary helpers.
import { NextResponse } from 'next/server';
import { QudraAuthorizationError, resolveAuthority } from './authority';
import { redact } from './redaction';

export async function requestBody(request: Request) {
  try {
    return await request.json();
  } catch {
    throw new QudraAuthorizationError('Invalid JSON body', 400);
  }
}
export async function routeAuthority(request: Request) {
  return resolveAuthority(request);
}
export function routeError(error: unknown) {
  if (error instanceof QudraAuthorizationError) {
    const message = redact(error.message);
    return NextResponse.json(
      { error: typeof message === 'string' ? message : 'Request rejected' },
      { status: error.status },
    );
  }
  return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
}
export function unauthorized() {
  return NextResponse.json({ error: 'Verified authority required' }, { status: 403 });
}
export function badRequest(message = 'Invalid request') {
  return NextResponse.json({ error: message }, { status: 400 });
}
