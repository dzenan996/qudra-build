// @polsia:user-owned — current/latest diagnostic observations and stable T1R registry.
import 'server-only';

import { prisma } from '@/lib/db';
import { authorizeDevice, type QudraAuthority, requireInternal, requireScope } from './authority';
import { redactMetadata } from './redaction';

export const DIAGNOSTIC_CODES = [
  {
    category: 'INTERNET',
    code: 'internet.unreachable',
    description: 'Internet reachability failed',
  },
  {
    category: 'QUDRA_CLOUD',
    code: 'qudra_cloud.unreachable',
    description: 'QUDRA Cloud is unreachable',
  },
  {
    category: 'ENTITLEMENT',
    code: 'entitlement.inactive',
    description: 'Device entitlement is not active',
  },
  {
    category: 'SOURCE',
    code: 'source.access_failed',
    description: 'Personal source access failed',
  },
  {
    category: 'SOURCE',
    code: 'source.reachability_denied',
    description: 'Personal source was unreachable or denied access',
  },
  {
    category: 'SOURCE',
    code: 'source.invalid',
    description: 'Personal source URL or response is invalid',
  },
  {
    category: 'SOURCE',
    code: 'source.selected_stream_unavailable',
    description: 'The selected direct stream is unavailable',
  },
  {
    category: 'PLAYLIST_EPG',
    code: 'playlist_epg.unavailable',
    description: 'Playlist or EPG is unavailable',
  },
  { category: 'PLAYBACK', code: 'playback.unavailable', description: 'Playback is unavailable' },
  {
    category: 'PLAYLIST_EPG',
    code: 'playlist.parse_failed',
    description: 'Playlist parsing failed on the Device',
  },
  { category: 'PLAYLIST_EPG', code: 'epg.stale', description: 'EPG data is stale or unavailable' },
  {
    category: 'PLAYBACK',
    code: 'playback.capability_issue',
    description: 'The Device cannot play the reported source capability',
  },
  {
    category: 'SOURCE',
    code: 'source.access_denied',
    description: 'Personal source access was denied',
  },
  {
    category: 'PLAYLIST_EPG',
    code: 'playlist.unsupported_format',
    description: 'The source format is not supported by the Device',
  },
  {
    category: 'PLAYLIST_EPG',
    code: 'epg.unavailable',
    description: 'No usable EPG is available for the source',
  },
  {
    category: 'PLAYBACK',
    code: 'playback.catch_up_unsupported',
    description: 'Catch-up is not supported for the selected stream',
  },
  {
    category: 'PLAYBACK',
    code: 'playback.timeshift_unsupported',
    description: 'Timeshift is not supported for the selected stream',
  },
  {
    category: 'QUDRA_CLOUD',
    code: 'sync.conflict',
    description: 'Source sync was rejected for a stale configuration',
  },
  {
    category: 'QUDRA_CLOUD',
    code: 'secret_provider.unavailable',
    description: 'Owner-controlled source secret provider is unavailable',
  },
] as const;

export async function writeDiagnostic(
  authority: QudraAuthority,
  input: {
    deviceId: string;
    category: 'INTERNET' | 'QUDRA_CLOUD' | 'ENTITLEMENT' | 'SOURCE' | 'PLAYLIST_EPG' | 'PLAYBACK';
    state: string;
    code: string;
    message: string;
    retryable: boolean;
    observedAt: Date;
    correlationId: string;
  },
) {
  requireInternal(authority, 'diagnostics:append');
  const device = await prisma.qudraDevice.findUnique({ where: { id: input.deviceId } });
  if (!device) throw new Error('Device not found');
  const safeInput = {
    ...input,
    message: String(redactMetadata({ message: input.message }).message ?? 'Diagnostic reported'),
  };
  return prisma.qudraDiagnostic.upsert({
    where: { deviceId_category: { deviceId: input.deviceId, category: input.category } },
    update: { ...safeInput, customerId: device.customerId },
    create: { ...safeInput, customerId: device.customerId },
  });
}

export async function currentDiagnostics(authority: QudraAuthority, deviceId: string) {
  if (authority.kind === 'internal') requireScope(authority, 'diagnostics:read');
  await authorizeDevice(authority, deviceId);
  return prisma.qudraDiagnostic.findMany({ where: { deviceId }, orderBy: { observedAt: 'desc' } });
}
