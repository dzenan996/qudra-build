// @polsia:user-owned
import 'server-only';

import { createHash } from 'node:crypto';
import { prisma } from '@/lib/db';
import { appendTrustedAudit } from './audit-t7';
import { QudraAuthorizationError } from './authority';
import { ANNUAL_LICENSE_DURATION_MS, PARTNER_ACTIVATION_CREDITS } from './domain';
import { partnerDevice } from './partner';
import { ensureCreditAccount } from './partner-credits';

export async function activatePartnerLicense(input: {
  partnerId: string;
  actorId: string;
  customerId: string;
  deviceId: string;
  kind: 'ANNUAL' | 'LIFETIME';
  idempotencyKey: string;
}) {
  const device = await partnerDevice(input.partnerId, input.customerId, input.deviceId);
  const partner = await prisma.qudraPartner.findUnique({
    where: { id: input.partnerId },
    include: { policy: true },
  });
  if (!partner || partner.status !== 'ACTIVE')
    throw new QudraAuthorizationError('Partner is not active', 403);
  const policy = partner.policy;
  if (
    !policy ||
    (device.productFamily === 'TV' ? !policy.allowTv : !policy.allowMobile) ||
    (input.kind === 'ANNUAL' ? !policy.allowAnnual : !policy.allowLifetime)
  )
    throw new QudraAuthorizationError('Activation is outside Partner policy', 403);
  const fingerprint = createHash('sha256')
    .update(`${input.customerId}:${input.deviceId}:${device.productFamily}:${input.kind}`)
    .digest('hex');
  return prisma.$transaction(async (tx) => {
    // Serialize retries for one Partner before checking idempotency or balance.
    // The conditional debit below remains the final no-overspend invariant.
    const account = await ensureCreditAccount(tx, input.partnerId);
    await tx.qudraPartnerCreditAccount.update({
      where: { id: account.id },
      data: { version: { increment: 0 } },
    });
    const replay = await tx.qudraPartnerActivation.findUnique({
      where: {
        partnerId_idempotencyKey: {
          partnerId: input.partnerId,
          idempotencyKey: input.idempotencyKey,
        },
      },
    });
    if (replay) {
      if (replay.payloadFingerprint !== fingerprint)
        throw new QudraAuthorizationError('Idempotency key payload conflict', 409);
      const entitlement = replay.entitlementId
        ? await tx.qudraEntitlement.findUnique({ where: { id: replay.entitlementId } })
        : null;
      return { activation: replay, entitlement, replay: true };
    }
    const activation = await tx.qudraPartnerActivation.create({
      data: {
        partnerId: input.partnerId,
        customerId: input.customerId,
        deviceId: input.deviceId,
        kind: input.kind,
        productFamily: device.productFamily,
        actorId: input.actorId,
        requiredCredits: PARTNER_ACTIVATION_CREDITS,
        idempotencyKey: input.idempotencyKey,
        payloadFingerprint: fingerprint,
      },
    });
    await appendTrustedAudit(tx, {
      action: 'activation.requested',
      actorId: input.actorId,
      actorType: 'PARTNER',
      partnerId: input.partnerId,
      customerId: input.customerId,
      deviceId: input.deviceId,
      entityType: 'PartnerActivation',
      entityId: activation.id,
      correlationId: input.idempotencyKey,
      metadata: { kind: input.kind, productFamily: device.productFamily },
    });
    const updated = await tx.qudraPartnerCreditAccount.updateMany({
      where: { id: account.id, balance: { gte: PARTNER_ACTIVATION_CREDITS } },
      data: { balance: { decrement: PARTNER_ACTIVATION_CREDITS }, version: { increment: 1 } },
    });
    if (updated.count !== 1) throw new QudraAuthorizationError('Insufficient Partner credits', 409);
    const debit = await tx.qudraPartnerCreditLedgerEntry.create({
      data: {
        partnerId: input.partnerId,
        accountId: account.id,
        delta: -PARTNER_ACTIVATION_CREDITS,
        kind: 'ACTIVATION_DEBIT',
        actorId: input.actorId,
        reference: activation.id,
        operationKey: `activation-debit:${activation.id}`,
        metadata: {},
      },
    });
    await tx.qudraEntitlement.updateMany({
      where: { deviceId: input.deviceId, state: 'ACTIVE' },
      data: { state: 'REPLACED', entitlementVersion: { increment: 1 } },
    });
    const activatedAt = new Date();
    const entitlement = await tx.qudraEntitlement.create({
      data: {
        customerId: input.customerId,
        deviceId: input.deviceId,
        kind: input.kind,
        channel: 'PARTNER',
        provenance: 'PARTNER',
        state: 'ACTIVE',
        activatedAt,
        expiresAt:
          input.kind === 'ANNUAL'
            ? new Date(activatedAt.getTime() + ANNUAL_LICENSE_DURATION_MS)
            : null,
        lastValidatedAt: activatedAt,
        graceUntil: new Date(activatedAt.getTime() + 72 * 60 * 60 * 1000),
        revalidationRequired: false,
        entitlementVersion: 1,
        activationRef: activation.id,
        idempotencyKey: input.idempotencyKey,
      },
    });
    await tx.qudraDeviceCurrentEntitlement.upsert({
      where: { deviceId: input.deviceId },
      update: { entitlementId: entitlement.id, assignedAt: activatedAt },
      create: { deviceId: input.deviceId, entitlementId: entitlement.id, assignedAt: activatedAt },
    });
    const completed = await tx.qudraPartnerActivation.update({
      where: { id: activation.id },
      data: { entitlementId: entitlement.id, status: 'COMPLETED', completedAt: activatedAt },
    });
    await appendTrustedAudit(tx, {
      action: 'activation.completed',
      actorId: input.actorId,
      actorType: 'PARTNER',
      partnerId: input.partnerId,
      customerId: input.customerId,
      deviceId: input.deviceId,
      entityType: 'PartnerActivation',
      entityId: completed.id,
      correlationId: input.idempotencyKey,
      metadata: { debitEntryId: debit.id, entitlementId: entitlement.id },
    });
    await appendTrustedAudit(tx, {
      action: 'entitlement.activated',
      actorId: input.actorId,
      actorType: 'PARTNER',
      partnerId: input.partnerId,
      customerId: input.customerId,
      deviceId: input.deviceId,
      entityType: 'QudraEntitlement',
      entityId: entitlement.id,
      correlationId: input.idempotencyKey,
      metadata: { kind: input.kind, provenance: 'PARTNER' },
    });
    return { activation: completed, entitlement, replay: false };
  });
}

export async function listPartnerActivations(partnerId: string) {
  return prisma.qudraPartnerActivation.findMany({
    where: { partnerId },
    orderBy: { createdAt: 'desc' },
    take: 100,
  });
}
