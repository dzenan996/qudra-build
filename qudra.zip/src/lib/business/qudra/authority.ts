// @polsia:user-owned — server-authoritative QUDRA authority resolution.
import 'server-only';

import {
  createHash,
  createPublicKey,
  timingSafeEqual,
  verify as verifySignature,
} from 'node:crypto';
import type { QudraDeviceAlgorithm } from '@prisma/client';
import { prisma } from '@/lib/db';
import { getSessionUser } from '@/lib/require-auth';

export { safeMetadata } from './domain';

export type QudraAuthority =
  | { kind: 'session'; userId: string; isSuperAdmin: boolean }
  | {
      kind: 'device';
      deviceId: string;
      customerId: string;
      keyVersion: number;
      fingerprint: string;
      sessionId?: string;
    }
  | { kind: 'internal'; serviceId: string; scopes: readonly InternalScope[] }
  | {
      kind: 'test';
      testId: string;
      customerId?: string;
      deviceId?: string;
      isSuperAdmin?: boolean;
    };

export class QudraAuthorizationError extends Error {
  status: 400 | 401 | 403 | 404 | 409 | 429 | 503 = 403;
  constructor(message: string, status: 400 | 401 | 403 | 404 | 409 | 429 | 503 = 403) {
    super(message);
    this.status = status;
  }
}

export const INTERNAL_SCOPES = [
  'audit:append',
  'audit:read',
  'diagnostics:append',
  'diagnostics:read',
  'entitlement:write',
  'device:replace',
  'device:rotate',
  'device:revoke',
  'source:read',
  'source:write',
  'trial:write',
  'access:read',
  'pairing:manage',
] as const;
export type InternalScope = (typeof INTERNAL_SCOPES)[number];

type ServiceCredential = {
  id: string;
  secret: string;
  scopes: InternalScope[];
  expiresAt?: string;
};

const asBuffer = (value: string) => {
  try {
    return Buffer.from(value, 'base64url');
  } catch {
    return Buffer.alloc(0);
  }
};

export function constantTimeStringEqual(left: string, right: string): boolean {
  const leftBuffer = Buffer.from(left, 'utf8');
  const rightBuffer = Buffer.from(right, 'utf8');
  return leftBuffer.length === rightBuffer.length && timingSafeEqual(leftBuffer, rightBuffer);
}

export function bootstrapProofPayload(input: {
  challengeId: string;
  nonce: string;
  deviceId: string;
  keyVersion: number;
}): string {
  return `${input.challengeId}:${input.nonce}:${input.deviceId}:${input.keyVersion}`;
}

export function fingerprintPublicKey(publicKey: string): string {
  return createHash('sha256').update(publicKey, 'utf8').digest('hex');
}

export function verifyDeviceSignature(input: {
  algorithm: QudraDeviceAlgorithm;
  publicKey: string;
  payload: string;
  signature: string;
}): boolean {
  const signature = asBuffer(input.signature);
  if (signature.length === 0) return false;
  try {
    const key = createPublicKey(input.publicKey);
    if (input.algorithm === 'ED25519')
      return verifySignature(null, Buffer.from(input.payload), key, signature);
    if (input.algorithm === 'P256')
      return verifySignature('sha256', Buffer.from(input.payload), key, signature);
    return false;
  } catch {
    return false;
  }
}

export async function resolveAuthority(req: Request): Promise<QudraAuthority | null> {
  // Never treat a browser's ordinary Authorization bearer as an internal service credential.
  // The dedicated header is only consumed here, on the server, after scoped verification.
  const internalToken = req.headers.get('x-qudra-internal-token');
  const internalAuthority = resolveInternalAuthority(internalToken);
  if (internalAuthority) return internalAuthority;

  const deviceSessionToken = req.headers.get('x-qudra-device-session');
  if (deviceSessionToken) {
    const { authenticateDeviceSession } = await import('./device-session');
    const sessionAuthority = await authenticateDeviceSession(deviceSessionToken);
    if (sessionAuthority) return sessionAuthority;
  }

  const user = await getSessionUser();
  if (user) return { kind: 'session', userId: user.id, isSuperAdmin: user.role === 'admin' };

  const deviceId = req.headers.get('x-qudra-device-id');
  const keyVersionHeader = req.headers.get('x-qudra-key-version');
  const challenge = req.headers.get('x-qudra-challenge');
  const proof = req.headers.get('x-qudra-proof');
  const keyVersion = Number(keyVersionHeader);
  if (!deviceId || !challenge || !proof || !Number.isInteger(keyVersion) || keyVersion < 1)
    return null;

  const device = await prisma.qudraDevice.findUnique({ where: { id: deviceId } });
  if (!device || device.status === 'REVOKED' || device.keyVersion !== keyVersion) return null;
  if (
    !verifyDeviceSignature({
      algorithm: device.algorithm,
      publicKey: device.publicKey,
      payload: `${device.id}:${challenge}:${keyVersion}`,
      signature: proof,
    })
  )
    return null;
  return {
    kind: 'device',
    deviceId: device.id,
    customerId: device.customerId,
    keyVersion,
    fingerprint: device.publicKeyFingerprint,
  };
}

function resolveInternalAuthority(token: string | null): QudraAuthority | null {
  if (!token) return null;
  let configured: unknown;
  try {
    configured = JSON.parse(process.env.QUDRA_INTERNAL_SERVICE_CREDENTIALS ?? '[]');
  } catch {
    return null;
  }
  const credentials = Array.isArray(configured) ? configured : [];
  for (const candidate of credentials) {
    if (!isServiceCredential(candidate)) continue;
    if (candidate.expiresAt) {
      const expiresAt = Date.parse(candidate.expiresAt);
      if (!Number.isFinite(expiresAt) || expiresAt <= Date.now()) continue;
    }
    const left = Buffer.from(token);
    const right = Buffer.from(candidate.secret);
    if (left.length !== right.length || !timingSafeEqual(left, right)) continue;
    return { kind: 'internal', serviceId: candidate.id, scopes: candidate.scopes };
  }
  return null;
}

function isServiceCredential(value: unknown): value is ServiceCredential {
  if (!value || typeof value !== 'object') return false;
  const candidate = value as Partial<ServiceCredential>;
  return (
    typeof candidate.id === 'string' &&
    candidate.id.length > 0 &&
    typeof candidate.secret === 'string' &&
    candidate.secret.length > 0 &&
    Array.isArray(candidate.scopes) &&
    candidate.scopes.every((scope) => INTERNAL_SCOPES.includes(scope as InternalScope))
  );
}

export function requireScope(authority: QudraAuthority, scope: InternalScope) {
  if (authority.kind === 'internal' && !authority.scopes.includes(scope))
    throw new QudraAuthorizationError(`Internal scope required: ${scope}`);
  return authority;
}

export function requireAuthority(authority: QudraAuthority | null): QudraAuthority {
  if (!authority) throw new QudraAuthorizationError('Verified authority required');
  assertTestAuthorityAllowed(authority);
  return authority;
}

export function assertTestAuthorityAllowed(authority: QudraAuthority) {
  if (authority.kind === 'test' && process.env.NODE_ENV !== 'test')
    throw new QudraAuthorizationError('Test authority is unavailable outside test runtime');
}

export async function customerIdForAuthority(
  authority: QudraAuthority,
  requestedCustomerId?: string,
): Promise<string | null> {
  assertTestAuthorityAllowed(authority);
  if (authority.kind === 'device') return authority.customerId;
  if (authority.kind === 'test') return authority.customerId ?? null;
  if (authority.kind === 'internal') return requestedCustomerId ?? null;
  const account = await prisma.qudraAccount.findFirst({
    where: { userId: authority.userId },
    select: { customerId: true },
  });
  return account?.customerId ?? null;
}

export async function authorizeDevice(authority: QudraAuthority, deviceId: string) {
  assertTestAuthorityAllowed(authority);
  const device = await prisma.qudraDevice.findUnique({ where: { id: deviceId } });
  if (!device) throw new QudraAuthorizationError('Device not found', 404);
  if (authority.kind === 'device' && authority.deviceId !== device.id)
    throw new QudraAuthorizationError('Device authority mismatch');
  if (authority.kind === 'test' && authority.deviceId && authority.deviceId !== device.id)
    throw new QudraAuthorizationError('Device authority mismatch');
  if (authority.kind === 'session') {
    const customerId = await customerIdForAuthority(authority);
    if (!customerId || customerId !== device.customerId)
      throw new QudraAuthorizationError('Customer authority mismatch');
  }
  if (authority.kind === 'internal') return device;
  if (authority.kind === 'session' && authority.isSuperAdmin) return device;
  return device;
}

export function requireInternal(
  authority: QudraAuthority | null,
  scope?: InternalScope,
): Extract<QudraAuthority, { kind: 'internal' | 'test' }> {
  if (
    !authority ||
    (authority.kind !== 'internal' &&
      !(authority.kind === 'test' && authority.isSuperAdmin && process.env.NODE_ENV === 'test')) ||
    (scope && authority.kind === 'internal' && !authority.scopes.includes(scope))
  )
    throw new QudraAuthorizationError('Internal authority required');
  return authority as Extract<QudraAuthority, { kind: 'internal' | 'test' }>;
}

export function requireSuperAdmin(authority: QudraAuthority | null): QudraAuthority {
  if (
    !authority ||
    !(
      (authority.kind === 'session' && authority.isSuperAdmin) ||
      (authority.kind === 'test' && authority.isSuperAdmin && process.env.NODE_ENV === 'test')
    )
  )
    throw new QudraAuthorizationError('Super Admin authority required');
  return authority;
}

export function assertSameDevice(authority: QudraAuthority, deviceId: string) {
  assertTestAuthorityAllowed(authority);
  if (authority.kind === 'device' && authority.deviceId !== deviceId)
    throw new QudraAuthorizationError('Cross-device authority rejected');
  if (authority.kind === 'test' && authority.deviceId && authority.deviceId !== deviceId)
    throw new QudraAuthorizationError('Cross-device authority rejected');
}
