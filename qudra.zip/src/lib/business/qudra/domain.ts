// @polsia:user-owned — pure QUDRA T2 invariants safe for unit tests.
import { redactMetadata, redactUrl } from './redaction';

export const TRIAL_DURATION_MS = 168 * 60 * 60 * 1000;
export const ENTITLEMENT_GRACE_MS = 72 * 60 * 60 * 1000;
export const AUDIT_ACTIONS = new Set([
  'device.registered',
  'device.revoked',
  'device.key_rotated',
  'pairing.created',
  'pairing.completed',
  'pairing.expired',
  'pairing.cancelled',
  'pairing.rate_limited',
  'pairing.replay_rejected',
  'recovery.requested',
  'recovery.approved',
  'recovery.rejected',
  'trial.started',
  'trial.expired',
  'trial.exception_requested',
  'trial.exception_approved',
  'trial.exception_rejected',
  'entitlement.activated',
  'entitlement.expired',
  'entitlement.suspended',
  'entitlement.revoked',
  'entitlement.replaced',
  'source_config.created',
  'source_config.updated',
  'source_config.deleted',
  'source_config.secret_changed',
  'active_source.changed',
  'source_sync.requested',
  'source_sync.completed',
  'source_sync.failed',
  'source_config.claimed',
  'partner.created',
  'partner.updated',
  'partner.suspended',
  'partner.credit_granted',
  'partner.credit_adjusted',
  'partner.credit_reversed',
  'activation.requested',
  'activation.completed',
  'activation.rejected',
  'branding.submitted',
  'branding.approved',
  'branding.rejected',
  'replacement.requested',
  'replacement.approved',
  'replacement.rejected',
  'trial.exception_requested',
  'trial.exception_approved',
  'trial.exception_rejected',
  'admin.view_as_partner_started',
  'admin.view_as_partner_ended',
]);

export const PARTNER_ACTIVATION_CREDITS = 1;
export const ANNUAL_LICENSE_DURATION_MS = 365 * 24 * 60 * 60 * 1000;
export const PARTNER_BRANDING_FIELDS = [
  'displayName',
  'logoUrl',
  'supportEmail',
  'supportPhone',
] as const;

export function trialEndsAt(startedAt: Date): Date {
  return new Date(startedAt.getTime() + TRIAL_DURATION_MS);
}
export function trialIsActive(
  startedAt: Date | null,
  endsAt: Date | null,
  now = new Date(),
): boolean {
  return !!startedAt && !!endsAt && now.getTime() < endsAt.getTime();
}
export function entitlementIsUsable(
  entitlement: { state: string; kind: string; expiresAt: Date | null },
  now = new Date(),
) {
  return (
    entitlement.state === 'ACTIVE' &&
    (entitlement.kind === 'LIFETIME' ||
      (!!entitlement.expiresAt && now.getTime() < entitlement.expiresAt.getTime()))
  );
}
export function safeMetadata(value: Record<string, unknown>): Record<string, unknown> {
  return redactMetadata(value);
}
export function redactSource(source: {
  id: string;
  deviceId: string | null;
  label: string;
  sourceType?: string;
  endpointUrl: string | null;
  epgUrl?: string | null;
  sourceTimezone?: string | null;
  utcOffsetMinutes?: number | null;
  slot: number | null;
  secretCiphertext: string | null;
  secretKeyReference: string | null;
  secretKeyVersion: number | null;
  configVersion: number;
}) {
  return {
    id: source.id,
    deviceId: source.deviceId ?? '',
    label: source.label,
    sourceType: 'personal_source' as const,
    endpointUrl: redactUrl(source.endpointUrl),
    epgUrl: redactUrl(source.epgUrl),
    sourceTimezone: source.sourceTimezone ?? null,
    utcOffsetMinutes: source.utcOffsetMinutes ?? null,
    slot: source.slot,
    hasSecret: !!source.secretCiphertext,
    secretStorage: {
      keyReference: source.secretKeyReference,
      keyVersion: source.secretKeyVersion,
      redacted: true as const,
    },
    configVersion: source.configVersion,
  };
}
export function validateEnvelopeSecret(value: {
  ciphertext: string;
  keyReference: string;
  keyVersion: number;
}) {
  if (
    !value.ciphertext ||
    !value.keyReference ||
    !Number.isInteger(value.keyVersion) ||
    value.keyVersion < 1
  )
    throw new Error('Approved envelope metadata is required');
  return {
    ciphertext: value.ciphertext,
    keyReference: value.keyReference,
    keyVersion: value.keyVersion,
  };
}
