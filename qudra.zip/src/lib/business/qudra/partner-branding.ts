// @polsia:user-owned
import 'server-only';

import { prisma } from '@/lib/db';
import { appendTrustedAudit } from './audit-t7';
import { QudraAuthorizationError } from './authority';
import { safeBranding } from './partner';

type BrandingInput = {
  displayName: string | null;
  logoUrl: string | null;
  supportEmail: string | null;
  supportPhone: string | null;
};
export async function submitPartnerBranding(
  partnerId: string,
  actorId: string,
  input: BrandingInput,
) {
  const partner = await prisma.qudraPartner.findUnique({ where: { id: partnerId } });
  if (!partner || partner.status !== 'ACTIVE')
    throw new QudraAuthorizationError('Partner is not active', 403);
  const result = await prisma.$transaction(async (tx) => {
    const branding = await tx.qudraPartnerBranding.upsert({
      where: { partnerId },
      update: {
        proposedName: input.displayName,
        proposedLogoUrl: input.logoUrl,
        proposedEmail: input.supportEmail,
        proposedPhone: input.supportPhone,
        state: 'PENDING',
        submittedBy: actorId,
        rejectionReason: null,
      },
      create: {
        partnerId,
        proposedName: input.displayName,
        proposedLogoUrl: input.logoUrl,
        proposedEmail: input.supportEmail,
        proposedPhone: input.supportPhone,
        submittedBy: actorId,
        state: 'PENDING',
      },
    });
    await appendTrustedAudit(tx, {
      action: 'branding.submitted',
      actorId,
      actorType: 'PARTNER',
      partnerId,
      entityType: 'QudraPartnerBranding',
      entityId: branding.id,
      correlationId: branding.id,
      metadata: { fields: ['displayName', 'logoUrl', 'supportEmail', 'supportPhone'] },
    });
    return branding;
  });
  return safeBranding(result);
}

export async function decidePartnerBranding(
  partnerId: string,
  actorId: string,
  decision: 'APPROVED' | 'REJECTED',
  reason?: string,
) {
  return prisma.$transaction(async (tx) => {
    const branding = await tx.qudraPartnerBranding.findUnique({ where: { partnerId } });
    if (!branding) throw new QudraAuthorizationError('Branding proposal not found', 404);
    const updated = await tx.qudraPartnerBranding.update({
      where: { partnerId },
      data: {
        state: decision,
        reviewedBy: actorId,
        reviewedAt: new Date(),
        rejectionReason: decision === 'REJECTED' ? (reason ?? 'Rejected') : null,
        approvedName: decision === 'APPROVED' ? branding.proposedName : branding.approvedName,
        approvedLogoUrl:
          decision === 'APPROVED' ? branding.proposedLogoUrl : branding.approvedLogoUrl,
        approvedEmail: decision === 'APPROVED' ? branding.proposedEmail : branding.approvedEmail,
        approvedPhone: decision === 'APPROVED' ? branding.proposedPhone : branding.approvedPhone,
      },
    });
    await appendTrustedAudit(tx, {
      action: decision === 'APPROVED' ? 'branding.approved' : 'branding.rejected',
      actorId,
      actorType: 'SUPER_ADMIN',
      partnerId,
      entityType: 'QudraPartnerBranding',
      entityId: updated.id,
      correlationId: updated.id,
      metadata: { decision },
    });
    return safeBranding(updated);
  });
}
