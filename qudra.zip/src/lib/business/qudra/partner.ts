// @polsia:user-owned
import 'server-only';

import { prisma } from '@/lib/db';
import { getSessionUser, type SessionUser } from '@/lib/require-auth';
import { QudraAuthorizationError } from './authority';

export async function requireSuperAdminApi(): Promise<SessionUser> {
  const user = await getSessionUser();
  if (!user) throw new QudraAuthorizationError('Authentication required', 401);
  if (user.role !== 'admin')
    throw new QudraAuthorizationError('Super Admin authority required', 403);
  return user;
}

export async function requirePartnerContext() {
  const user = await getSessionUser();
  if (!user) throw new QudraAuthorizationError('Authentication required', 401);
  const membership = await prisma.qudraPartnerMembership.findFirst({
    where: { userId: user.id, active: true },
    include: { partner: true },
    orderBy: { createdAt: 'asc' },
  });
  if (!membership) throw new QudraAuthorizationError('Active Partner membership required', 403);
  if (membership.partner.status !== 'ACTIVE')
    throw new QudraAuthorizationError('Partner is not active', 403);
  return { user, membership, partner: membership.partner };
}

export async function partnerCustomer(partnerId: string, customerId: string) {
  const scope = await prisma.qudraPartnerCustomerScope.findFirst({
    where: { partnerId, customerId, status: 'ACTIVE' },
  });
  if (!scope) throw new QudraAuthorizationError('Customer is outside Partner scope', 403);
  const customer = await prisma.qudraCustomer.findUnique({ where: { id: customerId } });
  if (!customer) throw new QudraAuthorizationError('Customer not found', 404);
  return customer;
}

export async function partnerDevice(partnerId: string, customerId: string, deviceId: string) {
  await partnerCustomer(partnerId, customerId);
  const device = await prisma.qudraDevice.findFirst({ where: { id: deviceId, customerId } });
  if (!device) throw new QudraAuthorizationError('Device is outside Customer scope', 403);
  return device;
}

export async function partnerBrandingView(partnerId: string) {
  return prisma.qudraPartnerBranding.findUnique({ where: { partnerId } });
}

export function safeBranding(
  branding: {
    state: string;
    proposedName: string | null;
    proposedLogoUrl: string | null;
    proposedEmail: string | null;
    proposedPhone: string | null;
    approvedName: string | null;
    approvedLogoUrl: string | null;
    approvedEmail: string | null;
    approvedPhone: string | null;
  } | null,
) {
  if (!branding) return null;
  return {
    state: branding.state,
    proposed: {
      displayName: branding.proposedName,
      logoUrl: branding.proposedLogoUrl,
      supportEmail: branding.proposedEmail,
      supportPhone: branding.proposedPhone,
    },
    approved: {
      displayName: branding.approvedName,
      logoUrl: branding.approvedLogoUrl,
      supportEmail: branding.approvedEmail,
      supportPhone: branding.approvedPhone,
    },
  };
}
