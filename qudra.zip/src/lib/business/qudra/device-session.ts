// @polsia:user-owned — durable, Device-bound session authority.
import 'server-only';

import { createHash, randomBytes } from 'node:crypto';
import type { Prisma } from '@prisma/client';
import { prisma } from '@/lib/db';
import { authorizeDevice, type QudraAuthority, QudraAuthorizationError } from './authority';

export const DEVICE_SESSION_LIFETIME_MS = 24 * 60 * 60 * 1000;

const digest = (token: string) => createHash('sha256').update(token).digest('hex');

export async function issueDeviceSessionRecord(
  tx: Prisma.TransactionClient,
  deviceId: string,
  keyVersion: number,
  now = new Date(),
) {
  const token = randomBytes(32).toString('base64url');
  const expiresAt = new Date(now.getTime() + DEVICE_SESSION_LIFETIME_MS);
  await tx.qudraDeviceSession.create({
    data: { deviceId, tokenDigest: digest(token), keyVersion, issuedAt: now, expiresAt },
  });
  return { token, deviceId, keyVersion, expiresAt };
}

export async function issueDeviceSession(authority: QudraAuthority, deviceId: string) {
  if (authority.kind !== 'device' && authority.kind !== 'session' && authority.kind !== 'test')
    throw new QudraAuthorizationError('Device or claim authority required');
  await authorizeDevice(authority, deviceId);
  const device = await prisma.qudraDevice.findUnique({ where: { id: deviceId } });
  if (!device) throw new QudraAuthorizationError('Device not found', 404);
  if (authority.kind === 'device' && authority.deviceId !== deviceId)
    throw new QudraAuthorizationError('Device authority mismatch');
  if (authority.kind === 'test' && authority.deviceId && authority.deviceId !== deviceId)
    throw new QudraAuthorizationError('Device authority mismatch');
  if (device.status === 'REVOKED')
    throw new QudraAuthorizationError('Revoked Device cannot receive a session', 409);

  return prisma.$transaction((tx) => issueDeviceSessionRecord(tx, deviceId, device.keyVersion));
}

export async function authenticateDeviceSession(token: string): Promise<QudraAuthority | null> {
  const session = await prisma.qudraDeviceSession.findUnique({
    where: { tokenDigest: digest(token) },
    include: { device: true },
  });
  if (
    !session ||
    session.revokedAt ||
    session.expiresAt.getTime() <= Date.now() ||
    session.device.status === 'REVOKED' ||
    session.keyVersion !== session.device.keyVersion
  )
    return null;
  await prisma.qudraDeviceSession.update({
    where: { id: session.id },
    data: { lastSeenAt: new Date() },
  });
  return {
    kind: 'device',
    deviceId: session.deviceId,
    customerId: session.device.customerId,
    keyVersion: session.keyVersion,
    fingerprint: session.device.publicKeyFingerprint,
    sessionId: session.id,
  };
}

export async function renewDeviceSession(token: string, expectedDeviceId?: string) {
  const authority = await authenticateDeviceSession(token);
  if (!authority || authority.kind !== 'device' || !authority.sessionId)
    throw new QudraAuthorizationError('Valid Device session required');
  if (expectedDeviceId && authority.deviceId !== expectedDeviceId)
    throw new QudraAuthorizationError('Device authority mismatch');
  return prisma.$transaction(async (tx) => {
    const now = new Date();
    const revoked = await tx.qudraDeviceSession.updateMany({
      where: {
        id: authority.sessionId,
        tokenDigest: digest(token),
        revokedAt: null,
        expiresAt: { gt: now },
        keyVersion: authority.keyVersion,
      },
      data: { revokedAt: now, lastRenewedAt: now },
    });
    if (revoked.count !== 1)
      throw new QudraAuthorizationError('Device session is no longer renewable', 401);
    const next = await issueDeviceSessionRecord(tx, authority.deviceId, authority.keyVersion, now);
    return next;
  });
}

export async function revokeDeviceSessions(deviceId: string) {
  return prisma.qudraDeviceSession.updateMany({
    where: { deviceId, revokedAt: null },
    data: { revokedAt: new Date() },
  });
}
