// @polsia:user-owned — QUDRA Device identity and registration service.
import 'server-only';

import { createPublicKey } from 'node:crypto';
import type {
  Prisma,
  QudraDeviceAlgorithm,
  QudraDevicePlatform,
  QudraProductFamily,
} from '@prisma/client';
import { prisma } from '@/lib/db';
import {
  assertTestAuthorityAllowed,
  fingerprintPublicKey,
  type QudraAuthority,
  QudraAuthorizationError,
} from './authority';

export function validatePlatformFamily(
  platform: QudraDevicePlatform,
  productFamily: QudraProductFamily,
) {
  if (platform === 'ANDROID_TV' && productFamily !== 'TV')
    throw new QudraAuthorizationError('ANDROID_TV requires TV family', 400);
  if (platform !== 'ANDROID_TV' && productFamily !== 'MOBILE')
    throw new QudraAuthorizationError('Mobile platforms require MOBILE family', 400);
}

export function deviceView(device: {
  id: string;
  customerId: string;
  publicDeviceId: string;
  platform: QudraDevicePlatform;
  productFamily: QudraProductFamily;
  algorithm: QudraDeviceAlgorithm;
  publicKeyFingerprint: string;
  keyVersion: number;
  status: string;
  registeredAt: Date;
  displayName?: string | null;
}) {
  return {
    id: device.id,
    customerId: device.customerId,
    publicDeviceId: device.publicDeviceId,
    platform: device.platform,
    productFamily: device.productFamily,
    algorithm: device.algorithm,
    publicKeyFingerprint: device.publicKeyFingerprint,
    keyVersion: device.keyVersion,
    status: device.status,
    registeredAt: device.registeredAt.toISOString(),
    displayName: device.displayName ?? null,
  };
}

export type AnonymousDeviceRegistration = {
  publicDeviceId: string;
  platform: QudraDevicePlatform;
  productFamily: QudraProductFamily;
  algorithm: QudraDeviceAlgorithm;
  publicKey: string;
  appVersion?: string;
  androidApiLevel?: number;
  deviceModel?: string;
};

export function validateP256PublicKey(publicKey: string) {
  try {
    const key = createPublicKey(publicKey);
    const details = key.asymmetricKeyDetails as { namedCurve?: string } | undefined;
    if (key.asymmetricKeyType !== 'ec' || details?.namedCurve !== 'prime256v1')
      throw new Error('wrong curve');
  } catch {
    throw new QudraAuthorizationError('Valid P-256 public key required', 400);
  }
}

async function provisionAnonymousDevice(
  tx: Prisma.TransactionClient,
  input: AnonymousDeviceRegistration,
  publicKeyFingerprint: string,
) {
  const matches = await tx.qudraDevice.findMany({
    where: { algorithm: input.algorithm, publicKeyFingerprint },
  });
  const exactMatches = matches.filter((candidate) => candidate.publicKey === input.publicKey);
  if (matches.length > 0 && (matches.length !== 1 || exactMatches.length !== 1))
    throw new QudraAuthorizationError('Protected Device identity is ambiguous', 409);

  const existing = exactMatches[0];
  if (existing) {
    if (existing.status === 'REVOKED')
      throw new QudraAuthorizationError('Revoked Device cannot bootstrap', 409);
    if (existing.platform !== input.platform || existing.productFamily !== input.productFamily)
      throw new QudraAuthorizationError('Protected Device identity context mismatch', 409);
    // publicDeviceId is metadata only. A reinstall may present a new value.
    return tx.qudraDevice.update({
      where: { id: existing.id },
      data: {
        publicDeviceId: input.publicDeviceId,
        appVersion: input.appVersion,
        androidApiLevel: input.androidApiLevel,
        deviceModel: input.deviceModel,
      },
    });
  }

  const customer = await tx.qudraCustomer.create({ data: {} });
  const device = await tx.qudraDevice.create({
    data: {
      customerId: customer.id,
      publicDeviceId: input.publicDeviceId,
      platform: input.platform,
      productFamily: input.productFamily,
      algorithm: input.algorithm,
      publicKey: input.publicKey,
      publicKeyFingerprint,
      appVersion: input.appVersion,
      androidApiLevel: input.androidApiLevel,
      deviceModel: input.deviceModel,
      keys: {
        create: {
          version: 1,
          algorithm: input.algorithm,
          publicKey: input.publicKey,
          publicKeyFingerprint,
        },
      },
    },
  });
  await tx.qudraTrial.create({ data: { customerId: customer.id, deviceId: device.id } });
  await tx.qudraActiveSource.create({
    data: { customerId: customer.id, deviceId: device.id, kind: 'QUDRA_OPEN' },
  });
  return device;
}

export async function registerAnonymousDevice(input: AnonymousDeviceRegistration) {
  validatePlatformFamily(input.platform, input.productFamily);
  if (input.algorithm !== 'P256')
    throw new QudraAuthorizationError('Anonymous bootstrap requires P-256', 400);
  validateP256PublicKey(input.publicKey);
  const publicKeyFingerprint = fingerprintPublicKey(input.publicKey);
  return prisma.$transaction((tx) => provisionAnonymousDevice(tx, input, publicKeyFingerprint));
}

export { provisionAnonymousDevice };

export async function registerDevice(
  authority: QudraAuthority,
  input: {
    publicDeviceId: string;
    platform: QudraDevicePlatform;
    productFamily: QudraProductFamily;
    algorithm: QudraDeviceAlgorithm;
    publicKey: string;
    appVersion?: string;
    androidApiLevel?: number;
    deviceModel?: string;
  },
) {
  assertTestAuthorityAllowed(authority);
  if (authority.kind !== 'session' && authority.kind !== 'test')
    throw new QudraAuthorizationError('Session authority required for registration');
  validatePlatformFamily(input.platform, input.productFamily);
  return prisma.$transaction(async (tx) => {
    let customerId: string | undefined =
      authority.kind === 'test' ? authority.customerId : undefined;
    if (!customerId && authority.kind === 'session') {
      const account = await tx.qudraAccount.findFirst({ where: { userId: authority.userId } });
      if (account) customerId = account.customerId;
      if (!customerId) {
        const customer = await tx.qudraCustomer.create({ data: {} });
        customerId = customer.id;
        await tx.qudraAccount.create({
          data: {
            customerId,
            userId: authority.userId,
            provider: 'better-auth',
            externalIdentityRef: authority.userId,
          },
        });
      }
    }
    if (!customerId) throw new QudraAuthorizationError('Customer context required');
    const existing = await tx.qudraDevice.findFirst({
      where: { publicDeviceId: input.publicDeviceId },
    });
    if (existing) {
      if (existing.customerId !== customerId)
        throw new QudraAuthorizationError(
          'publicDeviceId already belongs to another Customer',
          409,
        );
      return existing;
    }
    const device = await tx.qudraDevice.create({
      data: {
        customerId,
        publicDeviceId: input.publicDeviceId,
        platform: input.platform,
        productFamily: input.productFamily,
        algorithm: input.algorithm,
        publicKey: input.publicKey,
        publicKeyFingerprint: fingerprintPublicKey(input.publicKey),
        appVersion: input.appVersion,
        androidApiLevel: input.androidApiLevel,
        deviceModel: input.deviceModel,
        keys: {
          create: {
            version: 1,
            algorithm: input.algorithm,
            publicKey: input.publicKey,
            publicKeyFingerprint: fingerprintPublicKey(input.publicKey),
          },
        },
      },
    });
    await tx.qudraTrial.create({ data: { customerId, deviceId: device.id } });
    await tx.qudraActiveSource.create({
      data: { customerId, deviceId: device.id, kind: 'QUDRA_OPEN' },
    });
    return device;
  });
}
