// @polsia:user-owned — device-scoped entitlement service and current pointer.
import 'server-only';

import { prisma } from '@/lib/db';
import {
  authorizeDevice,
  type QudraAuthority,
  QudraAuthorizationError,
  requireInternal,
  requireScope,
} from './authority';
import { ENTITLEMENT_GRACE_MS, entitlementIsUsable } from './domain';

export { ENTITLEMENT_GRACE_MS, entitlementIsUsable } from './domain';

export async function activateEntitlement(
  authority: QudraAuthority,
  input: {
    deviceId: string;
    kind: 'ANNUAL' | 'LIFETIME';
    provenance: 'DIRECT' | 'PARTNER';
    activationRef?: string;
    idempotencyKey?: string;
  },
) {
  requireInternal(authority, 'entitlement:write');
  const device = await prisma.qudraDevice.findUnique({ where: { id: input.deviceId } });
  if (!device) throw new QudraAuthorizationError('Device not found', 404);
  return prisma.$transaction(async (tx) => {
    // Serialize active-row replacement and current-pointer assignment per
    // Device; historical entitlements remain untouched.
    const lockedDevice = await tx.qudraDevice.update({
      where: { id: input.deviceId },
      data: { updatedAt: new Date() },
    });
    if (input.idempotencyKey) {
      const existing = await tx.qudraEntitlement.findFirst({
        where: { idempotencyKey: input.idempotencyKey },
      });
      if (existing) return existing;
    }
    await tx.qudraEntitlement.updateMany({
      where: { deviceId: lockedDevice.id, state: 'ACTIVE' },
      data: { state: 'REPLACED', entitlementVersion: { increment: 1 } },
    });
    const activatedAt = new Date();
    const expiresAt =
      input.kind === 'ANNUAL' ? new Date(activatedAt.getTime() + 365 * 24 * 60 * 60 * 1000) : null;
    const entitlement = await tx.qudraEntitlement.create({
      data: {
        customerId: lockedDevice.customerId,
        deviceId: lockedDevice.id,
        kind: input.kind,
        channel: input.provenance,
        provenance: input.provenance,
        state: 'ACTIVE',
        activatedAt,
        expiresAt,
        lastValidatedAt: activatedAt,
        graceUntil: new Date(activatedAt.getTime() + ENTITLEMENT_GRACE_MS),
        revalidationRequired: false,
        entitlementVersion: 1,
        activationRef: input.activationRef,
        idempotencyKey: input.idempotencyKey,
      },
    });
    await tx.qudraDeviceCurrentEntitlement.upsert({
      where: { deviceId: lockedDevice.id },
      update: { entitlementId: entitlement.id, assignedAt: activatedAt },
      create: { deviceId: lockedDevice.id, entitlementId: entitlement.id, assignedAt: activatedAt },
    });
    return entitlement;
  });
}

export async function transitionEntitlement(
  authority: QudraAuthority,
  entitlementId: string,
  state: 'EXPIRED' | 'SUSPENDED' | 'REVOKED' | 'REPLACED',
  reason: string,
) {
  requireInternal(authority, 'entitlement:write');
  return prisma.$transaction(async (tx) => {
    const current = await tx.qudraEntitlement.findUnique({ where: { id: entitlementId } });
    if (!current) throw new QudraAuthorizationError('Entitlement not found', 404);
    const updated = await tx.qudraEntitlement.update({
      where: { id: entitlementId },
      data: { state, entitlementVersion: { increment: 1 }, revalidationRequired: true },
    });
    await tx.qudraDeviceCurrentEntitlement.deleteMany({ where: { entitlementId } });
    return { entitlement: updated, reason };
  });
}

export async function currentEntitlement(
  authority: QudraAuthority,
  deviceId: string,
  now = new Date(),
) {
  if (authority.kind === 'internal') requireScope(authority, 'access:read');
  const device = await authorizeDevice(authority, deviceId);
  const pointer = await prisma.qudraDeviceCurrentEntitlement.findUnique({
    where: { deviceId },
    include: { entitlement: true },
  });
  if (
    !pointer ||
    pointer.entitlement.deviceId !== deviceId ||
    pointer.entitlement.customerId !== device.customerId ||
    !entitlementIsUsable(pointer.entitlement, now)
  )
    return null;
  return pointer.entitlement;
}
