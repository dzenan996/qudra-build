// @polsia:user-owned — server-time, exactly-one-Device access calculation.
import 'server-only';

import { prisma } from '@/lib/db';
import { authorizeDevice, type QudraAuthority, requireScope } from './authority';
import { entitlementIsUsable } from './entitlement';
import { trialIsActive } from './trial';

export async function effectiveAccess(
  authority: QudraAuthority,
  deviceId: string,
  now = new Date(),
) {
  if (authority.kind === 'internal') requireScope(authority, 'access:read');
  const device = await authorizeDevice(authority, deviceId);
  const [trial, pointer] = await Promise.all([
    prisma.qudraTrial.findFirst({ where: { deviceId } }),
    prisma.qudraDeviceCurrentEntitlement.findUnique({
      where: { deviceId },
      include: { entitlement: true },
    }),
  ]);
  const trialActive = trialIsActive(trial?.startedAt ?? null, trial?.endsAt ?? null, now);
  const entitlementActive =
    pointer?.entitlement.deviceId === device.id &&
    pointer.entitlement.customerId === device.customerId &&
    entitlementIsUsable(pointer.entitlement, now);
  return {
    deviceId: device.id,
    serverTime: now.toISOString(),
    qudraOpen: true as const,
    trialActive,
    entitlementActive,
    personalSourceAllowed: trialActive || entitlementActive,
    entitlementId: entitlementActive ? (pointer?.entitlementId ?? null) : null,
    entitlementState: pointer?.entitlement.state ?? null,
    entitlementKind: pointer?.entitlement.kind ?? null,
    graceUntil: pointer?.entitlement.graceUntil?.toISOString() ?? null,
  };
}
