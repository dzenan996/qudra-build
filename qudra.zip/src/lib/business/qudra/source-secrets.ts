// @polsia:user-owned — authenticated source-secret envelope boundary; it never accepts a plaintext source secret into storage.
// QUDRA OPEN stays available when this Personal Source provider is unavailable.
import 'server-only';

import { createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';
import { QudraAuthorizationError } from './authority';

const KEY_RING_ENV = 'QUDRA_SOURCE_ENVELOPE_KEY_RING';
const ACTIVE_VERSION_ENV = 'QUDRA_SOURCE_ENVELOPE_ACTIVE_KEY_VERSION';
const PROVIDER_ENV = 'QUDRA_SOURCE_ENVELOPE_PROVIDER';
const DEFAULT_PROVIDER = 'aes-256-gcm-env';
const KEY_REFERENCE = `env:${KEY_RING_ENV}`;

export type SealedSourceSecret = { ciphertext: string; keyReference: string; keyVersion: number };
type KeyRing = Record<string, string>;

export type SourceSecretEnvelopeProvider = {
  readonly provider: string;
  readonly activeKeyVersion: number;
  seal(plaintext: string): SealedSourceSecret;
  open(value: SealedSourceSecret): string;
};

function decodeKey(value: string): Buffer | null {
  try {
    const key = Buffer.from(value, 'base64url');
    return key.length === 32 ? key : null;
  } catch {
    return null;
  }
}

function readKeyRing(): { keys: Map<number, Buffer>; activeVersion: number } {
  const raw = process.env[KEY_RING_ENV];
  const activeVersion = Number(process.env[ACTIVE_VERSION_ENV]);
  if (!raw || !Number.isInteger(activeVersion) || activeVersion < 1)
    throw new QudraAuthorizationError('Source secret provider is unavailable', 503);
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new QudraAuthorizationError('Source secret provider is unavailable', 503);
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed))
    throw new QudraAuthorizationError('Source secret provider is unavailable', 503);
  const keys = new Map<number, Buffer>();
  for (const [version, encoded] of Object.entries(parsed as KeyRing)) {
    const numericVersion = Number(version);
    if (!Number.isInteger(numericVersion) || numericVersion < 1 || typeof encoded !== 'string')
      continue;
    const key = decodeKey(encoded);
    if (key) keys.set(numericVersion, key);
  }
  if (!keys.has(activeVersion))
    throw new QudraAuthorizationError('Source secret provider is unavailable', 503);
  return { keys, activeVersion };
}

function providerName() {
  const configured = process.env[PROVIDER_ENV]?.trim();
  if (!configured && process.env.NODE_ENV === 'production')
    throw new QudraAuthorizationError('Source secret provider is unavailable', 503);
  const provider = configured || DEFAULT_PROVIDER;
  if (provider !== DEFAULT_PROVIDER)
    throw new QudraAuthorizationError('Source secret provider is unavailable', 503);
  return provider;
}

export function getSourceSecretEnvelopeProvider(): SourceSecretEnvelopeProvider {
  const provider = providerName();
  const config = readKeyRing();
  return {
    provider,
    activeKeyVersion: config.activeVersion,
    seal(plaintext) {
      if (!plaintext || plaintext.length > 4096)
        throw new QudraAuthorizationError('Source secret is invalid', 400);
      const key = config.keys.get(config.activeVersion);
      if (!key) throw new QudraAuthorizationError('Source secret provider is unavailable', 503);
      const iv = randomBytes(12);
      const cipher = createCipheriv('aes-256-gcm', key, iv);
      const ciphertext = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
      const tag = cipher.getAuthTag();
      return {
        ciphertext: [iv, tag, ciphertext].map((part) => part.toString('base64url')).join('.'),
        keyReference: KEY_REFERENCE,
        keyVersion: config.activeVersion,
      };
    },
    open(value) {
      if (value.keyReference !== KEY_REFERENCE)
        throw new QudraAuthorizationError('Source secret provider is unavailable', 503);
      const key = config.keys.get(value.keyVersion);
      if (!key) throw new QudraAuthorizationError('Source secret key version is unavailable', 503);
      const [ivEncoded, tagEncoded, ciphertextEncoded] = value.ciphertext.split('.');
      if (!ivEncoded || !tagEncoded || !ciphertextEncoded)
        throw new QudraAuthorizationError('Source secret is invalid', 400);
      try {
        const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(ivEncoded, 'base64url'));
        decipher.setAuthTag(Buffer.from(tagEncoded, 'base64url'));
        return Buffer.concat([
          decipher.update(Buffer.from(ciphertextEncoded, 'base64url')),
          decipher.final(),
        ]).toString('utf8');
      } catch {
        throw new QudraAuthorizationError('Source secret could not be opened', 503);
      }
    },
  };
}

export function sourceEnvelopeConfigured(): boolean {
  try {
    getSourceSecretEnvelopeProvider();
    return true;
  } catch {
    return false;
  }
}

/** Seal a credential-bearing source secret. Plaintext never leaves this function. */
export function sealSourceSecret(plaintext: string): SealedSourceSecret {
  return getSourceSecretEnvelopeProvider().seal(plaintext);
}

/** Decrypt only inside a future server-side source connector; never return this from an API. */
export function openSourceSecret(value: SealedSourceSecret): string {
  return getSourceSecretEnvelopeProvider().open(value);
}

// Compatibility guard for old internal callers. Clients may not submit ciphertext.
export function validateEnvelopeSecret(value: SealedSourceSecret): SealedSourceSecret {
  if (
    !value.ciphertext ||
    value.keyReference !== KEY_REFERENCE ||
    !Number.isInteger(value.keyVersion) ||
    value.keyVersion < 1
  )
    throw new QudraAuthorizationError('Approved envelope metadata is required', 400);
  return value;
}

export function redactEnvelopeSecret(value: {
  secretCiphertext: string | null;
  secretKeyReference: string | null;
  secretKeyVersion: number | null;
}) {
  return {
    hasSecret: Boolean(value.secretCiphertext),
    keyReference: value.secretKeyReference,
    keyVersion: value.secretKeyVersion,
    redacted: true as const,
  };
}
