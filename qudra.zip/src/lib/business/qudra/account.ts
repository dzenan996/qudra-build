// @polsia:user-owned — optional Better Auth account summary and safe claim flow.
import 'server-only';

import { prisma } from '@/lib/db';
import { effectiveAccess } from './access';
import { customerIdForAuthority, type QudraAuthority, QudraAuthorizationError } from './authority';
import { deviceView } from './device-identity';
import { getActiveSource, listSources, redactSource } from './sources';
import { listSync } from './sync';

export async function myQudraSummary(authority: Extract<QudraAuthority, { kind: 'session' }>) {
  const account = await prisma.qudraAccount.findFirst({ where: { userId: authority.userId } });
  if (!account)
    return {
      authenticated: true as const,
      optionalAccount: true as const,
      account: null,
      devices: [],
    };
  const devices = await prisma.qudraDevice.findMany({
    where: { customerId: account.customerId },
    orderBy: { createdAt: 'asc' },
  });
  const summaries = await Promise.all(
    devices.map(async (device) => {
      const [access, sources, active, sync] = await Promise.all([
        effectiveAccess(authority, device.id),
        listSources(authority, device.id),
        getActiveSource(authority, device.id),
        listSync(authority, device.id),
      ]);
      return {
        ...deviceView(device),
        displayName: device.displayName ?? null,
        access,
        sources: sources.map(redactSource),
        activeSource: {
          deviceId: device.id,
          kind: active.kind,
          sourceConfigId: active.activeSourceConfigId,
        },
        sync,
        partnerMetadata: null,
      };
    }),
  );
  return {
    authenticated: true as const,
    optionalAccount: false as const,
    account: { id: account.id, customerId: account.customerId, provider: account.provider },
    devices: summaries,
  };
}

export async function customerForSession(authority: Extract<QudraAuthority, { kind: 'session' }>) {
  return customerIdForAuthority(authority);
}

export async function updateDeviceMetadata(
  authority: QudraAuthority,
  deviceId: string,
  displayName: string | null,
) {
  const customerId = await customerIdForAuthority(authority);
  const device = await prisma.qudraDevice.findFirst({
    where: { id: deviceId, customerId: customerId ?? undefined },
  });
  if (!device) throw new QudraAuthorizationError('Device not found', 404);
  return prisma.qudraDevice.update({ where: { id: deviceId }, data: { displayName } });
}
