// @polsia:user-owned — server-only QUDRA OPEN fixture read boundary.
import 'server-only';

import type { QudraOpenManifest } from '@/lib/contracts/qudra-open';
import fixture from '../../../../specs/qudra/v1/fixtures/qudra-open-manifest.json';
import { parseQudraOpenManifest } from './open';

export function getQudraOpenManifest(): QudraOpenManifest {
  return parseQudraOpenManifest(fixture);
}
