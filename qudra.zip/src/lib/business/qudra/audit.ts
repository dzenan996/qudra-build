// @polsia:user-owned — allowlisted, redacted, append-only audit foundation.
import 'server-only';

import type { Prisma } from '@prisma/client';
import { prisma } from '@/lib/db';
import {
  authorizeDevice,
  type QudraAuthority,
  requireInternal,
  requireScope,
  safeMetadata,
} from './authority';
import { AUDIT_ACTIONS } from './domain';

export { AUDIT_ACTIONS } from './domain';

export async function appendAudit(
  authority: QudraAuthority,
  input: {
    customerId: string;
    deviceId?: string | null;
    actorType: 'DEVICE' | 'CUSTOMER' | 'PARTNER' | 'SUPER_ADMIN' | 'INTERNAL_SERVICE';
    actorId?: string | null;
    action: string;
    entityType: string;
    entityId: string;
    correlationId: string;
    metadata: Record<string, unknown>;
    occurredAt: Date;
  },
) {
  const internal = requireInternal(authority, 'audit:append');
  if (!AUDIT_ACTIONS.has(input.action)) throw new Error('Audit action is not allowlisted');
  const device = input.deviceId ? await authorizeDevice(internal, input.deviceId) : null;
  if (device && device.customerId !== input.customerId)
    throw new Error('Audit customer/device mismatch');
  return prisma.qudraAuditEvent.create({
    data: {
      customerId: device?.customerId ?? input.customerId,
      deviceId: device?.id ?? null,
      actorType: 'INTERNAL_SERVICE',
      actorId: internal.kind === 'internal' ? internal.serviceId : 'test-super-admin',
      action: input.action,
      entityType: input.entityType,
      entityId: input.entityId,
      correlationId: input.correlationId,
      eventType: input.action,
      metadata: safeMetadata(input.metadata) as Prisma.InputJsonObject,
      occurredAt: input.occurredAt,
    },
  });
}

export async function readAudit(authority: QudraAuthority, deviceId: string) {
  if (authority.kind === 'internal') requireScope(authority, 'audit:read');
  await authorizeDevice(authority, deviceId);
  return prisma.qudraAuditEvent.findMany({
    where: { deviceId },
    orderBy: { occurredAt: 'desc' },
    take: 100,
  });
}
