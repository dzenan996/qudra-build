// @polsia:user-owned — device-scoped server-authoritative trial service.
import 'server-only';

import { prisma } from '@/lib/db';
import type { QudraAuthority } from './authority';
import {
  authorizeDevice,
  QudraAuthorizationError,
  requireScope,
  requireSuperAdmin,
} from './authority';
import { trialEndsAt, trialIsActive } from './domain';

export { TRIAL_DURATION_MS, trialEndsAt, trialIsActive } from './domain';

export async function startTrial(authority: QudraAuthority, deviceId: string) {
  if (authority.kind === 'internal') requireScope(authority, 'trial:write');
  const device = await authorizeDevice(authority, deviceId);
  return prisma.$transaction(async (tx) => {
    // Serialize the one-trial check until the staged Device trial constraint
    // is approved for the populated table.
    await tx.qudraDevice.update({ where: { id: deviceId }, data: { updatedAt: new Date() } });
    const existing = await tx.qudraTrial.findFirst({ where: { deviceId } });
    if (existing?.startedAt && existing.endsAt) return existing;
    const startedAt = new Date();
    const endsAt = trialEndsAt(startedAt);
    if (existing)
      return tx.qudraTrial.update({
        where: { id: existing.id },
        data: { startedAt, endsAt, state: 'ACTIVE' },
      });
    return tx.qudraTrial.create({
      data: { customerId: device.customerId, deviceId, startedAt, endsAt, state: 'ACTIVE' },
    });
  });
}

export async function effectiveTrial(
  authority: QudraAuthority,
  deviceId: string,
  now = new Date(),
) {
  if (authority.kind === 'internal') requireScope(authority, 'access:read');
  const device = await authorizeDevice(authority, deviceId);
  const trial = await prisma.qudraTrial.findFirst({ where: { deviceId: device.id } });
  if (!trial) throw new QudraAuthorizationError('Trial not initialized', 404);
  const active = trialIsActive(trial.startedAt, trial.endsAt, now);
  if (trial.state === 'ACTIVE' && !active)
    await prisma.qudraTrial.update({ where: { id: trial.id }, data: { state: 'EXPIRED' } });
  return {
    ...trial,
    state: active
      ? ('ACTIVE' as const)
      : trial.startedAt
        ? ('EXPIRED' as const)
        : ('NOT_STARTED' as const),
    active,
  };
}

export async function requestTrialException(
  authority: QudraAuthority,
  deviceId: string,
  reason: string,
) {
  const device = await authorizeDevice(authority, deviceId);
  if (authority.kind === 'device')
    throw new QudraAuthorizationError('Device proof cannot request a support exception');
  return prisma.qudraTrialExceptionRequest.create({
    data: {
      customerId: device.customerId,
      deviceId,
      requestedBy: authority.kind === 'session' ? authority.userId : authority.kind,
      reason,
    },
  });
}

export async function decideTrialException(
  authority: QudraAuthority,
  requestId: string,
  decision: 'APPROVED' | 'REJECTED' | 'CANCELLED',
  reason: string,
) {
  requireSuperAdmin(authority);
  return prisma.$transaction(async (tx) => {
    const request = await tx.qudraTrialExceptionRequest.findUnique({ where: { id: requestId } });
    if (!request) throw new QudraAuthorizationError('Trial exception not found', 404);
    if (request.status !== 'PENDING')
      throw new QudraAuthorizationError('Trial exception is already decided', 409);
    const updated = await tx.qudraTrialExceptionRequest.update({
      where: { id: requestId },
      data: {
        status: decision,
        decidedAt: new Date(),
        decidedBy: authority.kind === 'session' ? authority.userId : authority.kind,
        decisionReason: reason,
      },
    });
    if (decision === 'APPROVED') {
      const startedAt = new Date();
      await tx.qudraTrial.upsert({
        where: {
          id:
            (
              await tx.qudraTrial.findFirst({
                where: { deviceId: request.deviceId },
                select: { id: true },
              })
            )?.id ?? '',
        },
        update: { startedAt, endsAt: trialEndsAt(startedAt), state: 'ACTIVE' },
        create: {
          customerId: request.customerId,
          deviceId: request.deviceId,
          startedAt,
          endsAt: trialEndsAt(startedAt),
          state: 'ACTIVE',
        },
      });
    }
    return updated;
  });
}
