// @polsia:user-owned
import 'server-only';

import { prisma } from '@/lib/db';
import { appendTrustedAudit, safeAuditEvent } from './audit-t7';
import { QudraAuthorizationError } from './authority';
import { requireSuperAdminApi } from './partner';
import { applyPartnerCreditOperation } from './partner-credits';

export async function listPartners() {
  await requireSuperAdminApi();
  const partners = await prisma.qudraPartner.findMany({
    include: { _count: { select: { memberships: true } } },
    orderBy: { createdAt: 'desc' },
  });
  return partners.map((partner) => ({
    id: partner.id,
    displayName: partner.displayName,
    status: partner.status,
    createdAt: partner.createdAt.toISOString(),
    updatedAt: partner.updatedAt.toISOString(),
    activeMemberships: partner._count.memberships,
  }));
}

export async function createPartner(displayName: string) {
  const actor = await requireSuperAdminApi();
  return prisma.$transaction(async (tx) => {
    const partner = await tx.qudraPartner.create({
      data: {
        displayName,
        createdBy: actor.id,
        policy: { create: { updatedBy: actor.id } },
        credits: { create: {} },
        branding: { create: {} },
      },
    });
    await appendTrustedAudit(tx, {
      action: 'partner.created',
      actorId: actor.id,
      actorType: 'SUPER_ADMIN',
      partnerId: partner.id,
      entityType: 'QudraPartner',
      entityId: partner.id,
      correlationId: partner.id,
      metadata: { displayName },
    });
    return partner;
  });
}

export async function updatePartnerStatus(
  partnerId: string,
  status: 'ACTIVE' | 'SUSPENDED' | 'REVOKED',
) {
  const actor = await requireSuperAdminApi();
  return prisma.$transaction(async (tx) => {
    const partner = await tx.qudraPartner.findUnique({ where: { id: partnerId } });
    if (!partner) throw new QudraAuthorizationError('Partner not found', 404);
    const updated = await tx.qudraPartner.update({
      where: { id: partnerId },
      data: {
        status,
        suspendedAt: status === 'SUSPENDED' ? new Date() : null,
        revokedAt: status === 'REVOKED' ? new Date() : null,
      },
    });
    await appendTrustedAudit(tx, {
      action: status === 'SUSPENDED' ? 'partner.suspended' : 'partner.updated',
      actorId: actor.id,
      actorType: 'SUPER_ADMIN',
      partnerId,
      entityType: 'QudraPartner',
      entityId: partnerId,
      correlationId: partnerId,
      metadata: { status },
    });
    return updated;
  });
}

export async function managePartnerMember(
  partnerId: string,
  input: { userId: string; role: 'ADMIN' | 'OPERATOR'; active: boolean },
) {
  const actor = await requireSuperAdminApi();
  if (input.userId === actor.id)
    throw new QudraAuthorizationError('Super Admin cannot be created as Partner membership', 403);
  const partner = await prisma.qudraPartner.findUnique({ where: { id: partnerId } });
  if (!partner) throw new QudraAuthorizationError('Partner not found', 404);
  const target = await prisma.user.findUnique({
    where: { id: input.userId },
    select: { id: true, role: true },
  });
  if (!target) throw new QudraAuthorizationError('User not found', 404);
  if (target.role === 'admin')
    throw new QudraAuthorizationError('Super Admin cannot become Partner membership', 403);
  return prisma.qudraPartnerMembership.upsert({
    where: { partnerId_userId: { partnerId, userId: input.userId } },
    update: { role: input.role, active: input.active },
    create: { partnerId, userId: input.userId, role: input.role, active: input.active },
  });
}

export async function listPartnerMembers(partnerId: string) {
  await requireSuperAdminApi();
  return prisma.qudraPartnerMembership.findMany({
    where: { partnerId },
    orderBy: { createdAt: 'asc' },
  });
}

export async function listPartnerScopes(partnerId: string) {
  await requireSuperAdminApi();
  return prisma.qudraPartnerCustomerScope.findMany({
    where: { partnerId },
    orderBy: { createdAt: 'asc' },
  });
}

export async function managePartnerScope(partnerId: string, customerId: string, active: boolean) {
  const actor = await requireSuperAdminApi();
  const [partner, customer] = await Promise.all([
    prisma.qudraPartner.findUnique({ where: { id: partnerId }, select: { id: true } }),
    prisma.qudraCustomer.findUnique({ where: { id: customerId }, select: { id: true } }),
  ]);
  if (!partner) throw new QudraAuthorizationError('Partner not found', 404);
  if (!customer) throw new QudraAuthorizationError('Customer not found', 404);
  return prisma.$transaction(async (tx) => {
    const scope = await tx.qudraPartnerCustomerScope.upsert({
      where: { partnerId_customerId: { partnerId, customerId } },
      update: { status: active ? 'ACTIVE' : 'INACTIVE' },
      create: {
        partnerId,
        customerId,
        status: active ? 'ACTIVE' : 'INACTIVE',
        createdBy: actor.id,
      },
    });
    await appendTrustedAudit(tx, {
      action: 'partner.updated',
      actorId: actor.id,
      actorType: 'SUPER_ADMIN',
      partnerId,
      customerId,
      entityType: 'QudraPartnerCustomerScope',
      entityId: scope.id,
      correlationId: scope.id,
      metadata: { active },
    });
    return scope;
  });
}

export async function adminCreditOperation(
  partnerId: string,
  input: {
    delta: number;
    kind: 'GRANT' | 'ADJUSTMENT' | 'REVERSAL';
    operationKey: string;
    reference?: string;
  },
) {
  const actor = await requireSuperAdminApi();
  if (input.kind === 'GRANT' && input.delta <= 0)
    throw new QudraAuthorizationError('Grant must add credits', 400);
  return applyPartnerCreditOperation({ ...input, partnerId, actorId: actor.id });
}

export async function adminBrandingDecision(
  partnerId: string,
  decision: 'APPROVED' | 'REJECTED',
  reason?: string,
) {
  const actor = await requireSuperAdminApi();
  const { decidePartnerBranding } = await import('./partner-branding');
  return decidePartnerBranding(partnerId, actor.id, decision, reason);
}

export async function adminCustomers() {
  await requireSuperAdminApi();
  const rows = await prisma.qudraCustomer.findMany({
    include: { _count: { select: { devices: true } } },
    orderBy: { createdAt: 'desc' },
    take: 100,
  });
  return rows.map((row) => ({
    id: row.id,
    status: row.status,
    createdAt: row.createdAt.toISOString(),
    deviceCount: row._count.devices,
  }));
}

export async function adminDevices() {
  await requireSuperAdminApi();
  const rows = await prisma.qudraDevice.findMany({
    select: {
      id: true,
      customerId: true,
      productFamily: true,
      platform: true,
      status: true,
      displayName: true,
    },
    orderBy: { createdAt: 'desc' },
    take: 100,
  });
  return rows;
}

export async function adminEntitlements() {
  await requireSuperAdminApi();
  return prisma.qudraEntitlement.findMany({
    select: {
      id: true,
      customerId: true,
      deviceId: true,
      kind: true,
      state: true,
      provenance: true,
      activatedAt: true,
      expiresAt: true,
    },
    orderBy: { createdAt: 'desc' },
    take: 100,
  });
}

export async function adminDiagnostics() {
  await requireSuperAdminApi();
  const [customerCount, deviceCount, activeEntitlementCount, partnerCount] = await Promise.all([
    prisma.qudraCustomer.count(),
    prisma.qudraDevice.count(),
    prisma.qudraEntitlement.count({ where: { state: 'ACTIVE' } }),
    prisma.qudraPartner.count(),
  ]);
  return {
    customerCount,
    deviceCount,
    activeEntitlementCount,
    partnerCount,
    timestamp: new Date().toISOString(),
  };
}

export async function adminAuditEvents() {
  await requireSuperAdminApi();
  const events = await prisma.qudraTrustedAuditEvent.findMany({
    orderBy: { occurredAt: 'desc' },
    take: 100,
  });
  return events.map(safeAuditEvent);
}

export async function adminPartnerDetail(partnerId: string) {
  await requireSuperAdminApi();
  const partner = await prisma.qudraPartner.findUnique({
    where: { id: partnerId },
    include: {
      _count: { select: { memberships: true, scopes: true } },
      policy: true,
      branding: true,
    },
  });
  if (!partner) throw new QudraAuthorizationError('Partner not found', 404);
  const account = await prisma.qudraPartnerCreditAccount.upsert({
    where: { partnerId },
    update: {},
    create: { partnerId },
  });
  return {
    partner: {
      id: partner.id,
      displayName: partner.displayName,
      status: partner.status,
      createdAt: partner.createdAt.toISOString(),
      updatedAt: partner.updatedAt.toISOString(),
      activeMemberships: partner._count.memberships,
    },
    policy: partner.policy,
    scopeCount: partner._count.scopes,
    balance: { partnerId, balance: account.balance, version: account.version },
    branding: partner.branding,
  };
}
