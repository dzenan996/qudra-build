// @polsia:user-owned — metadata-only refresh state machine.
import 'server-only';

import { prisma } from '@/lib/db';
import {
  authorizeDevice,
  type QudraAuthority,
  QudraAuthorizationError,
  requireScope,
} from './authority';

export type SyncReportInput = {
  sourceConfigId?: string;
  configVersion: number;
  state: 'IDLE' | 'REQUESTED' | 'SYNCING' | 'FRESH' | 'STALE' | 'FAILED' | 'UNAVAILABLE';
  format?: 'M3U' | 'M3U8' | 'XMLTV';
  lastAttemptAt?: Date;
  lastSuccessAt?: Date;
  staleSince?: Date;
  failureCode?: string;
  lastKnownGoodGeneration?: string;
  counts?: {
    live: number;
    movies: number;
    series: number;
    radio: number;
    epgChannels: number;
    epgProgrammes: number;
  };
  timezone?: string;
  utcOffsetMinutes?: number;
  capabilities?: {
    epg: 'UNKNOWN' | 'SUPPORTED' | 'UNSUPPORTED';
    catchUp: 'UNKNOWN' | 'SUPPORTED' | 'UNSUPPORTED';
    timeshift: 'UNKNOWN' | 'SUPPORTED' | 'UNSUPPORTED';
  };
  idempotencyKey?: string;
};

function serialize(row: {
  id: string;
  deviceId: string;
  sourceConfigId: string | null;
  configVersion: number;
  state: string;
  format: string | null;
  lastAttemptAt: Date | null;
  lastSuccessAt: Date | null;
  staleSince: Date | null;
  failureCode: string | null;
  lastKnownGoodGeneration: string | null;
  liveCount: number;
  movieCount: number;
  seriesCount: number;
  radioCount: number;
  epgChannelCount: number;
  epgProgrammeCount: number;
  sourceTimezone: string | null;
  utcOffsetMinutes: number | null;
  epgState: string;
  catchUpState: string;
  timeshiftState: string;
}) {
  return {
    id: row.id,
    deviceId: row.deviceId,
    sourceConfigId: row.sourceConfigId,
    configVersion: row.configVersion,
    state: row.state,
    format: row.format,
    lastAttemptAt: row.lastAttemptAt?.toISOString() ?? null,
    lastSuccessAt: row.lastSuccessAt?.toISOString() ?? null,
    staleSince: row.staleSince?.toISOString() ?? null,
    failureCode: row.failureCode,
    lastKnownGoodGeneration: row.lastKnownGoodGeneration,
    counts: {
      live: row.liveCount,
      movies: row.movieCount,
      series: row.seriesCount,
      radio: row.radioCount,
      epgChannels: row.epgChannelCount,
      epgProgrammes: row.epgProgrammeCount,
    },
    timezone: row.sourceTimezone,
    utcOffsetMinutes: row.utcOffsetMinutes,
    capabilities: { epg: row.epgState, catchUp: row.catchUpState, timeshift: row.timeshiftState },
  };
}

export { serialize as syncView };

export async function listSync(
  authority: QudraAuthority,
  deviceId: string,
  sourceConfigId?: string,
) {
  if (authority.kind === 'internal') requireScope(authority, 'source:read');
  const device = await authorizeDevice(authority, deviceId);
  return (
    await prisma.qudraSourceSync.findMany({
      where: {
        deviceId,
        customerId: device.customerId,
        ...(sourceConfigId ? { sourceConfigId } : {}),
      },
      orderBy: { updatedAt: 'desc' },
    })
  ).map(serialize);
}

export async function reportSync(
  authority: QudraAuthority,
  deviceId: string,
  input: SyncReportInput,
) {
  if (authority.kind === 'internal') requireScope(authority, 'source:write');
  const device = await authorizeDevice(authority, deviceId);
  if (input.sourceConfigId) {
    const source = await prisma.qudraSourceConfig.findFirst({
      where: { id: input.sourceConfigId, deviceId, customerId: device.customerId },
    });
    if (!source) throw new QudraAuthorizationError('Source not found', 404);
    if (source.configVersion !== input.configVersion)
      throw new QudraAuthorizationError('Sync report is for a stale source configuration', 409);
  }
  const existing = await prisma.qudraSourceSync.findFirst({
    where: { deviceId, sourceConfigId: input.sourceConfigId ?? null },
  });
  const data = {
    configVersion: input.configVersion,
    state: input.state,
    format: input.format,
    lastAttemptAt: input.lastAttemptAt,
    lastSuccessAt: input.lastSuccessAt,
    staleSince: input.staleSince,
    failureCode: input.failureCode,
    ...(input.state === 'FAILED' || input.state === 'UNAVAILABLE'
      ? {}
      : { lastKnownGoodGeneration: input.lastKnownGoodGeneration }),
    liveCount: input.counts?.live,
    movieCount: input.counts?.movies,
    seriesCount: input.counts?.series,
    radioCount: input.counts?.radio,
    epgChannelCount: input.counts?.epgChannels,
    epgProgrammeCount: input.counts?.epgProgrammes,
    sourceTimezone: input.timezone,
    utcOffsetMinutes: input.utcOffsetMinutes,
    epgState: input.capabilities?.epg,
    catchUpState: input.capabilities?.catchUp,
    timeshiftState: input.capabilities?.timeshift,
  };
  const row = existing
    ? await prisma.qudraSourceSync.update({ where: { id: existing.id }, data })
    : await prisma.qudraSourceSync.create({
        data: {
          customerId: device.customerId,
          deviceId,
          sourceConfigId: input.sourceConfigId,
          ...data,
        },
      });
  return serialize(row);
}

export async function requestSync(
  authority: QudraAuthority,
  deviceId: string,
  sourceConfigId: string,
  configVersion: number,
  idempotencyKey?: string,
) {
  return reportSync(authority, deviceId, {
    sourceConfigId,
    configVersion,
    state: 'REQUESTED',
    lastAttemptAt: new Date(),
    idempotencyKey,
  });
}
