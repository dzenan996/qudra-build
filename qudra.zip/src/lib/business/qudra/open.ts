// @polsia:user-owned — pure QUDRA OPEN parsing and playback selection.
import {
  type QudraOpenDirectOrigin,
  QudraOpenManifest,
  type QudraOpenManifest as QudraOpenManifestType,
  type QudraOpenResolution,
} from '@/lib/contracts/qudra-open';

export function parseQudraOpenManifest(value: unknown): QudraOpenManifestType {
  return QudraOpenManifest.parse(value);
}

export type QudraOpenPlaybackResolution =
  | {
      status: 'AVAILABLE';
      resolution: 'DIRECT' | 'REPLACEMENT' | 'FALLBACK';
      sourceId: string;
      directOrigin: QudraOpenDirectOrigin;
    }
  | { status: 'UNAVAILABLE'; resolution: 'UNAVAILABLE'; sourceId: string; reason: string };

function allSources(manifest: QudraOpenManifestType) {
  const sources = [
    ...manifest.sourceRegister,
    ...manifest.testOnly.liveTv,
    ...manifest.testOnly.radio,
  ];
  for (const series of manifest.series) sources.push(...series.episodes);
  return sources;
}

export function resolveQudraOpenPlayback(
  manifest: QudraOpenManifestType,
  sourceId: string,
): QudraOpenPlaybackResolution {
  const sources = new Map(allSources(manifest).map((source) => [source.sourceId, source]));
  const visited = new Set<string>();

  function resolve(
    currentId: string,
    resolution: Exclude<QudraOpenResolution, 'UNAVAILABLE'>,
  ): QudraOpenPlaybackResolution {
    if (visited.has(currentId))
      return {
        status: 'UNAVAILABLE',
        resolution: 'UNAVAILABLE',
        sourceId: currentId,
        reason: 'Selection cycle detected.',
      };
    visited.add(currentId);
    const source = sources.get(currentId);
    if (!source)
      return {
        status: 'UNAVAILABLE',
        resolution: 'UNAVAILABLE',
        sourceId: currentId,
        reason: 'Source is not registered.',
      };

    const preferredOrigin =
      source.originState.preferredOrigin === source.directOrigin?.url ? source.directOrigin : null;
    if (
      source.availability.status === 'AVAILABLE' &&
      preferredOrigin &&
      source.sourceHealth.status === 'HEALTHY'
    )
      return {
        status: 'AVAILABLE',
        resolution,
        sourceId: source.sourceId,
        directOrigin: preferredOrigin,
      };

    if (source.availability.status === 'AVAILABLE' && source.originState.fallbackOrigin)
      return {
        status: 'AVAILABLE',
        resolution: 'FALLBACK',
        sourceId: source.sourceId,
        directOrigin: source.originState.fallbackOrigin,
      };

    if (source.replacement) return resolve(source.replacement.sourceId, 'REPLACEMENT');
    if (source.fallback?.sourceId) return resolve(source.fallback.sourceId, 'FALLBACK');
    return {
      status: 'UNAVAILABLE',
      resolution: 'UNAVAILABLE',
      sourceId: source.sourceId,
      reason:
        source.originState.unavailableReason ??
        source.availability.reason ??
        'Source is unavailable and has no configured fallback.',
    };
  }

  return resolve(sourceId, 'DIRECT');
}
