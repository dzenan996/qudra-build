// @polsia:user-owned — bounded, single-use, Device-bound pairing service.
import 'server-only';

import { createHash, randomBytes } from 'node:crypto';
import type { Prisma, QudraDevice } from '@prisma/client';
import { prisma } from '@/lib/db';
import {
  assertTestAuthorityAllowed,
  authorizeDevice,
  bootstrapProofPayload,
  constantTimeStringEqual,
  fingerprintPublicKey,
  type QudraAuthority,
  QudraAuthorizationError,
  requireScope,
  verifyDeviceSignature,
} from './authority';
import {
  type AnonymousDeviceRegistration,
  provisionAnonymousDevice,
  validateP256PublicKey,
  validatePlatformFamily,
} from './device-identity';
import { issueDeviceSessionRecord } from './device-session';
import { redactMetadata } from './redaction';

export const PAIRING_LIFETIME_MS = 10 * 60 * 1000;
export const PAIRING_MAX_ATTEMPTS = 5;
const HOUR_MS = 60 * 60 * 1000;
const digest = (value: string) => createHash('sha256').update(value).digest('hex');
const sourceDigest = (value: string) => digest(value).slice(0, 64);

export const BOOTSTRAP_RATE_LIMIT_PER_HOUR = 5;

function limit(name: string, fallback: number) {
  const value = Number(process.env[name]);
  return Number.isInteger(value) && value > 0 ? value : fallback;
}

function requireDeviceProof(authority: QudraAuthority, deviceId: string) {
  assertTestAuthorityAllowed(authority);
  if (authority.kind === 'device' && authority.deviceId === deviceId) return;
  if (authority.kind === 'test' && authority.deviceId === deviceId) return;
  throw new QudraAuthorizationError('Registered Device proof required');
}

function requireClaimAuthority(authority: QudraAuthority) {
  assertTestAuthorityAllowed(authority);
  if (authority.kind === 'session') return;
  if (authority.kind === 'test' && authority.customerId) return;
  throw new QudraAuthorizationError('My Qudra claim authority required');
}

async function appendPairingAudit(
  tx: Prisma.TransactionClient,
  challenge: { customerId: string; deviceId: string },
  action: string,
  metadata: Record<string, unknown>,
  actor: { type: string; id: string } = { type: 'INTERNAL_SERVICE', id: 'pairing-service' },
) {
  return tx.qudraAuditEvent.create({
    data: {
      customerId: challenge.customerId,
      deviceId: challenge.deviceId,
      actorType: actor.type,
      actorId: actor.id,
      action,
      eventType: action,
      entityType: 'QudraPairingChallenge',
      entityId: challenge.deviceId,
      correlationId: `pairing:${challenge.deviceId}`,
      metadata: redactMetadata(metadata) as Prisma.InputJsonObject,
      occurredAt: new Date(),
    },
  });
}

async function consumeRateWindow(
  tx: Prisma.TransactionClient,
  scopeKey: string,
  deviceId: string | null,
  requestSourceHash: string | null,
  maxRequests: number,
  now: Date,
) {
  const windowStartedAt = new Date(Math.floor(now.getTime() / HOUR_MS) * HOUR_MS);
  const window = await tx.qudraPairingRateWindow.upsert({
    where: { scopeKey_windowStartedAt: { scopeKey, windowStartedAt } },
    create: { scopeKey, deviceId, requestSourceHash, windowStartedAt, requestCount: 1 },
    update: { requestCount: { increment: 1 } },
  });
  if (window.requestCount > maxRequests) return false;
  return true;
}

export async function createPairingChallenge(
  authority: QudraAuthority,
  deviceId: string,
  idempotencyKey?: string,
  requestSource?: string,
) {
  requireDeviceProof(authority, deviceId);
  const device = await authorizeDevice(authority, deviceId);
  const sourceHash = requestSource ? sourceDigest(requestSource) : null;

  const result = await prisma.$transaction(async (tx) => {
    const now = new Date();
    // Lock the Device row so concurrent requests rotate rather than create
    // multiple pending challenges for the same Device.
    await tx.qudraDevice.update({ where: { id: deviceId }, data: { lastChallengeAt: now } });
    if (idempotencyKey) {
      const prior = await tx.qudraPairingChallenge.findFirst({
        where: { deviceId, idempotencyKey },
      });
      if (prior) return { challenge: prior, token: '' };
    }
    const withinDeviceLimit = await consumeRateWindow(
      tx,
      `device:${deviceId}`,
      deviceId,
      null,
      limit('QUDRA_PAIRING_DEVICE_RATE_LIMIT_PER_HOUR', 5),
      now,
    );
    if (!withinDeviceLimit) return { rateLimited: true as const };
    if (sourceHash) {
      const withinSourceLimit = await consumeRateWindow(
        tx,
        `source:${sourceHash}`,
        null,
        sourceHash,
        limit('QUDRA_PAIRING_SOURCE_RATE_LIMIT_PER_HOUR', 20),
        now,
      );
      if (!withinSourceLimit) return { rateLimited: true as const };
    }

    const pending = await tx.qudraPairingChallenge.findMany({
      where: { deviceId, state: 'PAIRING_PENDING' },
    });
    for (const previous of pending) {
      await tx.qudraPairingChallenge.update({
        where: { id: previous.id },
        data: { state: 'REVOKED' },
      });
      await appendPairingAudit(tx, previous, 'pairing.replay_rejected', { reason: 'rotated' });
    }

    const token = randomBytes(32).toString('base64url');
    const challenge = await tx.qudraPairingChallenge.create({
      data: {
        customerId: device.customerId,
        deviceId,
        keyVersion: device.keyVersion,
        challengeDigest: digest(token),
        expiresAt: new Date(now.getTime() + PAIRING_LIFETIME_MS),
        maxAttempts: PAIRING_MAX_ATTEMPTS,
        idempotencyKey,
      },
    });
    await appendPairingAudit(tx, challenge, 'pairing.created', {
      lifetimeMs: PAIRING_LIFETIME_MS,
      maxAttempts: PAIRING_MAX_ATTEMPTS,
    });
    return { challenge, token };
  });
  if ('rateLimited' in result) {
    await prisma.qudraAuditEvent.create({
      data: {
        customerId: device.customerId,
        deviceId,
        actorType: 'INTERNAL_SERVICE',
        actorId: 'pairing-service',
        action: 'pairing.rate_limited',
        eventType: 'pairing.rate_limited',
        entityType: 'QudraDevice',
        entityId: deviceId,
        correlationId: `pairing:${deviceId}`,
        metadata: { reason: 'challenge_creation_limit' },
        occurredAt: new Date(),
      },
    });
    throw new QudraAuthorizationError('Pairing rate limit exceeded', 429);
  }
  return result;
}

export async function completePairingChallenge(
  authority: QudraAuthority,
  challengeId: string,
  response: string,
) {
  requireClaimAuthority(authority);
  const existing = await prisma.qudraPairingChallenge.findUnique({ where: { id: challengeId } });
  if (!existing) throw new QudraAuthorizationError('Pairing challenge not found', 404);
  await authorizeDevice(authority, existing.deviceId);
  const actor =
    authority.kind === 'session' ? { type: 'CUSTOMER', id: authority.userId } : undefined;

  const result = await prisma.$transaction(async (tx) => {
    const challenge = await tx.qudraPairingChallenge.findUnique({ where: { id: challengeId } });
    if (!challenge) throw new QudraAuthorizationError('Pairing challenge not found', 404);
    if (challenge.kind !== 'PAIRING')
      return {
        failure: new QudraAuthorizationError('Bootstrap challenge cannot use account pairing', 409),
      };
    if (challenge.state === 'PAIRED')
      return { challengeId, deviceId: challenge.deviceId, state: 'PAIRED' as const };
    const currentDevice = await tx.qudraDevice.findUnique({
      where: { id: challenge.deviceId },
    });
    if (!currentDevice || currentDevice.keyVersion !== challenge.keyVersion)
      return {
        failure: new QudraAuthorizationError('Pairing key version is no longer current', 409),
      };
    if (challenge.state !== 'PAIRING_PENDING') {
      await appendPairingAudit(tx, challenge, 'pairing.replay_rejected', {
        reason: `state:${challenge.state}`,
      });
      return {
        failure: new QudraAuthorizationError('Pairing challenge replay rejected', 409),
      };
    }
    const now = new Date();
    if (challenge.expiresAt.getTime() <= now.getTime()) {
      const expired = await tx.qudraPairingChallenge.updateMany({
        where: { id: challengeId, state: 'PAIRING_PENDING' },
        data: { state: 'EXPIRED' },
      });
      if (expired.count === 1) await appendPairingAudit(tx, challenge, 'pairing.expired', {});
      return { failure: new QudraAuthorizationError('Pairing challenge expired', 409) };
    }
    const claimed = await tx.qudraPairingChallenge.updateMany({
      where: {
        id: challengeId,
        state: 'PAIRING_PENDING',
        attemptCount: { lt: challenge.maxAttempts },
      },
      data: { attemptCount: { increment: 1 } },
    });
    if (claimed.count !== 1) {
      const current = await tx.qudraPairingChallenge.findUnique({ where: { id: challengeId } });
      if (current?.state === 'PAIRED')
        return { challengeId, deviceId: challenge.deviceId, state: 'PAIRED' as const };
      return { failure: new QudraAuthorizationError('Pairing attempt was already consumed', 409) };
    }

    const claimedAttempt = challenge.attemptCount + 1;
    const valid = constantTimeStringEqual(digest(response), challenge.challengeDigest);
    if (!valid) {
      if (claimedAttempt >= challenge.maxAttempts) {
        const exhausted = await tx.qudraPairingChallenge.updateMany({
          where: { id: challengeId, state: 'PAIRING_PENDING' },
          data: { state: 'REPLAYED' },
        });
        if (exhausted.count === 1)
          await appendPairingAudit(tx, challenge, 'pairing.replay_rejected', {
            reason: 'attempts_exhausted',
          });
        else
          await appendPairingAudit(tx, challenge, 'pairing.replay_rejected', {
            reason: 'terminal_during_attempt',
          });
        return { failure: new QudraAuthorizationError('Pairing attempts exhausted', 429) };
      }
      return { failure: new QudraAuthorizationError('Pairing proof rejected', 403) };
    }

    const completed = await tx.qudraPairingChallenge.updateMany({
      where: {
        id: challengeId,
        state: 'PAIRING_PENDING',
        attemptCount: claimedAttempt,
      },
      data: { state: 'PAIRED', consumedAt: now },
    });
    if (completed.count !== 1) {
      const current = await tx.qudraPairingChallenge.findUnique({ where: { id: challengeId } });
      if (current?.state === 'PAIRED')
        return { challengeId, deviceId: challenge.deviceId, state: 'PAIRED' as const };
      return { failure: new QudraAuthorizationError('Pairing challenge replay rejected', 409) };
    }

    const device = await tx.qudraDevice.update({
      where: { id: challenge.deviceId },
      data: { status: 'PAIRED', lastChallengeAt: now },
    });
    const session = await issueDeviceSessionRecord(tx, device.id, device.keyVersion, now);
    await appendPairingAudit(
      tx,
      challenge,
      'pairing.completed',
      { keyVersion: device.keyVersion },
      actor,
    );
    return {
      challengeId,
      deviceId: challenge.deviceId,
      state: 'PAIRED' as const,
      sessionToken: session.token,
      sessionExpiresAt: session.expiresAt.toISOString(),
    };
  });
  if ('failure' in result) throw result.failure;
  return result;
}

export type BootstrapChallengeResult = {
  challenge: {
    id: string;
    deviceId: string;
    kind: 'BOOTSTRAP';
    keyVersion: number;
    state: 'PAIRING_PENDING';
    expiresAt: Date;
    attemptCount: number;
    maxAttempts: number;
  };
  nonce: string;
  device: QudraDevice;
};

export async function createBootstrapChallenge(
  input: AnonymousDeviceRegistration,
  requestSource?: string,
): Promise<BootstrapChallengeResult> {
  validatePlatformFamily(input.platform, input.productFamily);
  if (input.algorithm !== 'P256')
    throw new QudraAuthorizationError('Anonymous bootstrap requires P-256', 400);
  validateP256PublicKey(input.publicKey);
  const fingerprint = fingerprintPublicKey(input.publicKey);
  const sourceHash = requestSource ? sourceDigest(requestSource) : null;

  const result = await prisma.$transaction(async (tx) => {
    const now = new Date();
    const fingerprintAllowed = await consumeRateWindow(
      tx,
      `bootstrap:fingerprint:${fingerprint}`,
      null,
      null,
      limit('QUDRA_BOOTSTRAP_FINGERPRINT_RATE_LIMIT_PER_HOUR', BOOTSTRAP_RATE_LIMIT_PER_HOUR),
      now,
    );
    if (!fingerprintAllowed) return { rateLimited: true as const };
    if (sourceHash) {
      const sourceAllowed = await consumeRateWindow(
        tx,
        `bootstrap:source:${sourceHash}`,
        null,
        sourceHash,
        limit('QUDRA_BOOTSTRAP_SOURCE_RATE_LIMIT_PER_HOUR', 20),
        now,
      );
      if (!sourceAllowed) return { rateLimited: true as const };
    }

    const device = await provisionAnonymousDevice(tx, input, fingerprint);
    if (device.status === 'REVOKED')
      throw new QudraAuthorizationError('Revoked Device cannot bootstrap', 409);
    await tx.qudraDevice.update({ where: { id: device.id }, data: { lastChallengeAt: now } });
    const pending = await tx.qudraPairingChallenge.findMany({
      where: { deviceId: device.id, kind: 'BOOTSTRAP', state: 'PAIRING_PENDING' },
    });
    for (const previous of pending) {
      await tx.qudraPairingChallenge.update({
        where: { id: previous.id },
        data: { state: 'REVOKED' },
      });
      await appendPairingAudit(tx, previous, 'pairing.replay_rejected', {
        reason: 'bootstrap_rotated',
      });
    }

    const nonce = randomBytes(32).toString('base64url');
    const challenge = await tx.qudraPairingChallenge.create({
      data: {
        customerId: device.customerId,
        deviceId: device.id,
        kind: 'BOOTSTRAP',
        keyVersion: device.keyVersion,
        challengeDigest: digest(nonce),
        expiresAt: new Date(now.getTime() + PAIRING_LIFETIME_MS),
        maxAttempts: PAIRING_MAX_ATTEMPTS,
      },
    });
    await appendPairingAudit(tx, challenge, 'pairing.created', {
      kind: 'bootstrap',
      lifetimeMs: PAIRING_LIFETIME_MS,
      maxAttempts: PAIRING_MAX_ATTEMPTS,
    });
    return { challenge, nonce, device };
  });
  if ('rateLimited' in result)
    throw new QudraAuthorizationError('Bootstrap rate limit exceeded', 429);
  return result as BootstrapChallengeResult;
}

export async function completeBootstrapChallenge(
  challengeId: string,
  nonce: string,
  proof: string,
) {
  const result = await prisma.$transaction(async (tx) => {
    const challenge = await tx.qudraPairingChallenge.findUnique({
      where: { id: challengeId },
      include: { device: true },
    });
    if (!challenge) throw new QudraAuthorizationError('Bootstrap challenge not found', 404);
    if (challenge.kind !== 'BOOTSTRAP')
      throw new QudraAuthorizationError('Pairing challenge is not a bootstrap challenge', 409);
    if (challenge.state !== 'PAIRING_PENDING')
      throw new QudraAuthorizationError('Bootstrap challenge replay rejected', 409);
    if (challenge.device.status === 'REVOKED')
      throw new QudraAuthorizationError('Revoked Device cannot bootstrap', 409);
    if (challenge.keyVersion !== challenge.device.keyVersion)
      throw new QudraAuthorizationError('Bootstrap key version is no longer current', 409);

    const now = new Date();
    if (challenge.expiresAt.getTime() <= now.getTime()) {
      await tx.qudraPairingChallenge.updateMany({
        where: { id: challengeId, state: 'PAIRING_PENDING' },
        data: { state: 'EXPIRED' },
      });
      await appendPairingAudit(tx, challenge, 'pairing.expired', { kind: 'bootstrap' });
      return { failure: new QudraAuthorizationError('Bootstrap challenge expired', 409) };
    }
    const claimed = await tx.qudraPairingChallenge.updateMany({
      where: {
        id: challengeId,
        kind: 'BOOTSTRAP',
        state: 'PAIRING_PENDING',
        attemptCount: { lt: challenge.maxAttempts },
      },
      data: { attemptCount: { increment: 1 } },
    });
    if (claimed.count !== 1)
      return { failure: new QudraAuthorizationError('Bootstrap challenge replay rejected', 409) };

    const nonceMatches = constantTimeStringEqual(digest(nonce), challenge.challengeDigest);
    const signatureMatches =
      nonceMatches &&
      verifyDeviceSignature({
        algorithm: challenge.device.algorithm,
        publicKey: challenge.device.publicKey,
        payload: bootstrapProofPayload({
          challengeId,
          nonce,
          deviceId: challenge.deviceId,
          keyVersion: challenge.keyVersion,
        }),
        signature: proof,
      });
    if (!signatureMatches) {
      const attempts = challenge.attemptCount + 1;
      if (attempts >= challenge.maxAttempts) {
        await tx.qudraPairingChallenge.updateMany({
          where: { id: challengeId, state: 'PAIRING_PENDING' },
          data: { state: 'REPLAYED' },
        });
      }
      await appendPairingAudit(tx, challenge, 'pairing.replay_rejected', {
        kind: 'bootstrap',
        reason: attempts >= challenge.maxAttempts ? 'attempts_exhausted' : 'proof_rejected',
      });
      return {
        failure: new QudraAuthorizationError(
          attempts >= challenge.maxAttempts
            ? 'Bootstrap attempts exhausted'
            : 'Bootstrap proof rejected',
          attempts >= challenge.maxAttempts ? 429 : 403,
        ),
      };
    }

    const completed = await tx.qudraPairingChallenge.updateMany({
      where: {
        id: challengeId,
        state: 'PAIRING_PENDING',
        attemptCount: challenge.attemptCount + 1,
      },
      data: { state: 'PAIRED', consumedAt: now },
    });
    if (completed.count !== 1)
      return { failure: new QudraAuthorizationError('Bootstrap challenge replay rejected', 409) };
    const device = await tx.qudraDevice.update({
      where: { id: challenge.deviceId },
      data: { status: 'PAIRED', lastChallengeAt: now },
    });
    const session = await issueDeviceSessionRecord(tx, device.id, device.keyVersion, now);
    await appendPairingAudit(tx, challenge, 'pairing.completed', {
      kind: 'bootstrap',
      keyVersion: device.keyVersion,
    });
    return {
      challengeId,
      deviceId: device.id,
      state: 'PAIRED' as const,
      sessionToken: session.token,
      sessionExpiresAt: session.expiresAt.toISOString(),
    };
  });
  if ('failure' in result) throw result.failure;
  return result;
}

export async function pairingQr(authority: QudraAuthority, challengeId: string) {
  if (authority.kind === 'internal') requireScope(authority, 'pairing:manage');
  const challenge = await prisma.qudraPairingChallenge.findUnique({ where: { id: challengeId } });
  if (!challenge) throw new QudraAuthorizationError('Pairing challenge not found', 404);
  await authorizeDevice(authority, challenge.deviceId);
  if (challenge.state !== 'PAIRING_PENDING')
    throw new QudraAuthorizationError('Pairing challenge is unavailable', 409);
  if (challenge.expiresAt.getTime() <= Date.now()) {
    const expired = await prisma.$transaction(async (tx) => {
      const updated = await tx.qudraPairingChallenge.updateMany({
        where: { id: challengeId, state: 'PAIRING_PENDING' },
        data: { state: 'EXPIRED' },
      });
      if (updated.count === 1) await appendPairingAudit(tx, challenge, 'pairing.expired', {});
      return updated.count === 1;
    });
    if (!expired) throw new QudraAuthorizationError('Pairing challenge is unavailable', 409);
    throw new QudraAuthorizationError('Pairing challenge expired', 409);
  }
  await prisma.qudraPairingChallenge.update({
    where: { id: challengeId },
    data: { qrIssuedAt: new Date() },
  });
  return {
    id: challenge.id,
    representation: challenge.id,
    expiresAt: challenge.expiresAt.toISOString(),
  };
}

export async function cancelPairing(authority: QudraAuthority, challengeId: string) {
  if (authority.kind === 'internal') requireScope(authority, 'pairing:manage');
  const challenge = await prisma.qudraPairingChallenge.findUnique({ where: { id: challengeId } });
  if (!challenge) throw new QudraAuthorizationError('Pairing challenge not found', 404);
  await authorizeDevice(authority, challenge.deviceId);
  if (challenge.state !== 'PAIRING_PENDING')
    throw new QudraAuthorizationError('Pairing challenge is already terminal', 409);
  return prisma.$transaction(async (tx) => {
    const updated = await tx.qudraPairingChallenge.updateMany({
      where: { id: challengeId, state: 'PAIRING_PENDING' },
      data: { state: 'CANCELLED' },
    });
    if (updated.count !== 1)
      throw new QudraAuthorizationError('Pairing challenge is already terminal', 409);
    await appendPairingAudit(tx, challenge, 'pairing.cancelled', {});
    return tx.qudraPairingChallenge.findUniqueOrThrow({ where: { id: challengeId } });
  });
}
