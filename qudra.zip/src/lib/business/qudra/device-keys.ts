// @polsia:user-owned — QUDRA key proof, rotation, and revocation service.
import 'server-only';

import type { QudraDeviceAlgorithm } from '@prisma/client';
import { prisma } from '@/lib/db';
import {
  authorizeDevice,
  fingerprintPublicKey,
  type QudraAuthority,
  QudraAuthorizationError,
  requireScope,
} from './authority';

export async function rotateDeviceKey(
  authority: QudraAuthority,
  deviceId: string,
  input: { algorithm: QudraDeviceAlgorithm; publicKey: string },
) {
  if (authority.kind === 'internal') requireScope(authority, 'device:rotate');
  const device = await authorizeDevice(authority, deviceId);
  if (device.status === 'REVOKED')
    throw new QudraAuthorizationError('Revoked Device cannot rotate', 409);
  return prisma.$transaction(async (tx) => {
    const now = new Date();
    const lockedDevice = await tx.qudraDevice.update({
      where: { id: deviceId },
      data: { updatedAt: now },
    });
    if (lockedDevice.status === 'REVOKED')
      throw new QudraAuthorizationError('Revoked Device cannot rotate', 409);
    const nextVersion = lockedDevice.keyVersion + 1;
    await tx.qudraDeviceKey.updateMany({
      where: { deviceId, version: lockedDevice.keyVersion, revokedAt: null },
      data: { revokedAt: now },
    });
    await tx.qudraDeviceSession.updateMany({
      where: { deviceId, revokedAt: null },
      data: { revokedAt: now },
    });
    const fingerprint = fingerprintPublicKey(input.publicKey);
    const key = await tx.qudraDeviceKey.create({
      data: {
        deviceId,
        version: nextVersion,
        algorithm: input.algorithm,
        publicKey: input.publicKey,
        publicKeyFingerprint: fingerprint,
        activatedAt: now,
      },
    });
    return tx.qudraDevice
      .update({
        where: { id: deviceId },
        data: {
          algorithm: input.algorithm,
          publicKey: input.publicKey,
          publicKeyFingerprint: fingerprint,
          keyVersion: nextVersion,
          oldKeyRevokedAt: now,
        },
      })
      .then((updated) => ({ device: updated, key }));
  });
}

export async function revokeDevice(authority: QudraAuthority, deviceId: string) {
  if (authority.kind === 'internal') requireScope(authority, 'device:revoke');
  const device = await authorizeDevice(authority, deviceId);
  if (authority.kind === 'device')
    throw new QudraAuthorizationError('Device proof cannot revoke its own Device');
  return prisma.$transaction(async (tx) => {
    const now = new Date();
    await tx.qudraDeviceKey.updateMany({
      where: { deviceId, revokedAt: null },
      data: { revokedAt: now },
    });
    await tx.qudraDeviceSession.updateMany({
      where: { deviceId, revokedAt: null },
      data: { revokedAt: now },
    });
    return tx.qudraDevice.update({
      where: { id: device.id },
      data: { status: 'REVOKED', revokedAt: now },
    });
  });
}
