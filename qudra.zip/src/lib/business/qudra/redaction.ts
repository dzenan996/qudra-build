// @polsia:user-owned — central, recursive QUDRA secret redaction boundary.

const SENSITIVE_KEY =
  /password|passphrase|secret|token|bearer|authorization|credential|private.?key|ciphertext|challenge|nonce|proof|signature|pairing|cast.?auth|access.?key|api.?key/i;
const SECRET_QUERY_KEY =
  /^(token|access_token|bearer|secret|password|pass(word)?|api[-_]?key|key|signature|proof|nonce|credential|authorization)$/i;
const URL_PATTERN = /https?:\/\/[^\s"'<>]+/gi;
const PEM_PATTERN = /-----BEGIN [^-]+-----[\s\S]*?-----END [^-]+-----/gi;
const BEARER_PATTERN = /\bBearer\s+[^\s,;]+/gi;

export function redactUrl(value: string | URL | null | undefined): string | null {
  if (!value) return null;
  try {
    const url = new URL(String(value));
    url.username = '';
    url.password = '';
    for (const key of [...url.searchParams.keys()]) {
      if (SECRET_QUERY_KEY.test(key)) url.searchParams.delete(key);
    }
    url.hash = '';
    return url.toString();
  } catch {
    return '[REDACTED_URL]';
  }
}

function redactString(value: string): string {
  let result = value.replace(PEM_PATTERN, '[REDACTED_PRIVATE_KEY]');
  result = result.replace(BEARER_PATTERN, 'Bearer [REDACTED]');
  result = result.replace(URL_PATTERN, (url) => redactUrl(url) ?? '[REDACTED_URL]');
  return result
    .replace(
      /(password|passphrase|secret|token|api[-_]?key|authorization)\s*[=:]\s*[^\s,;]+/gi,
      '$1=[REDACTED]',
    )
    .slice(0, 512);
}

function redactUnknown(value: unknown, seen: WeakSet<object>): unknown {
  if (typeof value === 'string') return redactString(value);
  if (value === null || typeof value === 'number' || typeof value === 'boolean') return value;
  if (value instanceof URL) return redactUrl(value);
  if (value instanceof Error) {
    return {
      name: value.name,
      message: redactString(value.message),
      ...(value.stack ? { stack: redactString(value.stack) } : {}),
      ...(value.cause !== undefined ? { cause: redactUnknown(value.cause, seen) } : {}),
    };
  }
  if (typeof value !== 'object') return String(value);
  if (seen.has(value)) return '[REDACTED_CIRCULAR]';
  seen.add(value);
  if (Array.isArray(value)) return value.map((entry) => redactUnknown(entry, seen));
  const output: Record<string, unknown> = {};
  for (const [key, entry] of Object.entries(value)) {
    output[key] = SENSITIVE_KEY.test(key) ? '[REDACTED]' : redactUnknown(entry, seen);
  }
  return output;
}

export function redact(value: unknown): unknown {
  return redactUnknown(value, new WeakSet<object>());
}

export function redactMetadata(value: Record<string, unknown> | null | undefined) {
  const redacted = redact(value ?? {});
  const stripKeys = (entry: unknown): unknown => {
    if (Array.isArray(entry)) return entry.map(stripKeys);
    if (!entry || typeof entry !== 'object') return entry;
    return Object.fromEntries(
      Object.entries(entry)
        .filter(([key]) => !SENSITIVE_KEY.test(key))
        .map(([key, child]) => [key, stripKeys(child)]),
    );
  };
  return (stripKeys(redacted) ?? {}) as Record<string, unknown>;
}

export function redactError(error: unknown) {
  return redact(error) as Record<string, unknown>;
}

export const SENSITIVE_KEY_PATTERN = SENSITIVE_KEY;
