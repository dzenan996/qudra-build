// @polsia:user-owned
import 'server-only';

import { prisma } from '@/lib/db';
import { appendTrustedAudit } from './audit-t7';
import { QudraAuthorizationError } from './authority';
import { trialEndsAt } from './domain';
import { partnerDevice, requirePartnerContext, requireSuperAdminApi } from './partner';
import { replaceDeviceInTransaction } from './replacement';

export async function createReplacementRequest(input: {
  customerId: string;
  oldDeviceId: string;
  newDeviceId: string;
  reason: string;
}) {
  const { user, partner } = await requirePartnerContext();
  await partnerDevice(partner.id, input.customerId, input.oldDeviceId);
  await partnerDevice(partner.id, input.customerId, input.newDeviceId);
  return prisma.$transaction(async (tx) => {
    const request = await tx.qudraPartnerReplacementRequest.create({
      data: {
        partnerId: partner.id,
        customerId: input.customerId,
        oldDeviceId: input.oldDeviceId,
        newDeviceId: input.newDeviceId,
        requestedBy: user.id,
        reason: input.reason,
      },
    });
    await appendTrustedAudit(tx, {
      action: 'replacement.requested',
      actorId: user.id,
      actorType: 'PARTNER',
      partnerId: partner.id,
      customerId: input.customerId,
      deviceId: input.oldDeviceId,
      entityType: 'PartnerReplacementRequest',
      entityId: request.id,
      correlationId: request.id,
      metadata: { newDeviceId: input.newDeviceId },
    });
    return request;
  });
}

export async function listPartnerReplacementRequests(partnerId: string) {
  return prisma.qudraPartnerReplacementRequest.findMany({
    where: { partnerId },
    orderBy: { requestedAt: 'desc' },
    take: 100,
  });
}

export async function decideReplacementRequest(
  requestId: string,
  decision: 'APPROVED' | 'REJECTED',
  reason: string,
) {
  const actor = await requireSuperAdminApi();
  return prisma.$transaction(async (tx) => {
    const request = await tx.qudraPartnerReplacementRequest.findUnique({
      where: { id: requestId },
    });
    if (!request) throw new QudraAuthorizationError('Replacement request not found', 404);
    if (request.status !== 'PENDING')
      throw new QudraAuthorizationError('Replacement request already decided', 409);
    if (decision === 'APPROVED') {
      await replaceDeviceInTransaction(
        tx,
        { kind: 'session', userId: actor.id, isSuperAdmin: true },
        {
          oldDeviceId: request.oldDeviceId,
          newDeviceId: request.newDeviceId,
          superAdminException: true,
        },
      );
    }
    const updated = await tx.qudraPartnerReplacementRequest.update({
      where: { id: requestId },
      data: {
        status: decision,
        decidedBy: actor.id,
        decisionReason: reason,
        decidedAt: new Date(),
      },
    });
    await appendTrustedAudit(tx, {
      action: decision === 'APPROVED' ? 'replacement.approved' : 'replacement.rejected',
      actorId: actor.id,
      actorType: 'SUPER_ADMIN',
      partnerId: request.partnerId,
      customerId: request.customerId,
      deviceId: request.oldDeviceId,
      entityType: 'PartnerReplacementRequest',
      entityId: request.id,
      correlationId: request.id,
      metadata: { reason },
    });
    return updated;
  });
}

export async function createTrialExceptionRequest(input: {
  customerId: string;
  deviceId: string;
  reason: string;
}) {
  const { user, partner } = await requirePartnerContext();
  await partnerDevice(partner.id, input.customerId, input.deviceId);
  return prisma.$transaction(async (tx) => {
    const request = await tx.qudraPartnerTrialExceptionRequest.create({
      data: {
        partnerId: partner.id,
        customerId: input.customerId,
        deviceId: input.deviceId,
        requestedBy: user.id,
        reason: input.reason,
      },
    });
    await appendTrustedAudit(tx, {
      action: 'trial.exception_requested',
      actorId: user.id,
      actorType: 'PARTNER',
      partnerId: partner.id,
      customerId: input.customerId,
      deviceId: input.deviceId,
      entityType: 'PartnerTrialExceptionRequest',
      entityId: request.id,
      correlationId: request.id,
      metadata: {},
    });
    return request;
  });
}

export async function listPartnerTrialExceptionRequests(partnerId: string) {
  return prisma.qudraPartnerTrialExceptionRequest.findMany({
    where: { partnerId },
    orderBy: { createdAt: 'desc' },
    take: 100,
  });
}

export async function decideTrialExceptionRequest(
  requestId: string,
  decision: 'APPROVED' | 'REJECTED',
  reason: string,
) {
  const actor = await requireSuperAdminApi();
  return prisma.$transaction(async (tx) => {
    const request = await tx.qudraPartnerTrialExceptionRequest.findUnique({
      where: { id: requestId },
    });
    if (!request) throw new QudraAuthorizationError('Trial exception request not found', 404);
    if (request.status !== 'PENDING')
      throw new QudraAuthorizationError('Trial exception already decided', 409);
    if (decision === 'APPROVED') {
      const startedAt = new Date();
      await tx.qudraTrial.updateMany({
        where: { deviceId: request.deviceId, customerId: request.customerId },
        data: { state: 'ACTIVE', startedAt, endsAt: trialEndsAt(startedAt) },
      });
    }
    const updated = await tx.qudraPartnerTrialExceptionRequest.update({
      where: { id: requestId },
      data: {
        status: decision,
        decidedBy: actor.id,
        decisionReason: reason,
        decidedAt: new Date(),
      },
    });
    await appendTrustedAudit(tx, {
      action: decision === 'APPROVED' ? 'trial.exception_approved' : 'trial.exception_rejected',
      actorId: actor.id,
      actorType: 'SUPER_ADMIN',
      partnerId: request.partnerId,
      customerId: request.customerId,
      deviceId: request.deviceId,
      entityType: 'PartnerTrialExceptionRequest',
      entityId: request.id,
      correlationId: request.id,
      metadata: { reason },
    });
    return updated;
  });
}
