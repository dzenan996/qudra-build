// @polsia:user-owned — Device-scoped source configuration and optimistic writes.
import 'server-only';

import { prisma } from '@/lib/db';
import {
  authorizeDevice,
  type QudraAuthority,
  QudraAuthorizationError,
  requireScope,
} from './authority';
import { sealSourceSecret } from './source-secrets';

export { redactSource } from './domain';

export type SourceInput = {
  label: string;
  sourceType: 'personal_source';
  endpointUrl?: string;
  epgUrl?: string;
  sourceTimezone?: string;
  utcOffsetMinutes?: number;
  slot?: 1 | 2;
  secret?: string;
  clearSecret?: boolean;
};

function requireWrite(authority: QudraAuthority) {
  if (authority.kind === 'internal') requireScope(authority, 'source:write');
}

function checkVersion(actual: number, expectedVersion: number | undefined) {
  if (expectedVersion === undefined || expectedVersion !== actual)
    throw new QudraAuthorizationError('Source configuration version is stale', 409);
}

function validateSourceUrl(value: string | undefined) {
  if (!value) return;
  try {
    const url = new URL(value);
    if (
      url.username ||
      url.password ||
      /token|secret|pass(word)?|api[-_]?key|auth/i.test(url.search)
    )
      throw new QudraAuthorizationError(
        'Credential-bearing source URLs are not accepted; use the sealed secret field',
        400,
      );
  } catch (error) {
    if (error instanceof QudraAuthorizationError) throw error;
    throw new QudraAuthorizationError('Source URL is invalid', 400);
  }
}

function envelopeFor(input: Pick<SourceInput, 'secret'>) {
  return input.secret === undefined ? undefined : sealSourceSecret(input.secret);
}

async function rememberMutation(
  tx: Parameters<Parameters<typeof prisma.$transaction>[0]>[0],
  input: {
    customerId: string;
    deviceId: string;
    sourceConfigId?: string;
    idempotencyKey?: string;
    operation: string;
    requestedVersion?: number;
    resultingVersion?: number;
  },
) {
  if (!input.idempotencyKey) return;
  await tx.qudraSourceMutation.create({
    data: {
      customerId: input.customerId,
      deviceId: input.deviceId,
      sourceConfigId: input.sourceConfigId,
      idempotencyKey: input.idempotencyKey,
      operation: input.operation,
      requestedVersion: input.requestedVersion,
      resultingVersion: input.resultingVersion,
      status: 'APPLIED',
    },
  });
}

export async function listSources(authority: QudraAuthority, deviceId: string) {
  if (authority.kind === 'internal') requireScope(authority, 'source:read');
  await authorizeDevice(authority, deviceId);
  return prisma.qudraSourceConfig.findMany({ where: { deviceId }, orderBy: { slot: 'asc' } });
}

export async function getActiveSource(authority: QudraAuthority, deviceId: string) {
  if (authority.kind === 'internal') requireScope(authority, 'source:read');
  const device = await authorizeDevice(authority, deviceId);
  const active = await prisma.qudraActiveSource.findUnique({
    where: { deviceId },
    include: { activeSourceConfig: true },
  });
  const validPersonalSource =
    active?.kind === 'PERSONAL_SOURCE' &&
    active.activeSourceConfig?.deviceId === device.id &&
    active.activeSourceConfig.customerId === device.customerId;
  if (validPersonalSource || (active?.kind === 'QUDRA_OPEN' && !active.activeSourceConfigId))
    return { kind: active.kind, activeSourceConfigId: active.activeSourceConfigId };
  await prisma.qudraActiveSource.upsert({
    where: { deviceId },
    update: { kind: 'QUDRA_OPEN', activeSourceConfigId: null, changedAt: new Date() },
    create: { customerId: device.customerId, deviceId, kind: 'QUDRA_OPEN' },
  });
  return { kind: 'QUDRA_OPEN' as const, activeSourceConfigId: null };
}

export async function createSource(
  authority: QudraAuthority,
  deviceId: string,
  input: SourceInput,
  idempotencyKey?: string,
) {
  requireWrite(authority);
  const device = await authorizeDevice(authority, deviceId);
  validateSourceUrl(input.endpointUrl);
  validateSourceUrl(input.epgUrl);
  const envelope = envelopeFor(input);
  return prisma.$transaction(async (tx) => {
    await tx.qudraDevice.update({ where: { id: deviceId }, data: { updatedAt: new Date() } });
    if (idempotencyKey) {
      const prior = await tx.qudraSourceMutation.findUnique({
        where: { deviceId_idempotencyKey: { deviceId, idempotencyKey } },
      });
      if (prior?.sourceConfigId) {
        const source = await tx.qudraSourceConfig.findUnique({
          where: { id: prior.sourceConfigId },
        });
        if (source) return source;
      }
    }
    const existing = await tx.qudraSourceConfig.findMany({
      where: { deviceId },
      select: { id: true, slot: true },
      orderBy: { slot: 'asc' },
    });
    if (existing.length >= 2)
      throw new QudraAuthorizationError('A Device may have at most two personal sources', 409);
    const slot =
      input.slot ??
      ([1, 2].find((candidate) => !existing.some((s) => s.slot === candidate)) as
        | 1
        | 2
        | undefined);
    if (!slot || existing.some((source) => source.slot === slot))
      throw new QudraAuthorizationError('Source slot is already in use', 409);
    const source = await tx.qudraSourceConfig.create({
      data: {
        customerId: device.customerId,
        deviceId,
        sourceKey: `source:${deviceId}:${slot}`,
        slot,
        label: input.label,
        sourceType: 'personal_source',
        endpointUrl: input.endpointUrl,
        epgUrl: input.epgUrl,
        sourceTimezone: input.sourceTimezone,
        utcOffsetMinutes: input.utcOffsetMinutes,
        secretCiphertext: envelope?.ciphertext,
        secretKeyReference: envelope?.keyReference,
        secretKeyVersion: envelope?.keyVersion,
        secretRedaction: envelope ? 'envelope_encrypted' : 'not_configured',
      },
    });
    await tx.qudraSourceSync.create({
      data: {
        customerId: device.customerId,
        deviceId,
        sourceConfigId: source.id,
        configVersion: source.configVersion,
      },
    });
    await rememberMutation(tx, {
      customerId: device.customerId,
      deviceId,
      sourceConfigId: source.id,
      idempotencyKey,
      operation: 'CREATE',
      resultingVersion: source.configVersion,
    });
    return source;
  });
}

export async function updateSource(
  authority: QudraAuthority,
  deviceId: string,
  sourceConfigId: string,
  input: Partial<SourceInput>,
  expectedVersion?: number,
  idempotencyKey?: string,
) {
  requireWrite(authority);
  const device = await authorizeDevice(authority, deviceId);
  validateSourceUrl(input.endpointUrl);
  validateSourceUrl(input.epgUrl);
  const envelope = envelopeFor(input);
  return prisma.$transaction(async (tx) => {
    await tx.qudraDevice.update({ where: { id: deviceId }, data: { updatedAt: new Date() } });
    if (idempotencyKey) {
      const prior = await tx.qudraSourceMutation.findUnique({
        where: { deviceId_idempotencyKey: { deviceId, idempotencyKey } },
      });
      if (prior?.sourceConfigId) {
        const source = await tx.qudraSourceConfig.findUnique({
          where: { id: prior.sourceConfigId },
        });
        if (source) return source;
      }
    }
    const source = await tx.qudraSourceConfig.findFirst({
      where: { id: sourceConfigId, deviceId, customerId: device.customerId },
    });
    if (!source) throw new QudraAuthorizationError('Source not found', 404);
    checkVersion(source.configVersion, expectedVersion);
    const result = await tx.qudraSourceConfig.updateMany({
      where: {
        id: sourceConfigId,
        deviceId,
        customerId: device.customerId,
        configVersion: source.configVersion,
      },
      data: {
        label: input.label,
        endpointUrl: input.endpointUrl,
        epgUrl: input.epgUrl,
        sourceTimezone: input.sourceTimezone,
        utcOffsetMinutes: input.utcOffsetMinutes,
        ...(input.clearSecret
          ? {
              secretCiphertext: null,
              secretKeyReference: null,
              secretKeyVersion: null,
              secretRedaction: 'not_configured',
            }
          : {}),
        ...(envelope
          ? {
              secretCiphertext: envelope.ciphertext,
              secretKeyReference: envelope.keyReference,
              secretKeyVersion: envelope.keyVersion,
              secretRedaction: 'envelope_encrypted',
            }
          : {}),
        configVersion: { increment: 1 },
      },
    });
    if (result.count !== 1)
      throw new QudraAuthorizationError('Source configuration version is stale', 409);
    const updated = await tx.qudraSourceConfig.findUniqueOrThrow({ where: { id: sourceConfigId } });
    await tx.qudraSourceSync.updateMany({
      where: { sourceConfigId },
      data: { configVersion: updated.configVersion, state: 'REQUESTED' },
    });
    await rememberMutation(tx, {
      customerId: device.customerId,
      deviceId,
      sourceConfigId,
      idempotencyKey,
      operation: 'UPDATE',
      requestedVersion: expectedVersion,
      resultingVersion: updated.configVersion,
    });
    return updated;
  });
}

export async function deleteSource(
  authority: QudraAuthority,
  deviceId: string,
  sourceConfigId: string,
  expectedVersion?: number,
  idempotencyKey?: string,
) {
  requireWrite(authority);
  const device = await authorizeDevice(authority, deviceId);
  return prisma.$transaction(async (tx) => {
    await tx.qudraDevice.update({ where: { id: deviceId }, data: { updatedAt: new Date() } });
    if (idempotencyKey) {
      const prior = await tx.qudraSourceMutation.findUnique({
        where: { deviceId_idempotencyKey: { deviceId, idempotencyKey } },
      });
      if (prior) return null;
    }
    const source = await tx.qudraSourceConfig.findFirst({
      where: { id: sourceConfigId, deviceId, customerId: device.customerId },
    });
    if (!source) throw new QudraAuthorizationError('Source not found', 404);
    checkVersion(source.configVersion, expectedVersion);
    await tx.qudraSourceConfig.delete({ where: { id: sourceConfigId } });
    await tx.qudraSourceSync.deleteMany({ where: { sourceConfigId } });
    await tx.qudraActiveSource.updateMany({
      where: { deviceId, customerId: device.customerId, activeSourceConfigId: sourceConfigId },
      data: { kind: 'QUDRA_OPEN', activeSourceConfigId: null, changedAt: new Date() },
    });
    await rememberMutation(tx, {
      customerId: device.customerId,
      deviceId,
      sourceConfigId,
      idempotencyKey,
      operation: 'DELETE',
      requestedVersion: expectedVersion,
    });
    return source;
  });
}

export async function selectActiveSource(
  authority: QudraAuthority,
  deviceId: string,
  kind: 'QUDRA_OPEN' | 'PERSONAL_SOURCE',
  sourceConfigId?: string | null,
) {
  if (authority.kind === 'internal') requireScope(authority, 'source:write');
  const device = await authorizeDevice(authority, deviceId);
  if (kind === 'QUDRA_OPEN')
    return prisma.qudraActiveSource.upsert({
      where: { deviceId },
      update: { kind, activeSourceConfigId: null, changedAt: new Date() },
      create: { customerId: device.customerId, deviceId, kind },
    });
  if (!sourceConfigId) throw new QudraAuthorizationError('Personal source is required', 400);
  const source = await prisma.qudraSourceConfig.findFirst({
    where: { id: sourceConfigId, deviceId, customerId: device.customerId },
  });
  if (!source) throw new QudraAuthorizationError('Cross-device source selection rejected', 403);
  return prisma.qudraActiveSource.upsert({
    where: { deviceId },
    update: { kind, activeSourceConfigId: source.id, changedAt: new Date() },
    create: { customerId: device.customerId, deviceId, kind, activeSourceConfigId: source.id },
  });
}
