// @polsia:user-owned — same-Customer Device replacement foundation.
import 'server-only';

import type { Prisma } from '@prisma/client';
import { prisma } from '@/lib/db';
import {
  assertTestAuthorityAllowed,
  type QudraAuthority,
  QudraAuthorizationError,
} from './authority';

const REPLACEMENT_INTERVAL_MS = 365 * 24 * 60 * 60 * 1000;

export async function replaceDeviceInTransaction(
  tx: Prisma.TransactionClient,
  authority: QudraAuthority,
  input: { oldDeviceId: string; newDeviceId: string; superAdminException?: boolean },
) {
  assertTestAuthorityAllowed(authority);
  const superAdmin =
    (authority.kind === 'session' && authority.isSuperAdmin) ||
    (authority.kind === 'test' && authority.isSuperAdmin && process.env.NODE_ENV === 'test');
  if (authority.kind !== 'internal' && !superAdmin)
    throw new QudraAuthorizationError('Device replacement requires Super Admin authority', 403);
  const [oldDevice, newDevice] = await Promise.all([
    tx.qudraDevice.findUnique({ where: { id: input.oldDeviceId } }),
    tx.qudraDevice.findUnique({ where: { id: input.newDeviceId } }),
  ]);
  if (!oldDevice || !newDevice)
    throw new QudraAuthorizationError('Replacement Device not found', 404);
  if (oldDevice.customerId !== newDevice.customerId)
    throw new QudraAuthorizationError('Cross-Customer replacement rejected', 403);
  const last = await tx.qudraDeviceReplacement.findFirst({
    where: { customerId: oldDevice.customerId },
    orderBy: { requestedAt: 'desc' },
  });
  const early = !!last && Date.now() - last.requestedAt.getTime() < REPLACEMENT_INTERVAL_MS;
  if (early && !input.superAdminException)
    throw new QudraAuthorizationError('Standard replacement interval has not elapsed', 409);
  if (early && input.superAdminException && !(authority.kind === 'internal' || superAdmin))
    throw new QudraAuthorizationError('Super Admin exception required', 403);
  const oldPointer = await tx.qudraDeviceCurrentEntitlement.findUnique({
    where: { deviceId: oldDevice.id },
  });
  const newPointer = await tx.qudraDeviceCurrentEntitlement.findUnique({
    where: { deviceId: newDevice.id },
  });
  if (oldPointer && newPointer)
    throw new QudraAuthorizationError('Successor Device already has an entitlement', 409);
  let successorId: string | null = null;
  if (oldPointer) {
    const oldEntitlement = await tx.qudraEntitlement.findUnique({
      where: { id: oldPointer.entitlementId },
    });
    if (oldEntitlement) {
      await tx.qudraEntitlement.update({
        where: { id: oldEntitlement.id },
        data: { state: 'REPLACED', entitlementVersion: { increment: 1 } },
      });
      const successor = await tx.qudraEntitlement.create({
        data: {
          customerId: newDevice.customerId,
          deviceId: newDevice.id,
          kind: oldEntitlement.kind,
          channel: oldEntitlement.channel,
          provenance: oldEntitlement.provenance,
          state: 'ACTIVE',
          activatedAt: new Date(),
          expiresAt: oldEntitlement.expiresAt,
          lastValidatedAt: new Date(),
          graceUntil: oldEntitlement.graceUntil,
          entitlementVersion: 1,
          replacedEntitlementId: oldEntitlement.id,
        },
      });
      await tx.qudraDeviceCurrentEntitlement.upsert({
        where: { deviceId: newDevice.id },
        update: { entitlementId: successor.id },
        create: { deviceId: newDevice.id, entitlementId: successor.id },
      });
      await tx.qudraDeviceCurrentEntitlement.delete({ where: { deviceId: oldDevice.id } });
      successorId = successor.id;
    }
  }
  const replacement = await tx.qudraDeviceReplacement.create({
    data: {
      customerId: oldDevice.customerId,
      oldDeviceId: oldDevice.id,
      newDeviceId: newDevice.id,
      superAdminExceptionGranted: !!input.superAdminException,
    },
  });
  return { replacement, successorEntitlementId: successorId };
}

export async function replaceDevice(
  authority: QudraAuthority,
  input: { oldDeviceId: string; newDeviceId: string; superAdminException?: boolean },
) {
  return prisma.$transaction((tx) => replaceDeviceInTransaction(tx, authority, input));
}
