// @polsia:user-owned — QUDRA T2 access wire contracts.
import { z } from 'zod';

export const QudraAccess = z.object({
  deviceId: z.string(),
  serverTime: z.string(),
  qudraOpen: z.literal(true),
  trialActive: z.boolean(),
  entitlementActive: z.boolean(),
  personalSourceAllowed: z.boolean(),
  entitlementId: z.string().nullable(),
  entitlementState: z
    .enum(['ACTIVE', 'EXPIRED', 'SUSPENDED', 'REVOKED', 'REPLACED'])
    .nullable()
    .optional(),
  entitlementKind: z.enum(['ANNUAL', 'LIFETIME']).nullable().optional(),
  graceUntil: z.string().datetime().nullable().optional(),
});
