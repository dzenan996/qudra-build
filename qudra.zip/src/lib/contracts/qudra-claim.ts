// @polsia:user-owned — approved account claim/link contract.
import { z } from 'zod';

export const QudraClaimRequest = z.object({
  challengeId: z.string().min(1),
  response: z.string().min(1).max(512),
});
export const QudraClaimResult = z.object({
  challengeId: z.string(),
  deviceId: z.string(),
  customerId: z.string(),
  state: z.literal('PAIRED'),
  linked: z.boolean(),
});
