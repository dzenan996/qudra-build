// @polsia:user-owned
import { z } from 'zod';

export const QudraAdminCustomer = z.object({
  id: z.string(),
  status: z.string(),
  createdAt: z.string(),
  deviceCount: z.number().int().nonnegative(),
});
export const QudraAdminCustomers = z.object({ items: z.array(QudraAdminCustomer) });
export const QudraAdminDevice = z.object({
  id: z.string(),
  customerId: z.string(),
  productFamily: z.enum(['TV', 'MOBILE']),
  platform: z.string(),
  status: z.string(),
  displayName: z.string().nullable(),
});
export const QudraAdminDevices = z.object({ items: z.array(QudraAdminDevice) });
export const QudraAdminEntitlement = z.object({
  id: z.string(),
  customerId: z.string(),
  deviceId: z.string().nullable(),
  kind: z.enum(['ANNUAL', 'LIFETIME']),
  state: z.enum(['ACTIVE', 'EXPIRED', 'SUSPENDED', 'REVOKED', 'REPLACED']),
  provenance: z.string().nullable(),
  activatedAt: z.string(),
  expiresAt: z.string().nullable(),
});
export const QudraAdminEntitlements = z.object({ items: z.array(QudraAdminEntitlement) });
export const QudraAdminDiagnostics = z.object({
  customerCount: z.number().int().nonnegative(),
  deviceCount: z.number().int().nonnegative(),
  activeEntitlementCount: z.number().int().nonnegative(),
  partnerCount: z.number().int().nonnegative(),
  timestamp: z.string(),
});
export const QudraAdminAuditEvent = z.object({
  id: z.string(),
  action: z.string(),
  actorType: z.string(),
  partnerId: z.string().nullable(),
  customerId: z.string().nullable(),
  deviceId: z.string().nullable(),
  entityType: z.string(),
  entityId: z.string(),
  metadata: z.record(z.unknown()),
  occurredAt: z.string(),
});
export const QudraAdminAuditEvents = z.object({ items: z.array(QudraAdminAuditEvent) });
