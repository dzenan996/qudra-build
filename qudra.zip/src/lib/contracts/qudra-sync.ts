// @polsia:user-owned — metadata-only source refresh and capability contracts.
import { z } from 'zod';

export const QudraSyncState = z.enum([
  'IDLE',
  'REQUESTED',
  'SYNCING',
  'FRESH',
  'STALE',
  'FAILED',
  'UNAVAILABLE',
]);
export const QudraSourceFormat = z.enum(['M3U', 'M3U8', 'XMLTV']);
export const QudraCapabilityState = z.enum(['UNKNOWN', 'SUPPORTED', 'UNSUPPORTED']);
export const QudraSyncStatus = z.object({
  id: z.string(),
  deviceId: z.string(),
  sourceConfigId: z.string().nullable(),
  configVersion: z.number().int().positive(),
  state: QudraSyncState,
  format: QudraSourceFormat.nullable(),
  lastAttemptAt: z.string().datetime().nullable(),
  lastSuccessAt: z.string().datetime().nullable(),
  staleSince: z.string().datetime().nullable(),
  failureCode: z.string().nullable(),
  lastKnownGoodGeneration: z.string().nullable(),
  counts: z.object({
    live: z.number().int().nonnegative(),
    movies: z.number().int().nonnegative(),
    series: z.number().int().nonnegative(),
    radio: z.number().int().nonnegative(),
    epgChannels: z.number().int().nonnegative(),
    epgProgrammes: z.number().int().nonnegative(),
  }),
  timezone: z.string().nullable(),
  utcOffsetMinutes: z.number().int().nullable(),
  capabilities: z.object({
    epg: QudraCapabilityState,
    catchUp: QudraCapabilityState,
    timeshift: QudraCapabilityState,
  }),
});
export const QudraSyncList = z.object({ items: z.array(QudraSyncStatus) });
export const QudraSyncReport = z.object({
  sourceConfigId: z.string().optional(),
  configVersion: z.number().int().positive(),
  state: QudraSyncState,
  format: QudraSourceFormat.optional(),
  lastAttemptAt: z.string().datetime().optional(),
  lastSuccessAt: z.string().datetime().optional(),
  staleSince: z.string().datetime().optional(),
  failureCode: z.string().max(128).optional(),
  lastKnownGoodGeneration: z.string().max(128).optional(),
  counts: z
    .object({
      live: z.number().int().nonnegative().max(1000000),
      movies: z.number().int().nonnegative().max(1000000),
      series: z.number().int().nonnegative().max(1000000),
      radio: z.number().int().nonnegative().max(1000000),
      epgChannels: z.number().int().nonnegative().max(1000000),
      epgProgrammes: z.number().int().nonnegative().max(1000000),
    })
    .optional(),
  timezone: z.string().max(64).optional(),
  utcOffsetMinutes: z.number().int().min(-840).max(840).optional(),
  capabilities: z
    .object({
      epg: QudraCapabilityState,
      catchUp: QudraCapabilityState,
      timeshift: QudraCapabilityState,
    })
    .optional(),
  idempotencyKey: z.string().min(8).max(128).optional(),
});
export const QudraCapabilities = z.object({
  items: z.array(
    z.object({
      sourceConfigId: z.string(),
      state: QudraSyncState,
      epg: QudraCapabilityState,
      catchUp: QudraCapabilityState,
      timeshift: QudraCapabilityState,
    }),
  ),
});
