// @polsia:user-owned
import { z } from 'zod';

export const QudraCreditBalance = z.object({
  partnerId: z.string(),
  balance: z.number().int().nonnegative(),
  version: z.number().int().nonnegative(),
});
export const QudraCreditLedgerEntry = z.object({
  id: z.string(),
  delta: z.number().int(),
  kind: z.enum(['GRANT', 'ADJUSTMENT', 'REVERSAL', 'ACTIVATION_DEBIT']),
  actorId: z.string(),
  reference: z.string().nullable(),
  operationKey: z.string(),
  createdAt: z.string(),
});
export const QudraCreditLedger = z.object({
  balance: QudraCreditBalance,
  entries: z.array(QudraCreditLedgerEntry),
});
export const QudraCreditOperation = z.object({
  delta: z
    .number()
    .int()
    .refine((value) => value !== 0),
  reference: z.string().max(256).optional(),
  operationKey: z.string().min(8).max(160),
});
export const QudraCreditReversal = z.object({
  operationKey: z.string().min(8).max(160),
  reference: z.string().max(256).optional(),
});
