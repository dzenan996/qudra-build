// @polsia:user-owned — QUDRA T2 trial wire contracts.
import { z } from 'zod';

export const QudraTrialState = z.enum(['NOT_STARTED', 'ACTIVE', 'EXPIRED', 'REVOKED']);
export const QudraTrial = z.object({
  id: z.string(),
  deviceId: z.string(),
  state: QudraTrialState,
  startedAt: z.string().nullable(),
  endsAt: z.string().nullable(),
});
export const QudraTrialExceptionRequest = z.object({
  id: z.string(),
  deviceId: z.string(),
  status: z.enum(['PENDING', 'APPROVED', 'REJECTED', 'CANCELLED']),
  reason: z.string(),
  createdAt: z.string(),
});
export const QudraTrialExceptionCreate = z.object({ reason: z.string().min(1).max(1024) });
export const QudraTrialExceptionDecision = z.object({
  decision: z.enum(['APPROVED', 'REJECTED', 'CANCELLED']),
  reason: z.string().min(1).max(1024),
});
export const QudraTrialResponse = z.object({ trial: QudraTrial, access: z.boolean() });
