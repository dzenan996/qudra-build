// @polsia:user-owned
import { z } from 'zod';

export const QudraPartnerActivationKind = z.enum(['ANNUAL', 'LIFETIME']);
export const QudraPartnerActivation = z.object({
  id: z.string(),
  partnerId: z.string(),
  customerId: z.string(),
  deviceId: z.string(),
  entitlementId: z.string().nullable(),
  kind: QudraPartnerActivationKind,
  productFamily: z.enum(['TV', 'MOBILE']),
  status: z.enum(['REQUESTED', 'COMPLETED', 'REJECTED']),
  requiredCredits: z.number().int().positive(),
  idempotencyKey: z.string(),
  createdAt: z.string(),
  completedAt: z.string().nullable(),
});
export const QudraPartnerActivationList = z.object({ items: z.array(QudraPartnerActivation) });
export const QudraPartnerActivationInput = z.object({
  customerId: z.string(),
  deviceId: z.string(),
  kind: QudraPartnerActivationKind,
  idempotencyKey: z.string().min(8).max(128),
});
export const QudraPartnerActivationResult = z.object({
  activation: QudraPartnerActivation,
  entitlement: z
    .object({
      id: z.string(),
      kind: QudraPartnerActivationKind,
      state: z.literal('ACTIVE'),
      activatedAt: z.string(),
      expiresAt: z.string().nullable(),
    })
    .nullable(),
});
