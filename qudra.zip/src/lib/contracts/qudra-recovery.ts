// @polsia:user-owned — QUDRA T2 recovery wire contracts.
import { z } from 'zod';

export const QudraRecoveryEvidence = z.enum([
  'ACCOUNT',
  'PARTNER_CUSTOMER_RECORD',
  'SUPER_ADMIN_SUPPORT',
]);
export const QudraRecoveryState = z.enum([
  'PENDING',
  'APPROVED',
  'DENIED',
  'REJECTED',
  'EXPIRED',
  'REVOKED',
  'CANCELLED',
  'REPLAYED',
]);
export const QudraRecoveryCreate = z.object({
  deviceId: z.string().min(1),
  evidenceCategory: QudraRecoveryEvidence,
  idempotencyKey: z.string().max(128).optional(),
});
export const QudraRecoveryDecision = z.object({
  decision: z.enum(['APPROVED', 'REJECTED', 'CANCELLED']),
  reason: z.string().min(1).max(1024),
});
export const QudraRecoveryChallenge = z.object({
  id: z.string(),
  deviceId: z.string(),
  evidenceCategory: QudraRecoveryEvidence,
  state: QudraRecoveryState,
  attempts: z.number().int(),
  maxAttempts: z.literal(5),
  expiresAt: z.string(),
});
export type QudraRecoveryCreateInput = z.infer<typeof QudraRecoveryCreate>;
