// @polsia:user-owned — account deletion request and status contract.
import { z } from 'zod';

export const accountDeletionConfirmation = 'DELETE MY QUDRA ACCOUNT' as const;

export const AccountDeletionStatus = z.object({
  authenticated: z.boolean(),
  deletionAvailable: z.boolean(),
  accountOptional: z.literal(true),
  confirmationPhrase: z.literal(accountDeletionConfirmation),
  retainedData: z.array(z.string()),
  ownerActionRequired: z.array(z.string()),
});

export const AccountDeletionRequest = z.object({
  confirmation: z.literal(accountDeletionConfirmation),
  password: z.string().min(1).optional(),
});

export const AccountDeletionResult = z.object({
  success: z.literal(true),
  message: z.string(),
});

export type AccountDeletionStatusOutput = z.infer<typeof AccountDeletionStatus>;
export type AccountDeletionRequestInput = z.infer<typeof AccountDeletionRequest>;
export type AccountDeletionResultOutput = z.infer<typeof AccountDeletionResult>;
