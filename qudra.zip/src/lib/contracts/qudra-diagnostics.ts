// @polsia:user-owned — QUDRA T2 diagnostics wire contracts.
import { z } from 'zod';

export const QudraDiagnosticCategory = z.enum([
  'INTERNET',
  'QUDRA_CLOUD',
  'ENTITLEMENT',
  'SOURCE',
  'PLAYLIST_EPG',
  'PLAYBACK',
]);
export const QudraDiagnosticWrite = z.object({
  deviceId: z.string(),
  category: QudraDiagnosticCategory,
  state: z.string().max(32),
  code: z.string().max(128),
  message: z.string().max(512),
  retryable: z.boolean(),
  observedAt: z.string().datetime(),
  correlationId: z.string().max(128),
});
export const QudraDiagnostic = QudraDiagnosticWrite.extend({ id: z.string() });
export const QudraDiagnosticList = z.object({ items: z.array(QudraDiagnostic) });
export const QudraDiagnosticCode = z.object({
  category: QudraDiagnosticCategory,
  code: z.string(),
  description: z.string(),
});
export const QudraDiagnosticCodeList = z.object({ items: z.array(QudraDiagnosticCode) });
