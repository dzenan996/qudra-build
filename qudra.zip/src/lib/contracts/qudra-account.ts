// @polsia:user-owned — QUDRA T2 account wire contracts.
import { z } from 'zod';
import { QudraDevice } from './qudra-device';

export const QudraAccount = z.object({
  id: z.string(),
  customerId: z.string(),
  provider: z.string(),
  externalIdentityRef: z.string(),
  devices: z.array(QudraDevice),
});
export const QudraAccountList = z.object({ items: z.array(QudraAccount) });
export type QudraAccountOutput = z.infer<typeof QudraAccount>;
