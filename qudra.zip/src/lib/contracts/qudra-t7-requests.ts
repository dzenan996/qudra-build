// @polsia:user-owned
import { z } from 'zod';

export const QudraReplacementRequest = z.object({
  id: z.string(),
  partnerId: z.string(),
  customerId: z.string(),
  oldDeviceId: z.string(),
  newDeviceId: z.string(),
  reason: z.string(),
  status: z.enum(['PENDING', 'APPROVED', 'REJECTED']),
  requestedAt: z.string(),
  decidedAt: z.string().nullable(),
});
export const QudraReplacementRequests = z.object({ items: z.array(QudraReplacementRequest) });
export const QudraReplacementRequestInput = z.object({
  customerId: z.string(),
  oldDeviceId: z.string(),
  newDeviceId: z.string(),
  reason: z.string().trim().min(1).max(1024),
});
export const QudraRequestDecision = z.object({
  decision: z.enum(['APPROVED', 'REJECTED']),
  reason: z.string().trim().min(1).max(1024),
});
export const QudraTrialExceptionRequest = z.object({
  id: z.string(),
  partnerId: z.string(),
  customerId: z.string(),
  deviceId: z.string(),
  reason: z.string(),
  status: z.enum(['PENDING', 'APPROVED', 'REJECTED']),
  createdAt: z.string(),
  decidedAt: z.string().nullable(),
});
export const QudraTrialExceptionRequests = z.object({ items: z.array(QudraTrialExceptionRequest) });
export const QudraTrialExceptionInput = z.object({
  customerId: z.string(),
  deviceId: z.string(),
  reason: z.string().trim().min(1).max(1024),
});
