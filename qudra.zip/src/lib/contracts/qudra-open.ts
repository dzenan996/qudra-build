// @polsia:user-owned — shared QUDRA OPEN runtime contract.
// Keep this module client-importable: it contains no server-only imports.
import { z } from 'zod';

const Url = z.string().url();
const UtcTimestamp = z.string().datetime({ offset: true });

export const QudraOpenMediaClass = z.enum(['LIVE_TV', 'MOVIE', 'SERIES', 'RADIO']);
export const QudraOpenProductionDesignation = z.enum(['PRODUCTION', 'TEST_ONLY']);
export const QudraOpenVerificationStatus = z.enum(['VERIFIED', 'REJECTED', 'PENDING']);
export const QudraOpenAvailabilityStatus = z.enum(['AVAILABLE', 'UNAVAILABLE']);
export const QudraOpenHealthStatus = z.enum(['HEALTHY', 'DEGRADED', 'UNAVAILABLE', 'UNKNOWN']);
export const QudraOpenResolution = z.enum(['DIRECT', 'REPLACEMENT', 'FALLBACK', 'UNAVAILABLE']);
export const QudraOpenArtworkStatus = z.enum(['VERIFIED', 'ABSENT', 'UNVERIFIED']);
export const QudraOpenArtworkFallback = z.enum(['QUDRA_NEUTRAL_PLACEHOLDER', 'NONE']);
export const QudraOpenCompatibilityClass = z.enum([
  'PREFERRED',
  'SUPPORTED_WITH_DEVICE_TEST',
  'COMPATIBILITY_RISK',
  'UNSUITABLE_AS_PRIMARY_FIXTURE',
]);

export const QudraOpenGeography = z.object({
  scope: z.enum(['WORLDWIDE', 'REGIONAL', 'UNKNOWN']),
  regions: z.array(z.string().min(2)).max(100),
  restrictions: z.array(z.string().min(1)).max(100),
});

export const QudraOpenStabilityEvidence = z.object({
  checkedAt: UtcTimestamp,
  method: z.enum(['HEAD_RANGE_PROBE', 'ARCHIVE_METADATA_AND_RANGE_PROBE', 'MANUAL_REVIEW']),
  notes: z.string().min(1).max(1000),
});

export const QudraOpenLegalEvidence = z.object({
  license: z.string().min(1).max(200),
  licenseUrl: Url,
  permissionEvidenceUrl: Url,
  attribution: z.string().min(1).max(1000),
  geography: QudraOpenGeography,
  rightsHolder: z.string().min(1).max(200),
  verificationStatus: QudraOpenVerificationStatus,
  verifiedAt: UtcTimestamp,
  verificationMethod: z.string().min(1).max(500),
  stabilityEvidence: QudraOpenStabilityEvidence,
});

export const QudraOpenFormat = z.object({
  mimeType: z.string().regex(/^[\w.+-]+\/[\w.+-]+$/),
  container: z.enum(['MP4', 'MOV', 'MKV', 'WEBM', 'OGG', 'HLS']),
  videoCodec: z.string().min(1).max(80).nullable(),
  audioCodec: z.string().min(1).max(80).nullable(),
  width: z.number().int().positive().nullable(),
  height: z.number().int().positive().nullable(),
  frameRate: z.number().positive().nullable(),
  durationSeconds: z.number().positive().nullable(),
  contentLengthBytes: z.number().int().positive().nullable(),
  rangeSupported: z.boolean(),
});

export const QudraOpenDirectOrigin = z.object({
  url: Url,
  mediaOrigin: z.literal(true),
  webpageEvidenceUrl: Url,
  format: QudraOpenFormat,
});

export const QudraOpenSourceHealth = z.object({
  status: QudraOpenHealthStatus,
  checkedAt: UtcTimestamp,
  httpStatus: z.number().int().min(100).max(599).nullable(),
  contentType: z.string().min(1).nullable(),
  rangeSupported: z.boolean().nullable(),
  stabilityEvidence: QudraOpenStabilityEvidence,
});

export const QudraOpenAvailability = z.object({
  status: QudraOpenAvailabilityStatus,
  geography: QudraOpenGeography,
  reason: z.string().min(1).max(500).nullable(),
});

export const QudraOpenReplacement = z.object({
  sourceId: z.string().min(1),
  reason: z.string().min(1).max(500),
});

export const QudraOpenFallback = z.object({
  sourceId: z.string().min(1).nullable(),
  reason: z.string().min(1).max(500),
});

export const QudraOpenArtwork = z.object({
  url: Url.nullable(),
  type: z.enum(['IMAGE', 'NONE']),
  rightsLicenseReference: Url.nullable(),
  requiredAttribution: z.string().min(1).max(1000).nullable(),
  status: QudraOpenArtworkStatus,
  fallbackState: QudraOpenArtworkFallback,
});

export const QudraOpenAttribution = z.object({
  rightsHolder: z.string().min(1).max(300),
  attributionText: z.string().min(1).max(1000),
  licenseName: z.string().min(1).max(200),
  licenseUrl: Url,
  rightsEvidenceUrl: Url,
  geography: QudraOpenGeography,
  restrictions: z.array(z.string().min(1)).max(100),
});

export const QudraOpenCapabilities = z.object({
  directPlayback: z.boolean(),
  epg: z.boolean(),
  nowNext: z.boolean(),
  fullSchedule: z.boolean(),
  catchUp: z.boolean(),
  timeshift: z.boolean(),
  recording: z.boolean(),
  castCompatibilityKnown: z.boolean(),
});

export const QudraOpenCompatibility = z.object({
  classification: QudraOpenCompatibilityClass,
  notes: z.string().min(1).max(1000),
});

export const QudraOpenOriginState = z.object({
  availability: QudraOpenAvailabilityStatus,
  lastValidatedAt: UtcTimestamp.nullable(),
  // The preferred URL points at directOrigin, which remains the descriptor carrying format evidence.
  preferredOrigin: Url.nullable(),
  fallbackOrigin: QudraOpenDirectOrigin.nullable(),
  unavailableReason: z.string().min(1).max(500).nullable(),
});

export const QudraOpenSourceMetadata = z.object({
  description: z.string().min(1).max(2000).nullable(),
  category: z.string().min(1).max(120).nullable(),
  genres: z.array(z.string().min(1).max(80)).max(20),
  releaseYear: z.number().int().min(1800).max(2200).nullable(),
  durationSeconds: z.number().positive().nullable(),
  contentLanguage: z
    .string()
    .regex(/^[a-z]{2,3}(-[A-Z]{2})?$/)
    .nullable(),
});

export const QudraOpenSeason = z.object({
  seasonNumber: z.number().int().positive(),
  order: z.number().int().positive(),
  title: z.string().min(1).max(300).nullable(),
  description: z.string().min(1).max(2000).nullable(),
});

const QudraOpenSourceBase = z.object({
  sourceId: z.string().min(1).max(160),
  title: z.string().min(1).max(300),
  mediaClass: QudraOpenMediaClass,
  productionDesignation: QudraOpenProductionDesignation,
  metadata: QudraOpenSourceMetadata,
  artwork: QudraOpenArtwork.nullable(),
  attribution: QudraOpenAttribution,
  capabilities: QudraOpenCapabilities,
  compatibility: QudraOpenCompatibility,
  legalEvidence: QudraOpenLegalEvidence,
  webpageUrl: Url,
  directOrigin: QudraOpenDirectOrigin.nullable(),
  sourceHealth: QudraOpenSourceHealth,
  availability: QudraOpenAvailability,
  originState: QudraOpenOriginState,
  replacement: QudraOpenReplacement.nullable(),
  fallback: QudraOpenFallback.nullable(),
  controlPlaneProxiesBytes: z.literal(false),
});

export const QudraOpenEpisode = QudraOpenSourceBase.extend({
  mediaClass: z.literal('MOVIE'),
  episodeNumber: z.number().int().positive(),
  episodeOrder: z.number().int().positive(),
  synopsis: z.string().min(1).max(1000),
});

export const QudraOpenSeries = z.object({
  seriesId: z.string().min(1).max(160),
  title: z.string().min(1).max(300),
  mediaClass: z.literal('SERIES'),
  productionDesignation: QudraOpenProductionDesignation,
  description: z.string().min(1).max(2000).nullable(),
  metadata: QudraOpenSourceMetadata,
  artwork: QudraOpenArtwork.nullable(),
  attribution: QudraOpenAttribution,
  capabilities: QudraOpenCapabilities,
  compatibility: QudraOpenCompatibility,
  legalEvidence: QudraOpenLegalEvidence,
  webpageUrl: Url,
  sourceHealth: QudraOpenSourceHealth,
  availability: QudraOpenAvailability,
  originState: QudraOpenOriginState,
  season: QudraOpenSeason,
  episodes: z.array(QudraOpenEpisode).min(1),
  controlPlaneProxiesBytes: z.literal(false),
});

export const QudraOpenMediaItem = QudraOpenSourceBase.extend({
  mediaClass: z.enum(['LIVE_TV', 'MOVIE', 'RADIO']),
});

export const QudraOpenEpgCapabilities = z.object({
  nowNext: z.boolean(),
  fullSchedule: z.boolean(),
  catchUp: z.boolean(),
  notes: z.string().min(1).max(500),
});

export const QudraOpenManifest = z.object({
  manifestVersion: z.literal('3.0.0-t3b'),
  manifestId: z.string().min(1).max(160),
  title: z.string().min(1).max(300),
  permanent: z.literal(true),
  availableWithoutEntitlement: z.literal(true),
  requiresPaidEntitlement: z.literal(false),
  personalSourceConfig: z.literal(false),
  controlPlaneProxiesBytes: z.literal(false),
  generatedAt: UtcTimestamp,
  mediaClasses: z.array(QudraOpenMediaClass).length(4),
  sourceRegister: z.array(QudraOpenMediaItem),
  liveTv: z.array(QudraOpenMediaItem),
  // Category index; full lawful descriptors live in sourceRegister.
  movies: z.array(z.string().min(1)),
  series: z.array(QudraOpenSeries),
  radio: z.array(QudraOpenMediaItem),
  testOnly: z.object({
    liveTv: z.array(QudraOpenMediaItem),
    radio: z.array(QudraOpenMediaItem),
  }),
  epg: QudraOpenEpgCapabilities,
});

export const QudraOpenManifestList = z.object({
  manifests: z.array(QudraOpenManifest),
});

export type QudraOpenMediaClass = z.infer<typeof QudraOpenMediaClass>;
export type QudraOpenProductionDesignation = z.infer<typeof QudraOpenProductionDesignation>;
export type QudraOpenVerificationStatus = z.infer<typeof QudraOpenVerificationStatus>;
export type QudraOpenAvailabilityStatus = z.infer<typeof QudraOpenAvailabilityStatus>;
export type QudraOpenHealthStatus = z.infer<typeof QudraOpenHealthStatus>;
export type QudraOpenResolution = z.infer<typeof QudraOpenResolution>;
export type QudraOpenArtworkStatus = z.infer<typeof QudraOpenArtworkStatus>;
export type QudraOpenArtworkFallback = z.infer<typeof QudraOpenArtworkFallback>;
export type QudraOpenCompatibilityClass = z.infer<typeof QudraOpenCompatibilityClass>;
export type QudraOpenGeography = z.infer<typeof QudraOpenGeography>;
export type QudraOpenLegalEvidence = z.infer<typeof QudraOpenLegalEvidence>;
export type QudraOpenFormat = z.infer<typeof QudraOpenFormat>;
export type QudraOpenDirectOrigin = z.infer<typeof QudraOpenDirectOrigin>;
export type QudraOpenSourceHealth = z.infer<typeof QudraOpenSourceHealth>;
export type QudraOpenAvailability = z.infer<typeof QudraOpenAvailability>;
export type QudraOpenReplacement = z.infer<typeof QudraOpenReplacement>;
export type QudraOpenFallback = z.infer<typeof QudraOpenFallback>;
export type QudraOpenArtwork = z.infer<typeof QudraOpenArtwork>;
export type QudraOpenAttribution = z.infer<typeof QudraOpenAttribution>;
export type QudraOpenCapabilities = z.infer<typeof QudraOpenCapabilities>;
export type QudraOpenCompatibility = z.infer<typeof QudraOpenCompatibility>;
export type QudraOpenOriginState = z.infer<typeof QudraOpenOriginState>;
export type QudraOpenSourceMetadata = z.infer<typeof QudraOpenSourceMetadata>;
export type QudraOpenSeason = z.infer<typeof QudraOpenSeason>;
export type QudraOpenEpisode = z.infer<typeof QudraOpenEpisode>;
export type QudraOpenSeries = z.infer<typeof QudraOpenSeries>;
export type QudraOpenMediaItem = z.infer<typeof QudraOpenMediaItem>;
export type QudraOpenEpgCapabilities = z.infer<typeof QudraOpenEpgCapabilities>;
export type QudraOpenManifest = z.infer<typeof QudraOpenManifest>;
export type QudraOpenManifestList = z.infer<typeof QudraOpenManifestList>;
