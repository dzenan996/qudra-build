// @polsia:user-owned — QUDRA T2 source wire contracts.
import { z } from 'zod';

export const QudraActiveSourceKind = z.enum(['QUDRA_OPEN', 'PERSONAL_SOURCE']);
export const QudraSourceWrite = z.object({
  label: z.string().min(1).max(128),
  sourceType: z.literal('personal_source'),
  endpointUrl: z.string().url().max(2048).optional(),
  epgUrl: z.string().url().max(2048).optional(),
  sourceTimezone: z.string().max(64).optional(),
  utcOffsetMinutes: z.number().int().min(-840).max(840).optional(),
  slot: z.union([z.literal(1), z.literal(2)]).optional(),
  // Write-only input. The server seals it; ciphertext is never client-supplied.
  secret: z.string().min(1).max(4096).optional(),
  clearSecret: z.boolean().optional(),
  configVersion: z.number().int().positive().optional(),
});
export const QudraSourceConfig = z.object({
  id: z.string(),
  deviceId: z.string(),
  label: z.string(),
  sourceType: z.literal('personal_source'),
  endpointUrl: z.string().nullable(),
  epgUrl: z.string().nullable(),
  sourceTimezone: z.string().nullable(),
  utcOffsetMinutes: z.number().int().nullable(),
  slot: z.number().int().min(1).max(2).nullable(),
  hasSecret: z.boolean(),
  secretStorage: z.object({
    keyReference: z.string().nullable(),
    keyVersion: z.number().int().nullable(),
    redacted: z.literal(true),
  }),
  configVersion: z.number().int().positive(),
});
export const QudraSourceList = z.object({ items: z.array(QudraSourceConfig) });
export const QudraActiveSource = z.object({
  deviceId: z.string(),
  kind: QudraActiveSourceKind,
  sourceConfigId: z.string().nullable(),
});
export const QudraActiveSourceSelection = z.object({
  kind: QudraActiveSourceKind,
  sourceConfigId: z.string().nullable().optional(),
});

export type QudraSourceWriteInput = z.infer<typeof QudraSourceWrite>;
