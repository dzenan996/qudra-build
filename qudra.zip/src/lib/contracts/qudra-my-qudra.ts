// @polsia:user-owned — My Qudra account/device summary contract.
import { z } from 'zod';
import { QudraAccess } from './qudra-access';
import { QudraDevice } from './qudra-device';
import { QudraActiveSource, QudraSourceConfig } from './qudra-source';
import { QudraSyncStatus } from './qudra-sync';

export const QudraDeviceSummary = QudraDevice.extend({
  displayName: z.string().nullable(),
  access: QudraAccess,
  sources: z.array(QudraSourceConfig),
  activeSource: QudraActiveSource,
  sync: z.array(QudraSyncStatus),
  partnerMetadata: z.record(z.string(), z.string()).nullable(),
});
export const QudraMe = z.object({
  authenticated: z.boolean(),
  optionalAccount: z.boolean(),
  account: z.object({ id: z.string(), customerId: z.string(), provider: z.string() }).nullable(),
  devices: z.array(QudraDeviceSummary),
});
