// @polsia:user-owned — QUDRA T2 entitlement wire contracts.
import { z } from 'zod';

export const QudraEntitlementKind = z.enum(['ANNUAL', 'LIFETIME']);
export const QudraEntitlementProvenance = z.enum(['DIRECT', 'PARTNER']);
export const QudraEntitlementState = z.enum([
  'ACTIVE',
  'EXPIRED',
  'SUSPENDED',
  'REVOKED',
  'REPLACED',
]);
export const QudraEntitlementActivate = z.object({
  deviceId: z.string(),
  kind: QudraEntitlementKind,
  provenance: QudraEntitlementProvenance,
  activationRef: z.string().max(256).optional(),
  idempotencyKey: z.string().max(128).optional(),
});
export const QudraEntitlementTransition = z.object({
  state: z.enum(['EXPIRED', 'SUSPENDED', 'REVOKED', 'REPLACED']),
  reason: z.string().min(1).max(1024),
});
export const QudraEntitlement = z.object({
  id: z.string(),
  deviceId: z.string(),
  kind: QudraEntitlementKind,
  provenance: QudraEntitlementProvenance,
  state: QudraEntitlementState,
  activatedAt: z.string(),
  expiresAt: z.string().nullable(),
  lastValidatedAt: z.string().nullable(),
  graceUntil: z.string().nullable(),
  revalidationRequired: z.boolean(),
  entitlementVersion: z.number().int().positive(),
  replacedEntitlementId: z.string().nullable(),
});
export const QudraEntitlementResponse = z.object({
  entitlement: QudraEntitlement,
  usable: z.boolean(),
});
