// @polsia:user-owned — QUDRA T2 device wire contracts.
import { z } from 'zod';

export const QudraPlatform = z.enum(['ANDROID_TV', 'ANDROID_PHONE', 'ANDROID_TABLET']);
export const QudraProductFamily = z.enum(['TV', 'MOBILE']);
export const QudraDeviceStatus = z.enum(['UNPAIRED', 'PAIRING_PENDING', 'PAIRED', 'REVOKED']);
export const QudraAlgorithm = z.enum(['ED25519', 'P256', 'PLATFORM_DEFINED']);

export const QudraDeviceRegistration = z.object({
  publicDeviceId: z.string().min(8).max(256),
  platform: QudraPlatform,
  productFamily: QudraProductFamily,
  algorithm: QudraAlgorithm,
  publicKey: z.string().min(32).max(8192),
  appVersion: z.string().max(64).optional(),
  androidApiLevel: z.number().int().positive().optional(),
  deviceModel: z.string().max(128).optional(),
  displayName: z.string().max(128).optional(),
});

export const QudraDevice = QudraDeviceRegistration.omit({ publicKey: true }).extend({
  id: z.string(),
  customerId: z.string(),
  publicKeyFingerprint: z.string(),
  keyVersion: z.number().int().positive(),
  status: QudraDeviceStatus,
  registeredAt: z.string(),
  displayName: z.string().nullable().optional(),
});

export const QudraDeviceList = z.object({ items: z.array(QudraDevice) });
export const QudraDeviceMetadataUpdate = z.object({ displayName: z.string().max(128).nullable() });
export type QudraDeviceRegistrationInput = z.infer<typeof QudraDeviceRegistration>;
export type QudraDeviceOutput = z.infer<typeof QudraDevice>;
