// @polsia:user-owned — QUDRA T2 audit wire contracts.
import { z } from 'zod';

export const QudraAuditActor = z.enum([
  'DEVICE',
  'CUSTOMER',
  'PARTNER',
  'SUPER_ADMIN',
  'INTERNAL_SERVICE',
]);
export const QudraAuditEvent = z.object({
  id: z.string(),
  customerId: z.string(),
  deviceId: z.string().nullable(),
  actorType: QudraAuditActor,
  action: z.string(),
  entityType: z.string(),
  entityId: z.string(),
  correlationId: z.string(),
  metadata: z.record(z.unknown()),
  occurredAt: z.string(),
});
export const QudraAuditWrite = z.object({
  customerId: z.string(),
  deviceId: z.string().nullable().optional(),
  actorType: QudraAuditActor,
  actorId: z.string().max(256).nullable().optional(),
  action: z.string(),
  entityType: z.string(),
  entityId: z.string(),
  correlationId: z.string(),
  metadata: z.record(z.unknown()),
  occurredAt: z.string().datetime(),
});
export const QudraAuditList = z.object({ items: z.array(QudraAuditEvent) });
