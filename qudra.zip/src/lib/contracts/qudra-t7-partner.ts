// @polsia:user-owned
import { z } from 'zod';

export const QudraPartnerStatus = z.enum(['ACTIVE', 'SUSPENDED', 'REVOKED']);
export const QudraPartnerRole = z.enum(['ADMIN', 'OPERATOR']);
export const QudraPartnerBrandingState = z.enum(['PENDING', 'APPROVED', 'REJECTED']);
export const QudraPartner = z.object({
  id: z.string(),
  displayName: z.string(),
  status: QudraPartnerStatus,
  createdAt: z.string(),
  updatedAt: z.string(),
  activeMemberships: z.number().int().nonnegative(),
});
export const QudraPartnerList = z.object({ items: z.array(QudraPartner) });
export const QudraPartnerCreate = z.object({ displayName: z.string().trim().min(2).max(160) });
export const QudraPartnerStatusUpdate = z.object({ status: QudraPartnerStatus });
export const QudraPartnerMember = z.object({
  id: z.string(),
  userId: z.string(),
  role: QudraPartnerRole,
  active: z.boolean(),
});
export const QudraPartnerMembers = z.object({ items: z.array(QudraPartnerMember) });
export const QudraPartnerMemberWrite = z.object({
  userId: z.string().min(1),
  role: QudraPartnerRole,
  active: z.boolean().default(true),
});
export const QudraPartnerScope = z.object({
  id: z.string(),
  customerId: z.string(),
  status: z.enum(['ACTIVE', 'INACTIVE']),
});
export const QudraPartnerScopeList = z.object({ items: z.array(QudraPartnerScope) });
export const QudraPartnerScopeWrite = z.object({
  customerId: z.string().min(1),
  active: z.boolean().default(true),
});
export const QudraPartnerBranding = z.object({
  state: QudraPartnerBrandingState,
  proposed: z.object({
    displayName: z.string().nullable(),
    logoUrl: z.string().nullable(),
    supportEmail: z.string().nullable(),
    supportPhone: z.string().nullable(),
  }),
  approved: z.object({
    displayName: z.string().nullable(),
    logoUrl: z.string().nullable(),
    supportEmail: z.string().nullable(),
    supportPhone: z.string().nullable(),
  }),
});
export const QudraPartnerBrandingWrite = z.object({
  displayName: z.string().trim().min(2).max(160).nullable(),
  logoUrl: z.string().url().max(2048).nullable(),
  supportEmail: z.string().email().max(320).nullable(),
  supportPhone: z.string().max(64).nullable(),
});
export const QudraPartnerBrandingDecision = z.object({
  decision: z.enum(['APPROVED', 'REJECTED']),
  reason: z.string().max(1024).optional(),
});
export const QudraPartnerSummary = z.object({
  partner: QudraPartner.pick({
    id: true,
    displayName: true,
    status: true,
    createdAt: true,
    updatedAt: true,
  }),
  customers: z.number().int().nonnegative(),
  devices: z.number().int().nonnegative(),
  balance: z.number().int().nonnegative(),
  branding: QudraPartnerBranding.nullable(),
});
export const QudraPartnerDetail = z.object({
  partner: QudraPartner,
  policy: z
    .object({
      allowTv: z.boolean(),
      allowMobile: z.boolean(),
      allowAnnual: z.boolean(),
      allowLifetime: z.boolean(),
    })
    .nullable(),
  scopeCount: z.number().int().nonnegative(),
  balance: z.object({
    partnerId: z.string(),
    balance: z.number().int().nonnegative(),
    version: z.number().int().nonnegative(),
  }),
  branding: QudraPartnerBranding.nullable(),
});
