// @polsia:user-owned — local-only EPG capability and mapping contract.
import { z } from 'zod';

export const QudraEpgMapping = z.object({
  sourceChannelId: z.string(),
  displayName: z.string(),
  xmltvId: z.string().nullable(),
});
export const QudraEpgSnapshot = z.object({
  format: z.literal('XMLTV'),
  timezone: z.string().nullable(),
  utcOffsetMinutes: z.number().int().nullable(),
  state: z.enum(['FRESH', 'STALE', 'UNAVAILABLE']),
  channelCount: z.number().int().nonnegative(),
  programmeCount: z.number().int().nonnegative(),
  nowNext: z.boolean(),
  fullSchedule: z.boolean(),
  mappings: z.array(QudraEpgMapping),
});
export type QudraEpgSnapshotOutput = z.infer<typeof QudraEpgSnapshot>;
