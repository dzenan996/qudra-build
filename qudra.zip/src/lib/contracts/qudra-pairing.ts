// @polsia:user-owned — QUDRA T2 pairing wire contracts.
import { z } from 'zod';

export const QudraPairingState = z.enum([
  'PAIRING_PENDING',
  'PAIRED',
  'CANCELLED',
  'EXPIRED',
  'REVOKED',
  'REPLAYED',
]);
export const QudraPairingCreate = z.object({
  deviceId: z.string().min(1),
  idempotencyKey: z.string().max(128).optional(),
});
export const QudraPairingComplete = z.object({ response: z.string().min(1).max(8192) });
export const QudraPairingChallenge = z.object({
  id: z.string(),
  deviceId: z.string(),
  state: QudraPairingState,
  expiresAt: z.string(),
  attemptCount: z.number().int(),
  maxAttempts: z.literal(5),
  pairingCode: z.string().optional(),
});
export const QudraPairingQr = z.object({
  id: z.string(),
  representation: z.string(),
  expiresAt: z.string(),
});
export const QudraPairingResult = z.object({
  challengeId: z.string(),
  state: QudraPairingState,
  deviceId: z.string(),
  sessionToken: z.string().optional(),
  sessionExpiresAt: z.string().datetime().optional(),
});
export type QudraPairingCreateInput = z.infer<typeof QudraPairingCreate>;
