// @polsia:user-owned — QUDRA Device-session wire contract.
import { z } from 'zod';

export const QudraDeviceSession = z.object({
  deviceId: z.string(),
  keyVersion: z.number().int().positive(),
  expiresAt: z.string().datetime(),
  sessionToken: z.string().optional(),
});

export type QudraDeviceSessionOutput = z.infer<typeof QudraDeviceSession>;
