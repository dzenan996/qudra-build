// @polsia:user-owned — customer-readable privacy and Data Safety inventory contract.
import { z } from 'zod';

export const PrivacyInventoryItem = z.object({
  label: z.string(),
  location: z.enum(['cloud', 'device', 'direct-origin', 'not-collected']),
  details: z.string(),
  playDataSafety: z.array(z.string()),
});

export const PrivacyInventory = z.object({
  product: z.literal('QUDRA'),
  accountOptional: z.literal(true),
  items: z.array(PrivacyInventoryItem),
  ownerActionRequired: z.array(z.string()),
});

export type PrivacyInventoryOutput = z.infer<typeof PrivacyInventory>;
