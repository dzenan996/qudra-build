// @polsia:user-owned — QUDRA T4C anonymous Device bootstrap contracts.
import { z } from 'zod';

const bootstrapDeviceFields = {
  publicDeviceId: z.string().min(8).max(256),
  algorithm: z.literal('P256'),
  publicKey: z.string().min(32).max(8192),
  appVersion: z.string().max(64).optional(),
  androidApiLevel: z.number().int().positive().optional(),
  deviceModel: z.string().max(128).optional(),
};

export const QudraBootstrapChallengeCreate = z.union([
  z.object({
    ...bootstrapDeviceFields,
    platform: z.literal('ANDROID_TV'),
    productFamily: z.literal('TV'),
  }),
  z.object({
    ...bootstrapDeviceFields,
    platform: z.literal('ANDROID_PHONE'),
    productFamily: z.literal('MOBILE'),
  }),
  z.object({
    ...bootstrapDeviceFields,
    platform: z.literal('ANDROID_TABLET'),
    productFamily: z.literal('MOBILE'),
  }),
]);

export const QudraBootstrapQr = z.object({
  id: z.string().min(1),
  representation: z.string().min(1),
  expiresAt: z.string().datetime(),
});

export const QudraBootstrapChallenge = z.object({
  id: z.string().min(1),
  deviceId: z.string().min(1),
  kind: z.literal('BOOTSTRAP'),
  keyVersion: z.number().int().positive(),
  state: z.literal('PAIRING_PENDING'),
  expiresAt: z.string().datetime(),
  attemptCount: z.number().int().min(0).max(5),
  maxAttempts: z.literal(5),
  nonce: z.string().min(32),
  qr: QudraBootstrapQr,
});

export const QudraBootstrapComplete = z.object({
  nonce: z.string().min(32).max(512),
  proof: z.string().min(1).max(8192),
});

export const QudraBootstrapResult = z.object({
  challengeId: z.string().min(1),
  deviceId: z.string().min(1),
  state: z.literal('PAIRED'),
  sessionToken: z.string().min(1),
  sessionExpiresAt: z.string().datetime(),
});

export type QudraBootstrapChallengeCreateInput = z.infer<typeof QudraBootstrapChallengeCreate>;
export type QudraBootstrapCompleteInput = z.infer<typeof QudraBootstrapComplete>;
