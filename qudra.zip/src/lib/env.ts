// @polsia:shared — edit only through declared slots. Code installed by polsia/template-next@0.3.0.
//
// Typed env via @t3-oss/env-nextjs.
//
// Modules contribute env vars via their manifest `contributions` block.
// The installer regenerates this file's slots between the markers below.
// Hand-editing outside those slots is rejected by the ownership validator.
//
// The `no-secrets-in-client-bundle` validator scans the build output and rejects
// the install if any non-NEXT_PUBLIC_ env name appears in client chunks.

import { createEnv } from '@t3-oss/env-nextjs';
import { z } from 'zod';

export const env = createEnv({
  server: {
    NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
    // D24: Prisma is the framework-native DB client. DATABASE_URL is
    // injected by Polsia at deploy time (D23). The actual Postgres is
    // provisioned by a separate Polsia service; this module ships the
    // client only.
    DATABASE_URL: z.string().url(),
    // @polsia:slot env_vars_server start
    // Modules append additional server-side env vars here at install time.
    // @polsia:contrib better-auth start
    BETTER_AUTH_SECRET: z.string().min(1),
    BETTER_AUTH_URL: z.string().url(),
    BETTER_AUTH_TRUSTED_ORIGINS: z.string().optional(),
    POLSIA_OWNER_EMAIL: z.string().optional(),
    // @polsia:contrib better-auth end
    QUDRA_INTERNAL_SERVICE_CREDENTIALS: z.string().optional(),
    QUDRA_PAIRING_DEVICE_RATE_LIMIT_PER_HOUR: z.coerce.number().int().positive().default(5),
    QUDRA_PAIRING_SOURCE_RATE_LIMIT_PER_HOUR: z.coerce.number().int().positive().default(20),
    QUDRA_BOOTSTRAP_FINGERPRINT_RATE_LIMIT_PER_HOUR: z.coerce.number().int().positive().default(5),
    QUDRA_BOOTSTRAP_SOURCE_RATE_LIMIT_PER_HOUR: z.coerce.number().int().positive().default(20),
    QUDRA_SOURCE_ENVELOPE_PROVIDER: z.string().min(1).optional(),
    // Owner-controlled envelope key ring. JSON object: {"1":"base64url-32-byte-key"}.
    // Optional at deploy so QUDRA OPEN and metadata-only sources remain usable;
    // credential-bearing writes fail closed until the owner configures it.
    QUDRA_SOURCE_ENVELOPE_KEY_RING: z.string().optional(),
    QUDRA_SOURCE_ENVELOPE_ACTIVE_KEY_VERSION: z.coerce.number().int().positive().optional(),
    // @polsia:slot env_vars_server end
  },

  client: {
    NEXT_PUBLIC_APP_URL: z.string().url().default('http://localhost:3000'),
    // Base for @/lib/api-client + proxy.ts connect-src. Default-empty
    // (unset) means same-origin `/api`; set only for an external API origin.
    NEXT_PUBLIC_API_URL: z.string().url().optional(),
    // @polsia:slot env_vars_client start
    // Modules append NEXT_PUBLIC_* env vars here at install time.
    // @polsia:slot env_vars_client end
  },

  runtimeEnv: {
    NODE_ENV: process.env.NODE_ENV,
    DATABASE_URL: process.env.DATABASE_URL,
    NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
    NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL,
    // @polsia:slot env_runtime start
    // Modules append runtime-env entries here at install time.
    // @polsia:contrib better-auth start
    BETTER_AUTH_SECRET: process.env.BETTER_AUTH_SECRET,
    BETTER_AUTH_URL: process.env.BETTER_AUTH_URL,
    BETTER_AUTH_TRUSTED_ORIGINS: process.env.BETTER_AUTH_TRUSTED_ORIGINS,
    POLSIA_OWNER_EMAIL: process.env.POLSIA_OWNER_EMAIL,
    // @polsia:contrib better-auth end
    QUDRA_INTERNAL_SERVICE_CREDENTIALS: process.env.QUDRA_INTERNAL_SERVICE_CREDENTIALS,
    QUDRA_PAIRING_DEVICE_RATE_LIMIT_PER_HOUR: process.env.QUDRA_PAIRING_DEVICE_RATE_LIMIT_PER_HOUR,
    QUDRA_PAIRING_SOURCE_RATE_LIMIT_PER_HOUR: process.env.QUDRA_PAIRING_SOURCE_RATE_LIMIT_PER_HOUR,
    QUDRA_BOOTSTRAP_FINGERPRINT_RATE_LIMIT_PER_HOUR:
      process.env.QUDRA_BOOTSTRAP_FINGERPRINT_RATE_LIMIT_PER_HOUR,
    QUDRA_BOOTSTRAP_SOURCE_RATE_LIMIT_PER_HOUR:
      process.env.QUDRA_BOOTSTRAP_SOURCE_RATE_LIMIT_PER_HOUR,
    QUDRA_SOURCE_ENVELOPE_PROVIDER: process.env.QUDRA_SOURCE_ENVELOPE_PROVIDER,
    QUDRA_SOURCE_ENVELOPE_KEY_RING: process.env.QUDRA_SOURCE_ENVELOPE_KEY_RING,
    QUDRA_SOURCE_ENVELOPE_ACTIVE_KEY_VERSION: process.env.QUDRA_SOURCE_ENVELOPE_ACTIVE_KEY_VERSION,
    // @polsia:slot env_runtime end
  },
  emptyStringAsUndefined: true,
  // SKIP_ENV_VALIDATION=1 bypasses validation for envless builds (lint/CI/local).
  skipValidation: !!process.env.SKIP_ENV_VALIDATION,
});
