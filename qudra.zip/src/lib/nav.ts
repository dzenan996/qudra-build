// @polsia:user-owned — app navigation rendered by SiteNav/SiteFooter and read by
// the sitemap. Edit it as pages are added or removed.
// This list is a convenience, not module registration.

export type NavGroup = 'primary' | 'secondary' | 'footer';

export interface NavItem {
  /** Visible link text. */
  label: string;
  /** App route, e.g. '/' or '/dashboard'. */
  href: string;
  /** Where it renders: top-nav 'primary'/'secondary', or 'footer'. */
  group: NavGroup;
  /** Group `primary` items into a dropdown: items sharing a `menu` value collapse
   *  into one "<menu> ⌄" top-bar slot (e.g. `menu: 'Resources'` on Blog/Docs/
   *  Changelog). Keeps the bar short. Ignored for 'secondary'/'footer'. */
  menu?: string;
  /** When true, render only if a session exists (see site-nav.tsx). */
  requiresAuth?: boolean;
  /** Sort key within a group (ascending); unordered items fall to the end. */
  order?: number;
}

// Keep the bar short: ~3-5 primary slots, group the tail with `menu`, push the
// rest to 'footer' (SiteNav overflows extras into a "More" dropdown). Example:
//   { label: 'Pricing', href: '/pricing', group: 'primary' },
//   { label: 'Blog',    href: '/blog',    group: 'primary', menu: 'Resources' },
//   { label: 'Docs',    href: '/docs',    group: 'primary', menu: 'Resources' },
//   { label: 'Sign in', href: '/login',   group: 'secondary' },
export const navItems: NavItem[] = [
  { label: 'Početna', href: '/', group: 'primary', order: 0 },
  { label: 'Proizvod', href: '/#proizvod', group: 'primary', order: 10 },
  { label: 'Za partnere', href: '/#partneri', group: 'primary', order: 20 },
  { label: 'Sigurnost', href: '/#sigurnost', group: 'primary', order: 30 },
  { label: 'My Qudra', href: '/my-qudra', group: 'primary', order: 40 },
  { label: 'Kontakt', href: 'mailto:qudra@polsia.app', group: 'secondary', order: 0 },
  { label: 'Prijava', href: '/login', group: 'secondary', order: 10 },
  { label: 'Control plane', href: '/dashboard', group: 'footer', requiresAuth: true, order: 20 },
  { label: 'Partner', href: '/partner', group: 'footer', requiresAuth: true, order: 30 },
  {
    label: 'Admin / Partneri',
    href: '/admin/partners',
    group: 'footer',
    requiresAuth: true,
    order: 40,
  },
  {
    label: 'Admin / Operacije',
    href: '/admin/operations',
    group: 'footer',
    requiresAuth: true,
    order: 50,
  },
  { label: 'QUDRA OPEN', href: '/#qudra-open', group: 'footer', order: 0 },
  { label: 'Licenca po uređaju', href: '/#licenca', group: 'footer', order: 10 },
  { label: 'Privatnost i Data Safety', href: '/privacy', group: 'footer', order: 60 },
  { label: 'Brisanje računa', href: '/account-deletion', group: 'footer', order: 70 },
];
