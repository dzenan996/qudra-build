// @polsia:user-owned — brand identity. Edit freely. `site.ts` re-exports
// siteName/siteDescription; `manifest.ts` + `opengraph-image.tsx` read `brandVisual`.

export const siteName = 'QUDRA';
export const siteDescription = 'Legalni reproduktor i upravljanje licencama po uređaju.';

// PWA + social-share colors. HEX only (the oklch() tokens in globals.css aren't
// readable here) — set to match your brand seed.
export const brandVisual = {
  /** PWA browser-UI / status-bar color. */
  themeColor: '#bd791c',
  /** PWA splash + install background. */
  backgroundColor: '#f5f1e8',
  /** Social-share (OG/Twitter) image. */
  og: {
    background: '#171815',
    foreground: '#f3b34f',
    /** Second line under the site name; '' hides it. */
    tagline: 'Legalni reproduktor i upravljanje licencama po uređaju.',
  },
} as const;
