// @polsia:user-owned — current-user account status and deletion boundary.
import 'server-only';

import { headers } from 'next/headers';
import { NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import {
  AccountDeletionRequest,
  AccountDeletionResult,
  AccountDeletionStatus,
  accountDeletionConfirmation,
} from '@/lib/contracts/account-deletion';
import { getSessionUser, requireAuth } from '@/lib/require-auth';

export const dynamic = 'force-dynamic';

const retainedData = [
  'QUDRA customer, Device, license/entitlement and replacement records may remain for integrity.',
  'Append-only credit, activation and audit records are not silently deleted.',
  'Personal Source catalogue, EPG and detailed viewing state remain Device-local.',
];

const ownerActionRequired = [
  'Owner/legal must decide retention periods, company identity and lawful basis.',
  'Owner must confirm any source-secret ciphertext/key-reference treatment before production deletion policy is published.',
];

export async function GET() {
  const user = await getSessionUser();
  return NextResponse.json(
    AccountDeletionStatus.parse({
      authenticated: Boolean(user),
      deletionAvailable: Boolean(user),
      accountOptional: true,
      confirmationPhrase: accountDeletionConfirmation,
      retainedData,
      ownerActionRequired,
    }),
  );
}

function statusCodeOf(error: unknown): number | undefined {
  if (typeof error !== 'object' || error === null || !('statusCode' in error)) return undefined;
  const value = error.statusCode;
  return typeof value === 'number' ? value : undefined;
}

export async function DELETE(request: Request) {
  try {
    await requireAuth(request);
  } catch (response) {
    return response as Response;
  }

  const body = AccountDeletionRequest.safeParse(await request.json().catch(() => null));
  if (!body.success) {
    return NextResponse.json(
      { errors: { confirmation: `Upišite točno: ${accountDeletionConfirmation}` } },
      { status: 400 },
    );
  }

  try {
    // Better Auth owns deletion of User, Account and Session rows. Its
    // beforeDelete hook invokes the QUDRA cleanup for this exact user id.
    const result = await auth.api.deleteUser({
      headers: await headers(),
      body: body.data.password ? { password: body.data.password } : {},
    });

    return NextResponse.json(
      AccountDeletionResult.parse({
        success: result.success,
        message: 'QUDRA račun i sesije su obrisani; zadržani zapisi ostaju za Owner/legal odluku.',
      }),
    );
  } catch (error) {
    const status = statusCodeOf(error);
    if (status === 401) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (status === 400) {
      return NextResponse.json(
        {
          error: 'Ponovno se autentificirajte ili unesite lozinku prije brisanja računa.',
          requiresReauth: true,
        },
        { status: 409 },
      );
    }

    // Keep the user id out of responses and logs; auth/business layers own
    // their error handling and the route exposes only a generic failure.
    return NextResponse.json({ error: 'Account deletion failed' }, { status: 500 });
  }
}
