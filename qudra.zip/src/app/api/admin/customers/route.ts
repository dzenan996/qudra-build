import 'server-only';
import { NextResponse } from 'next/server';
import { adminCustomers } from '@/lib/business/qudra/admin-control-plane';
import { requireSuperAdminApi } from '@/lib/business/qudra/partner';
import { routeError } from '@/lib/business/qudra/route-helpers';
import { QudraAdminCustomers } from '@/lib/contracts/qudra-t7-admin';
export async function GET() {
  try {
    await requireSuperAdminApi();
    return NextResponse.json(QudraAdminCustomers.parse({ items: await adminCustomers() }));
  } catch (error) {
    return routeError(error);
  }
}
