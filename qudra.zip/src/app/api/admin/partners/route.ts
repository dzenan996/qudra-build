import 'server-only';
import { NextResponse } from 'next/server';
import { createPartner, listPartners } from '@/lib/business/qudra/admin-control-plane';
import { requireSuperAdminApi } from '@/lib/business/qudra/partner';
import { requestBody, routeError } from '@/lib/business/qudra/route-helpers';
import {
  QudraPartner,
  QudraPartnerCreate,
  QudraPartnerList,
} from '@/lib/contracts/qudra-t7-partner';

export async function GET() {
  try {
    await requireSuperAdminApi();
    return NextResponse.json(QudraPartnerList.parse({ items: await listPartners() }));
  } catch (error) {
    return routeError(error);
  }
}
export async function POST(request: Request) {
  try {
    await requireSuperAdminApi();
    const parsed = QudraPartnerCreate.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const partner = await createPartner(parsed.data.displayName);
    return NextResponse.json(
      QudraPartner.parse({
        id: partner.id,
        displayName: partner.displayName,
        status: partner.status,
        createdAt: partner.createdAt.toISOString(),
        updatedAt: partner.updatedAt.toISOString(),
        activeMemberships: 0,
      }),
      { status: 201 },
    );
  } catch (error) {
    return routeError(error);
  }
}
