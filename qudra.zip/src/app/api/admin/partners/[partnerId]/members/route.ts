import 'server-only';
import { NextResponse } from 'next/server';
import { listPartnerMembers, managePartnerMember } from '@/lib/business/qudra/admin-control-plane';
import { requireSuperAdminApi } from '@/lib/business/qudra/partner';
import { requestBody, routeError } from '@/lib/business/qudra/route-helpers';
import {
  QudraPartnerMember,
  QudraPartnerMembers,
  QudraPartnerMemberWrite,
} from '@/lib/contracts/qudra-t7-partner';

export async function GET(_request: Request, context: { params: Promise<{ partnerId: string }> }) {
  try {
    await requireSuperAdminApi();
    const rows = await listPartnerMembers((await context.params).partnerId);
    return NextResponse.json(QudraPartnerMembers.parse({ items: rows }));
  } catch (error) {
    return routeError(error);
  }
}
export async function POST(request: Request, context: { params: Promise<{ partnerId: string }> }) {
  try {
    await requireSuperAdminApi();
    const parsed = QudraPartnerMemberWrite.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const row = await managePartnerMember((await context.params).partnerId, parsed.data);
    return NextResponse.json(QudraPartnerMember.parse(row), { status: 201 });
  } catch (error) {
    return routeError(error);
  }
}
