import 'server-only';
import { NextResponse } from 'next/server';
import { listPartnerScopes, managePartnerScope } from '@/lib/business/qudra/admin-control-plane';
import { requireSuperAdminApi } from '@/lib/business/qudra/partner';
import { requestBody, routeError } from '@/lib/business/qudra/route-helpers';
import { QudraPartnerScopeList, QudraPartnerScopeWrite } from '@/lib/contracts/qudra-t7-partner';

export async function GET(_request: Request, context: { params: Promise<{ partnerId: string }> }) {
  try {
    await requireSuperAdminApi();
    const rows = await listPartnerScopes((await context.params).partnerId);
    return NextResponse.json(QudraPartnerScopeList.parse({ items: rows }));
  } catch (error) {
    return routeError(error);
  }
}

export async function POST(request: Request, context: { params: Promise<{ partnerId: string }> }) {
  try {
    await requireSuperAdminApi();
    const parsed = QudraPartnerScopeWrite.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const row = await managePartnerScope(
      (await context.params).partnerId,
      parsed.data.customerId,
      parsed.data.active,
    );
    return NextResponse.json(QudraPartnerScopeList.shape.items.element.parse(row), { status: 201 });
  } catch (error) {
    return routeError(error);
  }
}
