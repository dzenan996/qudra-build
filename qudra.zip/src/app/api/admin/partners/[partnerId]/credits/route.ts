import 'server-only';
import { NextResponse } from 'next/server';
import { adminCreditOperation } from '@/lib/business/qudra/admin-control-plane';
import { requireSuperAdminApi } from '@/lib/business/qudra/partner';
import { listPartnerCredits } from '@/lib/business/qudra/partner-credits';
import { requestBody, routeError } from '@/lib/business/qudra/route-helpers';
import { QudraCreditLedger, QudraCreditOperation } from '@/lib/contracts/qudra-t7-credits';

export async function GET(_request: Request, context: { params: Promise<{ partnerId: string }> }) {
  try {
    await requireSuperAdminApi();
    const result = await listPartnerCredits((await context.params).partnerId);
    return NextResponse.json(
      QudraCreditLedger.parse({
        balance: {
          partnerId: result.account.partnerId,
          balance: result.account.balance,
          version: result.account.version,
        },
        entries: result.entries.map((entry) => ({
          id: entry.id,
          delta: entry.delta,
          kind: entry.kind,
          actorId: entry.actorId,
          reference: entry.reference,
          operationKey: entry.operationKey,
          createdAt: entry.createdAt.toISOString(),
        })),
      }),
    );
  } catch (error) {
    return routeError(error);
  }
}
export async function POST(request: Request, context: { params: Promise<{ partnerId: string }> }) {
  try {
    await requireSuperAdminApi();
    const body = await requestBody(request);
    const kind =
      typeof body === 'object' &&
      body !== null &&
      'kind' in body &&
      (body as { kind?: unknown }).kind;
    const parsed = QudraCreditOperation.safeParse(body);
    if (!parsed.success || !['GRANT', 'ADJUSTMENT', 'REVERSAL'].includes(String(kind)))
      return NextResponse.json({ error: 'Invalid credit operation' }, { status: 400 });
    const result = await adminCreditOperation((await context.params).partnerId, {
      ...parsed.data,
      kind: kind as 'GRANT' | 'ADJUSTMENT' | 'REVERSAL',
    });
    return NextResponse.json(
      {
        balance: result.account.balance,
        entry: {
          id: result.entry.id,
          delta: result.entry.delta,
          kind: result.entry.kind,
          operationKey: result.entry.operationKey,
        },
      },
      { status: 201 },
    );
  } catch (error) {
    return routeError(error);
  }
}
