import 'server-only';
import { NextResponse } from 'next/server';
import { adminAuditEvents } from '@/lib/business/qudra/admin-control-plane';
import { requireSuperAdminApi } from '@/lib/business/qudra/partner';
import { routeError } from '@/lib/business/qudra/route-helpers';
import { QudraAdminAuditEvents } from '@/lib/contracts/qudra-t7-admin';
export async function GET() {
  try {
    await requireSuperAdminApi();
    return NextResponse.json(QudraAdminAuditEvents.parse({ items: await adminAuditEvents() }));
  } catch (error) {
    return routeError(error);
  }
}
