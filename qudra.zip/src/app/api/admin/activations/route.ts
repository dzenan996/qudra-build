import 'server-only';
import { NextResponse } from 'next/server';
import { requireSuperAdminApi } from '@/lib/business/qudra/partner';
import { routeError } from '@/lib/business/qudra/route-helpers';
import { QudraPartnerActivationList } from '@/lib/contracts/qudra-t7-activation';
import { prisma } from '@/lib/db';
export async function GET() {
  try {
    await requireSuperAdminApi();
    const rows = await prisma.qudraPartnerActivation.findMany({
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
    return NextResponse.json(
      QudraPartnerActivationList.parse({
        items: rows.map((row) => ({
          ...row,
          createdAt: row.createdAt.toISOString(),
          completedAt: row.completedAt?.toISOString() ?? null,
        })),
      }),
    );
  } catch (error) {
    return routeError(error);
  }
}
