import 'server-only';
import { NextResponse } from 'next/server';
import { requireSuperAdminApi } from '@/lib/business/qudra/partner';
import { decideTrialExceptionRequest } from '@/lib/business/qudra/partner-requests';
import { requestBody, routeError } from '@/lib/business/qudra/route-helpers';
import {
  QudraRequestDecision,
  QudraTrialExceptionRequests,
} from '@/lib/contracts/qudra-t7-requests';
import { prisma } from '@/lib/db';
export async function GET() {
  try {
    await requireSuperAdminApi();
    const rows = await prisma.qudraPartnerTrialExceptionRequest.findMany({
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
    return NextResponse.json(
      QudraTrialExceptionRequests.parse({
        items: rows.map((row) => ({
          ...row,
          createdAt: row.createdAt.toISOString(),
          decidedAt: row.decidedAt?.toISOString() ?? null,
        })),
      }),
    );
  } catch (error) {
    return routeError(error);
  }
}
export async function PATCH(request: Request) {
  try {
    await requireSuperAdminApi();
    const body = await requestBody(request);
    const requestId =
      typeof body === 'object' && body !== null && 'requestId' in body
        ? String((body as { requestId: unknown }).requestId)
        : '';
    const parsed = QudraRequestDecision.safeParse(body);
    if (!requestId || !parsed.success)
      return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
    const row = await decideTrialExceptionRequest(
      requestId,
      parsed.data.decision,
      parsed.data.reason,
    );
    return NextResponse.json({ id: row.id, status: row.status });
  } catch (error) {
    return routeError(error);
  }
}
