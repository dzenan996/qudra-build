import 'server-only';
import { NextResponse } from 'next/server';
import { adminDevices } from '@/lib/business/qudra/admin-control-plane';
import { requireSuperAdminApi } from '@/lib/business/qudra/partner';
import { routeError } from '@/lib/business/qudra/route-helpers';
import { QudraAdminDevices } from '@/lib/contracts/qudra-t7-admin';
export async function GET() {
  try {
    await requireSuperAdminApi();
    return NextResponse.json(QudraAdminDevices.parse({ items: await adminDevices() }));
  } catch (error) {
    return routeError(error);
  }
}
