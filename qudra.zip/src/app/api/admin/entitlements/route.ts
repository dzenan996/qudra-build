import 'server-only';
import { NextResponse } from 'next/server';
import { adminEntitlements } from '@/lib/business/qudra/admin-control-plane';
import { requireSuperAdminApi } from '@/lib/business/qudra/partner';
import { routeError } from '@/lib/business/qudra/route-helpers';
import { QudraAdminEntitlements } from '@/lib/contracts/qudra-t7-admin';
export async function GET() {
  try {
    await requireSuperAdminApi();
    const rows = await adminEntitlements();
    return NextResponse.json(
      QudraAdminEntitlements.parse({
        items: rows.map((row) => ({
          ...row,
          activatedAt: row.activatedAt.toISOString(),
          expiresAt: row.expiresAt?.toISOString() ?? null,
        })),
      }),
    );
  } catch (error) {
    return routeError(error);
  }
}
