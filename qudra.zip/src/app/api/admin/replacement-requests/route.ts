import 'server-only';
import { NextResponse } from 'next/server';
import { requireSuperAdminApi } from '@/lib/business/qudra/partner';
import { decideReplacementRequest } from '@/lib/business/qudra/partner-requests';
import { requestBody, routeError } from '@/lib/business/qudra/route-helpers';
import { QudraReplacementRequests, QudraRequestDecision } from '@/lib/contracts/qudra-t7-requests';
import { prisma } from '@/lib/db';
export async function GET() {
  try {
    await requireSuperAdminApi();
    const rows = await prisma.qudraPartnerReplacementRequest.findMany({
      orderBy: { requestedAt: 'desc' },
      take: 100,
    });
    return NextResponse.json(
      QudraReplacementRequests.parse({
        items: rows.map((row) => ({
          ...row,
          requestedAt: row.requestedAt.toISOString(),
          decidedAt: row.decidedAt?.toISOString() ?? null,
        })),
      }),
    );
  } catch (error) {
    return routeError(error);
  }
}
export async function PATCH(request: Request) {
  try {
    await requireSuperAdminApi();
    const body = await requestBody(request);
    const requestId =
      typeof body === 'object' && body !== null && 'requestId' in body
        ? String((body as { requestId: unknown }).requestId)
        : '';
    const parsed = QudraRequestDecision.safeParse(body);
    if (!requestId || !parsed.success)
      return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
    const row = await decideReplacementRequest(requestId, parsed.data.decision, parsed.data.reason);
    return NextResponse.json({ id: row.id, status: row.status });
  } catch (error) {
    return routeError(error);
  }
}
