// @polsia:user-owned — public, implementation-backed privacy inventory.
import 'server-only';

import { NextResponse } from 'next/server';
import { PrivacyInventory } from '@/lib/contracts/privacy';

export const dynamic = 'force-static';

const inventory = PrivacyInventory.parse({
  product: 'QUDRA',
  accountOptional: true,
  items: [
    {
      label: 'Account and authentication',
      location: 'cloud',
      details:
        'Optional name, email and Better Auth session metadata are stored in the QUDRA control plane when you create an account.',
      playDataSafety: [
        'Personal info: name, email address',
        'App activity: authentication/session metadata',
      ],
    },
    {
      label: 'Device identity and control plane',
      location: 'cloud',
      details:
        'QUDRA stores a public Device ID, platform/model/API metadata, public-key fingerprint and versioned session digest, plus Customer/Partner scope, diagnostics and redacted audit metadata.',
      playDataSafety: ['Device or other identifiers', 'App info and performance: diagnostics'],
    },
    {
      label: 'Source configuration metadata',
      location: 'cloud',
      details:
        'QUDRA stores label, source type, endpoint/EPG metadata, timezone, slot, config version, aggregate sync counts/status and capability flags. Credential-bearing values use an approved server envelope; plaintext is not returned by the API.',
      playDataSafety: ['App info and performance: configuration and diagnostics'],
    },
    {
      label: 'Personal Source secrets and catalogue',
      location: 'device',
      details:
        'Native source secrets stay in the Android Keystore. Parsed Personal Source catalogue, XMLTV/EPG rows, favorites, recent/continue state and detailed viewing state stay on the Device and are not sent to QUDRA Cloud.',
      playDataSafety: ['Not collected by QUDRA Cloud; device-local processing'],
    },
    {
      label: 'Playback and Cast transport',
      location: 'direct-origin',
      details:
        'Playlist/XMLTV and media retrieval go directly from the Device to the lawful Personal Source/origin. Cast receives only a supported receiver-safe direct URL and MIME; media bytes do not pass through QUDRA Cloud.',
      playDataSafety: ['No QUDRA Cloud collection of media bytes'],
    },
    {
      label: 'Not collected by QUDRA Cloud',
      location: 'not-collected',
      details:
        'QUDRA does not centralize Personal Source catalogue/EPG rows, detailed viewing history, Cloud DVR/recording data, commercial provider catalogue, payment data or media relay bytes.',
      playDataSafety: ['No collection declared for these categories'],
    },
  ],
  ownerActionRequired: [
    'OWNER_ACTION_REQUIRED: Owner/legal must supply company identity, lawful basis and retention periods.',
    'OWNER_ACTION_REQUIRED: Owner must complete final Play Console Data Safety and deletion answers for every published track.',
  ],
});

export function GET() {
  return NextResponse.json(inventory);
}
