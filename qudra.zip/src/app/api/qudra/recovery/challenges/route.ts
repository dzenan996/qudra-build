import 'server-only';
import { NextResponse } from 'next/server';
import { createRecovery } from '@/lib/business/qudra/recovery';
import {
  requestBody,
  routeAuthority,
  routeError,
  unauthorized,
} from '@/lib/business/qudra/route-helpers';
import { QudraRecoveryChallenge, QudraRecoveryCreate } from '@/lib/contracts/qudra-recovery';

export async function POST(request: Request) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const parsed = QudraRecoveryCreate.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const challenge = await createRecovery(
      authority,
      parsed.data.deviceId,
      parsed.data.evidenceCategory,
      parsed.data.idempotencyKey,
    );
    return NextResponse.json(
      QudraRecoveryChallenge.parse({
        id: challenge.id,
        deviceId: challenge.deviceId,
        evidenceCategory: challenge.evidenceCategory,
        state: challenge.state,
        attempts: challenge.attemptCount,
        maxAttempts: 5,
        expiresAt: challenge.expiresAt.toISOString(),
      }),
      { status: 201 },
    );
  } catch (error) {
    return routeError(error);
  }
}
