import 'server-only';
import { NextResponse } from 'next/server';
import { decideRecovery } from '@/lib/business/qudra/recovery';
import {
  requestBody,
  routeAuthority,
  routeError,
  unauthorized,
} from '@/lib/business/qudra/route-helpers';
import { QudraRecoveryDecision } from '@/lib/contracts/qudra-recovery';

export async function POST(
  request: Request,
  context: { params: Promise<{ challengeId: string }> },
) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const parsed = QudraRecoveryDecision.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const { challengeId } = await context.params;
    const result = await decideRecovery(authority, challengeId, parsed.data.decision);
    return NextResponse.json({ id: result.id, state: result.state });
  } catch (error) {
    return routeError(error);
  }
}
