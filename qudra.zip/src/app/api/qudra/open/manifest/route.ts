// @polsia:user-owned — verified QUDRA OPEN manifest read boundary.
import 'server-only';

import { NextResponse } from 'next/server';
import { getQudraOpenManifest } from '@/lib/business/qudra/open-runtime';
import { routeAuthority, unauthorized } from '@/lib/business/qudra/route-helpers';
import { QudraOpenManifest } from '@/lib/contracts/qudra-open';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  const authority = await routeAuthority(request);
  if (!authority) return unauthorized();

  // QUDRA OPEN is entitlement-free and separate from Personal SourceConfig.
  // This route returns descriptors only; playback remains origin-to-device.
  return NextResponse.json(QudraOpenManifest.parse(getQudraOpenManifest()));
}
