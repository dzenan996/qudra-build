import 'server-only';
import { NextResponse } from 'next/server';
import { DIAGNOSTIC_CODES } from '@/lib/business/qudra/diagnostics';
import { QudraDiagnosticCodeList } from '@/lib/contracts/qudra-diagnostics';

export async function GET() {
  return NextResponse.json(QudraDiagnosticCodeList.parse({ items: DIAGNOSTIC_CODES }));
}
