import 'server-only';

import { NextResponse } from 'next/server';
import { myQudraSummary } from '@/lib/business/qudra/account';
import { routeError } from '@/lib/business/qudra/route-helpers';
import { QudraMe } from '@/lib/contracts/qudra-my-qudra';
import { getSessionUser } from '@/lib/require-auth';

export async function GET() {
  try {
    const user = await getSessionUser();
    if (!user)
      return NextResponse.json(
        QudraMe.parse({ authenticated: false, optionalAccount: true, account: null, devices: [] }),
      );
    return NextResponse.json(
      QudraMe.parse(
        await myQudraSummary({
          kind: 'session',
          userId: user.id,
          isSuperAdmin: user.role === 'admin',
        }),
      ),
    );
  } catch (error) {
    return routeError(error);
  }
}
