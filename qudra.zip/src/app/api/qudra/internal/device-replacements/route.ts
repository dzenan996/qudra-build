import 'server-only';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { replaceDevice } from '@/lib/business/qudra/replacement';
import {
  requestBody,
  routeAuthority,
  routeError,
  unauthorized,
} from '@/lib/business/qudra/route-helpers';

const Replacement = z.object({
  oldDeviceId: z.string(),
  newDeviceId: z.string(),
  superAdminException: z.boolean().optional(),
});
export async function POST(request: Request) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const parsed = Replacement.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    return NextResponse.json(await replaceDevice(authority, parsed.data), { status: 201 });
  } catch (error) {
    return routeError(error);
  }
}
