import 'server-only';
import { NextResponse } from 'next/server';
import { appendAudit } from '@/lib/business/qudra/audit';
import {
  requestBody,
  routeAuthority,
  routeError,
  unauthorized,
} from '@/lib/business/qudra/route-helpers';
import { QudraAuditWrite } from '@/lib/contracts/qudra-audit';

export async function POST(request: Request) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const parsed = QudraAuditWrite.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const result = await appendAudit(authority, {
      ...parsed.data,
      occurredAt: new Date(parsed.data.occurredAt),
    });
    return NextResponse.json(
      {
        ...result,
        occurredAt: result.occurredAt.toISOString(),
        metadata: result.metadata as Record<string, unknown>,
      },
      { status: 201 },
    );
  } catch (error) {
    return routeError(error);
  }
}
