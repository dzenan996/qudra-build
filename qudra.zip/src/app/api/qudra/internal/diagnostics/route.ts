import 'server-only';
import { NextResponse } from 'next/server';
import { writeDiagnostic } from '@/lib/business/qudra/diagnostics';
import {
  requestBody,
  routeAuthority,
  routeError,
  unauthorized,
} from '@/lib/business/qudra/route-helpers';
import { QudraDiagnosticWrite } from '@/lib/contracts/qudra-diagnostics';

export async function POST(request: Request) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const parsed = QudraDiagnosticWrite.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const result = await writeDiagnostic(authority, {
      ...parsed.data,
      observedAt: new Date(parsed.data.observedAt),
    });
    return NextResponse.json(
      { ...result, observedAt: result.observedAt.toISOString() },
      { status: 201 },
    );
  } catch (error) {
    return routeError(error);
  }
}
