import 'server-only';
import { NextResponse } from 'next/server';
import { activateEntitlement, entitlementIsUsable } from '@/lib/business/qudra/entitlement';
import {
  requestBody,
  routeAuthority,
  routeError,
  unauthorized,
} from '@/lib/business/qudra/route-helpers';
import {
  QudraEntitlementActivate,
  QudraEntitlementResponse,
} from '@/lib/contracts/qudra-entitlement';

export async function POST(request: Request) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const parsed = QudraEntitlementActivate.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const entitlement = await activateEntitlement(authority, parsed.data);
    return NextResponse.json(
      QudraEntitlementResponse.parse({
        entitlement: {
          ...entitlement,
          deviceId: entitlement.deviceId,
          provenance: entitlement.provenance,
          activatedAt: entitlement.activatedAt.toISOString(),
          expiresAt: entitlement.expiresAt?.toISOString() ?? null,
          lastValidatedAt: entitlement.lastValidatedAt?.toISOString() ?? null,
          graceUntil: entitlement.graceUntil?.toISOString() ?? null,
          replacedEntitlementId: entitlement.replacedEntitlementId,
        },
        usable: entitlementIsUsable(entitlement),
      }),
      { status: 201 },
    );
  } catch (error) {
    return routeError(error);
  }
}
