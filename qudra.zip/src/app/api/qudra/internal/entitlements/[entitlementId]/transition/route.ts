import 'server-only';
import { NextResponse } from 'next/server';
import { transitionEntitlement } from '@/lib/business/qudra/entitlement';
import {
  requestBody,
  routeAuthority,
  routeError,
  unauthorized,
} from '@/lib/business/qudra/route-helpers';
import { QudraEntitlementTransition } from '@/lib/contracts/qudra-entitlement';

export async function POST(
  request: Request,
  context: { params: Promise<{ entitlementId: string }> },
) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const parsed = QudraEntitlementTransition.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const { entitlementId } = await context.params;
    const result = await transitionEntitlement(
      authority,
      entitlementId,
      parsed.data.state,
      parsed.data.reason,
    );
    return NextResponse.json({
      id: result.entitlement.id,
      state: result.entitlement.state,
      reason: result.reason,
    });
  } catch (error) {
    return routeError(error);
  }
}
