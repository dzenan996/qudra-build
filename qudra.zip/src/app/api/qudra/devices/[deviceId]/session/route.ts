import 'server-only';

import { NextResponse } from 'next/server';
import { issueDeviceSession, renewDeviceSession } from '@/lib/business/qudra/device-session';
import { routeAuthority, routeError, unauthorized } from '@/lib/business/qudra/route-helpers';
import { QudraDeviceSession } from '@/lib/contracts/qudra-device-session';

export async function POST(request: Request, context: { params: Promise<{ deviceId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const { deviceId } = await context.params;
    const existingToken = request.headers.get('x-qudra-device-session');
    const result = existingToken
      ? await renewDeviceSession(existingToken, deviceId)
      : await issueDeviceSession(authority, deviceId);
    if (result.deviceId !== deviceId)
      return NextResponse.json({ error: 'Device authority mismatch' }, { status: 403 });
    return NextResponse.json(
      QudraDeviceSession.parse({
        deviceId: result.deviceId,
        keyVersion: result.keyVersion,
        expiresAt: result.expiresAt.toISOString(),
        sessionToken: 'token' in result ? result.token : undefined,
      }),
      { status: 201 },
    );
  } catch (error) {
    return routeError(error);
  }
}
