import 'server-only';
import { NextResponse } from 'next/server';
import { effectiveAccess } from '@/lib/business/qudra/access';
import { routeAuthority, routeError, unauthorized } from '@/lib/business/qudra/route-helpers';
import { QudraAccess } from '@/lib/contracts/qudra-access';

export async function GET(request: Request, context: { params: Promise<{ deviceId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const { deviceId } = await context.params;
    return NextResponse.json(QudraAccess.parse(await effectiveAccess(authority, deviceId)));
  } catch (error) {
    return routeError(error);
  }
}
