import 'server-only';
import { NextResponse } from 'next/server';
import { rotateDeviceKey } from '@/lib/business/qudra/device-keys';
import {
  requestBody,
  routeAuthority,
  routeError,
  unauthorized,
} from '@/lib/business/qudra/route-helpers';
import { QudraDeviceRegistration } from '@/lib/contracts/qudra-device';

export async function POST(request: Request, context: { params: Promise<{ deviceId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const parsed = QudraDeviceRegistration.pick({ algorithm: true, publicKey: true }).safeParse(
      await requestBody(request),
    );
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const { deviceId } = await context.params;
    const result = await rotateDeviceKey(authority, deviceId, parsed.data);
    return NextResponse.json({
      deviceId,
      keyVersion: result.device.keyVersion,
      publicKeyFingerprint: result.device.publicKeyFingerprint,
    });
  } catch (error) {
    return routeError(error);
  }
}
