import 'server-only';
import { NextResponse } from 'next/server';
import { currentDiagnostics } from '@/lib/business/qudra/diagnostics';
import { routeAuthority, routeError, unauthorized } from '@/lib/business/qudra/route-helpers';
import { QudraDiagnosticList } from '@/lib/contracts/qudra-diagnostics';

export async function GET(request: Request, context: { params: Promise<{ deviceId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const { deviceId } = await context.params;
    const items = await currentDiagnostics(authority, deviceId);
    return NextResponse.json(
      QudraDiagnosticList.parse({
        items: items.map((item) => ({ ...item, observedAt: item.observedAt.toISOString() })),
      }),
    );
  } catch (error) {
    return routeError(error);
  }
}
