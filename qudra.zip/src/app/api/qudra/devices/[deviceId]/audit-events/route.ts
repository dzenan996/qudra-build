import 'server-only';
import { NextResponse } from 'next/server';
import { readAudit } from '@/lib/business/qudra/audit';
import { routeAuthority, routeError, unauthorized } from '@/lib/business/qudra/route-helpers';
import { QudraAuditList } from '@/lib/contracts/qudra-audit';

export async function GET(request: Request, context: { params: Promise<{ deviceId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const { deviceId } = await context.params;
    const items = await readAudit(authority, deviceId);
    return NextResponse.json(
      QudraAuditList.parse({
        items: items.map((item) => ({
          ...item,
          metadata: item.metadata as Record<string, unknown>,
          occurredAt: item.occurredAt.toISOString(),
        })),
      }),
    );
  } catch (error) {
    return routeError(error);
  }
}
