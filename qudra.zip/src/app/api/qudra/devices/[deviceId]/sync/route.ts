import 'server-only';

import { NextResponse } from 'next/server';
import {
  requestBody,
  routeAuthority,
  routeError,
  unauthorized,
} from '@/lib/business/qudra/route-helpers';
import { listSync, reportSync } from '@/lib/business/qudra/sync';
import { QudraSyncList, QudraSyncReport } from '@/lib/contracts/qudra-sync';

export async function GET(request: Request, context: { params: Promise<{ deviceId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const { deviceId } = await context.params;
    return NextResponse.json(QudraSyncList.parse({ items: await listSync(authority, deviceId) }));
  } catch (error) {
    return routeError(error);
  }
}

export async function POST(request: Request, context: { params: Promise<{ deviceId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const parsed = QudraSyncReport.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const { deviceId } = await context.params;
    const report = parsed.data;
    const result = await reportSync(authority, deviceId, {
      ...report,
      lastAttemptAt: report.lastAttemptAt ? new Date(report.lastAttemptAt) : undefined,
      lastSuccessAt: report.lastSuccessAt ? new Date(report.lastSuccessAt) : undefined,
      staleSince: report.staleSince ? new Date(report.staleSince) : undefined,
    });
    return NextResponse.json(QudraSyncList.shape.items.element.parse(result));
  } catch (error) {
    return routeError(error);
  }
}
