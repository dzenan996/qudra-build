import 'server-only';
import { NextResponse } from 'next/server';
import { routeAuthority, routeError, unauthorized } from '@/lib/business/qudra/route-helpers';
import { effectiveTrial, startTrial } from '@/lib/business/qudra/trial';
import { QudraTrialResponse } from '@/lib/contracts/qudra-trial';

export async function GET(request: Request, context: { params: Promise<{ deviceId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const { deviceId } = await context.params;
    const trial = await effectiveTrial(authority, deviceId);
    return NextResponse.json(
      QudraTrialResponse.parse({
        trial: {
          id: trial.id,
          deviceId,
          state: trial.state,
          startedAt: trial.startedAt?.toISOString() ?? null,
          endsAt: trial.endsAt?.toISOString() ?? null,
        },
        access: trial.active,
      }),
    );
  } catch (error) {
    return routeError(error);
  }
}

export async function POST(request: Request, context: { params: Promise<{ deviceId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const { deviceId } = await context.params;
    const trial = await startTrial(authority, deviceId);
    return NextResponse.json(
      QudraTrialResponse.parse({
        trial: {
          id: trial.id,
          deviceId,
          state: trial.state,
          startedAt: trial.startedAt?.toISOString() ?? null,
          endsAt: trial.endsAt?.toISOString() ?? null,
        },
        access: true,
      }),
      { status: 201 },
    );
  } catch (error) {
    return routeError(error);
  }
}
