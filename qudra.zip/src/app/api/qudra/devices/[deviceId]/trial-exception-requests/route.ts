import 'server-only';
import { NextResponse } from 'next/server';
import {
  requestBody,
  routeAuthority,
  routeError,
  unauthorized,
} from '@/lib/business/qudra/route-helpers';
import { requestTrialException } from '@/lib/business/qudra/trial';
import { QudraTrialExceptionCreate, QudraTrialExceptionRequest } from '@/lib/contracts/qudra-trial';

export async function POST(request: Request, context: { params: Promise<{ deviceId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const parsed = QudraTrialExceptionCreate.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const { deviceId } = await context.params;
    const result = await requestTrialException(authority, deviceId, parsed.data.reason);
    return NextResponse.json(
      QudraTrialExceptionRequest.parse({
        id: result.id,
        deviceId: result.deviceId,
        status: result.status,
        reason: result.reason,
        createdAt: result.createdAt.toISOString(),
      }),
      { status: 201 },
    );
  } catch (error) {
    return routeError(error);
  }
}
