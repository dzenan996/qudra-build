import 'server-only';

import { NextResponse } from 'next/server';
import { routeAuthority, routeError, unauthorized } from '@/lib/business/qudra/route-helpers';
import { listSync } from '@/lib/business/qudra/sync';
import { QudraCapabilities } from '@/lib/contracts/qudra-sync';

export async function GET(request: Request, context: { params: Promise<{ deviceId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const { deviceId } = await context.params;
    const sync = await listSync(authority, deviceId);
    return NextResponse.json(
      QudraCapabilities.parse({
        items: sync
          .filter((item) => item.sourceConfigId)
          .map((item) => ({
            sourceConfigId: item.sourceConfigId,
            state: item.state,
            ...item.capabilities,
          })),
      }),
    );
  } catch (error) {
    return routeError(error);
  }
}
