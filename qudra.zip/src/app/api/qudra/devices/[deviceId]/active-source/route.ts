import 'server-only';
import { NextResponse } from 'next/server';
import {
  requestBody,
  routeAuthority,
  routeError,
  unauthorized,
} from '@/lib/business/qudra/route-helpers';
import { getActiveSource, selectActiveSource } from '@/lib/business/qudra/sources';
import { QudraActiveSource, QudraActiveSourceSelection } from '@/lib/contracts/qudra-source';

export async function GET(request: Request, context: { params: Promise<{ deviceId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const { deviceId } = await context.params;
    const active = await getActiveSource(authority, deviceId);
    return NextResponse.json(
      QudraActiveSource.parse({
        deviceId,
        kind: active?.kind ?? 'QUDRA_OPEN',
        sourceConfigId: active?.activeSourceConfigId ?? null,
      }),
    );
  } catch (error) {
    return routeError(error);
  }
}

export async function PUT(request: Request, context: { params: Promise<{ deviceId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const parsed = QudraActiveSourceSelection.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const { deviceId } = await context.params;
    const active = await selectActiveSource(
      authority,
      deviceId,
      parsed.data.kind,
      parsed.data.sourceConfigId,
    );
    return NextResponse.json(
      QudraActiveSource.parse({
        deviceId,
        kind: active.kind,
        sourceConfigId: active.activeSourceConfigId,
      }),
    );
  } catch (error) {
    return routeError(error);
  }
}
