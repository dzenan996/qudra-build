import 'server-only';
import { NextResponse } from 'next/server';
import { revokeDevice } from '@/lib/business/qudra/device-keys';
import { routeAuthority, routeError, unauthorized } from '@/lib/business/qudra/route-helpers';

export async function POST(request: Request, context: { params: Promise<{ deviceId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const { deviceId } = await context.params;
    const device = await revokeDevice(authority, deviceId);
    return NextResponse.json({ id: device.id, status: device.status });
  } catch (error) {
    return routeError(error);
  }
}
