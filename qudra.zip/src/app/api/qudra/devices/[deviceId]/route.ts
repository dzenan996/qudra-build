import 'server-only';
import { NextResponse } from 'next/server';
import { updateDeviceMetadata } from '@/lib/business/qudra/account';
import { authorizeDevice } from '@/lib/business/qudra/authority';
import { deviceView } from '@/lib/business/qudra/device-identity';
import {
  requestBody,
  routeAuthority,
  routeError,
  unauthorized,
} from '@/lib/business/qudra/route-helpers';
import { QudraDeviceMetadataUpdate } from '@/lib/contracts/qudra-device';

export async function GET(request: Request, context: { params: Promise<{ deviceId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const { deviceId } = await context.params;
    const device = await authorizeDevice(authority, deviceId);
    return NextResponse.json(deviceView(device));
  } catch (error) {
    return routeError(error);
  }
}

export async function PATCH(request: Request, context: { params: Promise<{ deviceId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const parsed = QudraDeviceMetadataUpdate.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const { deviceId } = await context.params;
    return NextResponse.json(
      deviceView(await updateDeviceMetadata(authority, deviceId, parsed.data.displayName)),
    );
  } catch (error) {
    return routeError(error);
  }
}
