import 'server-only';
import { NextResponse } from 'next/server';
import {
  requestBody,
  routeAuthority,
  routeError,
  unauthorized,
} from '@/lib/business/qudra/route-helpers';
import { deleteSource, redactSource, updateSource } from '@/lib/business/qudra/sources';
import { QudraSourceWrite } from '@/lib/contracts/qudra-source';

function expectedVersion(request: Request, body: { configVersion?: number }) {
  const header = request.headers.get('If-Match-Config-Version');
  return header ? Number(header) : body.configVersion;
}

export async function PATCH(
  request: Request,
  context: { params: Promise<{ deviceId: string; sourceConfigId: string }> },
) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const parsed = QudraSourceWrite.partial().safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const { deviceId, sourceConfigId } = await context.params;
    const source = await updateSource(
      authority,
      deviceId,
      sourceConfigId,
      parsed.data,
      expectedVersion(request, parsed.data),
      request.headers.get('Idempotency-Key') ?? undefined,
    );
    return NextResponse.json(redactSource(source));
  } catch (error) {
    return routeError(error);
  }
}

export async function DELETE(
  request: Request,
  context: { params: Promise<{ deviceId: string; sourceConfigId: string }> },
) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const { deviceId, sourceConfigId } = await context.params;
    const version = Number(request.headers.get('If-Match-Config-Version'));
    await deleteSource(
      authority,
      deviceId,
      sourceConfigId,
      Number.isInteger(version) ? version : undefined,
      request.headers.get('Idempotency-Key') ?? undefined,
    );
    return new NextResponse(null, { status: 204 });
  } catch (error) {
    return routeError(error);
  }
}
