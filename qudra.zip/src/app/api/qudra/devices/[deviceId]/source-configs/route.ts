import 'server-only';
import { NextResponse } from 'next/server';
import {
  requestBody,
  routeAuthority,
  routeError,
  unauthorized,
} from '@/lib/business/qudra/route-helpers';
import { createSource, listSources, redactSource } from '@/lib/business/qudra/sources';
import { QudraSourceList, QudraSourceWrite } from '@/lib/contracts/qudra-source';

export async function GET(request: Request, context: { params: Promise<{ deviceId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const { deviceId } = await context.params;
    const sources = await listSources(authority, deviceId);
    return NextResponse.json(QudraSourceList.parse({ items: sources.map(redactSource) }));
  } catch (error) {
    return routeError(error);
  }
}

export async function POST(request: Request, context: { params: Promise<{ deviceId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const parsed = QudraSourceWrite.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const { deviceId } = await context.params;
    const source = await createSource(
      authority,
      deviceId,
      parsed.data,
      request.headers.get('Idempotency-Key') ?? undefined,
    );
    return NextResponse.json(redactSource(source), { status: 201 });
  } catch (error) {
    return routeError(error);
  }
}
