import 'server-only';
import { NextResponse } from 'next/server';
import { deviceView, registerDevice } from '@/lib/business/qudra/device-identity';
import {
  requestBody,
  routeAuthority,
  routeError,
  unauthorized,
} from '@/lib/business/qudra/route-helpers';
import { QudraDeviceRegistration } from '@/lib/contracts/qudra-device';

export async function POST(request: Request) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const parsed = QudraDeviceRegistration.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const device = await registerDevice(authority, parsed.data);
    return NextResponse.json(deviceView(device), { status: 201 });
  } catch (error) {
    return routeError(error);
  }
}
