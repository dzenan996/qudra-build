import 'server-only';
import { NextResponse } from 'next/server';
import { cancelPairing } from '@/lib/business/qudra/pairing';
import { routeAuthority, routeError, unauthorized } from '@/lib/business/qudra/route-helpers';
import { QudraPairingResult } from '@/lib/contracts/qudra-pairing';

export async function POST(
  request: Request,
  context: { params: Promise<{ challengeId: string }> },
) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const { challengeId } = await context.params;
    const result = await cancelPairing(authority, challengeId);
    return NextResponse.json(
      QudraPairingResult.parse({
        challengeId: result.id,
        deviceId: result.deviceId,
        state: result.state,
      }),
    );
  } catch (error) {
    return routeError(error);
  }
}
