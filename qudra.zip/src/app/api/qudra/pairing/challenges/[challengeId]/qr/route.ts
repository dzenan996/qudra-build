import 'server-only';
import { NextResponse } from 'next/server';
import { pairingQr } from '@/lib/business/qudra/pairing';
import { routeAuthority, routeError, unauthorized } from '@/lib/business/qudra/route-helpers';
import { QudraPairingQr } from '@/lib/contracts/qudra-pairing';

export async function GET(request: Request, context: { params: Promise<{ challengeId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const { challengeId } = await context.params;
    return NextResponse.json(QudraPairingQr.parse(await pairingQr(authority, challengeId)));
  } catch (error) {
    return routeError(error);
  }
}
