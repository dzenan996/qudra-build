import 'server-only';
import { NextResponse } from 'next/server';
import { completePairingChallenge } from '@/lib/business/qudra/pairing';
import {
  requestBody,
  routeAuthority,
  routeError,
  unauthorized,
} from '@/lib/business/qudra/route-helpers';
import { QudraPairingComplete, QudraPairingResult } from '@/lib/contracts/qudra-pairing';

export async function POST(
  request: Request,
  context: { params: Promise<{ challengeId: string }> },
) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const parsed = QudraPairingComplete.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const { challengeId } = await context.params;
    return NextResponse.json(
      QudraPairingResult.parse(
        await completePairingChallenge(authority, challengeId, parsed.data.response),
      ),
    );
  } catch (error) {
    return routeError(error);
  }
}
