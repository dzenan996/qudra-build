import 'server-only';
import { NextResponse } from 'next/server';
import { createPairingChallenge } from '@/lib/business/qudra/pairing';
import {
  requestBody,
  routeAuthority,
  routeError,
  unauthorized,
} from '@/lib/business/qudra/route-helpers';
import { QudraPairingChallenge, QudraPairingCreate } from '@/lib/contracts/qudra-pairing';

export async function POST(request: Request) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const parsed = QudraPairingCreate.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const { challenge, token } = await createPairingChallenge(
      authority,
      parsed.data.deviceId,
      parsed.data.idempotencyKey,
      request.headers.get('x-forwarded-for') ?? request.headers.get('x-real-ip') ?? undefined,
    );
    return NextResponse.json(
      QudraPairingChallenge.parse({
        id: challenge.id,
        deviceId: challenge.deviceId,
        state: challenge.state,
        expiresAt: challenge.expiresAt.toISOString(),
        attemptCount: challenge.attemptCount,
        maxAttempts: 5,
        pairingCode: token || undefined,
      }),
      { status: 201 },
    );
  } catch (error) {
    return routeError(error);
  }
}
