import 'server-only';

import { NextResponse } from 'next/server';
import { claimPairingChallenge } from '@/lib/business/qudra/claim';
import { requestBody, routeError } from '@/lib/business/qudra/route-helpers';
import { QudraClaimRequest, QudraClaimResult } from '@/lib/contracts/qudra-claim';
import { requireAuth } from '@/lib/require-auth';

export async function POST(request: Request) {
  let user: Awaited<ReturnType<typeof requireAuth>>;
  try {
    user = await requireAuth(request);
  } catch (response) {
    return response as Response;
  }
  try {
    const parsed = QudraClaimRequest.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const result = await claimPairingChallenge(
      { kind: 'session', userId: user.id, isSuperAdmin: user.role === 'admin' },
      parsed.data.challengeId,
      parsed.data.response,
    );
    return NextResponse.json(QudraClaimResult.parse(result), { status: 201 });
  } catch (error) {
    return routeError(error);
  }
}
