import 'server-only';
import { NextResponse } from 'next/server';
import {
  requestBody,
  routeAuthority,
  routeError,
  unauthorized,
} from '@/lib/business/qudra/route-helpers';
import { decideTrialException } from '@/lib/business/qudra/trial';
import { QudraTrialExceptionDecision } from '@/lib/contracts/qudra-trial';

export async function POST(request: Request, context: { params: Promise<{ requestId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const parsed = QudraTrialExceptionDecision.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const { requestId } = await context.params;
    const result = await decideTrialException(
      authority,
      requestId,
      parsed.data.decision,
      parsed.data.reason,
    );
    return NextResponse.json({ id: result.id, status: result.status });
  } catch (error) {
    return routeError(error);
  }
}
