import 'server-only';
import { NextResponse } from 'next/server';
import { customerIdForAuthority } from '@/lib/business/qudra/authority';
import { deviceView } from '@/lib/business/qudra/device-identity';
import { routeAuthority, routeError, unauthorized } from '@/lib/business/qudra/route-helpers';
import { QudraDeviceList } from '@/lib/contracts/qudra-device';
import { prisma } from '@/lib/db';

export async function GET(request: Request, context: { params: Promise<{ accountId: string }> }) {
  try {
    const authority = await routeAuthority(request);
    if (!authority) return unauthorized();
    const { accountId } = await context.params;
    const callerCustomerId = await customerIdForAuthority(authority);
    const account =
      authority.kind === 'session' && authority.isSuperAdmin
        ? await prisma.qudraAccount.findUnique({ where: { id: accountId } })
        : callerCustomerId
          ? await prisma.qudraAccount.findFirst({
              where: { id: accountId, customerId: callerCustomerId },
            })
          : null;
    if (!account)
      return NextResponse.json(
        { error: callerCustomerId ? 'Not found' : 'Forbidden' },
        { status: callerCustomerId ? 404 : 403 },
      );
    const devices = await prisma.qudraDevice.findMany({
      where: { customerId: account.customerId },
      orderBy: { createdAt: 'asc' },
    });
    return NextResponse.json(QudraDeviceList.parse({ items: devices.map(deviceView) }));
  } catch (error) {
    return routeError(error);
  }
}
