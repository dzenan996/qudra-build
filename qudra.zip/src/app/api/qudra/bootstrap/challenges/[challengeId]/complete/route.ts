import 'server-only';

import { NextResponse } from 'next/server';
import { completeBootstrapChallenge } from '@/lib/business/qudra/pairing';
import { requestBody, routeError } from '@/lib/business/qudra/route-helpers';
import { QudraBootstrapComplete, QudraBootstrapResult } from '@/lib/contracts/qudra-bootstrap';

export async function POST(
  request: Request,
  context: { params: Promise<{ challengeId: string }> },
) {
  try {
    const parsed = QudraBootstrapComplete.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const { challengeId } = await context.params;
    const result = await completeBootstrapChallenge(
      challengeId,
      parsed.data.nonce,
      parsed.data.proof,
    );
    return NextResponse.json(QudraBootstrapResult.parse(result));
  } catch (error) {
    return routeError(error);
  }
}
