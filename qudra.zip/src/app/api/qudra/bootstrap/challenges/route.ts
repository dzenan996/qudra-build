import 'server-only';

import { NextResponse } from 'next/server';
import { createBootstrapChallenge } from '@/lib/business/qudra/pairing';
import { requestBody, routeError } from '@/lib/business/qudra/route-helpers';
import {
  QudraBootstrapChallenge,
  QudraBootstrapChallengeCreate,
} from '@/lib/contracts/qudra-bootstrap';

export async function POST(request: Request) {
  try {
    const parsed = QudraBootstrapChallengeCreate.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const result = await createBootstrapChallenge(
      parsed.data,
      request.headers.get('x-forwarded-for') ?? request.headers.get('x-real-ip') ?? undefined,
    );
    return NextResponse.json(
      QudraBootstrapChallenge.parse({
        id: result.challenge.id,
        deviceId: result.challenge.deviceId,
        kind: result.challenge.kind,
        keyVersion: result.challenge.keyVersion,
        state: result.challenge.state,
        expiresAt: result.challenge.expiresAt.toISOString(),
        attemptCount: result.challenge.attemptCount,
        maxAttempts: result.challenge.maxAttempts,
        nonce: result.nonce,
        qr: {
          id: result.challenge.id,
          representation: result.challenge.id,
          expiresAt: result.challenge.expiresAt.toISOString(),
        },
      }),
      { status: 201 },
    );
  } catch (error) {
    return routeError(error);
  }
}
