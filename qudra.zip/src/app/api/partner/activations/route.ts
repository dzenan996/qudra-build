import 'server-only';
import { NextResponse } from 'next/server';
import { requirePartnerContext } from '@/lib/business/qudra/partner';
import {
  activatePartnerLicense,
  listPartnerActivations,
} from '@/lib/business/qudra/partner-activation';
import { requestBody, routeError } from '@/lib/business/qudra/route-helpers';
import {
  QudraPartnerActivationInput,
  QudraPartnerActivationList,
  QudraPartnerActivationResult,
} from '@/lib/contracts/qudra-t7-activation';
export async function GET() {
  try {
    const { partner } = await requirePartnerContext();
    const rows = await listPartnerActivations(partner.id);
    return NextResponse.json(
      QudraPartnerActivationList.parse({
        items: rows.map((row) => ({
          ...row,
          createdAt: row.createdAt.toISOString(),
          completedAt: row.completedAt?.toISOString() ?? null,
        })),
      }),
    );
  } catch (error) {
    return routeError(error);
  }
}
export async function POST(request: Request) {
  try {
    const context = await requirePartnerContext();
    const parsed = QudraPartnerActivationInput.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const result = await activatePartnerLicense({
      ...parsed.data,
      partnerId: context.partner.id,
      actorId: context.user.id,
    });
    return NextResponse.json(
      QudraPartnerActivationResult.parse({
        activation: {
          ...result.activation,
          createdAt: result.activation.createdAt.toISOString(),
          completedAt: result.activation.completedAt?.toISOString() ?? null,
        },
        entitlement: result.entitlement
          ? {
              id: result.entitlement.id,
              kind: result.entitlement.kind,
              state: result.entitlement.state,
              activatedAt: result.entitlement.activatedAt.toISOString(),
              expiresAt: result.entitlement.expiresAt?.toISOString() ?? null,
            }
          : null,
      }),
      { status: result.replay ? 200 : 201 },
    );
  } catch (error) {
    return routeError(error);
  }
}
