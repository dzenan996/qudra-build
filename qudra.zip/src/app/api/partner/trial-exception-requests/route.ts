import 'server-only';
import { NextResponse } from 'next/server';
import { requirePartnerContext } from '@/lib/business/qudra/partner';
import {
  createTrialExceptionRequest,
  listPartnerTrialExceptionRequests,
} from '@/lib/business/qudra/partner-requests';
import { requestBody, routeError } from '@/lib/business/qudra/route-helpers';
import {
  QudraTrialExceptionInput,
  QudraTrialExceptionRequests,
} from '@/lib/contracts/qudra-t7-requests';
export async function GET() {
  try {
    const { partner } = await requirePartnerContext();
    const rows = await listPartnerTrialExceptionRequests(partner.id);
    return NextResponse.json(
      QudraTrialExceptionRequests.parse({
        items: rows.map((row) => ({
          ...row,
          createdAt: row.createdAt.toISOString(),
          decidedAt: row.decidedAt?.toISOString() ?? null,
        })),
      }),
    );
  } catch (error) {
    return routeError(error);
  }
}
export async function POST(request: Request) {
  try {
    const parsed = QudraTrialExceptionInput.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    const row = await createTrialExceptionRequest(parsed.data);
    return NextResponse.json(
      { ...row, createdAt: row.createdAt.toISOString(), decidedAt: null },
      { status: 201 },
    );
  } catch (error) {
    return routeError(error);
  }
}
