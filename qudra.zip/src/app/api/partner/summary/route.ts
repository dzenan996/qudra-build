import 'server-only';
import { NextResponse } from 'next/server';
import { requirePartnerContext, safeBranding } from '@/lib/business/qudra/partner';
import { routeError } from '@/lib/business/qudra/route-helpers';
import { QudraPartnerSummary } from '@/lib/contracts/qudra-t7-partner';
import { prisma } from '@/lib/db';
export async function GET() {
  try {
    const { partner } = await requirePartnerContext();
    const [customers, devices, account, branding] = await Promise.all([
      prisma.qudraPartnerCustomerScope.count({
        where: { partnerId: partner.id, status: 'ACTIVE' },
      }),
      prisma.qudraPartnerCustomerScope
        .findMany({
          where: { partnerId: partner.id, status: 'ACTIVE' },
          select: { customerId: true },
        })
        .then((rows) =>
          prisma.qudraDevice.count({
            where: { customerId: { in: rows.map((row) => row.customerId) } },
          }),
        ),
      prisma.qudraPartnerCreditAccount.upsert({
        where: { partnerId: partner.id },
        update: {},
        create: { partnerId: partner.id },
      }),
      prisma.qudraPartnerBranding.findUnique({ where: { partnerId: partner.id } }),
    ]);
    return NextResponse.json(
      QudraPartnerSummary.parse({
        partner: {
          id: partner.id,
          displayName: partner.displayName,
          status: partner.status,
          createdAt: partner.createdAt.toISOString(),
          updatedAt: partner.updatedAt.toISOString(),
        },
        customers,
        devices,
        balance: account.balance,
        branding: safeBranding(branding),
      }),
    );
  } catch (error) {
    return routeError(error);
  }
}
