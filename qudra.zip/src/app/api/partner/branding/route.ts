import 'server-only';
import { NextResponse } from 'next/server';
import { requirePartnerContext, safeBranding } from '@/lib/business/qudra/partner';
import { submitPartnerBranding } from '@/lib/business/qudra/partner-branding';
import { requestBody, routeError } from '@/lib/business/qudra/route-helpers';
import { QudraPartnerBranding, QudraPartnerBrandingWrite } from '@/lib/contracts/qudra-t7-partner';
import { prisma } from '@/lib/db';
export async function GET() {
  try {
    const { partner } = await requirePartnerContext();
    const branding = safeBranding(
      await prisma.qudraPartnerBranding.findUnique({ where: { partnerId: partner.id } }),
    ) ?? {
      state: 'PENDING' as const,
      proposed: { displayName: null, logoUrl: null, supportEmail: null, supportPhone: null },
      approved: { displayName: null, logoUrl: null, supportEmail: null, supportPhone: null },
    };
    return NextResponse.json(QudraPartnerBranding.parse(branding));
  } catch (error) {
    return routeError(error);
  }
}
export async function PATCH(request: Request) {
  try {
    const { partner, user } = await requirePartnerContext();
    const parsed = QudraPartnerBrandingWrite.safeParse(await requestBody(request));
    if (!parsed.success)
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    return NextResponse.json(
      QudraPartnerBranding.parse(await submitPartnerBranding(partner.id, user.id, parsed.data)),
    );
  } catch (error) {
    return routeError(error);
  }
}
