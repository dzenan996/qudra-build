import 'server-only';
import { NextResponse } from 'next/server';
import { requirePartnerContext } from '@/lib/business/qudra/partner';
import { listPartnerCredits } from '@/lib/business/qudra/partner-credits';
import { routeError } from '@/lib/business/qudra/route-helpers';
import { QudraCreditLedger } from '@/lib/contracts/qudra-t7-credits';
export async function GET() {
  try {
    const { partner } = await requirePartnerContext();
    const result = await listPartnerCredits(partner.id);
    return NextResponse.json(
      QudraCreditLedger.parse({
        balance: {
          partnerId: partner.id,
          balance: result.account.balance,
          version: result.account.version,
        },
        entries: result.entries.map((entry) => ({
          id: entry.id,
          delta: entry.delta,
          kind: entry.kind,
          actorId: entry.actorId,
          reference: entry.reference,
          operationKey: entry.operationKey,
          createdAt: entry.createdAt.toISOString(),
        })),
      }),
    );
  } catch (error) {
    return routeError(error);
  }
}
