import 'server-only';
import { NextResponse } from 'next/server';
import { requirePartnerContext } from '@/lib/business/qudra/partner';
import { routeError } from '@/lib/business/qudra/route-helpers';
import { QudraAdminDevices } from '@/lib/contracts/qudra-t7-admin';
import { prisma } from '@/lib/db';
export async function GET() {
  try {
    const { partner } = await requirePartnerContext();
    const scopes = await prisma.qudraPartnerCustomerScope.findMany({
      where: { partnerId: partner.id, status: 'ACTIVE' },
      select: { customerId: true },
    });
    const rows = await prisma.qudraDevice.findMany({
      where: { customerId: { in: scopes.map((scope) => scope.customerId) } },
      select: {
        id: true,
        customerId: true,
        productFamily: true,
        platform: true,
        status: true,
        displayName: true,
      },
    });
    return NextResponse.json(QudraAdminDevices.parse({ items: rows }));
  } catch (error) {
    return routeError(error);
  }
}
