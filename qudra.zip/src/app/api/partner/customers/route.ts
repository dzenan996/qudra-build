import 'server-only';
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requirePartnerContext } from '@/lib/business/qudra/partner';
import { routeError } from '@/lib/business/qudra/route-helpers';
import { prisma } from '@/lib/db';

const List = z.object({
  items: z.array(
    z.object({ id: z.string(), status: z.string(), deviceCount: z.number().int().nonnegative() }),
  ),
});
export async function GET() {
  try {
    const { partner } = await requirePartnerContext();
    const scopes = await prisma.qudraPartnerCustomerScope.findMany({
      where: { partnerId: partner.id, status: 'ACTIVE' },
      select: { customerId: true },
    });
    const ids = scopes.map((scope) => scope.customerId);
    const rows = await prisma.qudraCustomer.findMany({
      where: { id: { in: ids } },
      include: { _count: { select: { devices: true } } },
    });
    return NextResponse.json(
      List.parse({
        items: rows.map((row) => ({
          id: row.id,
          status: row.status,
          deviceCount: row._count.devices,
        })),
      }),
    );
  } catch (error) {
    return routeError(error);
  }
}
