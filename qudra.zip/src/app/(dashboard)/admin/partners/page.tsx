// @polsia:user-owned
import type { Metadata } from 'next';
import { T7PartnersPanel } from '@/components/custom/admin/t7-partners-panel';
export const metadata: Metadata = {
  title: 'Partneri — QUDRA Control plane',
  description: 'Super Admin upravljanje QUDRA Partnerima.',
};
export default function AdminPartnersPage() {
  return <T7PartnersPanel />;
}
