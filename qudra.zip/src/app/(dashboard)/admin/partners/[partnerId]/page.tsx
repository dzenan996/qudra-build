// @polsia:user-owned
import type { Metadata } from 'next';
import { T7PartnerDetailPanel } from '@/components/custom/admin/t7-partner-detail-panel';
export const metadata: Metadata = {
  title: 'Partner detalji — QUDRA',
  description: 'Partner membership, credits, scope i branding.',
};
export default async function AdminPartnerDetailPage({
  params,
}: {
  params: Promise<{ partnerId: string }>;
}) {
  return <T7PartnerDetailPanel partnerId={(await params).partnerId} />;
}
