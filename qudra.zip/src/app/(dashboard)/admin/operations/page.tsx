// @polsia:user-owned
import type { Metadata } from 'next';
import { T7OperationsPanel } from '@/components/custom/admin/t7-operations-panel';
export const metadata: Metadata = {
  title: 'Operacije — QUDRA',
  description: 'Globalni sigurni operativni pregled QUDRA Control planea.',
};
export default function AdminOperationsPage() {
  return <T7OperationsPanel />;
}
