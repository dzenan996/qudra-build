// @polsia:user-owned
import type { Metadata } from 'next';
import { T7BrandingPanel } from '@/components/custom/partner/t7-branding-panel';
export const metadata: Metadata = {
  title: 'Partner branding — QUDRA',
  description: 'Ograničeni support i branding podaci uz Super Admin approval.',
};
export default function PartnerBrandingPage() {
  return <T7BrandingPanel />;
}
