// @polsia:user-owned
import type { Metadata } from 'next';
import { T7RequestsPanel } from '@/components/custom/partner/t7-requests-panel';
export const metadata: Metadata = {
  title: 'Partner zahtjevi — QUDRA',
  description: 'Replacement i Trial exception zahtjevi u vlastitom scopeu.',
};
export default function PartnerRequestsPage() {
  return <T7RequestsPanel />;
}
