// @polsia:user-owned
import type { Metadata } from 'next';
import { T7OverviewPanel } from '@/components/custom/partner/t7-overview-panel';
export const metadata: Metadata = {
  title: 'Partner overview — QUDRA',
  description: 'Vlastiti Partner scope i activation credits.',
};
export default function PartnerPage() {
  return <T7OverviewPanel />;
}
