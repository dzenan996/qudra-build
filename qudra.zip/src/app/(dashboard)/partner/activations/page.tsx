// @polsia:user-owned
import type { Metadata } from 'next';
import { T7ActivationsPanel } from '@/components/custom/partner/t7-activations-panel';
export const metadata: Metadata = {
  title: 'Partner aktivacije — QUDRA',
  description: 'Annual i Lifetime software license aktivacije.',
};
export default function PartnerActivationsPage() {
  return <T7ActivationsPanel />;
}
