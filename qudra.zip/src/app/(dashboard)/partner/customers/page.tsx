// @polsia:user-owned
import type { Metadata } from 'next';
import { T7CustomersPanel } from '@/components/custom/partner/t7-customers-panel';
export const metadata: Metadata = {
  title: 'Partner Customers — QUDRA',
  description: 'Customers i Devices unutar vlastitog Partner scopea.',
};
export default function PartnerCustomersPage() {
  return <T7CustomersPanel />;
}
