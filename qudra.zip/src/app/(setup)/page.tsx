// @polsia:user-owned — starter home served at /. Replace it in place, or delete
// this route group before adding another page that resolves to /.

import {
  ArrowRight,
  Check,
  CirclePlay,
  MonitorSmartphone,
  Radio,
  Search,
  ShieldCheck,
  Tv,
  UsersRound,
  Waves,
  Waypoints,
} from 'lucide-react';
import type { Metadata } from 'next';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { siteDescription, siteName } from '@/lib/site';

// Keep this a Server Component so it can export metadata.
export const metadata: Metadata = {
  title: { absolute: siteName },
  description: siteDescription,
  // Do not export an explicit openGraph object here; that suppresses the
  // file-based opengraph-image.tsx for the home route.
  alternates: { canonical: '/' },
};

const playbackFeatures = [
  [
    '01',
    'LIVE TV, filmovi, serije i radio',
    'Jedno pregledno mjesto za izvore koje već smijete koristiti.',
  ],
  [
    '02',
    'Nastavak gledanja bez traženja',
    'Favoriti, pretraživanje i EPG drže vašu večer u ritmu.',
  ],
  [
    '03',
    'Funkcije koje prate vaš ekran',
    'Titlovi, ponovno povezivanje, slika u slici i emitiranje.',
  ],
];

const controlSteps = [
  [
    '01',
    'Dodajte ovlašteni izvor',
    'QUDRA reproducira vaš ili partnerski izvor — sadržaj ne prodaje, ne preporučuje i ne isporučuje.',
  ],
  [
    '02',
    'Aktivirajte uređaj',
    'Svaki ekran dobiva zasebnu softversku licencu, jasno vezanu uz korisnika i uređaj.',
  ],
  [
    '03',
    'Gledajte s više reda',
    'Upravljajte aktivnim uređajima, dijagnostikom i sigurnošću iz jednog administracijskog oblaka.',
  ],
];

function SignalMark() {
  return (
    <div className="flex size-10 items-center justify-center border border-primary/40 bg-primary/10 text-primary">
      <Waves className="size-5" aria-hidden="true" />
    </div>
  );
}

export default function HomePage() {
  return (
    <main className="overflow-hidden">
      <section className="relative border-b border-border bg-gradient-to-br from-muted/70 via-background to-background">
        <div className="container-page relative grid min-h-[calc(100vh-3.5rem)] items-center gap-16 py-20 lg:grid-cols-[minmax(0,1fr)_minmax(22rem,0.82fr)] lg:gap-24 lg:py-24">
          <div className="relative z-10 max-w-3xl">
            <div className="mb-8 flex items-center gap-3 text-caption font-semibold uppercase tracking-[0.14em] text-primary">
              <span className="h-px w-10 bg-primary" aria-hidden="true" />
              Softver za vaše izvore
            </div>
            <h1 className="max-w-3xl font-display text-5xl font-bold leading-[0.98] tracking-[-0.06em] text-foreground sm:text-7xl lg:text-display">
              QUDRA
              <span className="mt-4 block max-w-2xl font-body text-2xl font-medium leading-tight tracking-[-0.03em] text-muted-foreground sm:text-4xl">
                Legalni reproduktor i upravljanje licencama po uređaju.
              </span>
            </h1>
            <p className="mt-8 max-w-xl text-body-lg text-muted-foreground">
              Vaši ovlašteni izvori, vaši ekrani, jasna pravila. QUDRA objedinjuje gledanje i
              kontrolu uređaja bez miješanja softverske licence s medijskim sadržajem.
            </p>
            <div className="mt-10 flex flex-col gap-3 sm:flex-row sm:items-center">
              <Button asChild size="lg" className="h-12 rounded-sm px-6 font-semibold">
                <Link href="/#proizvod">
                  Istražite mogućnosti
                  <ArrowRight className="size-4" aria-hidden="true" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="h-12 rounded-sm px-6">
                <Link href="mailto:qudra@polsia.app">Razgovarajmo o vašoj postavi</Link>
              </Button>
            </div>
            <div className="mt-12 flex flex-wrap gap-x-8 gap-y-3 text-small text-muted-foreground">
              <span className="inline-flex items-center gap-2">
                <Check className="size-4 text-primary" aria-hidden="true" /> Bez isporuke sadržaja
              </span>
              <span className="inline-flex items-center gap-2">
                <Check className="size-4 text-primary" aria-hidden="true" /> Licenca po uređaju
              </span>
            </div>
          </div>

          <div className="relative mx-auto w-full max-w-[31rem] lg:mr-0">
            <div className="absolute -inset-8 bg-primary/10 blur-3xl" aria-hidden="true" />
            <div className="relative border border-border bg-card p-3 shadow-2xl">
              <div className="flex items-center justify-between border-b border-border px-3 pb-3 text-caption font-semibold uppercase tracking-[0.12em] text-muted-foreground">
                <span className="inline-flex items-center gap-2">
                  <span className="size-2 bg-primary" aria-hidden="true" /> QUDRA kontrolna ploča
                </span>
                <span>Uživo</span>
              </div>
              <div className="grid gap-3 p-3 sm:grid-cols-[1.15fr_0.85fr]">
                <div className="relative min-h-64 overflow-hidden bg-muted p-5">
                  <div className="absolute inset-x-0 top-1/2 h-px bg-border" aria-hidden="true" />
                  <div className="absolute inset-y-0 left-1/2 w-px bg-border" aria-hidden="true" />
                  <div className="relative flex h-full flex-col justify-between">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="text-caption font-semibold uppercase tracking-[0.1em] text-muted-foreground">
                          Glavni ekran
                        </p>
                        <p className="mt-1 font-display text-2xl tracking-[-0.04em]">Android TV</p>
                      </div>
                      <Tv className="size-5 text-primary" aria-hidden="true" />
                    </div>
                    <div className="relative mx-auto flex size-28 items-center justify-center rounded-full border border-primary/50 bg-primary/10">
                      <div className="absolute size-20 rounded-full border border-primary/40" />
                      <CirclePlay className="relative size-9 text-primary" aria-hidden="true" />
                    </div>
                    <div className="flex items-end justify-between gap-4">
                      <div className="flex items-end gap-1" role="img" aria-label="Jačina signala">
                        {['h-6', 'h-10', 'h-16', 'h-20', 'h-24'].map((height) => (
                          <span key={height} className={`w-1.5 bg-primary ${height}`} />
                        ))}
                      </div>
                      <span className="text-caption text-muted-foreground">Izvor povezan</span>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col gap-3">
                  <div className="border border-border bg-background p-4">
                    <div className="flex items-center justify-between text-caption uppercase tracking-[0.1em] text-muted-foreground">
                      <span>Aktivni uređaji</span>
                      <MonitorSmartphone className="size-4 text-primary" aria-hidden="true" />
                    </div>
                    <p className="mt-3 font-display text-4xl tracking-[-0.08em]">04</p>
                    <div className="mt-3 h-1 bg-muted">
                      <div className="h-full w-3/4 bg-primary" />
                    </div>
                  </div>
                  <div className="border border-border bg-background p-4">
                    <div className="flex items-center justify-between text-caption uppercase tracking-[0.1em] text-muted-foreground">
                      <span>Licenca</span>
                      <ShieldCheck className="size-4 text-primary" aria-hidden="true" />
                    </div>
                    <p className="mt-3 text-small font-semibold text-primary">ZAŠTIĆENA</p>
                    <p className="mt-1 text-caption text-muted-foreground">Vezana uz ovaj uređaj</p>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between border-t border-border px-3 pt-3 text-caption text-muted-foreground">
                <span>QUDRA / 00184</span>
                <span className="inline-flex items-center gap-2">
                  <span className="size-1.5 rounded-full bg-primary" aria-hidden="true" /> Sigurna
                  sesija
                </span>
              </div>
            </div>
          </div>
        </div>
        <div
          className="pointer-events-none absolute bottom-0 left-0 hidden h-px w-1/3 bg-primary/60 lg:block"
          aria-hidden="true"
        />
      </section>

      <section id="proizvod" className="section-lg scroll-mt-20">
        <div className="container-page">
          <div className="grid gap-12 lg:grid-cols-[0.72fr_1.28fr] lg:gap-24">
            <div>
              <Badge variant="outline" className="rounded-sm px-3 py-1 text-primary">
                01 / Reprodukcija
              </Badge>
              <h2 className="mt-6 max-w-md font-display text-h2 tracking-[-0.06em]">
                Sve za gledanje. Ništa suvišno.
              </h2>
              <p className="mt-6 max-w-sm text-body-lg text-muted-foreground">
                QUDRA je napravljen da vaš sadržaj bude lako dostupan na pravom ekranu, u pravom
                trenutku i bez nejasnih granica.
              </p>
              <div className="mt-10 flex items-center gap-3 text-small font-medium text-primary">
                <Radio className="size-4" aria-hidden="true" /> Vaši izvori ostaju vaši
              </div>
            </div>
            <div className="border-y border-border">
              {playbackFeatures.map(([number, title, description], index) => (
                <div
                  key={number}
                  className="grid gap-4 border-b border-border py-7 last:border-b-0 sm:grid-cols-[4rem_1fr] sm:gap-8"
                >
                  <span className="font-display text-small text-primary">{number}</span>
                  <div>
                    <h3 className="font-display text-h4 tracking-[-0.05em]">{title}</h3>
                    <p className="mt-2 max-w-xl text-muted-foreground">{description}</p>
                  </div>
                  {index === 0 && <span className="sr-only">Prva mogućnost</span>}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="licenca" className="scroll-mt-20 border-y border-border bg-muted/40">
        <div className="container-page grid gap-10 py-16 lg:grid-cols-[0.9fr_1.1fr] lg:gap-24 lg:py-24">
          <div className="flex flex-col justify-between gap-8">
            <div>
              <Badge variant="outline" className="rounded-sm px-3 py-1 text-primary">
                02 / Licenciranje
              </Badge>
              <h2 className="mt-6 max-w-lg font-display text-h2 tracking-[-0.06em]">
                Jedan uređaj. Jedna jasna odgovornost.
              </h2>
            </div>
            <p className="max-w-md text-body-lg text-muted-foreground">
              Licenca za softver aktivira se zasebno za svaki uređaj. Tako korisnici i ovlašteni
              partneri uvijek znaju što je aktivno, kome pripada i kako je zaštićeno.
            </p>
          </div>
          <Card className="rounded-sm border-border bg-card shadow-none">
            <CardHeader className="border-b border-border pb-5">
              <div className="flex items-center gap-3">
                <SignalMark />
                <div>
                  <CardTitle className="font-display text-h4 tracking-[-0.05em]">
                    Kontrola bez nagađanja
                  </CardTitle>
                  <p className="mt-1 text-small text-muted-foreground">
                    Pregled koji razumiju i ljudi i partneri.
                  </p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="grid gap-6 pt-6 sm:grid-cols-2">
              {[
                ['Izolacija partnera', 'Svaki partnerski prostor ostaje odvojen.'],
                ['Zaštita uređaja', 'Licenca se ne seli između korisnika.'],
                ['Dijagnostika', 'Brže pronađite i riješite tehničke poteškoće.'],
                ['Revizijski zapisi', 'Važne promjene ostaju pregledne i sljedive.'],
              ].map(([title, description]) => (
                <div key={title} className="border-l-2 border-primary/50 pl-4">
                  <p className="font-semibold">{title}</p>
                  <p className="mt-1 text-small text-muted-foreground">{description}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </section>

      <section id="sigurnost" className="section-lg scroll-mt-20">
        <div className="container-page">
          <div className="mb-14 flex flex-col justify-between gap-6 md:flex-row md:items-end">
            <div className="max-w-2xl">
              <Badge variant="outline" className="rounded-sm px-3 py-1 text-primary">
                03 / Upravljanje
              </Badge>
              <h2 className="mt-6 font-display text-h2 tracking-[-0.06em]">
                Od izvora do ekrana, tok je vaš.
              </h2>
            </div>
            <p className="max-w-sm text-muted-foreground">
              Administracijski oblak spaja pregled uređaja, korisnika i partnera s jasnim pravilima
              sigurnosti.
            </p>
          </div>
          <div className="relative grid gap-0 border-t border-border md:grid-cols-3 md:border-l">
            {controlSteps.map(([number, title, description], index) => (
              <div
                key={number}
                className="relative border-b border-border py-8 md:border-r md:px-8 md:py-10"
              >
                <div className="mb-14 flex items-center justify-between">
                  <span className="font-display text-small text-primary">{number}</span>
                  <Waypoints className="size-5 text-primary/70" aria-hidden="true" />
                </div>
                <h3 className="max-w-xs font-display text-h4 tracking-[-0.05em]">{title}</h3>
                <p className="mt-4 max-w-sm text-muted-foreground">{description}</p>
                {index < controlSteps.length - 1 && (
                  <ArrowRight
                    className="absolute -right-3 top-8 z-10 hidden size-5 bg-background text-primary md:block"
                    aria-hidden="true"
                  />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section
        id="qudra-open"
        className="scroll-mt-20 border-y border-border bg-primary text-primary-foreground"
      >
        <div className="container-page grid gap-12 py-16 lg:grid-cols-[1fr_0.8fr] lg:items-center lg:py-24">
          <div>
            <Badge
              variant="outline"
              className="rounded-sm border-primary-foreground/40 text-primary-foreground"
            >
              QUDRA OPEN
            </Badge>
            <h2 className="mt-6 max-w-2xl font-display text-h2 tracking-[-0.06em]">
              Počnite s lawful/open sadržajem koji je uvijek dostupan.
            </h2>
            <p className="mt-6 max-w-xl text-body-lg text-primary-foreground/75">
              QUDRA OPEN sadrži samo odobren lawful/open sadržaj i ne traži entitlement. QUDRA je
              media-player software i licenca po uređaju: ne prodaje kanale, filmove, serije, radio
              kataloge ni pristup sadržaju. Personal Sources su user-provided i authorized.
            </p>
          </div>
          <div className="border border-primary-foreground/25 p-6 sm:p-8">
            <div className="flex items-center gap-4">
              <div className="flex size-12 items-center justify-center border border-primary-foreground/35">
                <CirclePlay className="size-6" aria-hidden="true" />
              </div>
              <div>
                <p className="font-display text-h4 tracking-[-0.05em]">Otvoren početak</p>
                <p className="mt-1 text-small text-primary-foreground/70">
                  Bez vremenskog ograničenja.
                </p>
              </div>
            </div>
            <Separator className="my-6 bg-primary-foreground/20" />
            <div className="grid gap-3 text-small text-primary-foreground/80">
              <span className="inline-flex items-center gap-3">
                <Check className="size-4" aria-hidden="true" /> Legalno i trajno dostupno
              </span>
              <span className="inline-flex items-center gap-3">
                <Check className="size-4" aria-hidden="true" /> Bez prijenosa licence
              </span>
              <span className="inline-flex items-center gap-3">
                <Check className="size-4" aria-hidden="true" /> Spremno za vaš uređaj
              </span>
            </div>
          </div>
        </div>
      </section>

      <section id="partneri" className="section-lg scroll-mt-20">
        <div className="container-page">
          <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:items-end lg:gap-24">
            <div>
              <Badge variant="outline" className="rounded-sm px-3 py-1 text-primary">
                04 / Sljedeći korak
              </Badge>
              <h2 className="mt-6 max-w-md font-display text-h2 tracking-[-0.06em]">
                Za pojedince i partnere koji žele znati gdje stoje.
              </h2>
            </div>
            <div className="border-l-2 border-primary pl-6 sm:pl-8">
              <p className="max-w-2xl text-body-lg text-muted-foreground">
                Recite nam na kojim uređajima radite, koje izvore već imate i kako želite upravljati
                licencama. Zajedno ćemo pronaći jasan početak za vašu postavu.
              </p>
              <Button asChild size="lg" className="mt-8 h-12 rounded-sm px-6">
                <Link href="mailto:qudra@polsia.app">
                  Javite se QUDRA timu
                  <ArrowRight className="size-4" aria-hidden="true" />
                </Link>
              </Button>
            </div>
          </div>
          <div className="mt-16 grid gap-3 border-t border-border pt-6 text-small text-muted-foreground sm:grid-cols-3">
            <span className="inline-flex items-center gap-3">
              <UsersRound className="size-4 text-primary" aria-hidden="true" /> Pojedinci
            </span>
            <span className="inline-flex items-center gap-3">
              <MonitorSmartphone className="size-4 text-primary" aria-hidden="true" /> Ovlašteni
              partneri
            </span>
            <span className="inline-flex items-center gap-3">
              <Search className="size-4 text-primary" aria-hidden="true" /> Jasna dijagnostika
            </span>
          </div>
        </div>
      </section>
    </main>
  );
}
