// @polsia:user-owned — public deletion URL for QUDRA account holders.
import type { Metadata } from 'next';
import { AccountDeletionPanel } from '@/components/custom/account-deletion-panel';

export const metadata: Metadata = {
  title: 'Brisanje računa — QUDRA',
  description:
    'Funkcionalna QUDRA web stranica za brisanje autentificiranog računa i pregled zadržanih control-plane zapisa.',
};

export default function AccountDeletionPage() {
  return (
    <main className="section-lg">
      <div className="container-page grid max-w-3xl gap-8">
        <div className="grid gap-4">
          <p className="text-eyebrow text-primary">QUDRA / ACCOUNT CONTROL</p>
          <h1 className="text-h1">Brisanje računa</h1>
          <p className="max-w-2xl text-body-lg text-muted-foreground">
            QUDRA je media-player software i licenca po uređaju, ne prodaja kanala ili medijskog
            kataloga. Ako ste izradili optional account, ovdje možete pokrenuti njegovo brisanje.
          </p>
        </div>
        <AccountDeletionPanel />
      </div>
    </main>
  );
}
