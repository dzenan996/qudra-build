// @polsia:user-owned — public privacy and Data Safety inventory surface.
import type { Metadata } from 'next';
import { PrivacyPolicyPanel } from '@/components/custom/privacy-policy-panel';

export const metadata: Metadata = {
  title: 'Privatnost i Data Safety — QUDRA',
  description:
    'Implementacijom utemeljen inventar QUDRA Cloud, Device-local i direct-origin podataka.',
};

export default function PrivacyPage() {
  return (
    <main className="section-lg">
      <div className="container-page grid max-w-4xl gap-8">
        <div className="grid gap-4">
          <p className="text-eyebrow text-primary">QUDRA / PRIVACY CONTROL</p>
          <h1 className="text-h1">Privatnost i Data Safety inventar</h1>
          <p className="max-w-3xl text-body-lg text-muted-foreground">
            Ova release-ready površina razdvaja control-plane podatke od onoga što ostaje na uređaju
            ili ide izravno prema lawful media originu. Konačne pravne, identitetske i retention
            odgovore mora potvrditi Owner/legal.
          </p>
        </div>
        <PrivacyPolicyPanel />
      </div>
    </main>
  );
}
