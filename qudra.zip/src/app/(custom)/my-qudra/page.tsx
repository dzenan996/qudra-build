// @polsia:user-owned — metadata-only My Qudra shell.
import type { Metadata } from 'next';
import { MyQudraPanel } from '@/components/custom/qudra/my-qudra-panel';

export const metadata: Metadata = {
  title: 'My Qudra',
  description:
    'Manage your QUDRA Devices, Personal Sources, sync metadata, and direct playback controls.',
};

export default function MyQudraPage() {
  return (
    <main className="section-lg">
      <div className="container-page">
        <div className="mb-12 max-w-2xl">
          <p className="text-eyebrow">QUDRA / CONTROL PLANE</p>
          <h1 className="mt-4 text-h1 font-display">My Qudra</h1>
          <p className="mt-5 text-body-lg text-muted-foreground">
            One place for your Devices and the sources you already have permission to use. Catalogue
            data and playback stay on the Device; QUDRA Cloud stores control metadata.
          </p>
        </div>
        <MyQudraPanel />
      </div>
    </main>
  );
}
