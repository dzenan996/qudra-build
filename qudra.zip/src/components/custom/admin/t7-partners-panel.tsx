// @polsia:user-owned
'use client';

import { useCallback, useEffect, useState } from 'react';
import type { z } from 'zod';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { apiFetch } from '@/lib/api-client';
import {
  QudraPartner,
  QudraPartnerCreate,
  QudraPartnerList,
} from '@/lib/contracts/qudra-t7-partner';

type Partner = z.infer<typeof QudraPartner>;
export function T7PartnersPanel() {
  const [items, setItems] = useState<Partner[] | null>(null);
  const [name, setName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const load = useCallback(
    () =>
      apiFetch('/api/admin/partners', { schema: QudraPartnerList })
        .then((data) => setItems(data.items))
        .catch(() => setError('Nije moguće učitati Partnere.')),
    [],
  );
  useEffect(() => {
    load();
  }, [load]);
  async function create() {
    const parsed = QudraPartnerCreate.safeParse({ displayName: name });
    if (!parsed.success) {
      setError('Unesite naziv Partnera.');
      return;
    }
    try {
      await apiFetch('/api/admin/partners', {
        method: 'POST',
        body: JSON.stringify(parsed.data),
        schema: QudraPartner,
      });
      setName('');
      load();
    } catch {
      setError('Kreiranje Partnera nije uspjelo.');
    }
  }
  if (items === null && !error)
    return <p className="text-sm text-muted-foreground">Učitavanje Partnera…</p>;
  return (
    <div className="grid gap-6">
      <div>
        <p className="text-eyebrow text-primary">QUDRA / ADMIN</p>
        <h1 className="text-h2">Partneri</h1>
        <p className="mt-2 text-body text-muted-foreground">
          Upravljajte software licensing partnerima i njihovim operativnim scopeom.
        </p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="text-h4">Novi Partner</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-3 sm:flex-row">
          <Input
            aria-label="Naziv Partnera"
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder="Naziv Partnera"
          />
          <Button type="button" onClick={create}>
            Kreiraj Partnera
          </Button>
        </CardContent>
      </Card>
      {error ? (
        <p role="alert" className="text-sm text-destructive">
          {error}
        </p>
      ) : null}
      <Card>
        <CardHeader>
          <CardTitle className="text-h4">Registrirani Partneri</CardTitle>
        </CardHeader>
        <CardContent>
          {items?.length ? (
            <div className="grid gap-3">
              {items.map((partner) => (
                <div
                  key={partner.id}
                  className="flex flex-col gap-3 border border-border p-4 sm:flex-row sm:items-center sm:justify-between"
                >
                  <div>
                    <p className="font-semibold">{partner.displayName}</p>
                    <p className="text-sm text-muted-foreground">{partner.id}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant={partner.status === 'ACTIVE' ? 'default' : 'secondary'}>
                      {partner.status}
                    </Badge>
                    <Button asChild variant="outline" size="sm">
                      <a href={`/admin/partners/${partner.id}`}>Otvori</a>
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">Još nema Partnera.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
