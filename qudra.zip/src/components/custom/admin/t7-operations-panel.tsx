// @polsia:user-owned
'use client';

import { useEffect, useState } from 'react';
import type { z } from 'zod';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { apiFetch } from '@/lib/api-client';
import {
  QudraAdminCustomers,
  QudraAdminDevices,
  QudraAdminDiagnostics,
  QudraAdminEntitlements,
} from '@/lib/contracts/qudra-t7-admin';
export function T7OperationsPanel() {
  const [diagnostics, setDiagnostics] = useState<z.infer<typeof QudraAdminDiagnostics> | null>(
    null,
  );
  const [counts, setCounts] = useState<{
    customers: number;
    devices: number;
    entitlements: number;
  } | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    Promise.all([
      apiFetch('/api/admin/diagnostics', { schema: QudraAdminDiagnostics }),
      apiFetch('/api/admin/customers', { schema: QudraAdminCustomers }),
      apiFetch('/api/admin/devices', { schema: QudraAdminDevices }),
      apiFetch('/api/admin/entitlements', { schema: QudraAdminEntitlements }),
    ])
      .then(([nextDiagnostics, customers, devices, entitlements]) => {
        setDiagnostics(nextDiagnostics);
        setCounts({
          customers: customers.items.length,
          devices: devices.items.length,
          entitlements: entitlements.items.length,
        });
      })
      .catch(() => setError('Operativni podaci nisu dostupni.'));
  }, []);
  if (!diagnostics && !error)
    return <p className="text-sm text-muted-foreground">Učitavanje operacija…</p>;
  return (
    <div className="grid gap-6">
      <div>
        <p className="text-eyebrow text-primary">QUDRA / OPERACIJE</p>
        <h1 className="text-h2">Globalni operativni pregled</h1>
        <p className="mt-2 text-body text-muted-foreground">
          Safe projections za Customers, Devices, licence i stanje sustava.
        </p>
      </div>
      {error ? (
        <p role="alert" className="text-sm text-destructive">
          {error}
        </p>
      ) : null}
      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          ['Customers', counts?.customers ?? 0],
          ['Devices', counts?.devices ?? 0],
          ['Entitlements', counts?.entitlements ?? 0],
          ['Partneri', diagnostics?.partnerCount ?? 0],
        ].map(([label, value]) => (
          <Card key={String(label)}>
            <CardHeader>
              <CardTitle className="text-small">{label}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-display">{value}</p>
            </CardContent>
          </Card>
        ))}
      </section>
      <Card>
        <CardHeader>
          <CardTitle className="text-h4">Diagnostics</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            {diagnostics?.activeEntitlementCount ?? 0} aktivnih software entitlements. Personal
            Source tajne nisu dio projekcije.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
