// @polsia:user-owned
'use client';

import { useEffect, useState } from 'react';
import type { z } from 'zod';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { apiFetch } from '@/lib/api-client';
import { QudraCreditLedger } from '@/lib/contracts/qudra-t7-credits';
import { QudraPartnerDetail } from '@/lib/contracts/qudra-t7-partner';

type Detail = z.infer<typeof QudraPartnerDetail>;
export function T7PartnerDetailPanel({ partnerId }: { partnerId: string }) {
  const [detail, setDetail] = useState<Detail | null>(null);
  const [ledger, setLedger] = useState<z.infer<typeof QudraCreditLedger> | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    Promise.all([
      apiFetch(`/api/admin/partners/${partnerId}`, { schema: QudraPartnerDetail }),
      apiFetch(`/api/admin/partners/${partnerId}/credits`, { schema: QudraCreditLedger }),
    ])
      .then(([nextDetail, nextLedger]) => {
        setDetail(nextDetail);
        setLedger(nextLedger);
      })
      .catch(() => setError('Nije moguće učitati Partner detalje.'));
  }, [partnerId]);
  if (!detail && !error)
    return <p className="text-sm text-muted-foreground">Učitavanje detalja…</p>;
  return (
    <div className="grid gap-6">
      <div>
        <p className="text-eyebrow text-primary">PARTNER CONTROL</p>
        <h1 className="text-h2">{detail?.partner.displayName ?? 'Partner'}</h1>
      </div>
      {error ? (
        <p role="alert" className="text-sm text-destructive">
          {error}
        </p>
      ) : null}
      <section className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-small">Status</CardTitle>
          </CardHeader>
          <CardContent>
            <Badge>{detail?.partner.status}</Badge>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-small">Krediti</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-display">
              {ledger?.balance.balance ?? detail?.balance.balance ?? 0}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-small">Customer scope</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-display">{detail?.scopeCount ?? 0}</p>
          </CardContent>
        </Card>
      </section>
      <Card>
        <CardHeader>
          <CardTitle className="text-h4">Ledger</CardTitle>
        </CardHeader>
        <CardContent>
          {ledger?.entries.length ? (
            <div className="grid gap-2">
              {ledger.entries.map((entry) => (
                <div
                  key={entry.id}
                  className="flex justify-between border-b border-border py-2 text-sm"
                >
                  <span>{entry.kind}</span>
                  <span className={entry.delta < 0 ? 'text-destructive' : 'text-primary'}>
                    {entry.delta > 0 ? '+' : ''}
                    {entry.delta}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">Ledger je prazan.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
