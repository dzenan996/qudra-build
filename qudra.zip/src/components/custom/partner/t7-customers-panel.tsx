// @polsia:user-owned
'use client';
import { useEffect, useState } from 'react';
import { z } from 'zod';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { apiFetch } from '@/lib/api-client';
import { QudraAdminDevices } from '@/lib/contracts/qudra-t7-admin';

const Customers = z.object({
  items: z.array(z.object({ id: z.string(), status: z.string(), deviceCount: z.number().int() })),
});
export function T7CustomersPanel() {
  const [customers, setCustomers] = useState<z.infer<typeof Customers>['items']>([]);
  const [devices, setDevices] = useState<z.infer<typeof QudraAdminDevices>['items']>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    Promise.all([
      apiFetch('/api/partner/customers', { schema: Customers }),
      apiFetch('/api/partner/devices', { schema: QudraAdminDevices }),
    ])
      .then(([c, d]) => {
        setCustomers(c.items);
        setDevices(d.items);
      })
      .catch(() => setError('Vlastiti scope nije dostupan.'))
      .finally(() => setLoading(false));
  }, []);
  if (loading) return <p className="text-sm text-muted-foreground">Učitavanje Customers…</p>;
  return (
    <div className="grid gap-6">
      <div>
        <p className="text-eyebrow text-primary">PARTNER / SCOPE</p>
        <h1 className="text-h2">Customers i Devices</h1>
      </div>
      {error ? (
        <p role="alert" className="text-sm text-destructive">
          {error}
        </p>
      ) : null}
      <Card>
        <CardHeader>
          <CardTitle className="text-h4">Vlastiti Customers</CardTitle>
        </CardHeader>
        <CardContent>
          {customers.length ? (
            <div className="grid gap-2">
              {customers.map((customer) => (
                <div
                  key={customer.id}
                  className="flex justify-between border-b border-border py-2 text-sm"
                >
                  <span>{customer.id}</span>
                  <span>{customer.deviceCount} uređaja</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">Nema Customer scopea.</p>
          )}
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle className="text-h4">Vlastiti Devices</CardTitle>
        </CardHeader>
        <CardContent>
          {devices.length ? (
            <div className="grid gap-2">
              {devices.map((device) => (
                <div
                  key={device.id}
                  className="flex justify-between border-b border-border py-2 text-sm"
                >
                  <span>{device.displayName ?? device.id}</span>
                  <span>
                    {device.productFamily} / {device.status}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">Nema Devicea u scopeu.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
