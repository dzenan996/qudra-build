// @polsia:user-owned
'use client';
import { useCallback, useEffect, useState } from 'react';
import type { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { apiFetch } from '@/lib/api-client';
import {
  QudraPartnerActivationInput,
  QudraPartnerActivationList,
} from '@/lib/contracts/qudra-t7-activation';
export function T7ActivationsPanel() {
  const [items, setItems] = useState<z.infer<typeof QudraPartnerActivationList>['items']>([]);
  const [customerId, setCustomerId] = useState('');
  const [deviceId, setDeviceId] = useState('');
  const [kind, setKind] = useState<'ANNUAL' | 'LIFETIME'>('ANNUAL');
  const [error, setError] = useState<string | null>(null);
  const load = useCallback(
    () =>
      apiFetch('/api/partner/activations', { schema: QudraPartnerActivationList })
        .then((data) => setItems(data.items))
        .catch(() => setError('Aktivacije nisu dostupne.')),
    [],
  );
  useEffect(() => {
    load();
  }, [load]);
  async function activate() {
    const parsed = QudraPartnerActivationInput.safeParse({
      customerId,
      deviceId,
      kind,
      idempotencyKey: `${deviceId}-${kind}-${Date.now()}`,
    });
    if (!parsed.success) {
      setError('Customer, Device i tip licence su obavezni.');
      return;
    }
    try {
      await apiFetch('/api/partner/activations', {
        method: 'POST',
        body: JSON.stringify(parsed.data),
      });
      setError(null);
      load();
    } catch {
      setError('Aktivacija nije uspjela; provjerite scope i kredite.');
    }
  }
  return (
    <div className="grid gap-6">
      <div>
        <p className="text-eyebrow text-primary">PARTNER / LICENSING</p>
        <h1 className="text-h2">Software aktivacije</h1>
        <p className="mt-2 text-body text-muted-foreground">
          Jedan credit po uspješnoj Annual ili Lifetime aktivaciji.
        </p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="text-h4">Nova aktivacija</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-2">
          <Input
            aria-label="Customer ID"
            placeholder="Customer ID"
            value={customerId}
            onChange={(event) => setCustomerId(event.target.value)}
          />
          <Input
            aria-label="Device ID"
            placeholder="Device ID"
            value={deviceId}
            onChange={(event) => setDeviceId(event.target.value)}
          />
          <select
            aria-label="Vrsta licence"
            className="h-10 rounded-md border border-input bg-background px-3 text-sm"
            value={kind}
            onChange={(event) => setKind(event.target.value as 'ANNUAL' | 'LIFETIME')}
          >
            <option value="ANNUAL">Annual — 365 dana</option>
            <option value="LIFETIME">Lifetime</option>
          </select>
          <Button type="button" onClick={activate}>
            Aktiviraj licencu
          </Button>
        </CardContent>
      </Card>
      {error ? (
        <p role="alert" className="text-sm text-destructive">
          {error}
        </p>
      ) : null}
      <Card>
        <CardHeader>
          <CardTitle className="text-h4">Povijest aktivacija</CardTitle>
        </CardHeader>
        <CardContent>
          {items.length ? (
            <div className="grid gap-2">
              {items.map((item) => (
                <div
                  key={item.id}
                  className="flex flex-col border-b border-border py-3 text-sm sm:flex-row sm:justify-between"
                >
                  <span>
                    {item.kind} / {item.productFamily} / {item.status}
                  </span>
                  <span className="text-muted-foreground">{item.deviceId}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">Još nema aktivacija.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
