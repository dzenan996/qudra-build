// @polsia:user-owned
'use client';
import { useEffect, useState } from 'react';
import type { z } from 'zod';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { apiFetch } from '@/lib/api-client';
import { QudraPartnerSummary } from '@/lib/contracts/qudra-t7-partner';
export function T7OverviewPanel() {
  const [data, setData] = useState<z.infer<typeof QudraPartnerSummary> | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    apiFetch('/api/partner/summary', { schema: QudraPartnerSummary })
      .then(setData)
      .catch(() => setError('Partner summary nije dostupan.'));
  }, []);
  if (!data && !error)
    return <p className="text-sm text-muted-foreground">Učitavanje Partner pregleda…</p>;
  return (
    <div className="grid gap-6">
      <div>
        <p className="text-eyebrow text-primary">QUDRA / PARTNER</p>
        <h1 className="text-h2">{data?.partner.displayName ?? 'Partner overview'}</h1>
        <p className="mt-2 text-body text-muted-foreground">
          Vlastiti Customers, Devices i software activation krediti.
        </p>
      </div>
      {error ? (
        <p role="alert" className="text-sm text-destructive">
          {error}
        </p>
      ) : null}
      <section className="grid gap-4 sm:grid-cols-3">
        {[
          ['Customers', data?.customers ?? 0],
          ['Devices', data?.devices ?? 0],
          ['Credits', data?.balance ?? 0],
        ].map(([label, value]) => (
          <Card key={String(label)}>
            <CardHeader>
              <CardTitle className="text-small">{label}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-display">{value}</p>
            </CardContent>
          </Card>
        ))}
      </section>
    </div>
  );
}
