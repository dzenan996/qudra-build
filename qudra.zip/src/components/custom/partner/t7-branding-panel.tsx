// @polsia:user-owned
'use client';
import { useEffect, useState } from 'react';
import type { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { apiFetch } from '@/lib/api-client';
import { QudraPartnerBranding, QudraPartnerBrandingWrite } from '@/lib/contracts/qudra-t7-partner';
export function T7BrandingPanel() {
  const [data, setData] = useState<z.infer<typeof QudraPartnerBranding> | null>(null);
  const [displayName, setDisplayName] = useState('');
  const [logoUrl, setLogoUrl] = useState('');
  const [supportEmail, setSupportEmail] = useState('');
  const [supportPhone, setSupportPhone] = useState('');
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    apiFetch('/api/partner/branding', { schema: QudraPartnerBranding })
      .then((next) => {
        setData(next);
        setDisplayName(next.proposed.displayName ?? '');
        setLogoUrl(next.proposed.logoUrl ?? '');
        setSupportEmail(next.proposed.supportEmail ?? '');
        setSupportPhone(next.proposed.supportPhone ?? '');
      })
      .catch(() => setError('Branding nije dostupan.'));
  }, []);
  async function submit() {
    const parsed = QudraPartnerBrandingWrite.safeParse({
      displayName: displayName || null,
      logoUrl: logoUrl || null,
      supportEmail: supportEmail || null,
      supportPhone: supportPhone || null,
    });
    if (!parsed.success) {
      setError('Branding podržava samo naziv, jedan logo i support kontakte.');
      return;
    }
    try {
      const next = await apiFetch('/api/partner/branding', {
        method: 'PATCH',
        body: JSON.stringify(parsed.data),
        schema: QudraPartnerBranding,
      });
      setData(next);
      setError(null);
    } catch {
      setError('Branding prijedlog nije spremljen.');
    }
  }
  return (
    <div className="grid gap-6">
      <div>
        <p className="text-eyebrow text-primary">PARTNER / BRANDING</p>
        <h1 className="text-h2">Support branding</h1>
        <p className="mt-2 text-body text-muted-foreground">
          Ograničeno na display name, jedan logo, support email i support phone/WhatsApp. Svaka
          promjena čeka Super Admin approval.
        </p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="text-h4">Prijedlog</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3">
          <Input
            aria-label="Display name"
            placeholder="Display name"
            value={displayName}
            onChange={(event) => setDisplayName(event.target.value)}
          />
          <Input
            aria-label="Logo URL"
            placeholder="Logo URL"
            value={logoUrl}
            onChange={(event) => setLogoUrl(event.target.value)}
          />
          <Input
            aria-label="Support email"
            placeholder="Support email"
            value={supportEmail}
            onChange={(event) => setSupportEmail(event.target.value)}
          />
          <Input
            aria-label="Support phone"
            placeholder="Support phone / WhatsApp"
            value={supportPhone}
            onChange={(event) => setSupportPhone(event.target.value)}
          />
          <Button type="button" onClick={submit}>
            Pošalji na approval
          </Button>
        </CardContent>
      </Card>
      {data ? (
        <p className="text-sm text-muted-foreground">
          Stanje prijedloga: <span className="font-semibold text-foreground">{data.state}</span>
        </p>
      ) : null}
      {error ? (
        <p role="alert" className="text-sm text-destructive">
          {error}
        </p>
      ) : null}
    </div>
  );
}
