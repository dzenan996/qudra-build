// @polsia:user-owned
'use client';
import { useCallback, useEffect, useState } from 'react';
import type { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { apiFetch } from '@/lib/api-client';
import {
  QudraReplacementRequestInput,
  QudraReplacementRequests,
  QudraTrialExceptionInput,
  QudraTrialExceptionRequests,
} from '@/lib/contracts/qudra-t7-requests';
export function T7RequestsPanel() {
  const [replacements, setReplacements] = useState<
    z.infer<typeof QudraReplacementRequests>['items']
  >([]);
  const [trials, setTrials] = useState<z.infer<typeof QudraTrialExceptionRequests>['items']>([]);
  const [customerId, setCustomerId] = useState('');
  const [oldDeviceId, setOldDeviceId] = useState('');
  const [newDeviceId, setNewDeviceId] = useState('');
  const [reason, setReason] = useState('');
  const [error, setError] = useState<string | null>(null);
  const load = useCallback(
    () =>
      Promise.all([
        apiFetch('/api/partner/replacement-requests', { schema: QudraReplacementRequests }),
        apiFetch('/api/partner/trial-exception-requests', { schema: QudraTrialExceptionRequests }),
      ])
        .then(([r, t]) => {
          setReplacements(r.items);
          setTrials(t.items);
        })
        .catch(() => setError('Zahtjevi nisu dostupni.')),
    [],
  );
  useEffect(() => {
    load();
  }, [load]);
  async function submitReplacement() {
    const parsed = QudraReplacementRequestInput.safeParse({
      customerId,
      oldDeviceId,
      newDeviceId,
      reason,
    });
    if (!parsed.success) {
      setError('Sva polja za replacement su obavezna.');
      return;
    }
    try {
      await apiFetch('/api/partner/replacement-requests', {
        method: 'POST',
        body: JSON.stringify(parsed.data),
      });
      load();
    } catch {
      setError('Replacement zahtjev nije poslan.');
    }
  }
  async function submitTrial() {
    const parsed = QudraTrialExceptionInput.safeParse({
      customerId,
      deviceId: oldDeviceId,
      reason,
    });
    if (!parsed.success) {
      setError('Customer, Device i razlog su obavezni.');
      return;
    }
    try {
      await apiFetch('/api/partner/trial-exception-requests', {
        method: 'POST',
        body: JSON.stringify(parsed.data),
      });
      load();
    } catch {
      setError('Trial exception zahtjev nije poslan.');
    }
  }
  return (
    <div className="grid gap-6">
      <div>
        <p className="text-eyebrow text-primary">PARTNER / REQUESTS</p>
        <h1 className="text-h2">Zahtjevi</h1>
        <p className="mt-2 text-body text-muted-foreground">
          Partner samo predaje zahtjev; Super Admin donosi odluku.
        </p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="text-h4">Novi zahtjev</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-2">
          <Input
            aria-label="Customer ID"
            placeholder="Customer ID"
            value={customerId}
            onChange={(event) => setCustomerId(event.target.value)}
          />
          <Input
            aria-label="Stari Device ID"
            placeholder="Old Device ID"
            value={oldDeviceId}
            onChange={(event) => setOldDeviceId(event.target.value)}
          />
          <Input
            aria-label="Novi Device ID"
            placeholder="New Device ID"
            value={newDeviceId}
            onChange={(event) => setNewDeviceId(event.target.value)}
          />
          <Input
            aria-label="Razlog"
            placeholder="Razlog"
            value={reason}
            onChange={(event) => setReason(event.target.value)}
          />
          <Button type="button" variant="outline" onClick={submitReplacement}>
            Zatraži replacement
          </Button>
          <Button type="button" onClick={submitTrial}>
            Zatraži Trial iznimku
          </Button>
        </CardContent>
      </Card>
      {error ? (
        <p role="alert" className="text-sm text-destructive">
          {error}
        </p>
      ) : null}
      <Card>
        <CardHeader>
          <CardTitle className="text-h4">Replacement zahtjevi ({replacements.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {replacements.length ? (
            replacements.map((item) => (
              <p key={item.id} className="border-b border-border py-2 text-sm">
                {item.oldDeviceId} → {item.newDeviceId} / {item.status}
              </p>
            ))
          ) : (
            <p className="text-sm text-muted-foreground">Nema replacement zahtjeva.</p>
          )}
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle className="text-h4">Trial exception zahtjevi ({trials.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {trials.length ? (
            trials.map((item) => (
              <p key={item.id} className="border-b border-border py-2 text-sm">
                {item.deviceId} / {item.status}
              </p>
            ))
          ) : (
            <p className="text-sm text-muted-foreground">Nema Trial zahtjeva.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
