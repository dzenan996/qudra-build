// @polsia:user-owned — My List-only source selection.
'use client';

import type { z } from 'zod';
import { Button } from '@/components/ui/button';
import { apiFetch } from '@/lib/api-client';
import {
  QudraActiveSource,
  QudraActiveSourceSelection,
  type QudraSourceConfig,
} from '@/lib/contracts/qudra-source';

export function MyListSourcePicker({
  deviceId,
  sources,
  active,
  onChanged,
}: {
  deviceId: string;
  sources: z.infer<typeof QudraSourceConfig>[];
  active: z.infer<typeof QudraActiveSource>;
  onChanged: () => void;
}) {
  async function select(kind: 'QUDRA_OPEN' | 'PERSONAL_SOURCE', sourceConfigId?: string) {
    const selection = QudraActiveSourceSelection.parse({ kind, sourceConfigId });
    await apiFetch(`/api/qudra/devices/${deviceId}/active-source`, {
      method: 'PUT',
      body: JSON.stringify(selection),
      schema: QudraActiveSource,
    });
    onChanged();
  }
  return (
    <fieldset className="flex flex-wrap gap-2" aria-label="My List source">
      <Button
        type="button"
        variant={active.kind === 'QUDRA_OPEN' ? 'default' : 'outline'}
        size="sm"
        onClick={() => void select('QUDRA_OPEN')}
      >
        QUDRA OPEN
      </Button>
      {sources.map((source) => (
        <Button
          key={source.id}
          type="button"
          variant={active.sourceConfigId === source.id ? 'default' : 'outline'}
          size="sm"
          onClick={() => void select('PERSONAL_SOURCE', source.id)}
        >
          {source.label}
        </Button>
      ))}
    </fieldset>
  );
}
