// @polsia:user-owned — optional account claim island.
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { apiFetch } from '@/lib/api-client';
import { QudraClaimRequest, QudraClaimResult } from '@/lib/contracts/qudra-claim';

export function ClaimDeviceForm({ onComplete }: { onComplete: () => void }) {
  const [challengeId, setChallengeId] = useState('');
  const [response, setResponse] = useState('');
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  async function submit() {
    const parsed = QudraClaimRequest.safeParse({ challengeId, response });
    if (!parsed.success) {
      setMessage('Enter the challenge ID and the one-time response from your Device.');
      return;
    }
    setBusy(true);
    setMessage(null);
    try {
      await apiFetch('/api/qudra/claims', {
        method: 'POST',
        body: JSON.stringify(parsed.data),
        schema: QudraClaimResult,
      });
      setMessage('Device linked to this QUDRA Customer.');
      setChallengeId('');
      setResponse('');
      onComplete();
    } catch {
      setMessage('The claim could not be completed. The challenge may be expired or already used.');
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="grid gap-4 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
      <div className="space-y-2">
        <Label htmlFor="claim-challenge">Challenge ID</Label>
        <Input
          id="claim-challenge"
          value={challengeId}
          onChange={(event) => setChallengeId(event.target.value)}
          placeholder="From your Device"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="claim-response">One-time response</Label>
        <Input
          id="claim-response"
          value={response}
          onChange={(event) => setResponse(event.target.value)}
          type="password"
          autoComplete="off"
        />
      </div>
      <Button type="button" onClick={submit} disabled={busy}>
        {busy ? 'Linking…' : 'Link Device'}
      </Button>
      {message && (
        <output className="text-small text-muted-foreground sm:col-span-3">{message}</output>
      )}
    </div>
  );
}
