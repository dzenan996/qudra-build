// @polsia:user-owned — approved URL-based Personal Source form.
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { apiFetch } from '@/lib/api-client';
import { QudraSourceConfig, QudraSourceWrite } from '@/lib/contracts/qudra-source';

export function SourceConfigForm({ deviceId, onSaved }: { deviceId: string; onSaved: () => void }) {
  const [label, setLabel] = useState('Personal Source');
  const [endpointUrl, setEndpointUrl] = useState('');
  const [epgUrl, setEpgUrl] = useState('');
  const [secret, setSecret] = useState('');
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  async function submit() {
    const input = {
      label,
      sourceType: 'personal_source' as const,
      endpointUrl: endpointUrl || undefined,
      epgUrl: epgUrl || undefined,
      secret: secret || undefined,
    };
    const parsed = QudraSourceWrite.safeParse(input);
    if (!parsed.success) {
      setMessage('Use a valid playlist URL and optional XMLTV URL.');
      return;
    }
    setBusy(true);
    setMessage(null);
    try {
      await apiFetch(`/api/qudra/devices/${deviceId}/source-configs`, {
        method: 'POST',
        headers: { 'Idempotency-Key': crypto.randomUUID() },
        body: JSON.stringify(parsed.data),
        schema: QudraSourceConfig,
      });
      setMessage('Personal Source saved. Refresh runs on the Device.');
      setEndpointUrl('');
      setEpgUrl('');
      setSecret('');
      onSaved();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Could not save Personal Source.');
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="grid gap-4 border border-border bg-muted/20 p-5 lg:grid-cols-2">
      <div className="space-y-2">
        <Label htmlFor={`source-label-${deviceId}`}>Source name</Label>
        <Input
          id={`source-label-${deviceId}`}
          value={label}
          onChange={(event) => setLabel(event.target.value)}
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor={`source-url-${deviceId}`}>M3U/M3U8 playlist URL</Label>
        <Input
          id={`source-url-${deviceId}`}
          type="url"
          value={endpointUrl}
          onChange={(event) => setEndpointUrl(event.target.value)}
          placeholder="http://… or https://…"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor={`source-epg-${deviceId}`}>Optional XMLTV URL</Label>
        <Input
          id={`source-epg-${deviceId}`}
          type="url"
          value={epgUrl}
          onChange={(event) => setEpgUrl(event.target.value)}
          placeholder="http://… or https://…"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor={`source-secret-${deviceId}`}>Optional connection secret</Label>
        <Input
          id={`source-secret-${deviceId}`}
          type="password"
          autoComplete="off"
          value={secret}
          onChange={(event) => setSecret(event.target.value)}
          placeholder="Sealed server-side"
        />
      </div>
      <div className="lg:col-span-2">
        <Button type="button" onClick={submit} disabled={busy}>
          {busy ? 'Saving…' : 'Add Personal Source'}
        </Button>
      </div>
      {message && (
        <output className="text-small text-muted-foreground lg:col-span-2">{message}</output>
      )}
    </div>
  );
}
