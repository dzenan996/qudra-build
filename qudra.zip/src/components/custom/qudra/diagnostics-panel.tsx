// @polsia:user-owned — redacted diagnostic states.
'use client';

import type { z } from 'zod';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import type { QudraDiagnosticList } from '@/lib/contracts/qudra-diagnostics';

export function DiagnosticsPanel({
  diagnostics,
}: {
  diagnostics: z.infer<typeof QudraDiagnosticList>['items'];
}) {
  return (
    <div className="space-y-2">
      {diagnostics.length === 0 ? (
        <p className="text-small text-muted-foreground">No current diagnostic observations.</p>
      ) : (
        diagnostics.map((item) => (
          <Alert key={item.id} className="flex items-center justify-between gap-3">
            <span>
              <strong>{item.code}</strong>
              <span className="ml-2 text-small text-muted-foreground">{item.message}</span>
            </span>
            <Badge variant={item.retryable ? 'secondary' : 'outline'}>{item.state}</Badge>
          </Alert>
        ))
      )}
    </div>
  );
}
