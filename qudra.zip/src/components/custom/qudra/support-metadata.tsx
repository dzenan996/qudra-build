// @polsia:user-owned — support and approved metadata display.
import { Mail, ShieldCheck } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

export function SupportMetadata() {
  return (
    <div className="flex flex-wrap items-center gap-3 border-t border-border pt-5 text-small text-muted-foreground">
      <ShieldCheck className="size-4 text-primary" aria-hidden="true" />
      <span>QUDRA support metadata is limited to the device and partner record.</span>
      <Button asChild variant="link" size="sm" className="px-0">
        <Link href="mailto:qudra@polsia.app">
          <Mail className="mr-2 size-4" aria-hidden="true" />
          Contact support
        </Link>
      </Button>
    </div>
  );
}
