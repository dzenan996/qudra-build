// @polsia:user-owned — reusable Device summary card.
'use client';

import { Copy, RefreshCw } from 'lucide-react';
import { useState } from 'react';
import type { z } from 'zod';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { QudraDeviceSummary } from '@/lib/contracts/qudra-my-qudra';
import { MyListSourcePicker } from './my-list-source-picker';
import { SourceConfigForm } from './source-config-form';

export function DeviceCard({
  device,
  onRefresh,
}: {
  device: z.infer<typeof QudraDeviceSummary>;
  onRefresh: () => void;
}) {
  const [message, setMessage] = useState<string | null>(null);
  async function copyId() {
    await navigator.clipboard.writeText(device.publicDeviceId);
    setMessage('Device ID copied.');
  }
  return (
    <Card className="lift overflow-hidden rounded-sm border-border shadow-md">
      <CardHeader className="border-b border-border bg-muted/30">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-eyebrow">
              {device.productFamily} / {device.platform}
            </p>
            <CardTitle className="mt-2 font-display text-h4">
              {device.displayName || device.deviceModel || 'Unnamed Device'}
            </CardTitle>
            <p className="mt-1 text-small text-muted-foreground">
              {device.status} · registered {new Date(device.registeredAt).toLocaleDateString()}
            </p>
          </div>
          <Badge variant={device.access.personalSourceAllowed ? 'default' : 'secondary'}>
            {device.access.entitlementActive
              ? device.access.entitlementKind || 'ENTITLEMENT'
              : device.access.trialActive
                ? 'TRIAL'
                : 'QUDRA OPEN'}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6 pt-6">
        <div className="grid gap-4 text-small sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <p className="text-muted-foreground">Device ID</p>
            <p className="mt-1 break-all font-mono">{device.publicDeviceId}</p>
            <Button
              type="button"
              variant="link"
              size="sm"
              className="h-auto px-0"
              onClick={() => void copyId()}
            >
              <Copy className="mr-1 size-3" />
              Copy ID
            </Button>
          </div>
          <div>
            <p className="text-muted-foreground">License</p>
            <p className="mt-1">
              {device.access.entitlementState ||
                (device.access.trialActive ? 'TRIAL ACTIVE' : 'OPEN ONLY')}
            </p>
          </div>
          <div>
            <p className="text-muted-foreground">Last Sync</p>
            <p className="mt-1">
              {device.sync.find((item) => item.lastSuccessAt)?.lastSuccessAt
                ? new Date(
                    device.sync.find((item) => item.lastSuccessAt)?.lastSuccessAt || '',
                  ).toLocaleString()
                : 'Not synced'}
            </p>
          </div>
          <div>
            <p className="text-muted-foreground">Direct playback</p>
            <p className="mt-1">
              {device.access.qudraOpen ? 'QUDRA OPEN available' : 'Unavailable'}
            </p>
          </div>
        </div>
        <div>
          <p className="mb-3 text-eyebrow">My List source</p>
          <MyListSourcePicker
            deviceId={device.id}
            sources={device.sources}
            active={device.activeSource}
            onChanged={onRefresh}
          />
        </div>
        <div className="rounded-sm border border-border p-4">
          <div className="mb-4 flex items-center justify-between gap-3">
            <div>
              <p className="text-eyebrow">Personal Sources</p>
              <p className="mt-1 text-small text-muted-foreground">
                Up to two per Device. QUDRA OPEN is always separate.
              </p>
            </div>
            <Button type="button" variant="outline" size="sm" onClick={onRefresh}>
              <RefreshCw className="mr-2 size-4" />
              Refresh Device
            </Button>
          </div>
          <div className="space-y-3">
            {device.sources.map((source) => (
              <div
                key={source.id}
                className="flex flex-wrap items-center justify-between gap-3 border-b border-border pb-3 last:border-0 last:pb-0"
              >
                <div>
                  <p className="font-medium">{source.label}</p>
                  <p className="text-small text-muted-foreground">
                    {source.endpointUrl || 'URL not configured'} · version {source.configVersion} ·{' '}
                    {source.hasSecret ? 'secret sealed' : 'no secret'}
                  </p>
                </div>
                <Badge variant="outline">slot {source.slot}</Badge>
              </div>
            ))}
          </div>
          <div className="mt-5">
            <SourceConfigForm deviceId={device.id} onSaved={onRefresh} />
          </div>
        </div>
        {message && <output className="text-small text-muted-foreground">{message}</output>}
      </CardContent>
    </Card>
  );
}
