// @polsia:user-owned — client island for the optional-account My Qudra control surface.
'use client';

import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import type { z } from 'zod';
import { Alert } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { apiFetch } from '@/lib/api-client';
import { useSession } from '@/lib/auth-client';
import { QudraDiagnosticList } from '@/lib/contracts/qudra-diagnostics';
import { QudraMe } from '@/lib/contracts/qudra-my-qudra';
import { ClaimDeviceForm } from './claim-device-form';
import { DeviceCard } from './device-card';
import { DiagnosticsPanel } from './diagnostics-panel';
import { SupportMetadata } from './support-metadata';

export function MyQudraPanel() {
  const { data: session, isPending: sessionPending } = useSession();
  const [summary, setSummary] = useState<z.infer<typeof QudraMe> | null>(null);
  const [diagnostics, setDiagnostics] = useState<z.infer<typeof QudraDiagnosticList>['items']>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const next = await apiFetch('/api/qudra/me', { schema: QudraMe });
      setSummary(next);
      if (next.devices[0]) {
        const current = await apiFetch(
          `/api/qudra/devices/${next.devices[0].id}/diagnostics/current`,
          { schema: QudraDiagnosticList },
        );
        setDiagnostics(current.items);
      }
    } catch {
      setError('My Qudra is temporarily unavailable. Try again in a moment.');
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);
  if (loading || sessionPending)
    return (
      <output className="rounded-sm border border-border bg-muted/20 p-8 text-muted-foreground">
        Loading My Qudra…
      </output>
    );
  if (error)
    return (
      <Alert variant="destructive">
        <p>{error}</p>
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="mt-4"
          onClick={() => void load()}
        >
          Try again
        </Button>
      </Alert>
    );
  if (!summary) return null;
  if (!session?.user)
    return (
      <Card className="rounded-sm border-primary/30 bg-primary/5 shadow-md">
        <CardHeader>
          <p className="text-eyebrow">OPTIONAL ACCOUNT</p>
          <CardTitle className="font-display text-h3">Your Device can stay device-first.</CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          <p className="max-w-2xl text-muted-foreground">
            Sign in when you want to claim a Device, manage multiple screens, or configure Personal
            Sources from this control plane. QUDRA OPEN remains available without an account.
          </p>
          <div className="flex flex-wrap gap-3">
            <Button asChild>
              <Link href="/login">Sign in</Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/signup">Create account</Link>
            </Button>
          </div>
          <SupportMetadata />
        </CardContent>
      </Card>
    );
  return (
    <div className="space-y-8">
      <Card className="rounded-sm border-border shadow-sm">
        <CardHeader>
          <p className="text-eyebrow">ACCOUNT / CUSTOMER</p>
          <CardTitle className="font-display text-h3">
            {summary.account ? 'Your QUDRA Devices' : 'Link your first Device'}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <p className="text-muted-foreground">
            {summary.account
              ? 'Each Device keeps its own trial, license, source limit, and playback boundary.'
              : 'Use the short-lived challenge shown by a paired Device. No public Device ID is accepted as proof.'}
          </p>
          <ClaimDeviceForm onComplete={() => void load()} />
          <SupportMetadata />
        </CardContent>
      </Card>
      {summary.devices.length === 0 ? (
        <div className="rounded-sm border border-dashed border-border p-8 text-center text-muted-foreground">
          No account-owned Devices yet. Complete a Device claim or register one from an
          authenticated Device flow.
        </div>
      ) : (
        <div className="space-y-6">
          {summary.devices.map((device) => (
            <div key={device.id} className="space-y-5">
              <DeviceCard device={device} onRefresh={() => void load()} />
              <Card className="rounded-sm border-border">
                <CardHeader>
                  <CardTitle className="font-display text-h4">Current diagnostics</CardTitle>
                </CardHeader>
                <CardContent>
                  <DiagnosticsPanel diagnostics={diagnostics} />
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
