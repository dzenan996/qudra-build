// @polsia:user-owned — client island for the implementation-backed privacy inventory.
'use client';

import { useEffect, useState } from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { apiFetch } from '@/lib/api-client';
import { PrivacyInventory } from '@/lib/contracts/privacy';

async function loadPrivacy() {
  return apiFetch('/api/privacy', { schema: PrivacyInventory });
}

export function PrivacyPolicyPanel() {
  const [inventory, setInventory] = useState<Awaited<ReturnType<typeof loadPrivacy>> | null>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    void loadPrivacy()
      .then(setInventory)
      .catch(() => setError(true));
  }, []);

  if (error)
    return (
      <Alert variant="destructive">
        <AlertTitle>Inventar nije dostupan</AlertTitle>
        <AlertDescription>Pokušajte ponovno kasnije.</AlertDescription>
      </Alert>
    );
  if (!inventory) return <p className="text-muted-foreground">Učitavanje inventara…</p>;

  return (
    <div className="grid gap-5">
      <div className="grid gap-2 sm:grid-cols-3">
        {(['cloud', 'device', 'direct-origin'] as const).map((location) => (
          <Card key={location} className="bg-card/70">
            <CardHeader className="pb-3">
              <CardTitle className="text-small uppercase tracking-[0.12em]">
                {location === 'cloud'
                  ? 'QUDRA Cloud'
                  : location === 'device'
                    ? 'Samo uređaj'
                    : 'Izravni origin / Cast'}
              </CardTitle>
            </CardHeader>
            <CardContent className="text-small text-muted-foreground">
              {inventory.items.filter((item) => item.location === location).length} opisane
              kategorije
            </CardContent>
          </Card>
        ))}
      </div>
      {inventory.items.map((item) => (
        <Card key={item.label} className="border-border/80">
          <CardHeader className="gap-3 sm:flex-row sm:items-start sm:justify-between">
            <CardTitle className="text-h4">{item.label}</CardTitle>
            <Badge variant={item.location === 'not-collected' ? 'outline' : 'secondary'}>
              {item.location}
            </Badge>
          </CardHeader>
          <CardContent className="grid gap-4 text-body text-muted-foreground">
            <p>{item.details}</p>
            <p className="text-caption">Play Data Safety: {item.playDataSafety.join(' · ')}</p>
          </CardContent>
        </Card>
      ))}
      <Alert>
        <AlertTitle>Otvorene Owner/legal stavke</AlertTitle>
        <AlertDescription>
          <ul className="grid gap-1">
            {inventory.ownerActionRequired.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </AlertDescription>
      </Alert>
    </div>
  );
}
