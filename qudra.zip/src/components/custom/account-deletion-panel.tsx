// @polsia:user-owned — client island for the functional QUDRA deletion flow.
'use client';

import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { apiFetch } from '@/lib/api-client';
import {
  AccountDeletionResult,
  AccountDeletionStatus,
  accountDeletionConfirmation,
} from '@/lib/contracts/account-deletion';

type PanelState = 'loading' | 'ready' | 'signed-out' | 'error' | 'success';

async function loadStatus() {
  return apiFetch('/api/account', { schema: AccountDeletionStatus });
}

export function AccountDeletionPanel() {
  const [state, setState] = useState<PanelState>('loading');
  const [confirmation, setConfirmation] = useState('');
  const [password, setPassword] = useState('');
  const [status, setStatus] = useState<Awaited<ReturnType<typeof loadStatus>> | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    void loadStatus()
      .then((result) => {
        setStatus(result);
        setState(result.authenticated ? 'ready' : 'signed-out');
      })
      .catch(() => setState('error'));
  }, []);

  async function deleteAccount() {
    setSubmitting(true);
    try {
      await apiFetch('/api/account', {
        method: 'DELETE',
        body: JSON.stringify({ confirmation, password: password || undefined }),
        schema: AccountDeletionResult,
      });
      setState('success');
      toast.success('QUDRA račun je obrisan.');
      window.location.assign('/');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Brisanje računa nije uspjelo.');
    } finally {
      setSubmitting(false);
    }
  }

  if (state === 'loading') return <p className="text-muted-foreground">Učitavanje pravila…</p>;
  if (state === 'error') {
    return (
      <Alert variant="destructive">
        <AlertTitle>Podaci nisu dostupni</AlertTitle>
        <AlertDescription>Pokušajte ponovno.</AlertDescription>
      </Alert>
    );
  }
  if (state === 'success')
    return (
      <Alert>
        <AlertTitle>Brisanje je dovršeno</AlertTitle>
        <AlertDescription>Vaša autentificirana QUDRA sesija i račun su obrisani.</AlertDescription>
      </Alert>
    );
  if (state === 'signed-out' || !status?.authenticated) {
    return (
      <Alert>
        <AlertTitle>Prijava je potrebna</AlertTitle>
        <AlertDescription>
          <Button asChild variant="outline" className="mt-3">
            <a href="/login">Prijavite se za brisanje računa</a>
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Card className="border-primary/30 shadow-lg">
      <CardHeader>
        <CardTitle className="text-h4">Trajno brisanje QUDRA računa</CardTitle>
        <CardDescription>
          Ovaj korak briše Better Auth korisnika, povezane auth račune i sesije. QUDRA Customer,
          Device, licenca, ledger i audit zapisi ne brišu se tiho.
        </CardDescription>
      </CardHeader>
      <CardContent className="grid gap-6">
        <div className="grid gap-2">
          <Label htmlFor="deletion-confirmation">Potvrda</Label>
          <Input
            id="deletion-confirmation"
            value={confirmation}
            onChange={(event) => setConfirmation(event.target.value)}
            placeholder={accountDeletionConfirmation}
            autoComplete="off"
          />
          <p className="text-caption text-muted-foreground">
            Upišite: {accountDeletionConfirmation}
          </p>
        </div>
        <div className="grid gap-2">
          <Label htmlFor="deletion-password">
            Lozinka, ako je potrebna za ponovnu autentifikaciju
          </Label>
          <Input
            id="deletion-password"
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            autoComplete="current-password"
          />
        </div>
        <Button
          type="button"
          variant="destructive"
          disabled={submitting || confirmation !== accountDeletionConfirmation}
          onClick={() => void deleteAccount()}
        >
          {submitting ? 'Brisanje…' : 'Obriši moj QUDRA račun'}
        </Button>
        <ul className="grid gap-2 text-small text-muted-foreground">
          {status.ownerActionRequired.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}
