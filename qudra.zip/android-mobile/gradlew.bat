@echo off
set SCRIPT_DIR=%~dp0
set CACHE_ROOT=%GRADLE_USER_HOME%
if "%CACHE_ROOT%"=="" set CACHE_ROOT=%TEMP%\qudra-gradle
set DIST_DIR=%CACHE_ROOT%\wrapper\dists\gradle-8.9-bin
set GRADLE_BIN=%DIST_DIR%\gradle-8.9\bin\gradle.bat
if not exist "%GRADLE_BIN%" (
  mkdir "%DIST_DIR%"
  powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile '%DIST_DIR%\gradle.zip'"
  powershell -NoProfile -Command "Expand-Archive -Force '%DIST_DIR%\gradle.zip' '%DIST_DIR%'"
)
call "%GRADLE_BIN%" --project-dir "%SCRIPT_DIR%" %*
