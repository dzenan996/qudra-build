# QUDRA Mobile

Independent Android phone/tablet client for T6. The application is deliberately
separate from `android/` (the TV client): it uses `com.qudra.mobile`, registers
as `ANDROID_PHONE` or `ANDROID_TABLET` with `productFamily=MOBILE`, and keeps its
own Keystore identity, Device session, local source catalogue, EPG, and playback
state.

Build with `./gradlew testDebugUnitTest lint assembleDebug`. Mobile konfiguracija
sada deklarira `compileSdk = 36` i `targetSdk = 36`, prema aktualnom Play
zahtjevu za nove Mobile prijave i nadogradnje od 2026-08-31. Kompatibilnost nije
build-dokazana u ovom sandboxu jer JDK, Android SDK 36, Gradle extraction i
`adb` nisu dostupni. Zadajte API origin
with `-PqudraApiBaseUrl=https://your-app.example`. Debug builds use the explicit
Google Default Media Receiver development fallback `CC1AD845` when no receiver
property is supplied; release builds fail closed unless the Owner supplies a
registered receiver ID with `-PqudraCastReceiverAppId=<owner-receiver-id>`. The
Owner must register the production receiver ID in Google Cast Developer Console
before production use.

Na Android hostu pokrenite puni Mobile QA paket nakon potvrde SDK-a 36 i JDK-a
17. Production signing secret ni Cast receiver ID ne pripadaju ovom repozitoriju.

QUDRA Cloud receives only device/control-plane metadata and aggregate source
sync reports. Playlist bytes, credentials, catalogue rows, EPG rows, and
viewing state remain on the Mobile Device. Playback is direct source origin to
the Device or a Cast receiver; there is no media relay.

Cast discovery i session ostaju u Google Cast frameworku. Android ne daje pouzdan
app-level Boolean za dokaz istog SSID-a, pa Mobile prije slanja provjerava aktivnu
Cast session i dokazivi lokalni Wi-Fi/Ethernet transport; Personal Source se šalje
samo kao credential-free HTTPS direct origin kompatibilan s receiverom.
