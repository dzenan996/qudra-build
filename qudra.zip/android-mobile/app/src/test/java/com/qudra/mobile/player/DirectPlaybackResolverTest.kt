// @polsia:user-owned — JVM evidence for direct origin and unsupported-source rules.
package com.qudra.mobile.player

import com.qudra.mobile.data.api.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class DirectPlaybackResolverTest {
    private fun item(url: String, preferred: String? = url) = MediaItem("movie", "Movie", QudraMediaClass.MOVIE, null, Attribution("Rights", "Credit", "CC BY", "https://license", emptyList(), null, Geography("GLOBAL", emptyList(), emptyList())), DirectOrigin(url, MediaFormat("MP4", "video/mp4", "H264", "AAC"), true), preferred, true, null, Capabilities(false, false, false, false, false, true), 20.0, null)
    @Test fun onlyPreferredHttpsOriginIsAllowed() { assertEquals("https://media.example/movie.mp4", resolveDirectOrigin(item("https://media.example/movie.mp4"))); assertNull(resolveDirectOrigin(item("http://media.example/movie.mp4"))); assertNull(resolveDirectOrigin(item("https://media.example/movie.mp4", "https://other.example/movie.mp4"))); assertNull(validateDirectOrigin("https://user:secret@media.example/movie.mp4", "https://user:secret@media.example/movie.mp4")) }
}
