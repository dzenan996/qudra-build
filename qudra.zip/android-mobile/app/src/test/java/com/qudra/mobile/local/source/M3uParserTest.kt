// @polsia:user-owned — local four-class playlist mapping regression.
package com.qudra.mobile.local.source

import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.StringReader

class M3uParserTest {
    @Test fun mapsLiveMovieSeriesAndRadioLocally() { val text = "#EXTM3U\n#EXTINF:-1 group-title=\"Live\",News\nhttps://source/live.m3u8\n#EXTINF:-1 group-title=\"Movies\",Film\nhttps://source/movie.mp4\n#EXTINF:-1 group-title=\"Series\",Episode\nhttps://source/episode.mp4\n#EXTINF:-1 group-title=\"Radio\",Station\nhttps://source/radio.mp3\n"; val entries = M3uParser().parse(StringReader(text)); assertEquals(listOf(LocalMediaKind.LIVE_TV, LocalMediaKind.MOVIE, LocalMediaKind.SERIES, LocalMediaKind.RADIO), entries.map { it.kind }) }
}
