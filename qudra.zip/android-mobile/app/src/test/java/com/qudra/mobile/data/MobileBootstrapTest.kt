// @polsia:user-owned — JVM proof for account-free Mobile bootstrap invariants.
package com.qudra.mobile.data

import com.qudra.mobile.data.api.PairingQr
import com.qudra.mobile.data.api.bootstrapCanonicalPayload
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MobileBootstrapTest {
    @Test fun canonicalProofContainsDeviceAndKeyVersionButNotPublicMetadata() { val payload = bootstrapCanonicalPayload("challenge", "nonce", "server-device", 4); assertEquals("challenge:nonce:server-device:4", payload); assertFalse(payload.contains("public-device")) }
    @Test fun qrIsOpaque() { assertTrue(PairingQr("challenge", "challenge", "2030-01-01T00:00:00Z").representation == "challenge"); assertFalse(PairingQr("challenge", "https://bad", "2030-01-01T00:00:00Z").representation == "challenge") }
}
