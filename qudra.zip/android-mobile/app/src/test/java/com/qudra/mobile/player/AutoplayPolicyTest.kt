// @polsia:user-owned — Mobile autoplay policy regression coverage.
package com.qudra.mobile.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AutoplayPolicyTest {
    private fun episode(series: String, source: String, id: String, order: Int, url: String = "https://media.example/$id.mp4") =
        EpisodeDescriptor(series, source, id, order, url, url)

    @Test fun autoplayIsOnByDefault() = assertTrue(AutoplayPolicy.DEFAULT_ENABLED)

    @Test fun selectsOnlyImmediateSameSeriesAndSourceEpisode() {
        val current = episode("series", "source", "one", 1)
        assertEquals("two", AutoplayPolicy.next(current, listOf(episode("series", "source", "two", 2), episode("other", "source", "wrong", 2)))?.episodeId)
        assertNull(AutoplayPolicy.next(current, listOf(episode("series", "other", "cross-source", 2))))
        assertNull(AutoplayPolicy.next(current, listOf(episode("series", "source", "skipped", 3))))
    }

    @Test fun finalEpisodeStopsAndUnsafeOriginDoesNotAutoplay() {
        val current = episode("series", "source", "final", 2)
        assertNull(AutoplayPolicy.next(current, emptyList()))
        assertNull(AutoplayPolicy.next(current, listOf(episode("series", "source", "token", 3, "https://media.example/token?token=secret"))))
    }
}
