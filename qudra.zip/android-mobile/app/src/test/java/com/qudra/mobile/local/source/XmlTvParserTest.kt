// @polsia:user-owned — XMLTV offset/NOW-NEXT input coverage.
package com.qudra.mobile.local.source

import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.StringReader

class XmlTvParserTest {
    @Test fun parsesChannelsAndProgrammeTimes() { val xml = "<tv><channel id=\"one\"><display-name>One</display-name></channel><programme channel=\"one\" start=\"20260101120000 +0200\" stop=\"20260101130000 +0200\"><title>Now</title><desc>Details</desc></programme></tv>"; val result = XmlTvParser().parse(StringReader(xml)); assertEquals("One", result.first.single().displayName); assertEquals("Now", result.second.single().title); assertEquals(1, result.second.size) }
}
