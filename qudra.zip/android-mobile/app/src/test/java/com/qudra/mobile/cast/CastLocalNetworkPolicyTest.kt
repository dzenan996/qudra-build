// @polsia:user-owned — Cast transport/session evidence policy coverage.
package com.qudra.mobile.cast

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CastLocalNetworkPolicyTest {
    @Test fun requiresLocalTransportAndActiveSession() {
        assertTrue(CastLocalNetworkPolicy.allows(CastLocalNetworkState(true, true)))
        assertFalse(CastLocalNetworkPolicy.allows(CastLocalNetworkState(false, true)))
        assertFalse(CastLocalNetworkPolicy.allows(CastLocalNetworkState(true, false)))
    }
}
