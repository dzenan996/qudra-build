// @polsia:user-owned — Cast supported/unsupported/no-relay boundary coverage.
package com.qudra.mobile.cast

import com.qudra.mobile.data.api.*
import com.qudra.mobile.local.source.LocalMediaKind
import com.qudra.mobile.local.source.PlaylistEntry
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CastCapabilityDetectorTest {
    private fun item(url: String, known: Boolean = true, catchUp: Boolean = false) = MediaItem("id", "Title", QudraMediaClass.MOVIE, null, Attribution("Rights", "Credit", "CC", "https://license", emptyList(), null, Geography("GLOBAL", emptyList(), emptyList())), DirectOrigin(url, MediaFormat("MP4", "video/mp4", "H264", "AAC"), true), url, true, null, Capabilities(false, false, false, catchUp, false, known), null, null)
    @Test fun acceptsDirectOpenOrigin() { assertTrue(CastCapabilityDetector().assess(item("https://media.example/title.mp4")).supported) }
    @Test fun rejectsHttpCredentialedAndCapabilityUnknownSources() { assertFalse(CastCapabilityDetector().assess(item("http://media.example/title.mp4")).supported); assertFalse(CastCapabilityDetector().assess(item("https://user:secret@media.example/title.mp4")).supported); assertFalse(CastCapabilityDetector().assess(item("https://source/title.mp4", known = false)).supported) }
    @Test fun acceptsCredentialFreeCompatiblePersonalSource() {
        val entry = PlaylistEntry("entry", "Film", "https://source.example/film.mp4", LocalMediaKind.MOVIE, "Movies", null, false, false)
        assertTrue(CastCapabilityDetector().assess(entry).supported)
    }
    @Test fun rejectsPersonalSourceCredentialsAndCapabilityDependentStreams() {
        val detector = CastCapabilityDetector()
        val credentialed = PlaylistEntry("entry", "Film", "https://source.example/film.mp4?token=secret", LocalMediaKind.MOVIE, "Movies", null, false, false)
        val catchUp = PlaylistEntry("entry-2", "Live", "https://source.example/live.m3u8", LocalMediaKind.LIVE_TV, "Live", null, true, false)
        assertFalse(detector.assess(credentialed).supported)
        assertFalse(detector.assess(catchUp).supported)
    }
}
