// @polsia:user-owned — Mobile navigation parity regression coverage.
package com.qudra.mobile.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class HomeNavigationPolicyTest {
    @Test fun keepsFourAreasAndMyListOnlySourceSwitching() {
        assertEquals(listOf("LIVE TV", "MOVIES", "SERIES", "RADIO"), HomeNavigationPolicy.primaryAreas)
        assertEquals("MY LIST", HomeNavigationPolicy.sourceSwitchSurface)
        assertFalse(HomeNavigationPolicy.hasCategoriesSubmenu)
    }
}
