// @polsia:user-owned — Mobile DTOs for the shared QUDRA REST contracts.
package com.qudra.mobile.data.api

import org.json.JSONArray
import org.json.JSONObject

enum class QudraPlatform { ANDROID_PHONE, ANDROID_TABLET }
enum class QudraProductFamily { MOBILE }
enum class QudraAlgorithm { P256 }
enum class QudraMediaClass { LIVE_TV, MOVIE, SERIES, RADIO }

data class DeviceRegistration(
    val publicDeviceId: String,
    val platform: QudraPlatform,
    val publicKey: String,
    val appVersion: String,
    val androidApiLevel: Int,
    val deviceModel: String,
) {
    fun toJson() = JSONObject().apply {
        put("publicDeviceId", publicDeviceId)
        put("platform", platform.name)
        put("productFamily", QudraProductFamily.MOBILE.name)
        put("algorithm", QudraAlgorithm.P256.name)
        put("publicKey", publicKey)
        put("appVersion", appVersion)
        put("androidApiLevel", androidApiLevel)
        put("deviceModel", deviceModel)
    }
}

data class PairingQr(val id: String, val representation: String, val expiresAt: String) {
    companion object { fun parse(json: JSONObject) = PairingQr(json.getString("id"), json.getString("representation"), json.getString("expiresAt")) }
}

data class BootstrapChallenge(
    val id: String,
    val deviceId: String,
    val keyVersion: Int,
    val expiresAt: String,
    val attemptCount: Int,
    val maxAttempts: Int,
    val nonce: String,
    val qr: PairingQr,
) {
    companion object {
        fun parse(json: JSONObject) = BootstrapChallenge(
            json.getString("id"), json.getString("deviceId"), json.getInt("keyVersion"),
            json.getString("expiresAt"), json.getInt("attemptCount"), json.getInt("maxAttempts"),
            json.getString("nonce"), PairingQr.parse(json.getJSONObject("qr")),
        )
    }
}

data class BootstrapResult(val challengeId: String, val deviceId: String, val state: String, val sessionToken: String, val sessionExpiresAt: String) {
    companion object {
        fun parse(json: JSONObject) = BootstrapResult(json.getString("challengeId"), json.getString("deviceId"), json.getString("state"), json.getString("sessionToken"), json.getString("sessionExpiresAt"))
    }
}

data class DeviceView(val id: String, val publicDeviceId: String, val keyVersion: Int, val platform: String, val productFamily: String, val status: String, val publicKeyFingerprint: String) {
    companion object {
        fun parse(json: JSONObject) = DeviceView(json.getString("id"), json.getString("publicDeviceId"), json.getInt("keyVersion"), json.getString("platform"), json.getString("productFamily"), json.getString("status"), json.getString("publicKeyFingerprint"))
    }
}

data class DeviceSession(val deviceId: String, val keyVersion: Int, val expiresAt: String, val sessionToken: String?) {
    companion object { fun parse(json: JSONObject) = DeviceSession(json.getString("deviceId"), json.getInt("keyVersion"), json.getString("expiresAt"), json.optStringOrNull("sessionToken")) }
}

data class AccessView(val deviceId: String, val serverTime: String, val trialActive: Boolean, val entitlementActive: Boolean, val personalSourceAllowed: Boolean, val entitlementState: String?) {
    companion object { fun parse(json: JSONObject) = AccessView(json.getString("deviceId"), json.getString("serverTime"), json.optBoolean("trialActive"), json.optBoolean("entitlementActive"), json.optBoolean("personalSourceAllowed"), json.optStringOrNull("entitlementState")) }
}

data class Geography(val scope: String, val regions: List<String>, val restrictions: List<String>)
data class Attribution(val rightsHolder: String, val attributionText: String, val licenseName: String, val licenseUrl: String, val restrictions: List<String>, val rightsEvidenceUrl: String?, val geography: Geography)
data class MediaFormat(val container: String, val mimeType: String, val videoCodec: String?, val audioCodec: String?)
data class DirectOrigin(val url: String, val format: MediaFormat, val mediaOrigin: Boolean)
data class Capabilities(val epg: Boolean, val nowNext: Boolean, val fullSchedule: Boolean, val catchUp: Boolean, val timeshift: Boolean, val castCompatibilityKnown: Boolean)

data class MediaItem(
    val sourceId: String,
    val title: String,
    val mediaClass: QudraMediaClass,
    val description: String?,
    val attribution: Attribution,
    val directOrigin: DirectOrigin?,
    val preferredOrigin: String?,
    val available: Boolean,
    val availabilityReason: String?,
    val capabilities: Capabilities,
    val durationSeconds: Double?,
    val episodeOrder: Int?,
    val sourceConfigId: String? = null,
)

data class Series(val seriesId: String, val title: String, val episodes: List<MediaItem>)

data class OpenManifest(
    val manifestVersion: String,
    val availableWithoutEntitlement: Boolean,
    val requiresPaidEntitlement: Boolean,
    val personalSourceConfig: Boolean,
    val controlPlaneProxiesBytes: Boolean,
    val movies: List<MediaItem>,
    val series: List<Series>,
    val liveTv: List<MediaItem>,
    val radio: List<MediaItem>,
    val permanent: Boolean,
    val rawJson: String,
) {
    companion object {
        fun parse(json: JSONObject): OpenManifest {
            val register = json.optJSONArray("sourceRegister") ?: JSONArray()
            val byId = (0 until register.length()).associateBy({ register.getJSONObject(it).getString("sourceId") }, { register.getJSONObject(it).toMediaItem() })
            val movies = json.optJSONArray("movies")?.strings()?.mapNotNull(byId::get).orEmpty()
            val series = (0 until (json.optJSONArray("series")?.length() ?: 0)).map { index ->
                val value = json.getJSONArray("series").getJSONObject(index)
                val episodeArray = value.optJSONArray("episodes") ?: JSONArray()
                val episodes = (0 until episodeArray.length()).map { episodeArray.getJSONObject(it).toMediaItem() }
                Series(value.getString("seriesId"), value.getString("title"), episodes)
            }
            fun array(name: String) = (0 until (json.optJSONArray(name)?.length() ?: 0)).map { json.getJSONArray(name).getJSONObject(it).toMediaItem() }
            return OpenManifest(json.getString("manifestVersion"), json.optBoolean("availableWithoutEntitlement"), json.optBoolean("requiresPaidEntitlement"), json.optBoolean("personalSourceConfig"), json.optBoolean("controlPlaneProxiesBytes"), movies, series, array("liveTv"), array("radio"), json.optBoolean("permanent", true), json.toString())
        }
    }

    fun isSafeOpen() = permanent && availableWithoutEntitlement && !requiresPaidEntitlement && !personalSourceConfig && !controlPlaneProxiesBytes
}

data class Diagnostic(val code: String, val state: String, val retryable: Boolean, val message: String, val observedAt: String)

data class SourceConfig(val id: String, val label: String, val endpointUrl: String?, val epgUrl: String?, val sourceTimezone: String?, val utcOffsetMinutes: Int?, val slot: Int?, val hasSecret: Boolean, val configVersion: Int)
data class SourceSyncStatus(val sourceConfigId: String?, val state: String, val epg: String, val catchUp: String, val timeshift: String)

class QudraApiException(message: String, val statusCode: Int? = null) : Exception(message)

fun bootstrapCanonicalPayload(challengeId: String, nonce: String, deviceId: String, keyVersion: Int) = "$challengeId:$nonce:$deviceId:$keyVersion"

private fun JSONObject.toMediaItem(): MediaItem {
    val attributionJson = optJSONObject("attribution") ?: JSONObject()
    val geographyJson = attributionJson.optJSONObject("geography") ?: JSONObject()
    val originState = optJSONObject("originState")
    val originJson = optJSONObject("directOrigin")
    val format = originJson?.optJSONObject("format") ?: JSONObject()
    val capabilitiesJson = optJSONObject("capabilities") ?: JSONObject()
    return MediaItem(
        sourceId = getString("sourceId"), title = getString("title"), mediaClass = QudraMediaClass.valueOf(getString("mediaClass")),
        description = optStringOrNull("description") ?: optJSONObject("metadata")?.optStringOrNull("description"),
        attribution = Attribution(attributionJson.optString("rightsHolder"), attributionJson.optString("attributionText"), attributionJson.optString("licenseName"), attributionJson.optString("licenseUrl"), attributionJson.optJSONArray("restrictions")?.strings().orEmpty(), attributionJson.optStringOrNull("rightsEvidenceUrl"), Geography(geographyJson.optString("scope", "UNKNOWN"), geographyJson.optJSONArray("regions")?.strings().orEmpty(), geographyJson.optJSONArray("restrictions")?.strings().orEmpty())),
        directOrigin = originJson?.let { DirectOrigin(it.getString("url"), MediaFormat(format.optString("container"), format.optString("mimeType"), format.optStringOrNull("videoCodec"), format.optStringOrNull("audioCodec")), it.optBoolean("mediaOrigin", true)) },
        preferredOrigin = originState?.optStringOrNull("preferredOrigin"), available = optJSONObject("availability")?.optString("status") == "AVAILABLE", availabilityReason = optJSONObject("availability")?.optStringOrNull("reason") ?: originState?.optStringOrNull("unavailableReason"),
        capabilities = Capabilities(capabilitiesJson.optBoolean("epg"), capabilitiesJson.optBoolean("nowNext"), capabilitiesJson.optBoolean("fullSchedule"), capabilitiesJson.optBoolean("catchUp"), capabilitiesJson.optBoolean("timeshift"), capabilitiesJson.optBoolean("castCompatibilityKnown")),
        durationSeconds = optJSONObject("metadata")?.optDoubleOrNull("durationSeconds"), episodeOrder = optIntOrNull("episodeOrder"),
    )
}

private fun JSONObject.optStringOrNull(name: String): String? = if (isNull(name)) null else optString(name).takeIf(String::isNotBlank)
private fun JSONObject.optDoubleOrNull(name: String): Double? = if (isNull(name) || !has(name)) null else optDouble(name).takeIf { !it.isNaN() }
private fun JSONObject.optIntOrNull(name: String): Int? = if (isNull(name) || !has(name)) null else optInt(name)
private fun JSONArray.strings(): List<String> = (0 until length()).mapNotNull { optString(it).takeIf(String::isNotBlank) }
