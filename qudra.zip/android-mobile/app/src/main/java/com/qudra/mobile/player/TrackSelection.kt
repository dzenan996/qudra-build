// @polsia:user-owned — Media3 exposes audio/subtitle selection through PlayerView.
package com.qudra.mobile.player

import androidx.media3.common.Player

fun hasAudioOrSubtitleTracks(player: Player) = player.currentTracks.groups.any { it.type == androidx.media3.common.C.TRACK_TYPE_AUDIO || it.type == androidx.media3.common.C.TRACK_TYPE_TEXT }
