// @polsia:user-owned — redacted diagnostic categories; secrets never enter messages.
package com.qudra.mobile.data

import com.qudra.mobile.data.api.QudraApiException
import java.io.IOException
import java.net.SocketTimeoutException

enum class NativeFailureCategory {
    INTERNET, CLOUD, AUTHORITY, TRIAL_OR_ENTITLEMENT, PERSONAL_SOURCE_DENIED,
    SOURCE_UNAVAILABLE, SOURCE_ACCESS_DENIED, INVALID_PLAYLIST, PARSE_FAILURE, EPG_UNAVAILABLE,
    EPG_STALE, SELECTED_STREAM_UNAVAILABLE, UNSUPPORTED_FORMAT, PLAYBACK,
    CATCH_UP_UNSUPPORTED, TIMESHIFT_UNSUPPORTED, CAST_UNSUPPORTED, CAST_SESSION, BOOTSTRAP_EXPIRED, BOOTSTRAP_REPLAYED,
    BOOTSTRAP_RATE_LIMITED, UNKNOWN,
}

data class NativeFailure(val category: NativeFailureCategory, val message: String) {
    companion object {
        fun from(error: Throwable): NativeFailure {
            val api = error as? QudraApiException
            val category = when {
                api?.message?.contains("bootstrap", true) == true && api.statusCode == 429 -> NativeFailureCategory.BOOTSTRAP_RATE_LIMITED
                api?.message?.contains("expired", true) == true -> NativeFailureCategory.BOOTSTRAP_EXPIRED
                api?.message?.contains("replay", true) == true -> NativeFailureCategory.BOOTSTRAP_REPLAYED
                error.message?.contains("username or password", true) == true || error is SecurityException -> NativeFailureCategory.SOURCE_ACCESS_DENIED
                error.message?.contains("Xtream server", true) == true -> NativeFailureCategory.SOURCE_UNAVAILABLE
                api?.message?.contains("playlist", true) == true || error.message?.contains("playlist", true) == true -> NativeFailureCategory.INVALID_PLAYLIST
                api?.message?.contains("parse", true) == true -> NativeFailureCategory.PARSE_FAILURE
                api?.message?.contains("catch-up", true) == true -> NativeFailureCategory.CATCH_UP_UNSUPPORTED
                api?.message?.contains("timeshift", true) == true -> NativeFailureCategory.TIMESHIFT_UNSUPPORTED
                api?.statusCode == 401 || api?.statusCode == 403 || api?.statusCode == 409 -> NativeFailureCategory.AUTHORITY
                api?.statusCode == 502 || api?.statusCode?.let { it >= 500 } == true -> NativeFailureCategory.CLOUD
                error is SocketTimeoutException || error is IOException -> NativeFailureCategory.INTERNET
                else -> NativeFailureCategory.UNKNOWN
            }
            return NativeFailure(category, category.copy())
        }

        private fun NativeFailureCategory.copy() = when (this) {
            NativeFailureCategory.INTERNET -> "Internet unavailable. Check the connection and retry."
            NativeFailureCategory.CLOUD -> "QUDRA Cloud is unavailable. Retry or use the last validated QUDRA OPEN cache."
            NativeFailureCategory.AUTHORITY -> "This Mobile Device session is no longer authorized. Re-authorize this Device."
            NativeFailureCategory.TRIAL_OR_ENTITLEMENT -> "Personal Source playback needs this Mobile Device's server-issued entitlement. QUDRA OPEN remains available."
            NativeFailureCategory.PERSONAL_SOURCE_DENIED -> "Personal Source access is not enabled for this Mobile Device."
            NativeFailureCategory.SOURCE_UNAVAILABLE -> "The selected source is unavailable. QUDRA OPEN remains available."
            NativeFailureCategory.SOURCE_ACCESS_DENIED -> "The source denied access. Credentials remain local and were not sent to QUDRA Cloud."
            NativeFailureCategory.INVALID_PLAYLIST -> "The playlist could not be validated. The last-known-good catalogue was retained."
            NativeFailureCategory.PARSE_FAILURE -> "The Device could not parse this source safely."
            NativeFailureCategory.EPG_UNAVAILABLE -> "No electronic programme guide is available for this source."
            NativeFailureCategory.EPG_STALE -> "The electronic programme guide is stale; showing only retained data."
            NativeFailureCategory.SELECTED_STREAM_UNAVAILABLE -> "The selected stream is unavailable."
            NativeFailureCategory.UNSUPPORTED_FORMAT -> "This source format is not supported on this Mobile Device."
            NativeFailureCategory.PLAYBACK -> "Playback failed at the approved direct media origin. Retry or choose another item."
            NativeFailureCategory.CATCH_UP_UNSUPPORTED -> "Catch-up is not supported for this channel."
            NativeFailureCategory.TIMESHIFT_UNSUPPORTED -> "Timeshift is not supported for this channel."
            NativeFailureCategory.CAST_UNSUPPORTED -> "This source cannot be Cast. Playback stays on Mobile."
            NativeFailureCategory.CAST_SESSION -> "The Cast session failed. Playback stays on Mobile."
            NativeFailureCategory.BOOTSTRAP_EXPIRED -> "The Device bootstrap expired. Start bootstrap again."
            NativeFailureCategory.BOOTSTRAP_REPLAYED -> "The Device bootstrap was already used. Start bootstrap again."
            NativeFailureCategory.BOOTSTRAP_RATE_LIMITED -> "Device bootstrap is temporarily rate-limited. Try again later."
            NativeFailureCategory.UNKNOWN -> "QUDRA could not complete that request. Retry."
        }
    }
}
