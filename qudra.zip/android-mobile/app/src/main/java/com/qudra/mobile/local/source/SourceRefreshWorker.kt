// @polsia:user-owned — refreshes local source data through WorkManager backoff.
package com.qudra.mobile.local.source

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class SourceRefreshWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = runCatching {
        val url = inputData.getString("playlistUrl") ?: return Result.failure()
        val sourceId = inputData.getString("sourceId") ?: return Result.failure()
        val epg = inputData.getString("epgUrl")
        SourceImportCoordinator(SourceDownloadClient(), CatalogueStore(applicationContext), EpgStore(applicationContext)).importWithRetry(sourceId, url, epg, inputData.getString("timezone"), inputData.getInt("offsetMinutes", 0), cancelled = { isStopped })
        Result.success()
    }.getOrElse { if (runAttemptCount < 2) Result.retry() else Result.failure() }
}
