// @polsia:user-owned — responsive four-area Mobile home; My List is the sole source switcher.
package com.qudra.mobile.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import com.qudra.mobile.cast.CastSessionCoordinator
import com.qudra.mobile.data.HomeData
import com.qudra.mobile.data.NativeFailure
import com.qudra.mobile.data.QudraRepository
import com.qudra.mobile.data.api.MediaItem
import com.qudra.mobile.data.api.SourceConfig
import com.qudra.mobile.local.LocalPlaybackStateStore
import com.qudra.mobile.local.source.LocalMediaKind
import com.qudra.mobile.local.source.PlaylistEntry
import com.qudra.mobile.player.PlayerActivity
import com.qudra.mobile.player.resolveDirectOrigin
import com.qudra.mobile.player.validatePersonalSourceOrigin

object HomeScreen {
    fun show(activity: Activity, repository: QudraRepository, data: HomeData, local: LocalPlaybackStateStore, onReauthorize: () -> Unit) {
        val root = UiStyle.column(activity)
        val scroll = ScrollView(activity).apply { isFillViewport = true; addView(root) }
        activity.setContentView(scroll)
        val dashboard = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        root.addView(dashboard)
        val content = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        root.addView(content)
        val cast = CastSessionCoordinator(activity)
        val allOpen = data.manifest.movies + data.manifest.series.flatMap { it.episodes } + data.manifest.liveTv + data.manifest.radio

        fun episodeOrder(entry: PlaylistEntry): Int? = entry.episodeNumber?.let { (entry.seasonNumber ?: 0) * 10_000 + it }
        fun openPlayer(item: MediaItem, next: MediaItem? = null, seriesId: String? = null) {
            val url = resolveDirectOrigin(item) ?: return
            activity.startActivity(Intent(activity, PlayerActivity::class.java).apply {
                putExtra(PlayerActivity.EXTRA_URL, url); putExtra(PlayerActivity.EXTRA_PREFERRED_ORIGIN, item.preferredOrigin); putExtra(PlayerActivity.EXTRA_TITLE, item.title); putExtra(PlayerActivity.EXTRA_SOURCE_ID, "QUDRA_OPEN"); putExtra(PlayerActivity.EXTRA_MEDIA_CLASS, item.mediaClass.name); putExtra(PlayerActivity.EXTRA_SUPPORTED, true); putExtra(PlayerActivity.EXTRA_PERSONAL_SOURCE, false)
                if (seriesId != null && item.episodeOrder != null) { putExtra(PlayerActivity.EXTRA_SERIES_ID, seriesId); putExtra(PlayerActivity.EXTRA_EPISODE_ID, item.sourceId); putExtra(PlayerActivity.EXTRA_EPISODE_ORDER, item.episodeOrder) }
                if (next != null && seriesId != null && next.episodeOrder != null && next.directOrigin != null && next.preferredOrigin != null) { putExtra(PlayerActivity.EXTRA_NEXT_URL, next.directOrigin.url); putExtra(PlayerActivity.EXTRA_NEXT_PREFERRED_ORIGIN, next.preferredOrigin); putExtra(PlayerActivity.EXTRA_NEXT_TITLE, next.title); putExtra(PlayerActivity.EXTRA_NEXT_SOURCE_ID, "QUDRA_OPEN"); putExtra(PlayerActivity.EXTRA_NEXT_SERIES_ID, seriesId); putExtra(PlayerActivity.EXTRA_NEXT_EPISODE_ID, next.sourceId); putExtra(PlayerActivity.EXTRA_NEXT_EPISODE_ORDER, next.episodeOrder) }
            })
        }
        fun openLocal(entry: PlaylistEntry, next: PlaylistEntry? = null) {
            if (!data.access.personalSourceAllowed) { AlertDialog.Builder(activity).setTitle("Personal Source unavailable").setMessage("Personal Source playback requires this Mobile Device's active trial or entitlement. QUDRA OPEN remains available.").setPositiveButton("Close", null).show(); return }
            val url = validatePersonalSourceOrigin(entry.uri, entry.uri) ?: run { AlertDialog.Builder(activity).setTitle("Stream unavailable").setMessage("This selected source item is not a valid direct HTTP/HTTPS stream.").setPositiveButton("Close", null).show(); return }
            activity.startActivity(Intent(activity, PlayerActivity::class.java).apply {
                putExtra(PlayerActivity.EXTRA_URL, url); putExtra(PlayerActivity.EXTRA_PREFERRED_ORIGIN, url); putExtra(PlayerActivity.EXTRA_TITLE, entry.title); putExtra(PlayerActivity.EXTRA_SOURCE_ID, entry.sourceId); putExtra(PlayerActivity.EXTRA_MEDIA_CLASS, entry.kind.name); putExtra(PlayerActivity.EXTRA_SUPPORTED, true); putExtra(PlayerActivity.EXTRA_PERSONAL_SOURCE, true)
                episodeOrder(entry)?.let { order -> entry.seriesKey?.let { putExtra(PlayerActivity.EXTRA_SERIES_ID, it); putExtra(PlayerActivity.EXTRA_EPISODE_ID, entry.id); putExtra(PlayerActivity.EXTRA_EPISODE_ORDER, order) } }
                if (next != null) episodeOrder(next)?.let { order -> next.seriesKey?.let { putExtra(PlayerActivity.EXTRA_NEXT_URL, next.uri); putExtra(PlayerActivity.EXTRA_NEXT_PREFERRED_ORIGIN, next.uri); putExtra(PlayerActivity.EXTRA_NEXT_TITLE, next.title); putExtra(PlayerActivity.EXTRA_NEXT_SOURCE_ID, next.sourceId); putExtra(PlayerActivity.EXTRA_NEXT_SERIES_ID, it); putExtra(PlayerActivity.EXTRA_NEXT_EPISODE_ID, next.id); putExtra(PlayerActivity.EXTRA_NEXT_EPISODE_ORDER, order) } }
            })
        }
        fun openCard(item: MediaItem, next: MediaItem? = null, seriesId: String? = null, allowFavorite: Boolean = true) {
            val box = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(UiStyle.surface); setPadding(16, 14, 16, 14) }
            box.addView(UiStyle.title(activity, item.title, 20f)); item.description?.let { box.addView(UiStyle.body(activity, it, 14f)) }
            box.addView(UiStyle.body(activity, "${item.mediaClass.name.replace('_', ' ')} · ${item.attribution.rightsHolder}", 13f))
            val actions = UiStyle.row(activity)
            actions.addView(UiStyle.button(activity, if (resolveDirectOrigin(item) == null) "Unavailable" else "Play") { openPlayer(item, next, seriesId) })
            actions.addView(UiStyle.button(activity, "Cast") { val result = cast.load(item) { outcome -> if (!outcome.supported) activity.runOnUiThread { AlertDialog.Builder(activity).setTitle("Cast unavailable").setMessage(outcome.reason).setPositiveButton("Close", null).show() } }; if (!result.supported) AlertDialog.Builder(activity).setTitle("Cast unavailable").setMessage(result.reason).setPositiveButton("Close", null).show() })
            if (allowFavorite) actions.addView(UiStyle.button(activity, if (local.isFavorite(item.sourceId)) "Remove from My List" else "Add to My List") { local.setFavorite(item.sourceId, !local.isFavorite(item.sourceId)); show(activity, repository, data, local, onReauthorize) })
            box.addView(actions); content.addView(box)
        }
        fun openLocalCard(entry: PlaylistEntry, next: PlaylistEntry?) {
            val box = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(UiStyle.surface); setPadding(16, 14, 16, 14) }
            box.addView(UiStyle.title(activity, entry.title, 20f))
            box.addView(UiStyle.body(activity, listOfNotNull(entry.originalCategory, if (entry.catchUpSupported) "Catch-up" else null, if (entry.timeshiftSupported) "Timeshift" else null).joinToString(" · ").ifBlank { "Personal Source" }, 13f))
            val actions = UiStyle.row(activity)
            val isXtreamSeries = entry.kind == LocalMediaKind.SERIES && entry.uri.startsWith("qudra-series://")
            if (isXtreamSeries) {
                actions.addView(UiStyle.button(activity, "Browse episodes") {
                    val loading = AlertDialog.Builder(activity).setTitle(entry.title).setMessage("Loading episodes from the source server…").setCancelable(false).create()
                    loading.show()
                    Thread {
                        val result = runCatching { repository.localSeriesEpisodes(entry) }
                        activity.runOnUiThread {
                            loading.dismiss()
                            result.onSuccess { episodes ->
                                if (episodes.isEmpty()) {
                                    AlertDialog.Builder(activity).setTitle(entry.title).setMessage("No playable episodes were returned by this source.").setPositiveButton("Close", null).show()
                                } else {
                                    val labels = episodes.map { ep ->
                                        val number = listOfNotNull(ep.seasonNumber?.let { "S$it" }, ep.episodeNumber?.let { "E$it" }).joinToString(" ")
                                        if (number.isBlank()) ep.title else "$number · ${ep.title}"
                                    }.toTypedArray()
                                    AlertDialog.Builder(activity).setTitle(entry.title).setItems(labels) { _, index ->
                                        openLocal(episodes[index], episodes.getOrNull(index + 1))
                                    }.setNegativeButton("Close", null).show()
                                }
                            }.onFailure { error ->
                                AlertDialog.Builder(activity).setTitle("Series unavailable").setMessage(NativeFailure.from(error).message).setPositiveButton("Close", null).show()
                            }
                        }
                    }.start()
                })
            } else {
                actions.addView(UiStyle.button(activity, "Play") { openLocal(entry, next) })
                actions.addView(UiStyle.button(activity, "Cast") {
                    val result = cast.loadLocal(entry) { outcome -> if (!outcome.supported) activity.runOnUiThread { AlertDialog.Builder(activity).setTitle("Cast unavailable").setMessage(outcome.reason).setPositiveButton("Close", null).show() } }
                    if (!result.supported) AlertDialog.Builder(activity).setTitle("Cast unavailable").setMessage(result.reason).setPositiveButton("Close", null).show()
                })
            }
            actions.addView(UiStyle.button(activity, if (local.isFavorite(entry.id)) "Remove from My List" else "Add to My List") { local.setFavorite(entry.id, !local.isFavorite(entry.id)); show(activity, repository, data, local, onReauthorize) })
            box.addView(actions); content.addView(box)
        }
        fun renderLocal(kind: LocalMediaKind) {
            content.removeAllViews(); val all = repository.localCatalogue(kind)
            fun nextFor(item: PlaylistEntry) = item.seriesKey?.let { key -> all.filter { it.seriesKey == key && it.id != item.id }.sortedWith(compareBy({ it.seasonNumber ?: Int.MAX_VALUE }, { it.episodeNumber ?: Int.MAX_VALUE }, { it.id })).firstOrNull { episodeOrder(it) == episodeOrder(item)?.plus(1) } }
            fun section(label: String, items: List<PlaylistEntry>) { if (items.isNotEmpty()) { content.addView(UiStyle.title(activity, label, 22f)); items.forEach { openLocalCard(it, nextFor(it)) } } }
            section("Favorites", all.filter { local.isFavorite(it.id) }); section("Recently watched", local.recentlyWatched().mapNotNull { id -> all.firstOrNull { it.id == id } }); section("Continue watching", local.continueWatching().mapNotNull { id -> all.firstOrNull { it.id == id } }); repository.localCategories(kind).forEach { category -> section(category, repository.localCatalogue(kind, category)) }
            if (content.childCount == 0) content.addView(UiStyle.body(activity, "No local entries are available for the active Personal Source."))
        }
        fun renderOpen(area: String) {
            content.removeAllViews(); val items = when (area) { "MOVIES" -> data.manifest.movies; "LIVE TV" -> data.manifest.liveTv; "RADIO" -> data.manifest.radio; else -> emptyList() }
            fun section(label: String, values: List<MediaItem>) { if (values.isNotEmpty()) { content.addView(UiStyle.title(activity, label, 22f)); values.forEach { openCard(it) } } }
            section("Favorites", items.filter { local.isFavorite(it.sourceId) }); section("Recently watched", local.recentlyWatched().mapNotNull { id -> items.firstOrNull { it.sourceId == id } }); section("Continue watching", local.continueWatching().mapNotNull { id -> items.firstOrNull { it.sourceId == id } }); section(area, items)
            if (area == "LIVE TV" && items.isEmpty()) content.addView(UiStyle.body(activity, "QUDRA OPEN has no lawful production LIVE TV source. Configure a Personal Source from My List to use local Live TV."))
            if (area == "RADIO" && items.isEmpty()) content.addView(UiStyle.body(activity, "QUDRA OPEN has no lawful production RADIO source. Personal Radio remains local to a configured source."))
        }
        fun renderSeries() {
            content.removeAllViews(); val allEpisodes = data.manifest.series.flatMap { it.episodes }; fun section(label: String, values: List<MediaItem>) { if (values.isNotEmpty()) { content.addView(UiStyle.title(activity, label, 22f)); values.forEach { openCard(it) } } }; section("Favorites", allEpisodes.filter { local.isFavorite(it.sourceId) }); section("Recently watched", local.recentlyWatched().mapNotNull { id -> allEpisodes.firstOrNull { it.sourceId == id } }); section("Continue watching", local.continueWatching().mapNotNull { id -> allEpisodes.firstOrNull { it.sourceId == id } }); content.addView(UiStyle.title(activity, "SERIES", 26f)); data.manifest.series.forEach { series -> content.addView(UiStyle.title(activity, series.title, 20f)); val episodes = series.episodes.sortedWith(compareBy({ it.episodeOrder ?: Int.MAX_VALUE }, { it.sourceId })); episodes.forEachIndexed { index, item -> openCard(item, episodes.getOrNull(index + 1), series.seriesId) } }
        }
        fun showDashboard() {
            content.visibility = View.GONE
            dashboard.visibility = View.VISIBLE
        }
        fun decorateArea() {
            dashboard.visibility = View.GONE
            content.visibility = View.VISIBLE
            content.addView(UiStyle.button(activity, "← Home") { showDashboard() }, 0)
        }
        fun render(area: String) {
            val localKind = when (area) { "LIVE TV" -> LocalMediaKind.LIVE_TV; "MOVIES" -> LocalMediaKind.MOVIE; "SERIES" -> LocalMediaKind.SERIES; "RADIO" -> LocalMediaKind.RADIO; else -> null }
            if (data.activeSourceId != null && localKind != null) renderLocal(localKind) else if (area == "SERIES") renderSeries() else renderOpen(area)
            decorateArea()
        }
        fun showMyList() {
            content.removeAllViews()
            content.addView(UiStyle.title(activity, "MY LIST", 26f))
            content.addView(UiStyle.body(activity, "The only source-switching surface. Favorites, recent titles, progress, and Personal Source choices stay on this Mobile Device."))
            allOpen.filter { local.isFavorite(it.sourceId) }.forEach { openCard(it) }
            data.sourceConfigs.forEach { config -> val active = data.activeSourceId == config.id; content.addView(UiStyle.button(activity, if (active) "Active · ${config.label}" else "Use ${config.label}") { selectSource(activity, repository, config) }) }
            content.addView(UiStyle.button(activity, "Use QUDRA OPEN") { selectSource(activity, repository, null) })
            content.addView(UiStyle.button(activity, "Source setup") { SourceSetupScreen.show(activity, repository) { activity.recreate() } })
            decorateArea()
        }

        val activeLabel = data.sourceConfigs.firstOrNull { it.id == data.activeSourceId }?.label ?: "QUDRA OPEN"
        val sourceMode = if (data.activeSourceId == null) "OPEN catalogue" else "Personal Source"
        val counts = if (data.activeSourceId == null) {
            mapOf(
                "LIVE TV" to data.manifest.liveTv.size,
                "MOVIES" to data.manifest.movies.size,
                "SERIES" to data.manifest.series.size,
                "RADIO" to data.manifest.radio.size
            )
        } else {
            mapOf(
                "LIVE TV" to runCatching { repository.localCatalogue(LocalMediaKind.LIVE_TV).size }.getOrDefault(0),
                "MOVIES" to runCatching { repository.localCatalogue(LocalMediaKind.MOVIE).size }.getOrDefault(0),
                "SERIES" to runCatching { repository.localCatalogue(LocalMediaKind.SERIES).size }.getOrDefault(0),
                "RADIO" to runCatching { repository.localCatalogue(LocalMediaKind.RADIO).size }.getOrDefault(0)
            )
        }

        val header = UiStyle.row(activity).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(UiStyle.title(activity, "QUDRA", 34f).apply { layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) })
        header.addView(UiStyle.sourceChip(activity, activeLabel))
        dashboard.addView(header)
        dashboard.addView(UiStyle.body(activity, "Your media. One place.", 17f))
        dashboard.addView(UiStyle.body(activity, "$sourceMode · ${if (data.access.personalSourceAllowed) "Mobile entitlement active" else "QUDRA OPEN always available"}", 13f))
        if (data.fromCache) dashboard.addView(UiStyle.body(activity, "Offline cache active · cloud refresh will resume when connectivity returns.", 12f))

        val primaryTop = UiStyle.row(activity)
        val primaryBottom = UiStyle.row(activity)
        dashboard.addView(primaryTop)
        dashboard.addView(primaryBottom)
        fun addTile(row: LinearLayout, area: String, caption: String) {
            row.addView(UiStyle.dashboardTile(activity, area, "${counts[area] ?: 0} $caption") { render(area) }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(5, 5, 5, 5) }
            })
        }
        addTile(primaryTop, "LIVE TV", "channels")
        addTile(primaryTop, "MOVIES", "titles")
        addTile(primaryBottom, "SERIES", "shows")
        addTile(primaryBottom, "RADIO", "stations")

        dashboard.addView(UiStyle.title(activity, "QUICK ACCESS", 16f))
        val quick1 = UiStyle.row(activity)
        val quick2 = UiStyle.row(activity)
        dashboard.addView(quick1)
        dashboard.addView(quick2)
        quick1.addView(UiStyle.quickAction(activity, "My List") { showMyList() })
        quick1.addView(UiStyle.quickAction(activity, "Source setup") { SourceSetupScreen.show(activity, repository) { activity.recreate() } })
        quick1.addView(UiStyle.quickAction(activity, "Device") { AlertDialog.Builder(activity).setTitle("Mobile Device").setMessage("${data.device?.platform ?: "MOBILE"}\nDevice-scoped authority is established by Android Keystore P-256 proof.\nTV license: separate\nCast: sender only; no entitlement transfer").setPositiveButton("Close", null).show() })
        quick2.addView(UiStyle.quickAction(activity, "Diagnostics") { val body = data.diagnostics.joinToString("\n") { "${it.state}: ${it.message}" }.ifBlank { "No current server diagnostics. Local failures are shown without secrets." }; AlertDialog.Builder(activity).setTitle("Diagnostics").setMessage(body).setPositiveButton("Close", null).show() })
        quick2.addView(UiStyle.quickAction(activity, "Re-authorize") { repository.clearSession(); onReauthorize() })
        quick2.addView(UiStyle.quickAction(activity, "About") { AlertDialog.Builder(activity).setTitle("QUDRA").setMessage("Software player for direct playback of QUDRA OPEN and user-authorized Personal Sources. QUDRA does not sell media subscriptions.").setPositiveButton("Close", null).show() })

        dashboard.addView(UiStyle.body(activity, "Active source: $activeLabel", 12f))
        showDashboard()
    }

    private fun selectSource(activity: Activity, repository: QudraRepository, config: SourceConfig?) { Thread { runCatching { repository.activateSource(config) }.onFailure { error -> activity.runOnUiThread { AlertDialog.Builder(activity).setTitle("Source selection failed").setMessage(NativeFailure.from(error).message).setPositiveButton("Close", null).show() } }.onSuccess { activity.runOnUiThread { activity.recreate() } } }.start() }
}
