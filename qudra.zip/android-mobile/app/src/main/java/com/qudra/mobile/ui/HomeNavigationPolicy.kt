// @polsia:user-owned — Mobile primary-area and source-switching navigation invariant.
package com.qudra.mobile.ui

object HomeNavigationPolicy {
    val primaryAreas = listOf("LIVE TV", "MOVIES", "SERIES", "RADIO")
    const val sourceSwitchSurface = "MY LIST"
    const val hasCategoriesSubmenu = false
}
