// @polsia:user-owned — short-lived sender session; commercial state stays on Mobile.
package com.qudra.mobile.cast

import android.content.Context
import android.net.ConnectivityManager
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.qudra.mobile.data.api.MediaItem
import com.qudra.mobile.local.source.PlaylistEntry

class CastSessionCoordinator(context: Context) {
    private val appContext = context.applicationContext
    private val castContext = runCatching { CastContext.getSharedInstance(context) }.getOrNull()
    private val detector = CastCapabilityDetector()
    fun assess(item: MediaItem) = detector.assess(item)
    fun load(item: MediaItem, onResult: ((CastDecision) -> Unit)? = null): CastDecision {
        val decision = detector.assess(item); if (!decision.supported) return decision
        val session: CastSession = castContext?.sessionManager?.currentCastSession ?: return CastDecision(false, "No local Cast session is active.")
        val connectivity = appContext.getSystemService(ConnectivityManager::class.java)
            ?: return CastDecision(false, "Local network capability could not be verified.")
        if (!CastLocalNetworkPolicy.allows(CastLocalNetworkPolicy.inspect(connectivity, true))) return CastDecision(false, "Cast requires an active session over a local Wi-Fi or Ethernet transport.")
        val origin = item.directOrigin ?: return CastDecision(false, "This source cannot be Cast.")
        return submit(session, origin.url, origin.format.mimeType.ifBlank { "video/mp4" }, onResult)
    }

    fun loadLocal(entry: PlaylistEntry, onResult: ((CastDecision) -> Unit)? = null): CastDecision {
        val decision = detector.assess(entry); if (!decision.supported) return decision
        val session: CastSession = castContext?.sessionManager?.currentCastSession ?: return CastDecision(false, "No local Cast session is active.")
        val connectivity = appContext.getSystemService(ConnectivityManager::class.java)
            ?: return CastDecision(false, "Local network capability could not be verified.")
        if (!CastLocalNetworkPolicy.allows(CastLocalNetworkPolicy.inspect(connectivity, true))) return CastDecision(false, "Cast requires an active session over a local Wi-Fi or Ethernet transport.")
        return submit(session, entry.uri, detector.mimeType(entry), onResult)
    }

    private fun submit(session: CastSession, url: String, mimeType: String, onResult: ((CastDecision) -> Unit)?): CastDecision {
        val remoteMediaClient = session.remoteMediaClient ?: return CastDecision(false, "No Cast media client is active.")
        val info = MediaInfo.Builder(url).setContentType(mimeType).setStreamType(MediaInfo.STREAM_TYPE_BUFFERED).build()
        remoteMediaClient.load(MediaLoadRequestData.Builder().setMediaInfo(info).build()).setResultCallback { result ->
            onResult?.invoke(if (result.status.isSuccess) {
                CastDecision(true, "Cast started from the Mobile Device to the direct source origin; media bytes bypass QUDRA Cloud.")
            } else {
                CastDecision(false, "This source cannot be Cast.")
            })
        }
        return CastDecision(true, "Cast request submitted to the active local receiver; media bytes bypass QUDRA Cloud.")
    }
}
