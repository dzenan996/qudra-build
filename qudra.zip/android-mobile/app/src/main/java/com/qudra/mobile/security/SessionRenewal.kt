// @polsia:user-owned — fail-closed session/key-version replacement rules.
package com.qudra.mobile.security

data class RenewedSession(val deviceId: String, val keyVersion: Int, val expiresAt: String, val replacementToken: String?)
object SessionRenewal {
    fun apply(previous: StoredDeviceSession, renewed: RenewedSession): StoredDeviceSession {
        require(previous.deviceId == renewed.deviceId) { "Device authority mismatch" }
        require(previous.keyVersion == renewed.keyVersion) { "Device key version mismatch" }
        return StoredDeviceSession(previous.deviceId, previous.keyVersion, renewed.replacementToken?.takeIf(String::isNotBlank) ?: previous.token, renewed.expiresAt)
    }
}
