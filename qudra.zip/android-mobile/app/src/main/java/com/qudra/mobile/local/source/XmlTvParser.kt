// @polsia:user-owned — bounded XMLTV parser with explicit source offset handling.
package com.qudra.mobile.local.source

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.Reader
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

class XmlTvParser(private val maxProgrammes: Int = 200_000) {
    fun parse(reader: Reader, cancelled: () -> Boolean = { false }): Pair<List<EpgChannel>, List<EpgProgramme>> {
        val parser = Xml.newPullParser().apply { setInput(reader) }; val channels = mutableListOf<EpgChannel>(); val programmes = mutableListOf<EpgProgramme>()
        var channelId = ""; var programmeChannel = ""; var start = 0L; var stop = 0L; var title = ""; var description: String? = null; var text = ""
        while (parser.eventType != XmlPullParser.END_DOCUMENT) {
            if (cancelled()) throw InterruptedException("EPG import cancelled")
            when (parser.eventType) {
                XmlPullParser.START_TAG -> when (parser.name) { "channel" -> channelId = parser.getAttributeValue(null, "id").orEmpty(); "programme" -> { programmeChannel = parser.getAttributeValue(null, "channel").orEmpty(); start = parseTime(parser.getAttributeValue(null, "start")); stop = parseTime(parser.getAttributeValue(null, "stop")); title = ""; description = null }; "display-name", "title", "desc" -> text = "" }
                XmlPullParser.TEXT -> text += parser.text
                XmlPullParser.END_TAG -> when (parser.name) { "channel" -> if (channelId.isNotBlank()) channels += EpgChannel(channelId, text.trim()); "title" -> title = text.trim(); "desc" -> description = text.trim(); "programme" -> if (programmeChannel.isNotBlank() && title.isNotBlank() && start < stop && programmes.size < maxProgrammes) programmes += EpgProgramme(programmeChannel, title, description, start, stop) }
            }
            parser.next()
        }
        return channels to programmes
    }
    private fun parseTime(value: String?): Long { if (value.isNullOrBlank()) return 0L; val normalized = value.trim().replace(Regex("\\s+"), " "); return listOf("yyyyMMddHHmmss Z", "yyyyMMddHHmmss").firstNotNullOfOrNull { pattern -> runCatching { SimpleDateFormat(pattern, Locale.ROOT).apply { timeZone = TimeZone.getTimeZone("UTC") }.parse(normalized)?.time }.getOrNull() } ?: 0L }
}
