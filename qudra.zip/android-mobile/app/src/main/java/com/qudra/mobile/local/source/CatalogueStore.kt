// @polsia:user-owned — source-scoped staged generations and lazy local catalogue queries.
// The local generations table is the Device-local last-known-good boundary.
package com.qudra.mobile.local.source

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class CatalogueStore(context: Context) : SQLiteOpenHelper(context, "qudra_mobile_catalogue.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE generations (id INTEGER PRIMARY KEY AUTOINCREMENT, source_id TEXT NOT NULL, state TEXT NOT NULL, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE media (generation_id INTEGER NOT NULL, item_id TEXT NOT NULL, title TEXT NOT NULL, uri TEXT NOT NULL, kind TEXT NOT NULL, group_name TEXT, tvg_id TEXT, category TEXT, tvg_name TEXT, season INTEGER, episode INTEGER, series_key TEXT, catch_up INTEGER NOT NULL, timeshift INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX media_kind_idx ON media(generation_id, kind, title)")
        db.execSQL("CREATE INDEX media_series_idx ON media(generation_id, series_key, season, episode)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE generations ADD COLUMN source_id TEXT NOT NULL DEFAULT 'default'")
            listOf("category TEXT", "tvg_name TEXT", "season INTEGER", "episode INTEGER", "series_key TEXT").forEach { column -> runCatching { db.execSQL("ALTER TABLE media ADD COLUMN $column") } }
            db.execSQL("CREATE INDEX IF NOT EXISTS media_series_idx ON media(generation_id, series_key, season, episode)")
        }
    }

    fun beginGeneration(sourceId: String = "default"): Long = writableDatabase.insertOrThrow("generations", null, ContentValues().apply { put("source_id", sourceId); put("state", "STAGED"); put("created_at", System.currentTimeMillis()) })

    fun stageMedia(generation: Long, entries: List<PlaylistEntry>) {
        writableDatabase.beginTransaction()
        try {
            entries.chunked(500).forEach { batch -> batch.forEach { entry -> writableDatabase.insertOrThrow("media", null, ContentValues().apply { put("generation_id", generation); put("item_id", entry.id); put("title", entry.title); put("uri", entry.uri); put("kind", entry.kind.name); put("group_name", entry.group); put("tvg_id", entry.tvgId); put("category", entry.originalCategory); put("tvg_name", entry.tvgName); put("season", entry.seasonNumber); put("episode", entry.episodeNumber); put("series_key", entry.seriesKey); put("catch_up", if (entry.catchUpSupported) 1 else 0); put("timeshift", if (entry.timeshiftSupported) 1 else 0) }) } }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }

    fun promoteGeneration(generation: Long) {
        writableDatabase.beginTransaction()
        try {
            val sourceId = writableDatabase.query("generations", arrayOf("source_id"), "id = ?", arrayOf(generation.toString()), null, null, null).use { if (it.moveToFirst()) it.getString(0) else "default" }
            writableDatabase.update("generations", ContentValues().apply { put("state", "RETIRED") }, "source_id = ? AND state = ?", arrayOf(sourceId, "ACTIVE"))
            writableDatabase.update("generations", ContentValues().apply { put("state", "ACTIVE") }, "id = ?", arrayOf(generation.toString()))
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }

    fun retainLastKnownGood() = writableDatabase.delete("generations", "state = ?", arrayOf("STAGED"))

    fun count(kind: LocalMediaKind, sourceId: String? = null): Int {
        val sourceClause = if (sourceId == null) ")" else " AND source_id = ?)"
        val sql = "SELECT COUNT(*) FROM media WHERE generation_id IN (SELECT id FROM generations WHERE state = 'ACTIVE'" +
            sourceClause + " AND kind = ?"
        val args = listOfNotNull(sourceId, kind.name).toTypedArray()
        return readableDatabase.rawQuery(sql, args).use { cursor ->
            if (cursor.moveToFirst()) cursor.getInt(0) else 0
        }
    }

    fun categories(kind: LocalMediaKind, sourceId: String? = null): List<String> {
        val sourceClause = if (sourceId == null) ")" else " AND source_id = ?)"
        val where = "generation_id IN (SELECT id FROM generations WHERE state = 'ACTIVE'" +
            sourceClause + " AND kind = ? AND category IS NOT NULL AND category != ''"
        val args = listOfNotNull(sourceId, kind.name).toTypedArray()
        return readableDatabase.query(
            true,
            "media",
            arrayOf("category"),
            where,
            args,
            null,
            null,
            "category ASC",
            null,
        ).use { cursor ->
            buildList {
                while (cursor.moveToNext()) add(cursor.getString(0))
            }
        }
    }

    fun query(
        kind: LocalMediaKind,
        category: String? = null,
        offset: Int = 0,
        limit: Int = 200,
        sourceId: String? = null,
    ): List<PlaylistEntry> {
        val rows = mutableListOf<PlaylistEntry>()
        val sourceClause = if (sourceId == null) ")" else " AND source_id = ?)"
        val where = "generation_id IN (SELECT id FROM generations WHERE state = 'ACTIVE'" +
            sourceClause + " AND kind = ?" + if (category == null) "" else " AND category = ?"
        val args = listOfNotNull(sourceId, kind.name, category).toTypedArray()
        readableDatabase.query(
            "media",
            arrayOf(
                "item_id", "title", "uri", "group_name", "tvg_id", "category",
                "tvg_name", "season", "episode", "series_key", "catch_up", "timeshift",
            ),
            where,
            args,
            null,
            null,
            "title ASC",
            "$offset,$limit",
        ).use { cursor ->
            while (cursor.moveToNext()) {
                rows += PlaylistEntry(
                    cursor.getString(0), cursor.getString(1), cursor.getString(2), kind,
                    cursor.getString(3), cursor.getString(4), cursor.getInt(10) != 0,
                    cursor.getInt(11) != 0, cursor.getString(5), cursor.getString(6),
                    cursor.getIntOrNull(7), cursor.getIntOrNull(8), cursor.getString(9),
                    sourceId ?: "default",
                )
            }
        }
        return rows
    }

    private fun android.database.Cursor.getIntOrNull(index: Int): Int? = if (isNull(index)) null else getInt(index)
}
