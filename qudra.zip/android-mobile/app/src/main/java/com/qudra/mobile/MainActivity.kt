// @polsia:user-owned — Mobile entry point with credential-free bootstrap/home recovery.
package com.qudra.mobile

import android.app.Activity
import android.os.Bundle
import android.widget.ScrollView
import com.qudra.mobile.data.NativeFailure
import com.qudra.mobile.data.QudraRepository
import com.qudra.mobile.local.LocalPlaybackStateStore
import com.qudra.mobile.ui.BootstrapScreen
import com.qudra.mobile.ui.HomeScreen
import com.qudra.mobile.ui.UiStyle
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var repository: QudraRepository
    private lateinit var local: LocalPlaybackStateStore
    private val executor = Executors.newSingleThreadExecutor()
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); repository = QudraRepository(this); local = LocalPlaybackStateStore(this); if (repository.currentSession() == null) showBootstrap() else loadHome() }
    private fun showBootstrap() = BootstrapScreen.show(this, repository) { loadHome() }
    private fun loadHome() {
        val loading = UiStyle.column(this); loading.addView(UiStyle.title(this, "QUDRA Mobile", 34f)); loading.addView(UiStyle.body(this, "Loading the server-issued Mobile Device session and QUDRA OPEN manifest…")); setContentView(ScrollView(this).apply { addView(loading) })
        executor.execute { val result = runCatching { repository.loadHome() }; runOnUiThread { result.onSuccess { HomeScreen.show(this, repository, it, local, ::showBootstrap) }.onFailure { error -> val failed = UiStyle.column(this); failed.addView(UiStyle.title(this, "QUDRA needs attention", 28f)); failed.addView(UiStyle.body(this, NativeFailure.from(error).message)); failed.addView(UiStyle.button(this, "Retry") { loadHome() }); failed.addView(UiStyle.button(this, "Re-authorize Mobile Device") { repository.clearSession(); showBootstrap() }); setContentView(ScrollView(this).apply { addView(failed) }) } } }
    }
    override fun onDestroy() { executor.shutdown(); super.onDestroy() }
}
