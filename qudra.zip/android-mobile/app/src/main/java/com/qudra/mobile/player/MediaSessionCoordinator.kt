// @polsia:user-owned — Media3 session wrapper for foreground video controls.
package com.qudra.mobile.player

import android.content.Context
import androidx.media3.common.Player
import androidx.media3.session.MediaSession

class MediaSessionCoordinator(context: Context, player: Player) {
    val session = MediaSession.Builder(context, player).setId("qudra-mobile").build()
    fun release() = session.release()
}
