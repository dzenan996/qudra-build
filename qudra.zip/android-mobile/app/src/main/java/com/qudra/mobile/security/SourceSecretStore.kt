// @polsia:user-owned — source credentials are encrypted and stay on the Device.
package com.qudra.mobile.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class SourceSecretStore(context: Context) {
    private val preferences = context.getSharedPreferences("qudra_mobile_source_secrets", Context.MODE_PRIVATE)
    private val alias = "qudra_mobile_source_secrets_aes_v1"
    private val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    init { if (!keyStore.containsAlias(alias)) KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply { init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build()); generateKey() } }
    fun put(sourceId: String, secret: String) { preferences.edit().putString(sourceId, encrypt(secret)).commit() }
    fun get(sourceId: String): String? = preferences.getString(sourceId, null)?.let { runCatching { decrypt(it) }.getOrNull() }
    fun remove(sourceId: String) = preferences.edit().remove(sourceId).apply()
    private fun key(): SecretKey = keyStore.getKey(alias, null) as SecretKey
    private fun encrypt(value: String): String { val cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, key()); return Base64.encodeToString(cipher.iv + cipher.doFinal(value.toByteArray()), Base64.NO_WRAP) }
    private fun decrypt(value: String): String { val bytes = Base64.decode(value, Base64.NO_WRAP); val cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, bytes.copyOfRange(0, 12))); return cipher.doFinal(bytes.copyOfRange(12, bytes.size)).toString(Charsets.UTF_8) }
}
