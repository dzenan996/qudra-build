// @polsia:user-owned — video-only Android PiP policy.
package com.qudra.mobile.player

import android.app.Activity
import android.app.PictureInPictureParams
import android.os.Build
import android.util.Rational

object PictureInPictureController {
    fun enter(activity: Activity, width: Int = 16, height: Int = 9): Boolean { if (Build.VERSION.SDK_INT < 26) return false; activity.enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(width, height)).build()); return true }
}
