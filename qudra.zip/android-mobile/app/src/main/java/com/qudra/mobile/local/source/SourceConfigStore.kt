// @polsia:user-owned — two-slot local source selection and last-known-good metadata.
package com.qudra.mobile.local.source

import android.content.Context
import com.qudra.mobile.data.api.SourceConfig
import org.json.JSONArray
import org.json.JSONObject

class SourceConfigStore(context: Context) {
    private val preferences = context.getSharedPreferences("qudra_mobile_sources", Context.MODE_PRIVATE)
    fun save(configs: List<SourceConfig>) { require(configs.size <= 2); preferences.edit().putString("configs", JSONArray(configs.map { JSONObject().apply { put("id", it.id); put("label", it.label); put("endpointUrl", it.endpointUrl); put("epgUrl", it.epgUrl); put("sourceTimezone", it.sourceTimezone); put("utcOffsetMinutes", it.utcOffsetMinutes); put("slot", it.slot); put("hasSecret", it.hasSecret); put("configVersion", it.configVersion) } }.toString()).apply() }
    fun read(): List<SourceConfig> { val values = runCatching { JSONArray(preferences.getString("configs", "[]")) }.getOrNull() ?: return emptyList(); return (0 until values.length()).mapNotNull { value -> runCatching { val item = values.getJSONObject(value); SourceConfig(item.getString("id"), item.getString("label"), item.optStringOrNull("endpointUrl"), item.optStringOrNull("epgUrl"), item.optStringOrNull("sourceTimezone"), item.optIntOrNull("utcOffsetMinutes"), item.optIntOrNull("slot"), item.optBoolean("hasSecret"), item.optInt("configVersion", 1)) }.getOrNull() }.take(2) }
    fun setActive(id: String?) = preferences.edit().putString("active", id).apply()
    fun activeId(): String? = preferences.getString("active", null)
    fun active(): SourceConfig? = read().firstOrNull { it.id == activeId() }
    fun fallBackToOpen() { setActive(null) }
}
private fun JSONObject.optStringOrNull(name: String): String? = if (isNull(name)) null else optString(name).takeIf(String::isNotBlank)
private fun JSONObject.optIntOrNull(name: String): Int? = if (isNull(name) || !has(name)) null else optInt(name)
