// @polsia:user-owned — two-slot local source selection and last-known-good metadata.
package com.qudra.mobile.local.source

import android.content.Context
import com.qudra.mobile.data.api.SourceConfig
import org.json.JSONArray
import org.json.JSONObject

class SourceConfigStore(context: Context) {
    private val preferences = context.getSharedPreferences("qudra_mobile_sources", Context.MODE_PRIVATE)

    fun save(configs: List<SourceConfig>) {
        require(configs.size <= 2)
        val values = JSONArray(
            configs.map { config ->
                JSONObject().apply {
                    put("id", config.id)
                    put("label", config.label)
                    put("endpointUrl", config.endpointUrl)
                    put("epgUrl", config.epgUrl)
                    put("sourceTimezone", config.sourceTimezone)
                    put("utcOffsetMinutes", config.utcOffsetMinutes)
                    put("slot", config.slot)
                    put("hasSecret", config.hasSecret)
                    put("configVersion", config.configVersion)
                }
            },
        )
        preferences.edit().putString("configs", values.toString()).apply()
    }

    fun read(): List<SourceConfig> {
        val values = runCatching { JSONArray(preferences.getString("configs", "[]")) }.getOrNull()
            ?: return emptyList()
        return (0 until values.length()).mapNotNull { index ->
            runCatching {
                val item = values.getJSONObject(index)
                SourceConfig(
                    item.getString("id"),
                    item.getString("label"),
                    item.optStringOrNull("endpointUrl"),
                    item.optStringOrNull("epgUrl"),
                    item.optStringOrNull("sourceTimezone"),
                    item.optIntOrNull("utcOffsetMinutes"),
                    item.optIntOrNull("slot"),
                    item.optBoolean("hasSecret"),
                    item.optInt("configVersion", 1),
                )
            }.getOrNull()
        }.take(2)
    }

    fun setActive(id: String?) = preferences.edit().putString("active", id).apply()
    fun activeId(): String? = preferences.getString("active", null)
    fun active(): SourceConfig? = read().firstOrNull { it.id == activeId() }
    fun fallBackToOpen() { setActive(null) }
}

private fun JSONObject.optStringOrNull(name: String): String? =
    if (isNull(name)) null else optString(name).takeIf(String::isNotBlank)

private fun JSONObject.optIntOrNull(name: String): Int? =
    if (isNull(name) || !has(name)) null else optInt(name)
