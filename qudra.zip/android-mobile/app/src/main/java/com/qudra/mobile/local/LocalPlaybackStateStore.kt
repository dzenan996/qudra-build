// @polsia:user-owned — bounded, Device-local Favorites/Recent/Continue Watching state.
package com.qudra.mobile.local

import android.content.Context

data class PlaybackProgress(val sourceId: String, val positionMs: Long, val durationMs: Long)
class LocalPlaybackStateStore(context: Context) {
    private val preferences = context.getSharedPreferences("qudra_mobile_playback", Context.MODE_PRIVATE)
    fun isFavorite(id: String) = preferences.getBoolean("favorite_$id", false)
    fun setFavorite(id: String, value: Boolean) = preferences.edit().putBoolean("favorite_$id", value).apply()
    fun saveProgress(value: PlaybackProgress) = preferences.edit().putLong("position_${value.sourceId}", value.positionMs).putLong("duration_${value.sourceId}", value.durationMs).apply()
    fun progress(id: String): PlaybackProgress? { val position = preferences.getLong("position_$id", -1); val duration = preferences.getLong("duration_$id", -1); return if (position >= 0 && duration > 0) PlaybackProgress(id, position, duration) else null }
    fun recentlyWatched() = preferences.getString("recent", "").orEmpty().split('|').filter(String::isNotBlank)
    fun markWatched(id: String) { val values = (listOf(id) + recentlyWatched().filterNot { it == id }).take(20); preferences.edit().putString("recent", values.joinToString("|")).apply() }
    fun continueWatching() = recentlyWatched().filter { progress(it)?.let { item -> item.positionMs > 0 && item.positionMs < item.durationMs - 15_000 } == true }
    fun cleanup() { recentlyWatched().drop(20).forEach { preferences.edit().remove("position_$it").remove("duration_$it").apply() } }
}
