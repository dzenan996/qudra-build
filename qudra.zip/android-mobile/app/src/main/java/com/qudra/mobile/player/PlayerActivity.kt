// @polsia:user-owned — native Media3 direct-origin player with PiP and resume.
package com.qudra.mobile.player

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.qudra.mobile.data.api.QudraMediaClass
import com.qudra.mobile.local.LocalPlaybackStateStore
import com.qudra.mobile.ui.UiStyle

class PlayerActivity : Activity() {
    private var player: ExoPlayer? = null
    private var mediaSession: MediaSessionCoordinator? = null
    private lateinit var model: PlayerViewModel
    private lateinit var playerView: PlayerView
    private lateinit var mediaClass: QudraMediaClass
    private lateinit var autoplayPreferences: AutoplayPreferences
    private var currentEpisode: EpisodeDescriptor? = null
    private var nextEpisode: EpisodeDescriptor? = null
    private var finalEpisodeHandled = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val requested = intent.getStringExtra(EXTRA_URL) ?: return finish()
        val personalSource = intent.getBooleanExtra(EXTRA_PERSONAL_SOURCE, false)
        val validator: (String, String?) -> String? = if (personalSource) ::validatePersonalSourceOrigin else ::validateOpenOrigin
        val url = validator(requested, intent.getStringExtra(EXTRA_PREFERRED_ORIGIN)) ?: run { Toast.makeText(this, if (personalSource) "Personal Source playback requires a valid direct HTTP or HTTPS origin." else "QUDRA OPEN playback requires the manifest-approved HTTPS origin.", Toast.LENGTH_LONG).show(); return finish() }
        if (intent.getBooleanExtra(EXTRA_SUPPORTED, true).not()) { Toast.makeText(this, "This source format is not supported on this Mobile Device.", Toast.LENGTH_LONG).show(); return finish() }
        val sourceId = intent.getStringExtra(EXTRA_SOURCE_ID) ?: return finish(); mediaClass = runCatching { QudraMediaClass.valueOf(intent.getStringExtra(EXTRA_MEDIA_CLASS).orEmpty()) }.getOrDefault(QudraMediaClass.MOVIE); autoplayPreferences = AutoplayPreferences(this); currentEpisode = episodeFromIntent(EXTRA_SERIES_ID, EXTRA_EPISODE_ID, EXTRA_EPISODE_ORDER, EXTRA_URL, EXTRA_PREFERRED_ORIGIN); nextEpisode = episodeFromIntent(EXTRA_NEXT_SERIES_ID, EXTRA_NEXT_EPISODE_ID, EXTRA_NEXT_EPISODE_ORDER, EXTRA_NEXT_URL, EXTRA_NEXT_PREFERRED_ORIGIN); model = PlayerViewModel(LocalPlaybackStateStore(this), sourceId)
        val root = FrameLayout(this).apply { setBackgroundColor(UiStyle.background) }; playerView = PlayerView(this).apply { useController = true; requestFocus() }; root.addView(playerView, FrameLayout.LayoutParams(-1, -1)); root.addView(TextView(this).apply { text = intent.getStringExtra(EXTRA_TITLE) ?: "QUDRA"; textSize = 18f; setTextColor(UiStyle.text); setPadding(24, 18, 24, 18); gravity = Gravity.TOP }, FrameLayout.LayoutParams(-1, 72)); setContentView(root)
        player = ExoPlayer.Builder(this).build().also { exo -> playerView.player = exo; mediaSession = MediaSessionCoordinator(this, exo); exo.setMediaItem(ExoMediaItem.fromUri(url), model.resumePosition()); exo.addListener(object : androidx.media3.common.Player.Listener { override fun onPlayerError(error: PlaybackException) { Toast.makeText(this@PlayerActivity, "Playback failed at the direct source origin. Retry or choose another item.", Toast.LENGTH_LONG).show() }; override fun onPlaybackStateChanged(state: Int) { if (state == androidx.media3.common.Player.STATE_ENDED) playNextIfAllowed(exo) } }); exo.prepare(); exo.playWhenReady = true }
    }

    private fun playNextIfAllowed(exo: ExoPlayer) {
        if (finalEpisodeHandled) return
        model.save(exo.currentPosition, exo.duration)
        val current = currentEpisode ?: run { keepFinalEpisodeStopped(exo); return }
        val candidate = nextEpisode ?: run { keepFinalEpisodeStopped(exo); return }
        val next = AutoplayPolicy.next(current, listOf(candidate), autoplayPreferences.isEnabled()) ?: run { keepFinalEpisodeStopped(exo); return }
        val personalSource = intent.getBooleanExtra(EXTRA_PERSONAL_SOURCE, false)
        val safe = (if (personalSource) validatePersonalSourceOrigin(next.directOrigin, next.preferredOrigin) else validateOpenOrigin(next.directOrigin, next.preferredOrigin)) ?: run { keepFinalEpisodeStopped(exo); return }
        model = PlayerViewModel(LocalPlaybackStateStore(this), next.sourceId)
        currentEpisode = next
        nextEpisode = null
        exo.setMediaItem(ExoMediaItem.fromUri(safe), model.resumePosition())
        exo.prepare()
        exo.play()
    }

    private fun keepFinalEpisodeStopped(exo: ExoPlayer) { finalEpisodeHandled = true; exo.playWhenReady = false }

    private fun episodeFromIntent(seriesKey: String, episodeKey: String, orderKey: String, urlKey: String, originKey: String): EpisodeDescriptor? {
        val seriesId = intent.getStringExtra(seriesKey) ?: return null
        val episodeId = intent.getStringExtra(episodeKey) ?: return null
        val order = intent.getIntExtra(orderKey, -1)
        val direct = intent.getStringExtra(urlKey) ?: return null
        val preferred = intent.getStringExtra(originKey) ?: return null
        if (order < 0) return null
        return EpisodeDescriptor(seriesId, intent.getStringExtra(if (urlKey == EXTRA_URL) EXTRA_SOURCE_ID else EXTRA_NEXT_SOURCE_ID) ?: return null, episodeId, order, direct, preferred)
    }
    override fun onUserLeaveHint() { if (mediaClass != QudraMediaClass.RADIO) PictureInPictureController.enter(this) }
    override fun onPause() { player?.let { model.save(it.currentPosition, it.duration) }; super.onPause() }
    override fun onDestroy() { mediaSession?.release(); player?.release(); player = null; super.onDestroy() }
    companion object { const val EXTRA_URL = "qudra.direct_url"; const val EXTRA_PREFERRED_ORIGIN = "qudra.preferred_origin"; const val EXTRA_TITLE = "qudra.title"; const val EXTRA_SOURCE_ID = "qudra.source_id"; const val EXTRA_MEDIA_CLASS = "qudra.media_class"; const val EXTRA_SUPPORTED = "qudra.supported"; const val EXTRA_PERSONAL_SOURCE = "qudra.personal_source"; const val EXTRA_SERIES_ID = "qudra.series_id"; const val EXTRA_EPISODE_ID = "qudra.episode_id"; const val EXTRA_EPISODE_ORDER = "qudra.episode_order"; const val EXTRA_NEXT_URL = "qudra.next_url"; const val EXTRA_NEXT_PREFERRED_ORIGIN = "qudra.next_preferred_origin"; const val EXTRA_NEXT_TITLE = "qudra.next_title"; const val EXTRA_NEXT_SOURCE_ID = "qudra.next_source_id"; const val EXTRA_NEXT_SERIES_ID = "qudra.next_series_id"; const val EXTRA_NEXT_EPISODE_ID = "qudra.next_episode_id"; const val EXTRA_NEXT_EPISODE_ORDER = "qudra.next_episode_order" }
}
