// @polsia:user-owned — deterministic, account-free same-series/source autoplay policy.
package com.qudra.mobile.player

import java.net.URI

data class EpisodeDescriptor(
    val seriesId: String,
    val sourceId: String,
    val episodeId: String,
    val episodeOrder: Int,
    val directOrigin: String,
    val preferredOrigin: String,
)

object AutoplayPolicy {
    const val DEFAULT_ENABLED = true

    fun next(
        current: EpisodeDescriptor,
        candidates: List<EpisodeDescriptor>,
        enabled: Boolean = DEFAULT_ENABLED,
    ): EpisodeDescriptor? {
        if (!enabled) return null
        return candidates
            .asSequence()
            .filter { it.seriesId == current.seriesId && it.sourceId == current.sourceId }
            .filter { it.episodeOrder == current.episodeOrder + 1 }
            .filter { it.directOrigin == it.preferredOrigin && isSafeOrigin(it.directOrigin) }
            .sortedBy { it.episodeId }
            .firstOrNull()
    }

    private fun isSafeOrigin(url: String): Boolean = runCatching {
        val uri = URI(url)
        uri.scheme == "https" && !uri.host.isNullOrBlank() && uri.userInfo == null &&
            !Regex("token|secret|password|api[-_]?key|auth", RegexOption.IGNORE_CASE)
                .containsMatchIn(uri.rawQuery.orEmpty())
    }.getOrDefault(false)
}
