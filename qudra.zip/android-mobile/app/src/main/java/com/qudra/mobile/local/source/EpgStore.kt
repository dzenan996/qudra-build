// @polsia:user-owned — source-scoped XMLTV generations with stale-state retention.
package com.qudra.mobile.local.source

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class EpgStore(context: Context) : SQLiteOpenHelper(context, "qudra_mobile_epg.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE generations (id INTEGER PRIMARY KEY AUTOINCREMENT, source_id TEXT NOT NULL, state TEXT NOT NULL, updated_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE channels (generation_id INTEGER NOT NULL, id TEXT NOT NULL, display_name TEXT NOT NULL)")
        db.execSQL("CREATE TABLE programmes (generation_id INTEGER NOT NULL, channel_id TEXT NOT NULL, title TEXT NOT NULL, description TEXT, start_ms INTEGER NOT NULL, stop_ms INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX programme_time_idx ON programmes(generation_id, channel_id, start_ms, stop_ms)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE generations (id INTEGER PRIMARY KEY AUTOINCREMENT, source_id TEXT NOT NULL, state TEXT NOT NULL, updated_at INTEGER NOT NULL)")
            db.execSQL("ALTER TABLE channels ADD COLUMN generation_id INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE programmes ADD COLUMN generation_id INTEGER NOT NULL DEFAULT 0")
        }
    }

    fun replace(sourceId: String, snapshot: Pair<List<EpgChannel>, List<EpgProgramme>>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.update("generations", ContentValues().apply { put("state", "RETIRED") }, "source_id = ? AND state = ?", arrayOf(sourceId, "ACTIVE"))
            val generation = db.insertOrThrow("generations", null, ContentValues().apply { put("source_id", sourceId); put("state", "ACTIVE"); put("updated_at", System.currentTimeMillis()) })
            snapshot.first.forEach { channel -> db.insertOrThrow("channels", null, ContentValues().apply { put("generation_id", generation); put("id", channel.id); put("display_name", channel.displayName) }) }
            snapshot.second.forEach { programme -> db.insertOrThrow("programmes", null, ContentValues().apply { put("generation_id", generation); put("channel_id", programme.channelId); put("title", programme.title); put("description", programme.description); put("start_ms", programme.startEpochMillis); put("stop_ms", programme.stopEpochMillis) }) }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun markStale(sourceId: String) = writableDatabase.update("generations", ContentValues().apply { put("state", "STALE") }, "source_id = ? AND state = ?", arrayOf(sourceId, "ACTIVE"))

    fun nowNext(sourceId: String, channelId: String, now: Long = System.currentTimeMillis()): List<EpgProgramme> {
        val rows = mutableListOf<EpgProgramme>(); val generation = activeGeneration(sourceId) ?: return rows
        readableDatabase.query("programmes", arrayOf("channel_id", "title", "description", "start_ms", "stop_ms"), "generation_id = ? AND channel_id = ? AND stop_ms >= ?", arrayOf(generation.toString(), channelId, now.toString()), null, null, "start_ms ASC", "2").use { cursor -> while (cursor.moveToNext()) rows += EpgProgramme(cursor.getString(0), cursor.getString(1), cursor.getStringOrNull(2), cursor.getLong(3), cursor.getLong(4)) }
        return rows
    }

    private fun activeGeneration(sourceId: String): Long? = readableDatabase.query("generations", arrayOf("id"), "source_id = ? AND state = ?", arrayOf(sourceId, "ACTIVE"), null, null, "updated_at DESC", "1").use { if (it.moveToFirst()) it.getLong(0) else null }
    private fun android.database.Cursor.getStringOrNull(index: Int): String? = if (isNull(index)) null else getString(index)
}
