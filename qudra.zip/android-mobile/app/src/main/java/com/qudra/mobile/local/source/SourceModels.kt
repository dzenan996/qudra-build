// @polsia:user-owned — local Personal Source models; no cloud catalogue model.
package com.qudra.mobile.local.source

enum class LocalMediaKind { LIVE_TV, MOVIE, SERIES, RADIO }
data class PlaylistEntry(
    val id: String,
    val title: String,
    val uri: String,
    val kind: LocalMediaKind,
    val group: String?,
    val tvgId: String?,
    val catchUpSupported: Boolean,
    val timeshiftSupported: Boolean,
    val originalCategory: String? = group,
    val tvgName: String? = null,
    val seasonNumber: Int? = null,
    val episodeNumber: Int? = null,
    val seriesKey: String? = null,
    val sourceId: String = "default",
)
data class EpgChannel(val id: String, val displayName: String)
data class EpgProgramme(val channelId: String, val title: String, val description: String?, val startEpochMillis: Long, val stopEpochMillis: Long)
data class LocalCapabilities(val epg: Boolean, val nowNext: Boolean, val fullSchedule: Boolean, val catchUp: Boolean, val timeshift: Boolean)
data class LocalSourceSnapshot(val generation: Long, val media: List<PlaylistEntry>, val channels: List<EpgChannel>, val programmes: List<EpgProgramme>, val timezone: String?, val utcOffsetMinutes: Int?, val state: String, val capabilities: LocalCapabilities, val lastKnownGood: Boolean = true)
