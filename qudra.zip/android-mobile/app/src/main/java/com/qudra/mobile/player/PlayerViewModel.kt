// @polsia:user-owned — local progress only; detailed viewing history never uploads.
package com.qudra.mobile.player

import com.qudra.mobile.local.LocalPlaybackStateStore

class PlayerViewModel(private val local: LocalPlaybackStateStore, private val sourceId: String) {
    fun resumePosition() = local.progress(sourceId)?.positionMs ?: 0L
    fun save(positionMs: Long, durationMs: Long) { if (durationMs > 0) local.saveProgress(com.qudra.mobile.local.PlaybackProgress(sourceId, positionMs, durationMs)); local.markWatched(sourceId); local.cleanup() }
}
