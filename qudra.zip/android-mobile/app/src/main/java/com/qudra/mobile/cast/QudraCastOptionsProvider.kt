// @polsia:user-owned — Cast receiver ID je build-time konfiguracija, nije tajna.
package com.qudra.mobile.cast

import android.content.Context
import com.google.android.gms.cast.CastOptions
import com.google.android.gms.cast.framework.OptionsProvider
import com.google.android.gms.cast.framework.SessionProvider
import com.qudra.mobile.BuildConfig

class QudraCastOptionsProvider : OptionsProvider {
    override fun getCastOptions(context: Context) = CastOptions.Builder()
        .setReceiverApplicationId(receiverApplicationId())
        .setStopReceiverApplicationWhenEndingSession(false)
        .build()

    private fun receiverApplicationId(): String {
        val receiverId = BuildConfig.CAST_RECEIVER_APP_ID.trim()
        if (receiverId.isBlank() || (BuildConfig.BUILD_TYPE == "release" && receiverId == DEVELOPMENT_RECEIVER_APP_ID)) {
            throw IllegalStateException("Cast production receiver ID is not configured for this build.")
        }
        return receiverId
    }

    private companion object {
        // Ovaj ID dopušten je samo u debug buildovima; release koristi Owner konfiguraciju.
        const val DEVELOPMENT_RECEIVER_APP_ID = "CC1AD845"
    }

    override fun getAdditionalSessionProviders(context: Context): List<SessionProvider>? = null
}
