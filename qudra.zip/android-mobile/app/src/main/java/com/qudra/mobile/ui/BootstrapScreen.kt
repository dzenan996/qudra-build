// @polsia:user-owned — credential-free first-run bootstrap; account is optional and absent here.
package com.qudra.mobile.ui

import android.app.Activity
import android.app.AlertDialog
import android.widget.ScrollView
import com.qudra.mobile.data.NativeFailure
import com.qudra.mobile.data.QudraRepository
import java.util.concurrent.Executors

object BootstrapScreen {
    fun show(activity: Activity, repository: QudraRepository, onComplete: () -> Unit) {
        val root = UiStyle.column(activity); root.addView(UiStyle.title(activity, "QUDRA Mobile", 34f)); root.addView(UiStyle.body(activity, "A protected Mobile Device identity is created locally. No account, password, or paid entitlement is required to start QUDRA OPEN.")); root.addView(UiStyle.body(activity, "This device uses a separate Mobile license boundary from QUDRA TV. Personal Source credentials remain encrypted on this device.")); root.addView(UiStyle.button(activity, "Set up this Mobile Device") {
            val executor = Executors.newSingleThreadExecutor(); executor.execute { val result = runCatching { val pending = repository.beginBootstrap(); repository.completeBootstrap(pending) }; activity.runOnUiThread { executor.shutdown(); result.onSuccess { onComplete() }.onFailure { error -> AlertDialog.Builder(activity).setTitle("Mobile setup needs attention").setMessage(NativeFailure.from(error).message).setPositiveButton("Try again", null).show() } } }
        }); activity.setContentView(ScrollView(activity).apply { addView(root) })
    }
}
