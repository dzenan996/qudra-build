// @polsia:user-owned — encrypted last-known-good QUDRA OPEN metadata cache.
package com.qudra.mobile.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.qudra.mobile.data.api.OpenManifest
import org.json.JSONObject
import java.security.KeyStore
import java.time.Duration
import java.time.Instant
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class OpenManifestCacheRecord(val version: String, val storedAt: String)
object OpenManifestCachePolicy { const val MAX_AGE_HOURS = 24L; fun canFallback(record: OpenManifestCacheRecord, now: Instant) = record.version.isNotBlank() && runCatching { Duration.between(Instant.parse(record.storedAt), now).let { !it.isNegative && it.toHours() <= MAX_AGE_HOURS } }.getOrDefault(false) }
class OpenManifestCache(context: Context) {
    private val preferences = context.getSharedPreferences("qudra_mobile_open_cache", Context.MODE_PRIVATE)
    private val alias = "qudra_mobile_open_cache_aes_v1"
    private val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    init { if (!keyStore.containsAlias(alias)) KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply { init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build()); generateKey() } }
    fun save(manifest: OpenManifest) { preferences.edit().putString("version", manifest.manifestVersion).putString("stored", Instant.now().toString()).putString("payload", encrypt(manifest.rawJson)).commit() }
    fun read(): OpenManifest? { val version = preferences.getString("version", null) ?: return null; val stored = preferences.getString("stored", null) ?: return null; val payload = preferences.getString("payload", null) ?: return null; if (!OpenManifestCachePolicy.canFallback(OpenManifestCacheRecord(version, stored), Instant.now())) return null; return runCatching { OpenManifest.parse(JSONObject(decrypt(payload))) }.getOrNull() }
    private fun key(): SecretKey = keyStore.getKey(alias, null) as SecretKey
    private fun encrypt(value: String): String { val cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, key()); return Base64.encodeToString(cipher.iv + cipher.doFinal(value.toByteArray()), Base64.NO_WRAP) }
    private fun decrypt(value: String): String { val bytes = Base64.decode(value, Base64.NO_WRAP); val cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, bytes.copyOfRange(0, 12))); return cipher.doFinal(bytes.copyOfRange(12, bytes.size)).toString(Charsets.UTF_8) }
}
