// @polsia:user-owned — P-256 identity remains inside Android Keystore.
package com.qudra.mobile.security

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.qudra.mobile.data.api.urlSafe
import java.nio.charset.StandardCharsets
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.util.UUID

class DeviceIdentityStore(private val context: Context) {
    private val preferences = context.getSharedPreferences("qudra_mobile_identity", Context.MODE_PRIVATE)
    private val alias = "qudra_mobile_p256_v1"
    private val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    init {
        if (!keyStore.containsAlias(alias)) {
            KeyPairGenerator.getInstance("EC", "AndroidKeyStore").apply {
                initialize(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY).setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1")).setDigests(KeyProperties.DIGEST_SHA256).build())
                generateKeyPair()
            }
        }
        if (preferences.getString("fingerprint", null) != fingerprint) preferences.edit().putString("public_device_id", "mobile-${UUID.randomUUID()}").putString("fingerprint", fingerprint).commit()
    }

    val publicDeviceId get() = preferences.getString("public_device_id", null) ?: error("Mobile identity metadata missing")
    val publicKeyPem get() = pem(keyStore.getCertificate(alias).publicKey.encoded)
    val fingerprint get() = MessageDigest.getInstance("SHA-256").digest(publicKeyPem.toByteArray(StandardCharsets.UTF_8)).joinToString("") { "%02x".format(it) }
    val deviceModel get() = "${Build.MANUFACTURER} ${Build.MODEL}".take(128)
    val platform get() = if (contextResourcesSmallestWidth(context) >= 600) com.qudra.mobile.data.api.QudraPlatform.ANDROID_TABLET else com.qudra.mobile.data.api.QudraPlatform.ANDROID_PHONE

    fun sign(payload: String): String {
        val key = keyStore.getKey(alias, null) as? PrivateKey ?: error("Mobile private key unavailable")
        return Signature.getInstance("SHA256withECDSA").run { initSign(key); update(payload.toByteArray(StandardCharsets.UTF_8)); urlSafe(sign()) }
    }

    private fun pem(encoded: ByteArray) = "-----BEGIN PUBLIC KEY-----\n${Base64.encodeToString(encoded, Base64.NO_WRAP).chunked(64).joinToString("\n")}\n-----END PUBLIC KEY-----"
    private fun contextResourcesSmallestWidth(context: Context) = context.resources.configuration.smallestScreenWidthDp
}
