// @polsia:user-owned — cancellable staged import; invalid refreshes retain last-known-good.
package com.qudra.mobile.local.source

import java.io.InputStreamReader

class SourceImportCoordinator(
    private val downloader: SourceDownloadClient,
    private val catalogue: CatalogueStore,
    private val epgStore: EpgStore,
    private val m3u: M3uParser = M3uParser(),
    private val xmlTv: XmlTvParser = XmlTvParser(),
) {
    fun import(sourceId: String, playlistUrl: String, epgUrl: String?, timezone: String?, offsetMinutes: Int?, sourceSecret: String? = null, allowCredentialQuery: Boolean = false, cancelled: () -> Boolean = { false }): LocalSourceSnapshot {
        val generation = catalogue.beginGeneration(sourceId)
        return try {
            val response = downloader.open(playlistUrl, sourceSecret, allowCredentialQuery)
            val media = response.stream.use { m3u.parse(InputStreamReader(it, Charsets.UTF_8), cancelled) }.map { it.copy(id = "$sourceId::${it.id}", sourceId = sourceId) }
            require(media.isNotEmpty()) { "Playlist did not contain usable entries" }
            catalogue.stageMedia(generation, media)
            val epg = epgUrl?.let { url -> downloader.open(url, sourceSecret, allowCredentialQuery).stream.use { xmlTv.parse(InputStreamReader(it, Charsets.UTF_8), cancelled) } }
            if (epg != null) epgStore.replace(sourceId, epg)
            catalogue.promoteGeneration(generation)
            LocalSourceSnapshot(generation, media, epg?.first.orEmpty(), epg?.second.orEmpty(), timezone, offsetMinutes, "FRESH", LocalCapabilities(epg != null, epg != null, epg != null, media.any { it.catchUpSupported }, media.any { it.timeshiftSupported }))
        } catch (error: Throwable) {
            catalogue.retainLastKnownGood(); epgStore.markStale(sourceId); throw error
        }
    }

    fun importXtream(sourceId: String, credentials: XtreamCredentials, timezone: String?, offsetMinutes: Int?, cancelled: () -> Boolean = { false }): LocalSourceSnapshot {
        val generation = catalogue.beginGeneration(sourceId)
        return try {
            val client = XtreamApiClient(downloader)
            val media = client.fetchCatalogue(sourceId, credentials, cancelled)
            require(media.isNotEmpty()) { "Xtream source did not contain usable entries" }
            catalogue.stageMedia(generation, media)
            val epg = runCatching {
                downloader.open(credentials.epgUrl(), allowCredentialQuery = true).stream.use { xmlTv.parse(InputStreamReader(it, Charsets.UTF_8), cancelled) }
            }.getOrNull()
            if (epg != null) epgStore.replace(sourceId, epg) else epgStore.markStale(sourceId)
            catalogue.promoteGeneration(generation)
            LocalSourceSnapshot(generation, media, epg?.first.orEmpty(), epg?.second.orEmpty(), timezone, offsetMinutes, "FRESH", LocalCapabilities(epg != null, epg != null, epg != null, media.any { it.catchUpSupported }, media.any { it.timeshiftSupported }))
        } catch (error: Throwable) {
            catalogue.retainLastKnownGood(); epgStore.markStale(sourceId); throw error
        }
    }

    fun importWithRetry(sourceId: String, playlistUrl: String, epgUrl: String?, timezone: String?, offsetMinutes: Int?, sourceSecret: String? = null, attempts: Int = 3, allowCredentialQuery: Boolean = false, cancelled: () -> Boolean = { false }): LocalSourceSnapshot {
        require(attempts in 1..3); var last: Throwable? = null
        repeat(attempts) { attempt ->
            try { return import(sourceId, playlistUrl, epgUrl, timezone, offsetMinutes, sourceSecret, allowCredentialQuery, cancelled) }
            catch (error: InterruptedException) { throw error }
            catch (error: Throwable) { last = error; if (attempt < attempts - 1) Thread.sleep(250L * (attempt + 1)) }
        }
        throw last ?: IllegalStateException("Source import failed")
    }

    fun importXtreamWithRetry(sourceId: String, credentials: XtreamCredentials, timezone: String?, offsetMinutes: Int?, attempts: Int = 2, cancelled: () -> Boolean = { false }): LocalSourceSnapshot {
        require(attempts in 1..2); var last: Throwable? = null
        repeat(attempts) { attempt ->
            try { return importXtream(sourceId, credentials, timezone, offsetMinutes, cancelled) }
            catch (error: InterruptedException) { throw error }
            catch (error: Throwable) { last = error; if (attempt < attempts - 1) Thread.sleep(500L) }
        }
        throw last ?: IllegalStateException("Xtream import failed")
    }
}
