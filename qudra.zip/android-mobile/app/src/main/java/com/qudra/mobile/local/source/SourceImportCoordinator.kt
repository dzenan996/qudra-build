// @polsia:user-owned — cancellable staged import; invalid refreshes retain last-known-good.
package com.qudra.mobile.local.source

import java.io.InputStreamReader

class SourceImportCoordinator(private val downloader: SourceDownloadClient, private val catalogue: CatalogueStore, private val epgStore: EpgStore, private val m3u: M3uParser = M3uParser(), private val xmlTv: XmlTvParser = XmlTvParser()) {
    fun import(sourceId: String, playlistUrl: String, epgUrl: String?, timezone: String?, offsetMinutes: Int?, sourceSecret: String? = null, cancelled: () -> Boolean = { false }): LocalSourceSnapshot {
        val generation = catalogue.beginGeneration(sourceId)
        return try {
            val response = downloader.open(playlistUrl, sourceSecret); val media = response.stream.use { m3u.parse(InputStreamReader(it, Charsets.UTF_8), cancelled) }.map { it.copy(id = "$sourceId::${it.id}", sourceId = sourceId) }; require(media.isNotEmpty()) { "Playlist did not contain usable entries" }; catalogue.stageMedia(generation, media)
            val epg = epgUrl?.let { url -> val epgResponse = downloader.open(url, sourceSecret); epgResponse.stream.use { xmlTv.parse(InputStreamReader(it, Charsets.UTF_8), cancelled) } }
            if (epg != null) epgStore.replace(sourceId, epg); catalogue.promoteGeneration(generation)
            LocalSourceSnapshot(generation, media, epg?.first.orEmpty(), epg?.second.orEmpty(), timezone, offsetMinutes, "FRESH", LocalCapabilities(epg != null, epg != null, epg != null, media.any { it.catchUpSupported }, media.any { it.timeshiftSupported }))
        } catch (error: Throwable) { catalogue.retainLastKnownGood(); epgStore.markStale(sourceId); throw error }
    }
    fun importWithRetry(sourceId: String, playlistUrl: String, epgUrl: String?, timezone: String?, offsetMinutes: Int?, sourceSecret: String? = null, attempts: Int = 3, cancelled: () -> Boolean = { false }): LocalSourceSnapshot { require(attempts in 1..3); var last: Throwable? = null; repeat(attempts) { attempt -> try { return import(sourceId, playlistUrl, epgUrl, timezone, offsetMinutes, sourceSecret, cancelled) } catch (error: InterruptedException) { throw error } catch (error: Throwable) { last = error; if (attempt < attempts - 1) Thread.sleep(250L * (attempt + 1)) } }; throw last ?: IllegalStateException("Source import failed") }
}
