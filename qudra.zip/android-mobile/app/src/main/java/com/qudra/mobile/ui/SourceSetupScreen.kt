// @polsia:user-owned — Device-scoped Personal Source setup; Xtream credentials are encrypted locally.
package com.qudra.mobile.ui

import android.app.Activity
import android.app.AlertDialog
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import com.qudra.mobile.data.NativeFailure
import com.qudra.mobile.data.QudraRepository

object SourceSetupScreen {
    fun show(activity: Activity, repository: QudraRepository, onSaved: () -> Unit) {
        val form = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 10, 28, 0) }
        fun field(hint: String, secret: Boolean = false): EditText = EditText(activity).apply {
            this.hint = hint; setTextColor(UiStyle.text); setHintTextColor(UiStyle.muted)
            if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        fun note(value: String) = TextView(activity).apply { text = value; setTextColor(UiStyle.muted); textSize = 13f; setPadding(0, 4, 0, 8) }

        val label = field("Label, e.g. Home TV")
        val types = RadioGroup(activity).apply { orientation = RadioGroup.HORIZONTAL }
        val m3uRadio = RadioButton(activity).apply { id = View.generateViewId(); text = "M3U / M3U8"; setTextColor(UiStyle.text); isChecked = true }
        val xtreamRadio = RadioButton(activity).apply { id = View.generateViewId(); text = "Xtream Codes"; setTextColor(UiStyle.text) }
        types.addView(m3uRadio); types.addView(xtreamRadio)

        val endpoint = field("Playlist HTTP/HTTPS URL")
        val xtreamUsername = field("Username")
        val xtreamPassword = field("Password", true)
        val epg = field("XMLTV HTTP/HTTPS URL (optional)")
        val secret = field("Bearer/source token (optional)", true)
        val transportNote = note("HTTP and HTTPS are supported for Personal Sources. HTTP is not encrypted.")
        val xtreamNote = note("Xtream: enter Server URL + Username + Password. You may also paste a full get.php URL; QUDRA extracts the credentials locally.")

        listOf(label, types, endpoint, xtreamUsername, xtreamPassword, epg, secret, transportNote, xtreamNote).forEach(form::addView)

        fun applyMode(xtream: Boolean) {
            endpoint.hint = if (xtream) "Server URL, e.g. http://server:port" else "Playlist HTTP/HTTPS URL"
            xtreamUsername.visibility = if (xtream) View.VISIBLE else View.GONE
            xtreamPassword.visibility = if (xtream) View.VISIBLE else View.GONE
            xtreamNote.visibility = if (xtream) View.VISIBLE else View.GONE
            epg.visibility = if (xtream) View.GONE else View.VISIBLE
            secret.visibility = if (xtream) View.GONE else View.VISIBLE
        }
        applyMode(false)
        types.setOnCheckedChangeListener { _, id -> applyMode(id == xtreamRadio.id) }

        AlertDialog.Builder(activity)
            .setTitle("Add Personal Source")
            .setMessage("Choose M3U/M3U8 or Xtream Codes. Catalogue and credentials stay on this Device; QUDRA Cloud receives only non-secret source metadata.")
            .setView(form)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Connect") { _, _ ->
                val useXtream = types.checkedRadioButtonId == xtreamRadio.id
                Thread {
                    val result = runCatching {
                        repository.createSource(
                            label = label.text.toString().trim(),
                            endpointUrl = endpoint.text.toString().trim().ifBlank { null },
                            epgUrl = if (useXtream) null else epg.text.toString().trim().ifBlank { null },
                            secret = if (useXtream) null else secret.text.toString().ifBlank { null },
                            slot = null,
                            xtreamUsername = if (useXtream) xtreamUsername.text.toString().trim().ifBlank { null } else null,
                            xtreamPassword = if (useXtream) xtreamPassword.text.toString().ifBlank { null } else null,
                            useXtream = useXtream,
                        )
                    }
                    activity.runOnUiThread {
                        result.onSuccess { config ->
                            AlertDialog.Builder(activity)
                                .setTitle("Source connected")
                                .setMessage(if (useXtream) "Xtream login accepted. QUDRA will now import Live TV, Movies, Series and EPG directly from the source server." else "Source saved. QUDRA will now import the playlist locally.")
                                .setPositiveButton("Import") { _, _ ->
                                    Thread {
                                        val refresh = runCatching { repository.refreshLocalSource(config) }
                                        activity.runOnUiThread {
                                            refresh.onSuccess { onSaved() }.onFailure { error ->
                                                AlertDialog.Builder(activity).setTitle("Import failed").setMessage(NativeFailure.from(error).message).setPositiveButton("Close", null).show()
                                            }
                                        }
                                    }.start()
                                }.show()
                        }.onFailure { error ->
                            AlertDialog.Builder(activity).setTitle("Source was not saved").setMessage(NativeFailure.from(error).message).setPositiveButton("Close", null).show()
                        }
                    }
                }.start()
            }.show()
    }
}
