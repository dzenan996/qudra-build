// @polsia:user-owned — Device-scoped Personal Source setup; secrets are write-only to Cloud and encrypted locally.
package com.qudra.mobile.ui

import android.app.Activity
import android.app.AlertDialog
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import com.qudra.mobile.data.NativeFailure
import com.qudra.mobile.data.QudraRepository

object SourceSetupScreen {
    fun show(activity: Activity, repository: QudraRepository, onSaved: () -> Unit) {
        val form = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 10, 28, 0) }
        fun field(hint: String, secret: Boolean = false): EditText = EditText(activity).apply { this.hint = hint; setTextColor(UiStyle.text); setHintTextColor(UiStyle.muted); if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val label = field("Label, e.g. Home TV"); val endpoint = field("Playlist HTTPS URL"); val epg = field("XMLTV HTTPS URL (optional)"); val secret = field("Source secret (optional)", true)
        listOf(label, endpoint, epg, secret).forEach { form.addView(it) }
        AlertDialog.Builder(activity).setTitle("Add Personal Source").setMessage("Up to two sources per Mobile Device. Source bytes and credentials stay on this Device.").setView(form).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
            Thread {
                val result = runCatching { repository.createSource(label.text.toString().trim(), endpoint.text.toString().trim().ifBlank { null }, epg.text.toString().trim().ifBlank { null }, secret.text.toString().ifBlank { null }, null) }
                activity.runOnUiThread { result.onSuccess { config -> Thread { repository.refreshLocalSource(config) }.start(); onSaved() }.onFailure { error -> AlertDialog.Builder(activity).setTitle("Source was not saved").setMessage(NativeFailure.from(error).message).setPositiveButton("Close", null).show() } }
            }.start()
        }.show()
    }
}
