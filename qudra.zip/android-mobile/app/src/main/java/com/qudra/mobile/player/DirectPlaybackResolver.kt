// @polsia:user-owned — direct approved HTTPS origin, never a QUDRA relay.
package com.qudra.mobile.player

import com.qudra.mobile.data.api.MediaItem
import java.net.URI

fun validateDirectOrigin(url: String, expected: String?): String? { if (expected.isNullOrBlank() || url != expected) return null; val parsed = runCatching { URI(url) }.getOrNull() ?: return null; if (parsed.scheme != "https" || parsed.host.isNullOrBlank() || parsed.userInfo != null || Regex("token|secret|password|api[-_]?key|auth", RegexOption.IGNORE_CASE).containsMatchIn(parsed.rawQuery.orEmpty())) return null; return url }
fun resolveDirectOrigin(item: MediaItem): String? { val origin = item.directOrigin ?: return null; if (!item.available || !origin.mediaOrigin) return null; return validateDirectOrigin(origin.url, item.preferredOrigin) }
fun supportsNativeFormat(item: MediaItem): Boolean = item.directOrigin?.format?.container?.uppercase() in setOf("MP4", "M4V", "M3U8", "HLS", "WEBM", "MP3", "AAC", "OGG")
