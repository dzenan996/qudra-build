// @polsia:user-owned — direct approved media origins, never a QUDRA relay.
package com.qudra.mobile.player

import com.qudra.mobile.data.api.MediaItem
import java.net.URI

private val sensitiveQuery = Regex("token|secret|password|api[-_]?key|auth", RegexOption.IGNORE_CASE)

fun validateOpenOrigin(url: String, expected: String?): String? {
    if (expected.isNullOrBlank() || url != expected) return null
    val parsed = runCatching { URI(url) }.getOrNull() ?: return null
    if (parsed.scheme?.lowercase() != "https" || parsed.host.isNullOrBlank() || parsed.userInfo != null || sensitiveQuery.containsMatchIn(parsed.rawQuery.orEmpty())) return null
    return url
}

fun validatePersonalSourceOrigin(url: String, expected: String?): String? {
    if (expected.isNullOrBlank() || url != expected) return null
    val parsed = runCatching { URI(url) }.getOrNull() ?: return null
    if (parsed.scheme?.lowercase() !in setOf("http", "https") || parsed.host.isNullOrBlank() || parsed.userInfo != null) return null
    return url
}

// Kept for compatibility with existing OPEN call sites/tests.
fun validateDirectOrigin(url: String, expected: String?): String? = validateOpenOrigin(url, expected)

fun resolveDirectOrigin(item: MediaItem): String? {
    val origin = item.directOrigin ?: return null
    if (!item.available || !origin.mediaOrigin) return null
    return validateOpenOrigin(origin.url, item.preferredOrigin)
}

fun supportsNativeFormat(item: MediaItem): Boolean = item.directOrigin?.format?.container?.uppercase() in setOf("MP4", "M4V", "M3U8", "HLS", "WEBM", "MP3", "AAC", "OGG")
