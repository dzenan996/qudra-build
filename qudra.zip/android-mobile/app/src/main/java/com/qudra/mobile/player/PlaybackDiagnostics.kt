// @polsia:user-owned — player-facing diagnostics without URL/token disclosure.
package com.qudra.mobile.player

enum class PlaybackDiagnostic { LOADING, PLAYING, PAUSED, RETRYING, PLAYBACK_FAILURE, UNSUPPORTED_FORMAT, SELECTED_STREAM_UNAVAILABLE, CATCH_UP_UNSUPPORTED, TIMESHIFT_UNSUPPORTED, CAST_UNSUPPORTED, CAST_SESSION_FAILURE }
