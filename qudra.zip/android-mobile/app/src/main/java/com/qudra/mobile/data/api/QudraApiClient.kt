// @polsia:user-owned — HTTPS-only client; media URLs are never fetched here.
package com.qudra.mobile.data.api

import android.util.Base64
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class QudraApiClient(private val baseUrl: String) {
    init { require(baseUrl.startsWith("https://")) { "QUDRA calls require HTTPS" } }
    private data class Response(val status: Int, val body: String)

    private fun request(method: String, path: String, body: JSONObject? = null, session: String? = null): Response {
        val connection = (URL(baseUrl.trimEnd('/') + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method; connectTimeout = 12_000; readTimeout = 20_000; useCaches = false
            setRequestProperty("Accept", "application/json")
            session?.let { setRequestProperty("x-qudra-device-session", it) }
            if (body != null) { doOutput = true; setRequestProperty("Content-Type", "application/json") }
        }
        body?.let { connection.outputStream.use { output -> output.write(it.toString().toByteArray(Charsets.UTF_8)) } }
        val status = connection.responseCode
        val stream = if (status in 200..299) connection.inputStream else connection.errorStream
        val responseBody = stream?.use { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText() }.orEmpty()
        connection.disconnect()
        if (status !in 200..299) {
            val error = runCatching { JSONObject(responseBody).optString("error") }.getOrNull().orEmpty()
            throw QudraApiException(error.ifBlank { "QUDRA request failed ($status)" }, status)
        }
        return Response(status, responseBody)
    }

    fun createBootstrapChallenge(registration: DeviceRegistration) = BootstrapChallenge.parse(JSONObject(request("POST", "/api/qudra/bootstrap/challenges", registration.toJson()).body))
    fun completeBootstrapChallenge(challengeId: String, nonce: String, proof: String) = BootstrapResult.parse(JSONObject(request("POST", "/api/qudra/bootstrap/challenges/$challengeId/complete", JSONObject().apply { put("nonce", nonce); put("proof", proof) }).body))
    fun getManifest(session: String) = runCatching { OpenManifest.parse(JSONObject(request("GET", "/api/qudra/open/manifest", session = session).body)) }.getOrElse { throw QudraApiException("QUDRA OPEN manifest could not be validated", 502) }
    fun renewSession(session: String, deviceId: String) = DeviceSession.parse(JSONObject(request("POST", "/api/qudra/devices/$deviceId/session", session = session).body))
    fun getAccess(session: String, deviceId: String) = AccessView.parse(JSONObject(request("GET", "/api/qudra/devices/$deviceId/access/effective", session = session).body))
    fun getDevice(session: String, deviceId: String) = DeviceView.parse(JSONObject(request("GET", "/api/qudra/devices/$deviceId", session = session).body))

    fun getDiagnostics(session: String, deviceId: String): List<Diagnostic> {
        val items = JSONObject(request("GET", "/api/qudra/devices/$deviceId/diagnostics/current", session = session).body).optJSONArray("items") ?: return emptyList()
        return (0 until items.length()).map { val item = items.getJSONObject(it); Diagnostic(item.optString("code"), item.optString("state", "UNKNOWN"), item.optBoolean("retryable"), item.optString("message"), item.optString("observedAt")) }
    }

    fun getSourceConfigs(session: String, deviceId: String): List<SourceConfig> {
        val items = JSONObject(request("GET", "/api/qudra/devices/$deviceId/source-configs", session = session).body).optJSONArray("items") ?: return emptyList()
        return (0 until items.length()).map { value ->
            val item = items.getJSONObject(value)
            SourceConfig(item.getString("id"), item.getString("label"), item.optStringOrNull("endpointUrl"), item.optStringOrNull("epgUrl"), item.optStringOrNull("sourceTimezone"), item.optIntOrNull("utcOffsetMinutes"), item.optIntOrNull("slot"), item.optBoolean("hasSecret"), item.optInt("configVersion", 1))
        }.take(2)
    }

    fun createSource(session: String, deviceId: String, label: String, endpointUrl: String?, epgUrl: String?, secret: String?, slot: Int?): SourceConfig {
        val body = JSONObject().apply {
            put("label", label); put("sourceType", "personal_source"); put("endpointUrl", endpointUrl); put("epgUrl", epgUrl); put("secret", secret); put("slot", slot)
        }
        val item = JSONObject(request("POST", "/api/qudra/devices/$deviceId/source-configs", body, session).body)
        return SourceConfig(item.getString("id"), item.getString("label"), item.optStringOrNull("endpointUrl"), item.optStringOrNull("epgUrl"), item.optStringOrNull("sourceTimezone"), item.optIntOrNull("utcOffsetMinutes"), item.optIntOrNull("slot"), item.optBoolean("hasSecret"), item.optInt("configVersion", 1))
    }

    fun selectActiveSource(session: String, deviceId: String, sourceConfigId: String?) {
        request("PUT", "/api/qudra/devices/$deviceId/active-source", JSONObject().apply { put("kind", if (sourceConfigId == null) "QUDRA_OPEN" else "PERSONAL_SOURCE"); put("sourceConfigId", sourceConfigId ?: JSONObject.NULL) }, session)
    }

    fun getActiveSource(session: String, deviceId: String): Pair<String, String?> {
        val json = JSONObject(request("GET", "/api/qudra/devices/$deviceId/active-source", session = session).body)
        return json.optString("kind", "QUDRA_OPEN") to json.optStringOrNull("sourceConfigId")
    }

    fun getCapabilities(session: String, deviceId: String): List<SourceSyncStatus> {
        val items = JSONObject(request("GET", "/api/qudra/devices/$deviceId/capabilities", session = session).body).optJSONArray("items") ?: return emptyList()
        return (0 until items.length()).map { value ->
            val item = items.getJSONObject(value); val caps = item.optJSONObject("capabilities") ?: JSONObject()
            SourceSyncStatus(item.optStringOrNull("sourceConfigId"), item.optString("state"), caps.optString("epg"), caps.optString("catchUp"), caps.optString("timeshift"))
        }
    }

    fun reportAggregateSync(session: String, deviceId: String, config: SourceConfig, counts: JSONObject, capabilities: JSONObject) {
        request("POST", "/api/qudra/devices/$deviceId/source-configs/${config.id}/sync", JSONObject().apply { put("configVersion", config.configVersion); put("state", "FRESH"); put("counts", counts); put("capabilities", capabilities); put("idempotencyKey", java.util.UUID.randomUUID().toString()) }, session)
    }
}

data class ProofHeaders(val deviceId: String, val keyVersion: Int, val challenge: String, val signature: String, val requestId: String)
fun urlSafe(bytes: ByteArray): String = Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
private fun JSONObject.optStringOrNull(name: String): String? = if (isNull(name)) null else optString(name).takeIf(String::isNotBlank)
private fun JSONObject.optIntOrNull(name: String): Int? = if (isNull(name) || !has(name)) null else optInt(name)
