// @polsia:user-owned — Mobile orchestration; domain authority remains in REST handlers.
package com.qudra.mobile.data

import android.content.Context
import android.os.Build
import com.qudra.mobile.BuildConfig
import com.qudra.mobile.data.api.*
import com.qudra.mobile.local.source.SourceConfigStore
import com.qudra.mobile.local.source.CatalogueStore
import com.qudra.mobile.local.source.EpgStore
import com.qudra.mobile.local.source.SourceDownloadClient
import com.qudra.mobile.local.source.SourceImportCoordinator
import com.qudra.mobile.local.source.LocalMediaKind
import com.qudra.mobile.local.source.XtreamCredentials
import com.qudra.mobile.local.source.XtreamApiClient
import com.qudra.mobile.local.source.PlaylistEntry
import com.qudra.mobile.security.*

data class PendingBootstrap(val challengeId: String, val deviceId: String, val nonce: String, val keyVersion: Int, val expiresAt: String, val qr: PairingQr)
data class HomeData(val manifest: OpenManifest, val access: AccessView, val device: DeviceView?, val diagnostics: List<Diagnostic>, val sourceConfigs: List<SourceConfig>, val capabilities: List<SourceSyncStatus>, val fromCache: Boolean, val activeSourceId: String? = null)

class QudraRepository(context: Context) {
    private val appContext = context.applicationContext
    private val identity = DeviceIdentityStore(context)
    private val sessions = DeviceSessionStore(context)
    private val cache = OpenManifestCache(context)
    private val sourceStore = SourceConfigStore(context)
    private val sourceSecrets = SourceSecretStore(context)
    private val api = QudraApiClient(BuildConfig.QUDRA_API_BASE_URL)

    fun beginBootstrap(): PendingBootstrap {
        val registration = DeviceRegistration(identity.publicDeviceId, identity.platform, identity.publicKeyPem, BuildConfig.VERSION_NAME, Build.VERSION.SDK_INT, identity.deviceModel)
        val challenge = api.createBootstrapChallenge(registration)
        require(challenge.qr.id == challenge.id && challenge.qr.representation == challenge.id) { "Bootstrap QR was not opaque" }
        return PendingBootstrap(challenge.id, challenge.deviceId, challenge.nonce, challenge.keyVersion, challenge.expiresAt, challenge.qr)
    }
    fun completeBootstrap(pending: PendingBootstrap) { val proof = identity.sign(bootstrapCanonicalPayload(pending.challengeId, pending.nonce, pending.deviceId, pending.keyVersion)); val result = api.completeBootstrapChallenge(pending.challengeId, pending.nonce, proof); require(result.state == "PAIRED" && result.deviceId == pending.deviceId); sessions.write(StoredDeviceSession(result.deviceId, pending.keyVersion, result.sessionToken, result.sessionExpiresAt)) }

    fun loadHome(): HomeData {
        val session = sessions.read() ?: throw QudraApiException("Mobile Device bootstrap is required", 403)
        return try {
            val renewed = api.renewSession(session.token, session.deviceId)
            val current = SessionRenewal.apply(session, RenewedSession(renewed.deviceId, renewed.keyVersion, renewed.expiresAt, renewed.sessionToken))
            sessions.write(current)
            val manifest = api.getManifest(current.token); require(manifest.isSafeOpen()) { "QUDRA OPEN contract invariants failed" }; cache.save(manifest)
            val configs = api.getSourceConfigs(current.token, current.deviceId); sourceStore.save(configs)
            val active = api.getActiveSource(current.token, current.deviceId); val activeId = active.second?.takeIf { id -> configs.any { it.id == id } }
            if (active.first == "QUDRA_OPEN" || activeId == null && active.second != null) sourceStore.fallBackToOpen() else sourceStore.setActive(activeId)
            HomeData(manifest, api.getAccess(current.token, current.deviceId), api.getDevice(current.token, current.deviceId), api.getDiagnostics(current.token, current.deviceId), configs, api.getCapabilities(current.token, current.deviceId), false, activeId)
        } catch (error: Throwable) {
            if (error is QudraApiException && (error.statusCode == 401 || error.statusCode == 403 || error.statusCode == 409)) { sessions.clear(); throw error }
            if (error.message?.contains("key version", true) == true) { sessions.clear(); throw QudraApiException("Device key version mismatch", 409) }
            val manifest = cache.read()?.takeIf(OpenManifest::isSafeOpen) ?: throw error
            HomeData(manifest, AccessView(session.deviceId, "offline", false, false, false, null), null, emptyList(), sourceStore.read(), emptyList(), true, sourceStore.activeId())
        }
    }
    fun currentSession() = sessions.read()
    fun clearSession() = sessions.clear()
    fun activeSource() = sourceStore.active()
    fun setActiveSource(config: SourceConfig?) { sourceStore.setActive(config?.id); if (config == null) sourceStore.fallBackToOpen() }
    fun createSource(
        label: String,
        endpointUrl: String?,
        epgUrl: String?,
        secret: String?,
        slot: Int?,
        xtreamUsername: String? = null,
        xtreamPassword: String? = null,
        useXtream: Boolean = false,
    ): SourceConfig {
        val session = sessions.read() ?: throw QudraApiException("Mobile Device bootstrap is required", 403)
        require(sourceStore.read().size < 2) { "A Mobile Device may have at most two Personal Sources" }
        require(label.isNotBlank()) { "Source label is required" }

        // A pasted credential-bearing get.php URL is normalized entirely on-device.
        // For Xtream, even the server base stays local: QUDRA Cloud receives only non-secret slot/label metadata.
        // This avoids leaking source topology and keeps HTTP/HTTPS transport policy device-local.
        val xtream = if (useXtream) XtreamCredentials.fromInput(endpointUrl, xtreamUsername, xtreamPassword) else null
        if (useXtream) {
            require(xtream != null) { "Xtream requires a valid HTTP/HTTPS server and username/password" }
            XtreamApiClient(SourceDownloadClient(5L * 1024L * 1024L)).requireAuthenticated(xtream)
        }
        val cloudEndpoint = if (xtream == null) endpointUrl else null
        val cloudEpg = if (xtream == null) epgUrl else null
        val cloudSecret = if (xtream == null) secret else null
        val config = api.createSource(session.token, session.deviceId, label, cloudEndpoint, cloudEpg, cloudSecret, slot)

        when {
            xtream != null -> sourceSecrets.put(config.id, xtream.serialize())
            !secret.isNullOrBlank() -> sourceSecrets.put(config.id, secret)
        }
        sourceStore.save((sourceStore.read() + config).distinctBy { it.id }.take(2))
        return config
    }
    fun activateSource(config: SourceConfig?) {
        val session = sessions.read() ?: throw QudraApiException("Mobile Device bootstrap is required", 403)
        api.selectActiveSource(session.token, session.deviceId, config?.id)
        setActiveSource(config)
    }
    fun refreshLocalSource(config: SourceConfig) {
        val storedSecret = sourceSecrets.get(config.id)
        val xtream = XtreamCredentials.deserialize(storedSecret)
        val coordinator = SourceImportCoordinator(SourceDownloadClient(), CatalogueStore(appContext), EpgStore(appContext))
        if (xtream != null) {
            coordinator.importXtreamWithRetry(
                sourceId = config.id,
                credentials = xtream,
                timezone = config.sourceTimezone,
                offsetMinutes = config.utcOffsetMinutes,
            )
        } else {
            val endpoint = config.endpointUrl ?: throw IllegalArgumentException("Source has no playlist URL")
            coordinator.importWithRetry(config.id, endpoint, config.epgUrl, config.sourceTimezone, config.utcOffsetMinutes, storedSecret)
        }
    }

    fun localSeriesEpisodes(series: PlaylistEntry): List<PlaylistEntry> {
        require(series.kind == LocalMediaKind.SERIES && series.seriesKey != null) { "Series selection is invalid" }
        val active = sourceStore.active() ?: throw IllegalStateException("No active Personal Source")
        val xtream = XtreamCredentials.deserialize(sourceSecrets.get(active.id))
            ?: throw IllegalStateException("This series is not backed by an Xtream source")
        return XtreamApiClient(SourceDownloadClient(50L * 1024L * 1024L)).fetchSeriesEpisodes(
            sourceId = active.id,
            credentials = xtream,
            seriesId = series.seriesKey,
            seriesTitle = series.title,
        )
    }
    fun localCatalogue(kind: LocalMediaKind, category: String? = null, offset: Int = 0, limit: Int = 200) = CatalogueStore(appContext).query(kind, category, offset, limit, sourceStore.activeId())
    fun localCategories(kind: LocalMediaKind) = CatalogueStore(appContext).categories(kind, sourceStore.activeId())
    fun localSourceConfigs() = sourceStore.read()
    fun apiClient() = api
}
