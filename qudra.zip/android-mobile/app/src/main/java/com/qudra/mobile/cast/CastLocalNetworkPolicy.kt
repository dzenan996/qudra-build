// @polsia:user-owned — evidence-based Cast transport guard; Cast itself owns discovery.
// Google Cast exposes a session, not a reliable app-level same-SSID Boolean. This policy
// verifies only the strongest observable local evidence and never claims more than that.
package com.qudra.mobile.cast

import android.net.ConnectivityManager
import android.net.NetworkCapabilities

data class CastLocalNetworkState(
    val hasLocalTransport: Boolean,
    val hasCastSession: Boolean,
)

object CastLocalNetworkPolicy {
    fun allows(state: CastLocalNetworkState): Boolean = state.hasLocalTransport && state.hasCastSession

    fun inspect(connectivity: ConnectivityManager, hasCastSession: Boolean): CastLocalNetworkState {
        val network = connectivity.activeNetwork ?: return CastLocalNetworkState(false, hasCastSession)
        val capabilities = connectivity.getNetworkCapabilities(network)
            ?: return CastLocalNetworkState(false, hasCastSession)
        val localTransport = capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
        return CastLocalNetworkState(localTransport, hasCastSession)
    }
}
