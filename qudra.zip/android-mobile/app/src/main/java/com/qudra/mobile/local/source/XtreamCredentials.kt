// Device-local Xtream credentials. Never put username/password into cloud endpoint metadata.
package com.qudra.mobile.local.source

import org.json.JSONObject
import java.net.URI
import java.net.URLDecoder
import java.net.URLEncoder

/** Serialized only through SourceSecretStore, backed by Android Keystore AES/GCM. */
data class XtreamCredentials(
    val baseUrl: String,
    val username: String,
    val password: String,
    val playlistType: String = "m3u_plus",
    val output: String = "ts",
) {
    fun playlistUrl(): String =
        "${baseUrl.trimEnd('/')}/get.php?username=${enc(username)}&password=${enc(password)}&type=${enc(playlistType)}&output=${enc(output)}"

    fun epgUrl(): String = "${baseUrl.trimEnd('/')}/xmltv.php?username=${enc(username)}&password=${enc(password)}"

    fun playerApiUrl(action: String? = null, extra: Map<String, String> = emptyMap()): String {
        val params = linkedMapOf("username" to username, "password" to password)
        if (!action.isNullOrBlank()) params["action"] = action
        params.putAll(extra)
        return "${baseUrl.trimEnd('/')}/player_api.php?" + params.entries.joinToString("&") { "${enc(it.key)}=${enc(it.value)}" }
    }

    fun liveStreamUrl(streamId: String): String = "${baseUrl.trimEnd('/')}/live/${path(username)}/${path(password)}/${path(streamId)}.${safeExt(output, "ts")}" 
    fun vodStreamUrl(streamId: String, extension: String?): String = "${baseUrl.trimEnd('/')}/movie/${path(username)}/${path(password)}/${path(streamId)}.${safeExt(extension, "mp4")}" 
    fun seriesStreamUrl(episodeId: String, extension: String?): String = "${baseUrl.trimEnd('/')}/series/${path(username)}/${path(password)}/${path(episodeId)}.${safeExt(extension, "mp4")}" 

    fun serialize(): String = JSONObject().apply {
        put("kind", KIND); put("baseUrl", baseUrl); put("username", username); put("password", password); put("playlistType", playlistType); put("output", output)
    }.toString()

    companion object {
        private const val KIND = "xtream_v1"

        fun fromInput(endpoint: String?, usernameInput: String?, passwordInput: String?): XtreamCredentials? {
            val raw = endpoint?.trim().orEmpty()
            if (raw.isBlank()) return null
            val uri = runCatching { URI(raw) }.getOrNull() ?: return null
            if (uri.scheme?.lowercase() !in setOf("http", "https") || uri.host.isNullOrBlank()) return null

            val explicitUser = usernameInput?.trim().orEmpty()
            val explicitPass = passwordInput.orEmpty()
            if (explicitUser.isNotBlank() || explicitPass.isNotBlank()) {
                require(explicitUser.isNotBlank() && explicitPass.isNotBlank()) { "Xtream username and password must both be provided" }
                return XtreamCredentials(baseUrl(uri), explicitUser, explicitPass)
            }

            val query = queryMap(uri.rawQuery)
            val user = query["username"].orEmpty(); val pass = query["password"].orEmpty()
            if (user.isBlank() || pass.isBlank()) return null
            return XtreamCredentials(
                baseUrl = baseUrl(uri), username = user, password = pass,
                playlistType = query["type"].takeUnless { it.isNullOrBlank() } ?: "m3u_plus",
                output = query["output"].takeUnless { it.isNullOrBlank() } ?: "ts",
            )
        }

        fun deserialize(value: String?): XtreamCredentials? = runCatching {
            if (value.isNullOrBlank()) return null
            val json = JSONObject(value); if (json.optString("kind") != KIND) return null
            XtreamCredentials(json.getString("baseUrl"), json.getString("username"), json.getString("password"), json.optString("playlistType", "m3u_plus"), json.optString("output", "ts"))
        }.getOrNull()

        private fun baseUrl(uri: URI): String {
            val defaultPort = (uri.scheme.equals("http", true) && uri.port == 80) || (uri.scheme.equals("https", true) && uri.port == 443)
            val authority = if (uri.port >= 0 && !defaultPort) "${uri.host}:${uri.port}" else uri.host
            val path = uri.path.orEmpty()
            val prefix = when {
                path.isBlank() || path == "/" -> ""
                path.endsWith("/get.php", true) || path.endsWith("/player_api.php", true) || path.endsWith("/xmltv.php", true) -> path.substringBeforeLast('/').trimEnd('/')
                else -> path.trimEnd('/')
            }
            return "${uri.scheme.lowercase()}://$authority$prefix"
        }

        private fun queryMap(raw: String?): Map<String, String> = raw.orEmpty().split('&').mapNotNull { pair ->
            if (pair.isBlank()) return@mapNotNull null
            dec(pair.substringBefore('=')).lowercase() to dec(pair.substringAfter('=', ""))
        }.toMap()

        private fun dec(value: String) = URLDecoder.decode(value, Charsets.UTF_8.name())
        private fun enc(value: String) = URLEncoder.encode(value, Charsets.UTF_8.name())
        private fun path(value: String) = enc(value).replace("+", "%20")
        private fun safeExt(value: String?, fallback: String): String = value.orEmpty().lowercase().filter { it.isLetterOrDigit() }.ifBlank { fallback }
    }
}
