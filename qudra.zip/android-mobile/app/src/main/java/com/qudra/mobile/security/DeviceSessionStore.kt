// @polsia:user-owned — encrypted, expiring Device-bound session; no token logs.
package com.qudra.mobile.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.time.Instant
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class StoredDeviceSession(val deviceId: String, val keyVersion: Int, val token: String, val expiresAt: String)

class DeviceSessionStore(context: Context) {
    private val preferences = context.getSharedPreferences("qudra_mobile_session", Context.MODE_PRIVATE)
    private val alias = "qudra_mobile_session_aes_v1"
    private val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    init { if (!keyStore.containsAlias(alias)) KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply { init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build()); generateKey() } }

    fun read(): StoredDeviceSession? {
        val encrypted = preferences.getString("token", null) ?: return null
        val session = runCatching { StoredDeviceSession(preferences.getString("device_id", null) ?: return null, preferences.getInt("key_version", 0), decrypt(encrypted), preferences.getString("expires_at", null) ?: return null) }.getOrNull() ?: run { clear(); return null }
        return if (SessionExpiry.isUsable(session.expiresAt, Instant.now())) session else run { clear(); null }
    }
    fun write(value: StoredDeviceSession) { require(value.deviceId.isNotBlank() && value.keyVersion > 0 && value.token.isNotBlank() && SessionExpiry.isUsable(value.expiresAt, Instant.now())); preferences.edit().putString("device_id", value.deviceId).putInt("key_version", value.keyVersion).putString("token", encrypt(value.token)).putString("expires_at", value.expiresAt).commit() }
    fun clear() = preferences.edit().clear().apply()
    private fun key(): SecretKey = keyStore.getKey(alias, null) as SecretKey
    private fun encrypt(value: String): String { val cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, key()); return Base64.encodeToString(cipher.iv + cipher.doFinal(value.toByteArray()), Base64.NO_WRAP) }
    private fun decrypt(value: String): String { val bytes = Base64.decode(value, Base64.NO_WRAP); require(bytes.size > 12); val cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, bytes.copyOfRange(0, 12))); return cipher.doFinal(bytes.copyOfRange(12, bytes.size)).toString(Charsets.UTF_8) }
}

object SessionExpiry { fun isUsable(expiresAt: String, now: Instant) = runCatching { Instant.parse(expiresAt).isAfter(now) }.getOrDefault(false) }
