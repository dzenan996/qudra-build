// @polsia:user-owned — bounded M3U/M3U8 parser with source-local series metadata.
package com.qudra.mobile.local.source

import java.io.BufferedReader
import java.io.Reader
import java.util.Locale

class M3uParser(private val maxEntries: Int = 100_000) {
    fun parse(reader: Reader, cancelled: () -> Boolean = { false }): List<PlaylistEntry> {
        val result = ArrayList<PlaylistEntry>()
        var pending: Map<String, String> = emptyMap()
        BufferedReader(reader).useLines { lines ->
            for (line in lines) {
                if (cancelled()) throw InterruptedException("M3U import cancelled")
                val value = line.trim()
                if (value.startsWith("#EXTINF", true)) {
                    val attrs = Regex("([A-Za-z0-9_-]+)=\\\"([^\\\"]*)\\\"").findAll(value).associate { it.groupValues[1].lowercase(Locale.ROOT) to it.groupValues[2] }
                    pending = attrs + ("title" to value.substringAfterLast(',', "Untitled").trim().ifBlank { "Untitled" })
                } else if (value.isNotEmpty() && !value.startsWith("#") && value.startsWith("https://", true)) {
                    if (result.size >= maxEntries) throw IllegalArgumentException("Playlist exceeds the local safety bound")
                    val group = pending["group-title"]
                    val category = group ?: pending["category"]
                    val kind = when {
                        pending["radio"].isTruthy() || category?.contains("radio", true) == true -> LocalMediaKind.RADIO
                        category?.contains("movie", true) == true -> LocalMediaKind.MOVIE
                        category?.contains("series", true) == true || pending["episode-num"] != null -> LocalMediaKind.SERIES
                        else -> LocalMediaKind.LIVE_TV
                    }
                    val title = pending["title"] ?: value.substringAfterLast('/').substringBefore('?').ifBlank { "Untitled" }
                    val stable = listOf(pending["tvg-id"], value, title).joinToString("|")
                    val season = pending["season"]?.toIntOrNull()
                    val episode = pending["episode-num"]?.substringBefore('-')?.toIntOrNull()
                    result += PlaylistEntry("entry-${stable.hashCode().toUInt().toString(16)}", title, value, kind, group, pending["tvg-id"], pending["catchup"].isTruthy(), pending["timeshift"].isTruthy(), category, pending["tvg-name"], season, episode, pending["series-id"] ?: pending["tvg-id"])
                    pending = emptyMap()
                } else if (value.isNotEmpty() && !value.startsWith("#")) pending = emptyMap()
            }
        }
        return result
    }

    private fun String?.isTruthy() = !isNullOrBlank() && lowercase(Locale.ROOT) !in setOf("none", "false", "0", "no")
}
