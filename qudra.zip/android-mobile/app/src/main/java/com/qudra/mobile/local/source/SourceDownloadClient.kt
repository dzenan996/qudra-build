// @polsia:user-owned — direct HTTPS source download with response bounds.
package com.qudra.mobile.local.source

import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

data class SourceResponse(val stream: InputStream, val contentLength: Long?, val contentType: String?)
class SourceDownloadClient(private val maxBytes: Long = 50L * 1024L * 1024L) {
    fun open(url: String, sourceSecret: String? = null): SourceResponse {
        require(isSafeUrl(url)) { "Personal Source requires a credential-free HTTPS URL" }
        var current = url
        repeat(3) {
            val connection = (URL(current).openConnection() as HttpURLConnection).apply { connectTimeout = 15_000; readTimeout = 30_000; instanceFollowRedirects = false; requestMethod = "GET"; setRequestProperty("Accept", "application/x-mpegURL, application/xml, text/xml, */*"); sourceSecret?.takeIf(String::isNotBlank)?.let { setRequestProperty("Authorization", "Bearer $it") } }
            when (val status = connection.responseCode) {
                in 200..299 -> { val length = connection.contentLengthLong.takeIf { it >= 0 }; require(length == null || length <= maxBytes) { connection.disconnect(); "Source response exceeds local safety bound" }; return SourceResponse(BoundedInputStream(connection.inputStream, maxBytes) { connection.disconnect() }, length, connection.contentType) }
                in 300..399 -> { val next = connection.getHeaderField("Location"); connection.disconnect(); require(isSafeUrl(next.orEmpty())) { "Source redirect is not a safe HTTPS origin" }; current = next!! }
                else -> { connection.disconnect(); throw IllegalStateException("Source request was rejected") }
            }
        }
        throw IllegalStateException("Source redirect chain is too long")
    }
    private fun isSafeUrl(value: String): Boolean = runCatching { val uri = URI(value); uri.scheme == "https" && !uri.host.isNullOrBlank() && uri.userInfo == null && !Regex("token|secret|password|api[-_]?key|auth", RegexOption.IGNORE_CASE).containsMatchIn(uri.rawQuery.orEmpty()) }.getOrDefault(false)
}
private class BoundedInputStream(private val source: InputStream, private val maxBytes: Long, private val closeHook: () -> Unit) : java.io.FilterInputStream(source) { private var total = 0L; override fun read(buffer: ByteArray, offset: Int, length: Int): Int { val count = super.read(buffer, offset, length); if (count > 0) { total += count; if (total > maxBytes) throw IllegalArgumentException("Source response exceeds local safety bound") }; return count }; override fun close() { runCatching { super.close() }; closeHook() } }
