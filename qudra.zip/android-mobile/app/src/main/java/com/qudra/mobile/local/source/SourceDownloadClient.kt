// @polsia:user-owned — direct HTTP/HTTPS Personal Source download with response bounds.
package com.qudra.mobile.local.source

import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

data class SourceResponse(val stream: InputStream, val contentLength: Long?, val contentType: String?)

class SourceDownloadClient(private val maxBytes: Long = 50L * 1024L * 1024L) {
    fun open(url: String, sourceSecret: String? = null, allowCredentialQuery: Boolean = false): SourceResponse {
        require(isSafeUrl(url, allowCredentialQuery)) {
            if (allowCredentialQuery) "Xtream source requires a valid HTTP or HTTPS URL" else "Personal Source requires a credential-free HTTP or HTTPS URL"
        }
        var current = url
        val credentialOrigin = if (allowCredentialQuery) URI(url) else null
        repeat(3) {
            val connection = (URL(current).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 30_000
                instanceFollowRedirects = false
                requestMethod = "GET"
                setRequestProperty("Accept", "application/x-mpegURL, application/vnd.apple.mpegurl, application/xml, text/xml, application/json, */*")
                sourceSecret?.takeIf(String::isNotBlank)?.let { setRequestProperty("Authorization", "Bearer $it") }
            }
            when (val status = connection.responseCode) {
                in 200..299 -> {
                    val length = connection.contentLengthLong.takeIf { it >= 0 }
                    require(length == null || length <= maxBytes) { connection.disconnect(); "Source response exceeds local safety bound" }
                    return SourceResponse(BoundedInputStream(connection.inputStream, maxBytes) { connection.disconnect() }, length, connection.contentType)
                }
                in 300..399 -> {
                    val next = connection.getHeaderField("Location")
                    connection.disconnect()
                    require(isSafeUrl(next.orEmpty(), allowCredentialQuery)) { "Source redirect is not a safe HTTP/HTTPS origin" }
                    if (credentialOrigin != null) {
                        val redirected = URI(next!!)
                        require(sameAuthority(credentialOrigin, redirected)) { "Credential-bearing source redirect changed origin" }
                    }
                    current = next!!
                }
                else -> {
                    connection.disconnect()
                    throw IllegalStateException("Source request was rejected ($status)")
                }
            }
        }
        throw IllegalStateException("Source redirect chain is too long")
    }

    private fun isSafeUrl(value: String, allowCredentialQuery: Boolean): Boolean = runCatching {
        val uri = URI(value)
        uri.scheme?.lowercase() in setOf("http", "https") &&
            !uri.host.isNullOrBlank() &&
            uri.userInfo == null &&
            (allowCredentialQuery || !Regex("token|secret|password|api[-_]?key|auth", RegexOption.IGNORE_CASE).containsMatchIn(uri.rawQuery.orEmpty()))
    }.getOrDefault(false)

    private fun sameAuthority(a: URI, b: URI): Boolean {
        fun effectivePort(uri: URI) = when {
            uri.port >= 0 -> uri.port
            uri.scheme.equals("https", true) -> 443
            else -> 80
        }
        return a.host.equals(b.host, true) && effectivePort(a) == effectivePort(b)
    }
}

private class BoundedInputStream(
    private val source: InputStream,
    private val maxBytes: Long,
    private val closeHook: () -> Unit,
) : java.io.FilterInputStream(source) {
    private var total = 0L
    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        val count = super.read(buffer, offset, length)
        if (count > 0) {
            total += count
            if (total > maxBytes) throw IllegalArgumentException("Source response exceeds local safety bound")
        }
        return count
    }
    override fun close() { runCatching { super.close() }; closeHook() }
}
