// @polsia:user-owned — honest Cast capability gate; no credential-bearing metadata.
package com.qudra.mobile.cast

import com.qudra.mobile.data.api.MediaItem
import com.qudra.mobile.local.source.PlaylistEntry
import java.net.URI

data class CastDecision(val supported: Boolean, val reason: String)
class CastCapabilityDetector {
    fun assess(item: MediaItem): CastDecision {
        val origin = item.directOrigin ?: return CastDecision(false, "This source cannot be Cast.")
        val uri = runCatching { URI(origin.url) }.getOrNull() ?: return CastDecision(false, "This source cannot be Cast.")
        val container = origin.format.container.uppercase()
        if (!item.available || !origin.mediaOrigin || !isCastSafe(uri, container)) return CastDecision(false, "This source cannot be Cast.")
        if (item.capabilities.castCompatibilityKnown.not() && item.sourceConfigId != null) return CastDecision(false, "This source cannot be Cast.")
        if (item.capabilities.catchUp || item.capabilities.timeshift) return CastDecision(false, "This source cannot be Cast.")
        return CastDecision(true, "Direct source origin is receiver-compatible; local transport is checked when the Cast session loads.")
    }

    fun assess(entry: PlaylistEntry): CastDecision {
        val uri = runCatching { URI(entry.uri) }.getOrNull() ?: return CastDecision(false, "This source cannot be Cast.")
        val container = entry.uri.substringBefore('?').substringBefore('#').substringAfterLast('.').uppercase()
        if (!isCastSafe(uri, container) || entry.catchUpSupported || entry.timeshiftSupported) return CastDecision(false, "This source cannot be Cast.")
        return CastDecision(true, "Direct Personal Source origin is receiver-compatible; credentials and source headers are not sent.")
    }

    fun mimeType(entry: PlaylistEntry): String = when (entry.uri.substringBefore('?').substringBefore('#').substringAfterLast('.').lowercase()) {
        "m3u8" -> "application/x-mpegURL"
        "mp3" -> "audio/mpeg"
        "aac" -> "audio/aac"
        "m4v" -> "video/x-m4v"
        else -> "video/mp4"
    }

    private fun isCastSafe(uri: URI, container: String): Boolean = uri.scheme == "https" &&
        !uri.host.isNullOrBlank() &&
        uri.userInfo == null &&
        !Regex("token|secret|password|api[-_]?key|auth", RegexOption.IGNORE_CASE).containsMatchIn(uri.rawQuery.orEmpty()) &&
        container in setOf("MP4", "M4V", "M3U8", "HLS", "MP3", "AAC")
}
