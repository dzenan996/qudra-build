// @polsia:user-owned — Cast receives only a direct, receiver-compatible origin.
package com.qudra.mobile.cast

import com.qudra.mobile.data.api.MediaItem

class CastMediaResolver(private val detector: CastCapabilityDetector = CastCapabilityDetector()) {
    fun resolve(item: MediaItem): String? = item.directOrigin?.url?.takeIf { detector.assess(item).supported }
}
