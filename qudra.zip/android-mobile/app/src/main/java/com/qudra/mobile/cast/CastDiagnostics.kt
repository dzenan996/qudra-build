// @polsia:user-owned — Cast failure copy is explicit and redacted.
package com.qudra.mobile.cast

enum class CastDiagnostic { UNSUPPORTED_SOURCE, INCOMPATIBLE_CODEC, AUTHENTICATION_REQUIRED, RECEIVER_UNREACHABLE, SESSION_FAILURE }
