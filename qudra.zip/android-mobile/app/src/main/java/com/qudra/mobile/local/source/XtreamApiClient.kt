// Device-local Xtream Codes API client. Credentials never leave the user's Device for QUDRA Cloud.
package com.qudra.mobile.local.source

import android.util.JsonReader
import android.util.JsonToken
import org.json.JSONObject
import java.io.InputStreamReader
import java.net.URI
import java.util.Locale

private data class XtreamCategory(val id: String, val name: String)

data class XtreamProbe(val authenticated: Boolean, val status: String?, val message: String?)

/**
 * Reads Xtream responses as streams so large VOD/series catalogues do not have to be held as a raw String.
 * The architecture follows the common Xtream player_api.php contract while keeping credentials Device-local.
 */
class XtreamApiClient(
    private val downloader: SourceDownloadClient = SourceDownloadClient(150L * 1024L * 1024L),
    private val maxEntries: Int = 150_000,
) {
    fun probe(credentials: XtreamCredentials): XtreamProbe {
        val response = try {
            downloader.open(credentials.playerApiUrl(), allowCredentialQuery = true)
        } catch (error: Throwable) {
            throw IllegalStateException("Xtream server is unavailable", error)
        }
        val json = response.stream.use { it.reader(Charsets.UTF_8).readText() }
        val root = runCatching { JSONObject(json) }.getOrElse {
            throw IllegalArgumentException("Xtream server returned an invalid login response", it)
        }
        val user = root.optJSONObject("user_info")
            ?: throw IllegalArgumentException("Xtream server returned an invalid login response")
        val authValue = user.opt("auth")?.toString()?.lowercase(Locale.ROOT)
        val status = user.optString("status").takeIf(String::isNotBlank)
        val message = user.optString("message").takeIf(String::isNotBlank)
        val authenticated = authValue in setOf("1", "true") && !status.equals("disabled", true) && !status.equals("banned", true)
        return XtreamProbe(authenticated, status, message)
    }

    fun requireAuthenticated(credentials: XtreamCredentials) {
        val probe = probe(credentials)
        if (!probe.authenticated) throw SecurityException("Xtream username or password was rejected by the source server")
    }

    fun fetchCatalogue(sourceId: String, credentials: XtreamCredentials, cancelled: () -> Boolean = { false }): List<PlaylistEntry> {
        requireAuthenticated(credentials)
        val result = ArrayList<PlaylistEntry>()

        val liveCategories = fetchCategories(credentials, "get_live_categories", cancelled)
        readArray(credentials.playerApiUrl("get_live_streams"), cancelled) { reader ->
            val fields = readObject(reader, setOf("stream_id", "name", "stream_icon", "epg_channel_id", "category_id", "tv_archive", "tv_archive_duration", "direct_source", "stream_type"))
            val id = fields["stream_id"].orEmpty(); if (id.isBlank()) return@readArray
            val title = fields["name"].orEmpty().ifBlank { "Live $id" }
            val category = liveCategories[fields["category_id"]]?.name
            val direct = fields["direct_source"].takeIf(::isHttpUrl)
            val uri = direct ?: credentials.liveStreamUrl(id)
            val isRadio = fields["stream_type"]?.contains("radio", true) == true || category?.contains("radio", true) == true
            val catchUp = fields["tv_archive"].isTruthy() || (fields["tv_archive_duration"]?.toIntOrNull() ?: 0) > 0
            result += PlaylistEntry(
                id = "$sourceId::xt-live:$id",
                title = title,
                uri = uri,
                kind = if (isRadio) LocalMediaKind.RADIO else LocalMediaKind.LIVE_TV,
                group = category,
                tvgId = fields["epg_channel_id"],
                catchUpSupported = catchUp,
                timeshiftSupported = false,
                originalCategory = category,
                tvgName = title,
                sourceId = sourceId,
            )
            checkLimit(result)
        }

        val vodCategories = fetchCategories(credentials, "get_vod_categories", cancelled)
        readArray(credentials.playerApiUrl("get_vod_streams"), cancelled) { reader ->
            val fields = readObject(reader, setOf("stream_id", "name", "stream_icon", "category_id", "container_extension", "direct_source"))
            val id = fields["stream_id"].orEmpty(); if (id.isBlank()) return@readArray
            val title = fields["name"].orEmpty().ifBlank { "Movie $id" }
            val category = vodCategories[fields["category_id"]]?.name
            val direct = fields["direct_source"].takeIf(::isHttpUrl)
            val uri = direct ?: credentials.vodStreamUrl(id, fields["container_extension"])
            result += PlaylistEntry(
                id = "$sourceId::xt-vod:$id", title = title, uri = uri, kind = LocalMediaKind.MOVIE,
                group = category, tvgId = null, catchUpSupported = false, timeshiftSupported = false,
                originalCategory = category, tvgName = title, sourceId = sourceId,
            )
            checkLimit(result)
        }

        val seriesCategories = fetchCategories(credentials, "get_series_categories", cancelled)
        readArray(credentials.playerApiUrl("get_series"), cancelled) { reader ->
            val fields = readObject(reader, setOf("series_id", "name", "category_id", "cover"))
            val id = fields["series_id"].orEmpty(); if (id.isBlank()) return@readArray
            val title = fields["name"].orEmpty().ifBlank { "Series $id" }
            val category = seriesCategories[fields["category_id"]]?.name
            result += PlaylistEntry(
                id = "$sourceId::xt-series:$id", title = title, uri = "qudra-series://$id", kind = LocalMediaKind.SERIES,
                group = category, tvgId = null, catchUpSupported = false, timeshiftSupported = false,
                originalCategory = category, tvgName = title, seriesKey = id, sourceId = sourceId,
            )
            checkLimit(result)
        }

        return result
    }

    fun fetchSeriesEpisodes(sourceId: String, credentials: XtreamCredentials, seriesId: String, seriesTitle: String, cancelled: () -> Boolean = { false }): List<PlaylistEntry> {
        val result = ArrayList<PlaylistEntry>()
        val response = downloader.open(credentials.playerApiUrl("get_series_info", mapOf("series_id" to seriesId)), allowCredentialQuery = true)
        response.stream.use { stream ->
            JsonReader(InputStreamReader(stream, Charsets.UTF_8)).use { reader ->
                reader.isLenient = true
                if (reader.peek() != JsonToken.BEGIN_OBJECT) throw IllegalArgumentException("Xtream series response was invalid")
                reader.beginObject()
                while (reader.hasNext()) {
                    if (cancelled()) throw InterruptedException("Xtream series import cancelled")
                    when (reader.nextName()) {
                        "episodes" -> {
                            if (reader.peek() != JsonToken.BEGIN_OBJECT) { reader.skipValue(); continue }
                            reader.beginObject()
                            while (reader.hasNext()) {
                                val seasonKey = reader.nextName()
                                val seasonFromKey = seasonKey.toIntOrNull()
                                if (reader.peek() != JsonToken.BEGIN_ARRAY) { reader.skipValue(); continue }
                                reader.beginArray()
                                while (reader.hasNext()) {
                                    val fields = readObject(reader, setOf("id", "episode_num", "title", "container_extension", "season"))
                                    val id = fields["id"].orEmpty(); if (id.isBlank()) continue
                                    val episode = fields["episode_num"]?.toIntOrNull()
                                    val season = fields["season"]?.toIntOrNull() ?: seasonFromKey
                                    val title = fields["title"].orEmpty().ifBlank {
                                        listOfNotNull(season?.let { "S$it" }, episode?.let { "E$it" }).joinToString(" ").ifBlank { "Episode $id" }
                                    }
                                    result += PlaylistEntry(
                                        id = "$sourceId::xt-episode:$id",
                                        title = title,
                                        uri = credentials.seriesStreamUrl(id, fields["container_extension"]),
                                        kind = LocalMediaKind.SERIES,
                                        group = seriesTitle,
                                        tvgId = null,
                                        catchUpSupported = false,
                                        timeshiftSupported = false,
                                        originalCategory = seriesTitle,
                                        tvgName = title,
                                        seasonNumber = season,
                                        episodeNumber = episode,
                                        seriesKey = seriesId,
                                        sourceId = sourceId,
                                    )
                                    checkLimit(result)
                                }
                                reader.endArray()
                            }
                            reader.endObject()
                        }
                        else -> reader.skipValue()
                    }
                }
                reader.endObject()
            }
        }
        return result.sortedWith(compareBy({ it.seasonNumber ?: Int.MAX_VALUE }, { it.episodeNumber ?: Int.MAX_VALUE }, { it.title }))
    }

    private fun fetchCategories(credentials: XtreamCredentials, action: String, cancelled: () -> Boolean): Map<String, XtreamCategory> {
        val result = LinkedHashMap<String, XtreamCategory>()
        readArray(credentials.playerApiUrl(action), cancelled) { reader ->
            val fields = readObject(reader, setOf("category_id", "category_name"))
            val id = fields["category_id"].orEmpty()
            if (id.isNotBlank()) result[id] = XtreamCategory(id, fields["category_name"].orEmpty().ifBlank { "Other" })
        }
        return result
    }

    private inline fun readArray(url: String, cancelled: () -> Boolean, consume: (JsonReader) -> Unit) {
        val response = try { downloader.open(url, allowCredentialQuery = true) } catch (error: Throwable) {
            throw IllegalStateException("Xtream server is unavailable", error)
        }
        response.stream.use { stream ->
            JsonReader(InputStreamReader(stream, Charsets.UTF_8)).use { reader ->
                reader.isLenient = true
                if (reader.peek() != JsonToken.BEGIN_ARRAY) throw IllegalArgumentException("Xtream server returned an unexpected catalogue response")
                reader.beginArray()
                while (reader.hasNext()) {
                    if (cancelled()) throw InterruptedException("Xtream import cancelled")
                    consume(reader)
                }
                reader.endArray()
            }
        }
    }

    private fun readObject(reader: JsonReader, wanted: Set<String>): Map<String, String?> {
        if (reader.peek() != JsonToken.BEGIN_OBJECT) { reader.skipValue(); return emptyMap() }
        val out = HashMap<String, String?>()
        reader.beginObject()
        while (reader.hasNext()) {
            val name = reader.nextName()
            if (name in wanted) out[name] = readScalar(reader) else reader.skipValue()
        }
        reader.endObject()
        return out
    }

    private fun readScalar(reader: JsonReader): String? = when (reader.peek()) {
        JsonToken.NULL -> { reader.nextNull(); null }
        JsonToken.STRING -> reader.nextString()
        JsonToken.NUMBER -> reader.nextString()
        JsonToken.BOOLEAN -> reader.nextBoolean().toString()
        else -> { reader.skipValue(); null }
    }

    private fun checkLimit(list: List<*>) {
        if (list.size > maxEntries) throw IllegalArgumentException("Xtream catalogue exceeds the local safety bound")
    }

    private fun String?.isTruthy(): Boolean = !isNullOrBlank() && lowercase(Locale.ROOT) !in setOf("0", "false", "no", "none")

    private fun isHttpUrl(value: String?): Boolean = runCatching {
        if (value.isNullOrBlank()) return false
        val uri = URI(value)
        uri.scheme?.lowercase() in setOf("http", "https") && !uri.host.isNullOrBlank()
    }.getOrDefault(false)
}
