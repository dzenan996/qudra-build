// @polsia:user-owned — QUDRA Mobile visual language: deep teal, warm amber, readable touch targets.
package com.qudra.mobile.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

object UiStyle {
    val background = Color.rgb(7, 16, 19); val surface = Color.rgb(13, 32, 36); val raised = Color.rgb(20, 46, 50); val text = Color.rgb(240, 239, 227); val muted = Color.rgb(164, 184, 178); val accent = Color.rgb(230, 184, 92); val danger = Color.rgb(232, 125, 104)
    fun column(context: Context) = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL; setBackgroundColor(UiStyle.background)
        setPadding(24, 26, 24, 28)
        ViewCompat.setOnApplyWindowInsetsListener(this) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(24, bars.top + 18, 24, bars.bottom + 20)
            insets
        }
        ViewCompat.requestApplyInsets(this)
    }
    fun row(context: Context) = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    fun title(context: Context, value: String, size: Float = 30f) = TextView(context).apply { text = value; textSize = size; setTextColor(UiStyle.text); typeface = Typeface.create("sans-serif", Typeface.BOLD); setPadding(0, 0, 0, 12) }
    fun body(context: Context, value: String, size: Float = 16f) = TextView(context).apply { text = value; textSize = size; setTextColor(UiStyle.muted); setPadding(0, 4, 0, 12) }
    fun button(context: Context, value: String, onClick: () -> Unit) = Button(context).apply { text = value; textSize = 15f; isAllCaps = false; setTextColor(UiStyle.background); setBackgroundColor(UiStyle.accent); minHeight = 52; setPadding(14, 8, 14, 8); setOnClickListener { onClick() }; layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 6, 8, 6) } }
    fun grow(view: View) = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(4, 0, 4, 0) }
}
