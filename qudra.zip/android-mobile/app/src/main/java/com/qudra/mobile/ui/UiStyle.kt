// @polsia:user-owned — QUDRA Mobile visual language and Master Home dashboard components.
package com.qudra.mobile.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

object UiStyle {
    val background = Color.rgb(7, 16, 19)
    val surface = Color.rgb(13, 32, 36)
    val raised = Color.rgb(20, 46, 50)
    val text = Color.rgb(240, 239, 227)
    val muted = Color.rgb(164, 184, 178)
    val accent = Color.rgb(230, 184, 92)
    val danger = Color.rgb(232, 125, 104)

    private fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, stroke: Int? = null, radiusDp: Int = 18, context: Context): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(fill)
            cornerRadius = dp(context, radiusDp).toFloat()
            if (stroke != null) setStroke(dp(context, 1), stroke)
        }

    fun column(context: Context) = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(UiStyle.background)
        setPadding(dp(context, 18), dp(context, 18), dp(context, 18), dp(context, 24))
        ViewCompat.setOnApplyWindowInsetsListener(this) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(dp(context, 18), bars.top + dp(context, 12), dp(context, 18), bars.bottom + dp(context, 18))
            insets
        }
        ViewCompat.requestApplyInsets(this)
    }

    fun row(context: Context) = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    fun title(context: Context, value: String, size: Float = 30f) = TextView(context).apply {
        text = value
        textSize = size
        setTextColor(UiStyle.text)
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        setPadding(0, 0, 0, dp(context, 8))
    }

    fun body(context: Context, value: String, size: Float = 16f) = TextView(context).apply {
        text = value
        textSize = size
        setTextColor(UiStyle.muted)
        setPadding(0, dp(context, 3), 0, dp(context, 8))
    }

    fun sourceChip(context: Context, value: String) = TextView(context).apply {
        text = value
        textSize = 12f
        setTextColor(UiStyle.accent)
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        gravity = Gravity.CENTER
        background = rounded(UiStyle.surface, UiStyle.accent, 999, context)
        setPadding(dp(context, 12), dp(context, 7), dp(context, 12), dp(context, 7))
    }

    fun dashboardTile(context: Context, titleText: String, subtitle: String, onClick: () -> Unit) = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        isClickable = true
        isFocusable = true
        background = rounded(UiStyle.raised, UiStyle.accent, 20, context)
        setPadding(dp(context, 12), dp(context, 18), dp(context, 12), dp(context, 18))
        minimumHeight = dp(context, 128)
        addView(TextView(context).apply {
            text = titleText
            textSize = 22f
            setTextColor(UiStyle.text)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
        })
        addView(TextView(context).apply {
            text = subtitle
            textSize = 12f
            setTextColor(UiStyle.muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(context, 7), 0, 0)
        })
        setOnClickListener { onClick() }
    }

    fun quickAction(context: Context, value: String, onClick: () -> Unit) = Button(context).apply {
        text = value
        textSize = 13f
        isAllCaps = false
        setTextColor(UiStyle.text)
        background = rounded(UiStyle.surface, null, 14, context)
        minHeight = dp(context, 50)
        setPadding(dp(context, 10), dp(context, 8), dp(context, 10), dp(context, 8))
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dp(context, 3), dp(context, 4), dp(context, 3), dp(context, 4))
        }
    }

    fun button(context: Context, value: String, onClick: () -> Unit) = Button(context).apply {
        text = value
        textSize = 15f
        isAllCaps = false
        setTextColor(UiStyle.background)
        background = rounded(UiStyle.accent, null, 12, context)
        minHeight = dp(context, 52)
        setPadding(dp(context, 14), dp(context, 8), dp(context, 14), dp(context, 8))
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, dp(context, 6), dp(context, 8), dp(context, 6))
        }
    }

    fun grow(view: View) = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
        setMargins(4, 0, 4, 0)
    }
}
