// @polsia:user-owned — emulator smoke check; physical playback is not claimed here.
package com.qudra.mobile

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.rule.ActivityTestRule
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MainActivityTest {
    @get:Rule val activityRule = ActivityTestRule(MainActivity::class.java)
    @Test fun launchesCredentialFreeMobileShell() { activityRule.activity.window.decorView }
}
