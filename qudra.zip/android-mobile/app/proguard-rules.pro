# QUDRA Mobile keeps release shrinking disabled for the first device-validation build.
