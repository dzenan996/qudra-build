plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

val configuredCastReceiverAppId = providers.gradleProperty("qudraCastReceiverAppId")
    .orNull
    ?.trim()
    .orEmpty()

fun String.asBuildConfigString(): String =
    "\"${replace("\\", "\\\\").replace("\"", "\\\"")}\""

android {
    namespace = "com.qudra.mobile"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.qudra.mobile"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0-t6"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        buildConfigField("String", "QUDRA_API_BASE_URL", "\"${project.findProperty("qudraApiBaseUrl") ?: "https://your-app.polsia.app"}\"")
        buildConfigField("String", "CAST_RECEIVER_APP_ID", "\"\"")
    }

    buildFeatures { buildConfig = true }
    buildTypes {
        debug {
            // Google Default Media Receiver je eksplicitni razvojni fallback.
            buildConfigField("String", "CAST_RECEIVER_APP_ID", (configuredCastReceiverAppId.ifBlank { "CC1AD845" }).asBuildConfigString())
        }
        release {
            // Production nema fallback: Owner mora predati registrirani receiver ID.
            buildConfigField("String", "CAST_RECEIVER_APP_ID", configuredCastReceiverAppId.asBuildConfigString())
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(libs.androidx.core)
    implementation(libs.androidx.lifecycle.runtime)
    implementation(libs.androidx.lifecycle.viewmodel)
    implementation(libs.work.runtime)
    implementation(libs.media3.exoplayer)
    implementation(libs.media3.exoplayer.hls)
    implementation(libs.media3.ui)
    implementation(libs.media3.session)
    implementation(libs.cast.framework)

    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.test.ext)
    androidTestImplementation(libs.androidx.test.rules)
    androidTestImplementation(libs.espresso.core)
}
