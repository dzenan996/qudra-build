# QUDRA TV keeps release shrinking disabled for the first vertical slice.
