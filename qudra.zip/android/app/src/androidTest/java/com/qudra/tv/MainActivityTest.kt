// @polsia:user-owned — emulator/UI evidence only; no physical Android TV claim.
package com.qudra.tv

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.rule.ActivityTestRule
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.matcher.ViewMatchers.withText
import androidx.test.espresso.matcher.ViewMatchers.withHint
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.assertion.ViewAssertions.doesNotExist

@RunWith(AndroidJUnit4::class)
class MainActivityTest {
    @get:Rule val activityRule = ActivityTestRule(MainActivity::class.java)

    @Test fun firstRunShowsPairingAuthorityBoundary() {
        onView(withText("Pair this TV")).check(matches(androidx.test.espresso.matcher.ViewMatchers.isDisplayed()))
        onView(withHint("Account email")).check(doesNotExist())
        onView(withHint("Account password")).check(doesNotExist())
    }
}
