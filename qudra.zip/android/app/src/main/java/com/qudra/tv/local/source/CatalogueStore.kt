// @polsia:user-owned — staged/active/retired local generations with lazy category queries.
package com.qudra.tv.local.source

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class CatalogueStore(context: Context) : SQLiteOpenHelper(context, "qudra_tv_catalogue.db", null, 3) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE generations (id INTEGER PRIMARY KEY AUTOINCREMENT, source_id TEXT NOT NULL, state TEXT NOT NULL, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE media (generation_id INTEGER NOT NULL, item_id TEXT NOT NULL, title TEXT NOT NULL, uri TEXT NOT NULL, kind TEXT NOT NULL, group_name TEXT, tvg_id TEXT, logo_uri TEXT, category TEXT, tvg_name TEXT, season INTEGER, episode INTEGER, series_key TEXT, catch_up INTEGER NOT NULL DEFAULT 0, timeshift INTEGER NOT NULL DEFAULT 0)")
        createIndexes(db)
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            listOf("logo_uri TEXT", "category TEXT", "tvg_name TEXT", "season INTEGER", "episode INTEGER", "series_key TEXT", "catch_up INTEGER NOT NULL DEFAULT 0", "timeshift INTEGER NOT NULL DEFAULT 0").forEach { column -> runCatching { db.execSQL("ALTER TABLE media ADD COLUMN $column") } }
            createIndexes(db)
        }
        if (oldVersion < 3) db.execSQL("ALTER TABLE generations ADD COLUMN source_id TEXT NOT NULL DEFAULT 'default'")
    }
    private fun createIndexes(db: SQLiteDatabase) { db.execSQL("CREATE INDEX IF NOT EXISTS media_active_kind_idx ON media(generation_id, kind, title)"); db.execSQL("CREATE INDEX IF NOT EXISTS media_active_category_idx ON media(generation_id, category, title)"); db.execSQL("CREATE INDEX IF NOT EXISTS media_series_idx ON media(generation_id, series_key, season, episode)") }
    fun beginGeneration(sourceId: String = "default"): Long = writableDatabase.insertOrThrow("generations", null, ContentValues().apply { put("source_id", sourceId); put("state", "STAGED"); put("created_at", System.currentTimeMillis()) })
    fun stageMedia(generation: Long, entries: List<PlaylistEntry>) {
        writableDatabase.beginTransaction()
        try { entries.chunked(500).forEach { batch -> batch.forEach { entry -> writableDatabase.insertOrThrow("media", null, ContentValues().apply { put("generation_id", generation); put("item_id", entry.id); put("title", entry.title); put("uri", entry.uri); put("kind", entry.kind.name); put("group_name", entry.group); put("tvg_id", entry.tvgId); put("logo_uri", entry.logoUri); put("category", entry.originalCategory); put("tvg_name", entry.tvgName); put("season", entry.seasonNumber); put("episode", entry.episodeNumber); put("series_key", entry.seriesKey); put("catch_up", if (entry.catchUpSupported) 1 else 0); put("timeshift", if (entry.timeshiftSupported) 1 else 0) }) }; writableDatabase.setTransactionSuccessful() } finally { writableDatabase.endTransaction() }
    }
    fun promoteGeneration(generation: Long) { writableDatabase.beginTransaction(); try { val source = writableDatabase.query("generations", arrayOf("source_id"), "id = ?", arrayOf(generation.toString()), null, null, null).use { if (it.moveToFirst()) it.getString(0) else "default" }; writableDatabase.update("generations", ContentValues().apply { put("state", "RETIRED") }, "state = ? AND source_id = ?", arrayOf("ACTIVE", source)); writableDatabase.update("generations", ContentValues().apply { put("state", "ACTIVE") }, "id = ?", arrayOf(generation.toString())); writableDatabase.setTransactionSuccessful() } finally { writableDatabase.endTransaction() } }
    fun retainLastKnownGood() { writableDatabase.delete("generations", "state = ?", arrayOf("STAGED")) }
    fun query(kind: LocalMediaKind, category: String? = null, offset: Int = 0, limit: Int = 100, sourceId: String? = null): List<PlaylistEntry> {
        val result = mutableListOf<PlaylistEntry>()
        val where = "generation_id IN (SELECT id FROM generations WHERE state = 'ACTIVE'" + if (sourceId == null) ")" else " AND source_id = ?)") + " AND kind = ?" + if (category == null) "" else " AND category = ?"
        val args = listOfNotNull(sourceId) + listOf(kind.name) + listOfNotNull(category)
        readableDatabase.query("media", arrayOf("item_id", "title", "uri", "group_name", "tvg_id", "logo_uri", "category", "tvg_name", "season", "episode", "series_key", "catch_up", "timeshift"), where, args.toTypedArray(), null, null, "title ASC", "$offset,$limit").use { cursor -> while (cursor.moveToNext()) result += PlaylistEntry(cursor.getString(0), cursor.getString(1), cursor.getString(2), kind, cursor.getString(3), cursor.getString(4), cursor.getString(5), cursor.getInt(11) != 0, cursor.getInt(12) != 0, cursor.getString(6), cursor.getString(7), cursor.getIntOrNull(8), cursor.getIntOrNull(9), cursor.getString(10), sourceId ?: "default") }
        return result
    }
    fun categories(kind: LocalMediaKind, sourceId: String? = null): List<String> = readableDatabase.query(true, "media", arrayOf("category"), "generation_id IN (SELECT id FROM generations WHERE state = 'ACTIVE'" + if (sourceId == null) ")" else " AND source_id = ?)") + " AND kind = ? AND category IS NOT NULL AND category != ''", listOfNotNull(sourceId, kind.name).toTypedArray(), null, null, "category ASC", null).use { cursor -> buildList { while (cursor.moveToNext()) add(cursor.getString(0)) } }
    fun count(kind: LocalMediaKind, sourceId: String? = null): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM media WHERE generation_id IN (SELECT id FROM generations WHERE state = 'ACTIVE'" + if (sourceId == null) ")" else " AND source_id = ?)") + " AND kind = ?", listOfNotNull(sourceId, kind.name).toTypedArray()).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    private fun android.database.Cursor.getIntOrNull(index: Int): Int? = if (isNull(index)) null else getInt(index)
}
