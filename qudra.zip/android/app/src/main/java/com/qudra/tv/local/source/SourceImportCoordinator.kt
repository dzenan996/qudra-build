// @polsia:user-owned — cancellable staged playlist/XMLTV import with last-known-good retention.
package com.qudra.tv.local.source

import java.io.InputStreamReader

class SourceImportCoordinator(
    private val downloader: SourceDownloadClient,
    private val catalogueStore: CatalogueStore,
    private val epgStore: EpgStore,
    private val m3uParser: M3uParser = M3uParser(),
    private val xmlTvParser: XmlTvParser = XmlTvParser(),
) {
    fun import(sourceId: String, playlistUrl: String, xmlTvUrl: String? = null, timezone: String? = null, offsetMinutes: Int? = null, sourceSecret: String? = null, cancelled: () -> Boolean = { false }): LocalSourceSnapshot {
        val generation = catalogueStore.beginGeneration(sourceId)
        return try {
            val playlist = downloader.open(playlistUrl, sourceSecret)
            val media = playlist.stream.use { m3uParser.parse(InputStreamReader(it, Charsets.UTF_8), cancelled) }.map { it.copy(id = "$sourceId::${it.id}", sourceId = sourceId) }
            require(media.isNotEmpty()) { "Playlist did not contain usable entries" }
            catalogueStore.stageMedia(generation, media)
            val epg = xmlTvUrl?.let { url -> val response = downloader.open(url, sourceSecret); response.stream.use { xmlTvParser.parse(InputStreamReader(it, Charsets.UTF_8), cancelled) } }
            if (epg != null) epgStore.replace(sourceId, epg, timezone, offsetMinutes)
            catalogueStore.promoteGeneration(generation)
            LocalSourceSnapshot(generation, media, epg?.first.orEmpty(), epg?.second.orEmpty(), timezone, offsetMinutes, LocalSyncState.FRESH, LocalCapabilities(epg != null, epg != null, epg != null, media.any { it.catchUpSupported }, media.any { it.timeshiftSupported }))
        } catch (error: Throwable) {
            catalogueStore.retainLastKnownGood()
            epgStore.markStale(sourceId)
            if (error is InterruptedException) throw error
            throw error
        }
    }
    fun import(playlistUrl: String, xmlTvUrl: String? = null, cancelled: () -> Boolean = { false }): LocalSourceSnapshot = import("default", playlistUrl, xmlTvUrl, cancelled = cancelled)
    fun importWithRetry(sourceId: String, playlistUrl: String, xmlTvUrl: String? = null, timezone: String? = null, offsetMinutes: Int? = null, sourceSecret: String? = null, attempts: Int = 3, cancelled: () -> Boolean = { false }): LocalSourceSnapshot {
        require(attempts in 1..3); var last: Throwable? = null
        repeat(attempts) { attempt -> try { return import(sourceId, playlistUrl, xmlTvUrl, timezone, offsetMinutes, sourceSecret, cancelled) } catch (error: InterruptedException) { throw error } catch (error: Throwable) { last = error; if (attempt < attempts - 1) Thread.sleep(250L * (attempt + 1)) } }
        throw last ?: IllegalStateException("Source import failed")
    }
    fun importWithRetry(playlistUrl: String, xmlTvUrl: String? = null, attempts: Int = 3, cancelled: () -> Boolean = { false }): LocalSourceSnapshot = importWithRetry("default", playlistUrl, xmlTvUrl, attempts = attempts, cancelled = cancelled)
}
