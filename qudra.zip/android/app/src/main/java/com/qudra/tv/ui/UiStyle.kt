// @polsia:user-owned — QUDRA TV visual language: deep teal, warm amber, high-focus controls.
package com.qudra.tv.ui

import android.graphics.Color
import android.graphics.Typeface
import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

object UiStyle {
    val background = Color.rgb(7, 16, 19)
    val surface = Color.rgb(13, 32, 36)
    val surfaceRaised = Color.rgb(20, 46, 50)
    val text = Color.rgb(240, 239, 227)
    val muted = Color.rgb(164, 184, 178)
    val accent = Color.rgb(230, 184, 92)
    val danger = Color.rgb(232, 125, 104)

    fun column(context: Context): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(UiStyle.background)
        setPadding(48, 36, 48, 36)
    }

    fun title(context: Context, textValue: String, size: Float = 30f) = TextView(context).apply {
        text = textValue
        textSize = size
        setTextColor(UiStyle.text)
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        setPadding(0, 0, 0, 16)
    }

    fun body(context: Context, textValue: String, size: Float = 17f) = TextView(context).apply {
        text = textValue
        textSize = size
        setTextColor(UiStyle.muted)
        setPadding(0, 4, 0, 12)
    }

    fun button(context: Context, textValue: String, onClick: () -> Unit) = Button(context).apply {
        text = textValue
        textSize = 16f
        isAllCaps = false
        setTextColor(UiStyle.background)
        setBackgroundColor(UiStyle.accent)
        setPadding(20, 10, 20, 10)
        isFocusable = true
        setOnFocusChangeListener { view, focused -> view.setBackgroundColor(if (focused) UiStyle.accent else UiStyle.surfaceRaised) }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-2, 64).apply { setMargins(0, 8, 12, 8) }
    }

    fun grow(view: View) = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(8, 0, 8, 0) }
    fun row(context: Context) = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
}
