// @polsia:user-owned — credential-free, Device-first bootstrap with safe QR representation.
package com.qudra.tv.ui.pairing

import android.graphics.Bitmap
import android.graphics.Color
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.qudra.tv.data.PendingBootstrap
import com.qudra.tv.data.QudraRepository
import com.qudra.tv.ui.UiStyle
import java.time.Duration
import java.time.Instant
import java.util.concurrent.Executors

object PairingScreen {
    fun show(activity: android.app.Activity, repository: QudraRepository, onComplete: () -> Unit) {
        val model = PairingViewModel(repository)
        val root = UiStyle.column(activity)
        root.addView(UiStyle.title(activity, "QUDRA", 42f))
        root.addView(UiStyle.body(activity, "A private media player for your screen. QUDRA OPEN does not require a paid or Personal Source entitlement.", 19f))
        root.addView(UiStyle.title(activity, "Pair this TV", 26f))
        root.addView(UiStyle.body(activity, "This TV creates a protected P-256 identity in Android Keystore, proves possession directly to QUDRA Cloud, and receives a server-issued Device session. Account claim is optional and secondary."))

        val status = UiStyle.body(activity, "No Device session has been issued yet.")
        root.addView(status)
        val qr = ImageView(activity).apply { setBackgroundColor(Color.WHITE); visibility = View.GONE; contentDescription = "Server-issued pairing QR" }
        root.addView(qr, LinearLayout.LayoutParams(300, 300).apply { gravity = android.view.Gravity.CENTER_HORIZONTAL; setMargins(0, 12, 0, 12) })
        val countdown = UiStyle.body(activity, "")
        root.addView(countdown)
        val code = UiStyle.body(activity, "")
        root.addView(code)
        val action = UiStyle.button(activity, "Start secure device bootstrap") { }
        root.addView(action)
        val cancel = UiStyle.button(activity, "Clear and start again") { show(activity, repository, onComplete) }
        root.addView(cancel)
        activity.setContentView(root)

        var pending: PendingBootstrap? = null
        val executor = Executors.newSingleThreadExecutor()
        action.setOnClickListener {
            if (pending != null) {
                val current = pending ?: return@setOnClickListener
                action.isEnabled = false
                status.text = "Proving possession of this TV's protected key…"
                executor.execute {
                    runCatching { model.complete(current) }.onSuccess {
                        activity.runOnUiThread { executor.shutdown(); onComplete() }
                    }.onFailure { error ->
                        activity.runOnUiThread {
                            action.isEnabled = true
                status.text = com.qudra.tv.data.NativeFailure.from(error).message
                        }
                    }
                }
                return@setOnClickListener
            }
            action.isEnabled = false
            status.text = "Registering a provisional Device identity…"
            executor.execute {
                runCatching { model.begin() }.onSuccess { result ->
                    pending = result
                    activity.runOnUiThread {
                        status.text = "Challenge created. This TV will complete its own proof; no account credentials are required."
                        code.text = "Secure pairing code: ${result.qr.representation}"
                        qr.setImageBitmap(qrBitmap(result.qr.representation))
                        qr.visibility = View.VISIBLE
                        action.text = "Complete secure bootstrap"
                        action.isEnabled = true
                        startCountdown(countdown, result)
                    }
                }.onFailure { error ->
                    activity.runOnUiThread {
                        action.isEnabled = true
                        status.text = com.qudra.tv.data.NativeFailure.from(error).message
                    }
                }
            }
        }
    }

    private fun startCountdown(view: TextView, pairing: PendingBootstrap) {
        val expiresAt = runCatching { Instant.parse(pairing.expiresAt) }.getOrNull() ?: return
        val timer = android.os.Handler(android.os.Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                val remaining = Duration.between(Instant.now(), expiresAt).seconds
                if (remaining <= 0) view.text = "Challenge expired on the server. Create a new one."
                else { view.text = "Server challenge window: ${remaining / 60}:${(remaining % 60).toString().padStart(2, '0')} remaining"; timer.postDelayed(this, 1000) }
            }
        }
        timer.post(tick)
    }

    private fun qrBitmap(value: String): Bitmap {
        val matrix = MultiFormatWriter().encode(value, BarcodeFormat.QR_CODE, 300, 300)
        return Bitmap.createBitmap(300, 300, Bitmap.Config.ARGB_8888).also { bitmap ->
            for (x in 0 until 300) for (y in 0 until 300) bitmap.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
        }
    }
}
