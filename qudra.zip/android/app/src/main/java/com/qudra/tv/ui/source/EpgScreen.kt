// @polsia:user-owned — local XMLTV NOW/NEXT and grid-friendly TV guide.
package com.qudra.tv.ui.source

import android.app.Activity
import android.widget.ScrollView
import com.qudra.tv.data.QudraRepository
import com.qudra.tv.ui.UiStyle

object EpgScreen {
    fun show(activity: Activity, repository: QudraRepository, sourceId: String) {
        val root = UiStyle.column(activity).apply { setPadding(48, 28, 48, 28) }
        val state = repository.localEpg(sourceId)
        root.addView(UiStyle.title(activity, "EPG", 32f))
        root.addView(UiStyle.body(activity, if (state.state.name == "FRESH") "Local XMLTV guide · ${state.timezone ?: "source timezone"}" else "EPG is unavailable or stale for this source. No programmes are invented."))
        state.channels.forEach { channel ->
            root.addView(UiStyle.title(activity, channel.displayName, 22f))
            val programmes = repository.localNowNext(sourceId, channel.id)
            if (programmes.isEmpty()) root.addView(UiStyle.body(activity, "No NOW/NEXT programme is mapped for this channel."))
            programmes.forEach { programme -> root.addView(UiStyle.body(activity, "${java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(java.util.Date(programme.startEpochMillis))}–${java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(java.util.Date(programme.stopEpochMillis))}  ${programme.title}${programme.description?.let { "\n$it" } ?: ""}")) }
        }
        val now = System.currentTimeMillis()
        root.addView(UiStyle.title(activity, "Schedule grid", 24f))
        repository.localGrid(sourceId, now - 60 * 60 * 1000L, now + 6 * 60 * 60 * 1000L).forEach { programme -> root.addView(UiStyle.body(activity, "${programme.channelId} · ${java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(java.util.Date(programme.startEpochMillis))} · ${programme.title}")) }
        root.addView(UiStyle.button(activity, "Back") { activity.finish() })
        activity.setContentView(ScrollView(activity).apply { addView(root) })
    }
}
