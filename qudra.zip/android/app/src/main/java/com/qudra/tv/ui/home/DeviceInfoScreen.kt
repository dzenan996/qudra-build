// @polsia:user-owned — server-authoritative identity/status view; no private key or token display.
package com.qudra.tv.ui.home

import android.app.Activity
import android.widget.ScrollView
import com.qudra.tv.data.api.DeviceView
import com.qudra.tv.data.api.AccessView
import com.qudra.tv.data.api.SourceSyncStatus
import com.qudra.tv.ui.UiStyle

object DeviceInfoScreen {
    fun show(activity: Activity, device: DeviceView, onBack: () -> Unit) {
        val root = UiStyle.column(activity)
        root.addView(UiStyle.title(activity, "Device info", 32f))
        root.addView(UiStyle.body(activity, "Identity is a P-256 public-key registration. The private key stays in Android Keystore and is never shown."))
        root.addView(UiStyle.body(activity, "Device ID\n${device.id}\n\nPlatform\nANDROID_TV · TV\n\nStatus\n${device.status}\n\nKey version\n${device.keyVersion}\n\nFingerprint\n${device.publicKeyFingerprint}"))
        root.addView(UiStyle.button(activity, "Back to QUDRA") { onBack() })
        activity.setContentView(ScrollView(activity).apply { addView(root) })
    }
    fun show(activity: Activity, device: DeviceView, access: AccessView, sync: List<SourceSyncStatus>, onBack: () -> Unit) {
        val root = UiStyle.column(activity)
        root.addView(UiStyle.title(activity, "Device info", 32f))
        root.addView(UiStyle.body(activity, "Public Device ID: ${device.publicDeviceId}\nPlatform: ANDROID_TV · API ${android.os.Build.VERSION.SDK_INT}\nApp: ${com.qudra.tv.BuildConfig.VERSION_NAME}\nPairing: ${device.status}\nTrial: ${if (access.trialActive) "ACTIVE" else "INACTIVE"}\nEntitlement: ${if (access.entitlementActive) "ACTIVE" else "INACTIVE"}\nPersonal Source access: ${if (access.personalSourceAllowed) "ALLOWED" else "DENIED"}\nActive control-plane sync: ${sync.maxByOrNull { it.lastAttemptAt.orEmpty() }?.state ?: "NONE"}"))
        root.addView(UiStyle.body(activity, "Private keys, session tokens, source secrets and credential-bearing URLs are never displayed."))
        root.addView(UiStyle.button(activity, "Back") { onBack() })
        activity.setContentView(ScrollView(activity).apply { addView(root) })
    }
}
