// @polsia:user-owned — device-installation-local state; never sent as viewing history.
package com.qudra.tv.local

import android.content.Context

data class PlaybackProgress(val sourceId: String, val positionMs: Long, val durationMs: Long)

class LocalPlaybackStateStore(context: Context) {
    private val preferences = context.getSharedPreferences("qudra_local_state", Context.MODE_PRIVATE)

    fun isFavorite(sourceId: String) = preferences.getBoolean("favorite_$sourceId", false)
    fun setFavorite(sourceId: String, favorite: Boolean) = preferences.edit().putBoolean("favorite_$sourceId", favorite).apply()
    fun saveProgress(progress: PlaybackProgress) = preferences.edit().putLong("progress_${progress.sourceId}", progress.positionMs).putLong("duration_${progress.sourceId}", progress.durationMs).apply()
    fun progress(sourceId: String): PlaybackProgress? {
        val position = preferences.getLong("progress_$sourceId", -1L)
        val duration = preferences.getLong("duration_$sourceId", -1L)
        return if (position >= 0L && duration > 0L) PlaybackProgress(sourceId, position, duration) else null
    }
    fun recentlyWatched(): List<String> = preferences.getString("recent", "").orEmpty().split('|').filter(String::isNotBlank)
    fun markWatched(sourceId: String) {
        val values = (listOf(sourceId) + recentlyWatched().filterNot { it == sourceId }).take(20)
        preferences.edit().putString("recent", values.joinToString("|")).apply()
    }
    fun continueWatching(): List<String> = recentlyWatched().filter { id -> progress(id)?.let { it.positionMs > 15_000L && it.positionMs < it.durationMs - 15_000L } == true }
    fun saveEpisodeProgress(seriesId: String, episodeId: String, positionMs: Long, durationMs: Long) = saveProgress(PlaybackProgress("$seriesId::$episodeId", positionMs, durationMs))
    fun episodeProgress(seriesId: String, episodeId: String): PlaybackProgress? = progress("$seriesId::$episodeId")
    fun nextEpisode(episodes: List<String>, currentId: String): String? = episodes.dropWhile { it != currentId }.drop(1).firstOrNull()
    fun cleanup(maxRecent: Int = 20) { recentlyWatched().drop(maxRecent).forEach { preferences.edit().remove("progress_$it").remove("duration_$it").apply() } }
}
