// @polsia:user-owned — pure source-selection invariants shared by TV UI and tests.
package com.qudra.tv.local.source

object SourceSlotPolicy {
    const val MAX_PERSONAL_SOURCES = 2
    fun canAdd(current: Int) = current in 0 until MAX_PERSONAL_SOURCES
    fun fallbackAfterDelete(activeId: String?, deletedId: String) = if (activeId == deletedId) null else activeId
    fun orderedCategories(categories: List<String>) = categories.filter(String::isNotBlank).distinct().sorted()
    fun nextEpisode(orderedIds: List<String>, currentId: String) = orderedIds.dropWhile { it != currentId }.drop(1).firstOrNull()
    fun showCatchUp(supported: Boolean) = supported
    fun showTimeshift(supported: Boolean) = supported
}
