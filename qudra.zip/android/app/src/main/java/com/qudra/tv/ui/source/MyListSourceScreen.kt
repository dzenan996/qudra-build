// @polsia:user-owned — the only TV surface allowed to switch sources.
package com.qudra.tv.ui.source

import android.app.Activity
import android.app.AlertDialog
import android.widget.ScrollView
import com.qudra.tv.data.QudraRepository
import com.qudra.tv.data.api.SourceConfig
import com.qudra.tv.ui.UiStyle
import java.util.concurrent.Executors

object MyListSourceScreen {
    fun show(activity: Activity, repository: QudraRepository, configs: List<SourceConfig>, activeId: String?, onChanged: () -> Unit) {
        val root = UiStyle.column(activity).apply { setPadding(48, 28, 48, 28) }
        root.addView(UiStyle.title(activity, "My List · Sources", 30f))
        root.addView(UiStyle.body(activity, "QUDRA OPEN is always available. Only this screen changes the active source; there are at most two Personal Source slots."))
        val worker = Executors.newSingleThreadExecutor()
        fun action(label: String, work: () -> Unit) { root.addView(UiStyle.button(activity, label) { worker.execute { val result = runCatching { work() }; activity.runOnUiThread { result.onSuccess { onChanged() }.onFailure { AlertDialog.Builder(activity).setTitle("Source action failed").setMessage(it.message ?: "The source is unavailable.").setPositiveButton("Close", null).show() } } } }) }
        root.addView(UiStyle.button(activity, if (activeId == null) "✓ QUDRA OPEN" else "Use QUDRA OPEN") { worker.execute { val result = runCatching { repository.activateSource(null) }; activity.runOnUiThread { result.onSuccess { onChanged() }.onFailure { AlertDialog.Builder(activity).setTitle("Source action failed").setMessage(it.message ?: "QUDRA OPEN is unavailable.").setPositiveButton("Close", null).show() } } } })
        configs.sortedBy { it.slot ?: Int.MAX_VALUE }.forEach { config ->
            root.addView(UiStyle.title(activity, "Slot ${config.slot ?: "?"} · ${config.label}", 21f))
            root.addView(UiStyle.body(activity, "${if (config.id == activeId) "ACTIVE · " else ""}${if (config.hasSecret) "secret configured" else "no secret"} · config v${config.configVersion}"))
            action(if (config.id == activeId) "Refresh source" else "Use this source") { if (config.id == activeId) repository.refreshSource(config) else repository.activateSource(config) }
            root.addView(UiStyle.button(activity, "Delete source") { AlertDialog.Builder(activity).setTitle("Delete ${config.label}?").setMessage("The active source falls back to QUDRA OPEN. Source secrets are removed from this TV.").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> worker.execute { val result = runCatching { repository.deleteSource(config) }; activity.runOnUiThread { result.onSuccess { onChanged() }.onFailure { AlertDialog.Builder(activity).setTitle("Source was not deleted").setMessage(it.message ?: "The source is unavailable.").setPositiveButton("Close", null).show() } } } }.show() })
        }
        root.addView(UiStyle.button(activity, "Add Personal Source") { PersonalSourceScreen.show(activity, repository, onChanged) })
        root.addView(UiStyle.button(activity, "Back") { worker.shutdown(); onChanged() })
        activity.setContentView(ScrollView(activity).apply { addView(root) })
    }
}
