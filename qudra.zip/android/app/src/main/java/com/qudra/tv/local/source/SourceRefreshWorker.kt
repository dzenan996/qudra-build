// @polsia:user-owned — WorkManager refresh with bounded retry and aggregate-only sync report.
package com.qudra.tv.local.source

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.qudra.tv.BuildConfig
import com.qudra.tv.data.api.QudraApiClient
import com.qudra.tv.data.api.SourceFormat
import com.qudra.tv.data.api.SourceSyncState
import com.qudra.tv.security.DeviceSessionStore
import com.qudra.tv.security.SourceSecretStore
import org.json.JSONObject

class SourceRefreshWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = runCatching {
        val sourceId = inputData.getString("sourceId") ?: return Result.failure()
        val playlist = inputData.getString("playlistUrl") ?: return Result.failure()
        val config = SourceConfigStore(applicationContext).read().firstOrNull { it.id == sourceId } ?: return Result.failure()
        val snapshot = SourceImportCoordinator(SourceDownloadClient(), CatalogueStore(applicationContext), EpgStore(applicationContext)).importWithRetry(sourceId, playlist, inputData.getString("epgUrl"), inputData.getString("timezone"), inputData.getInt("offsetMinutes", 0), SourceSecretStore(applicationContext).get(sourceId), cancelled = { isStopped })
        DeviceSessionStore(applicationContext).read()?.let { session ->
            val counts = JSONObject().apply { put("live", snapshot.media.count { it.kind == LocalMediaKind.LIVE_TV }); put("movies", snapshot.media.count { it.kind == LocalMediaKind.MOVIE }); put("series", snapshot.media.count { it.kind == LocalMediaKind.SERIES }); put("radio", snapshot.media.count { it.kind == LocalMediaKind.RADIO }); put("epgChannels", snapshot.channels.size); put("epgProgrammes", snapshot.programmes.size) }
            val capabilities = JSONObject().apply { put("epg", if (snapshot.capabilities.epg) "SUPPORTED" else "UNSUPPORTED"); put("catchUp", if (snapshot.capabilities.catchUp) "SUPPORTED" else "UNSUPPORTED"); put("timeshift", if (snapshot.capabilities.timeshift) "SUPPORTED" else "UNSUPPORTED") }
            QudraApiClient(BuildConfig.QUDRA_API_BASE_URL).reportSync(session.token, session.deviceId, config.id, config.configVersion, SourceSyncState.FRESH, if (playlist.endsWith(".m3u8", true)) SourceFormat.M3U8 else SourceFormat.M3U, counts, capabilities, config.sourceTimezone, config.utcOffsetMinutes, snapshot.generation.toString())
        }
        Result.success()
    }.getOrElse { if (runAttemptCount < 2) Result.retry() else Result.failure() }
}
