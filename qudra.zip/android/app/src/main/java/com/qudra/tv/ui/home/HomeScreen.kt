// @polsia:user-owned — four-area, source-aware, D-pad-first TV home.
package com.qudra.tv.ui.home

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import com.qudra.tv.data.HomeData
import com.qudra.tv.data.QudraRepository
import com.qudra.tv.data.api.MediaItem
import com.qudra.tv.local.LocalPlaybackStateStore
import com.qudra.tv.local.source.LocalMediaKind
import com.qudra.tv.local.source.PlaylistEntry
import com.qudra.tv.player.PlayerActivity
import com.qudra.tv.player.validateDirectOrigin
import com.qudra.tv.player.resolveDirectOrigin
import com.qudra.tv.ui.UiStyle
import com.qudra.tv.ui.source.EpgScreen
import com.qudra.tv.ui.source.MyListSourceScreen
import com.qudra.tv.ui.source.SearchScreen
import java.util.concurrent.Executors

object HomeScreen {
    fun show(activity: Activity, repository: QudraRepository, data: HomeData, local: LocalPlaybackStateStore, onRePair: () -> Unit) {
        val root = UiStyle.column(activity).apply { setPadding(48, 28, 48, 28) }
        val scroll = ScrollView(activity).apply { isFillViewport = true; addView(root) }
        activity.setContentView(scroll)
        val reloadExecutor = Executors.newSingleThreadExecutor()
        fun reloadHome() { reloadExecutor.execute { runCatching { repository.loadHome() }.onSuccess { next -> activity.runOnUiThread { show(activity, repository, next, local, onRePair) } }.onFailure { error -> activity.runOnUiThread { EmptyStates.dialog(activity, "Refresh failed", com.qudra.tv.data.NativeFailure.from(error).message) } } } }
        root.addView(UiStyle.title(activity, "QUDRA", 38f))
        root.addView(UiStyle.body(activity, "Direct media for the living room. Four clear areas, source-local data, no invented programming.", 18f))
        if (data.fromCache) root.addView(UiStyle.body(activity, "Cloud is temporarily unavailable. Showing the last validated QUDRA OPEN catalog."))
        root.addView(UiStyle.body(activity, if (data.access.personalSourceAllowed) "QUDRA OPEN is permanent · Personal Source entitlement active" else "QUDRA OPEN is permanent · Personal Sources require an active trial or entitlement"))

        val navigation = UiStyle.row(activity).apply { gravity = Gravity.CENTER_VERTICAL }
        root.addView(navigation)
        val content = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        root.addView(content)

        fun episodeOrder(entry: PlaylistEntry): Int? = entry.episodeNumber?.let { (entry.seasonNumber ?: 0) * 10_000 + it }
        fun openLocal(entry: PlaylistEntry, next: PlaylistEntry? = null) {
            val url = validateDirectOrigin(entry.uri, entry.uri) ?: run { AlertDialog.Builder(activity).setTitle("Stream unavailable").setMessage("This selected source item is not a safe direct HTTPS stream.").setPositiveButton("Close", null).show(); return }
            activity.startActivity(Intent(activity, PlayerActivity::class.java).apply {
                putExtra(PlayerActivity.EXTRA_URL, url); putExtra(PlayerActivity.EXTRA_PREFERRED_ORIGIN, url); putExtra(PlayerActivity.EXTRA_TITLE, entry.title); putExtra(PlayerActivity.EXTRA_SOURCE_ID, data.activeSourceId ?: entry.sourceId); putExtra(PlayerActivity.EXTRA_CATCH_UP, entry.catchUpSupported); putExtra(PlayerActivity.EXTRA_TIMESHIFT, entry.timeshiftSupported)
                episodeOrder(entry)?.let { order -> entry.seriesKey?.let { putExtra(PlayerActivity.EXTRA_SERIES_ID, it); putExtra(PlayerActivity.EXTRA_EPISODE_ID, entry.id); putExtra(PlayerActivity.EXTRA_EPISODE_ORDER, order) } }
                if (next != null) episodeOrder(next)?.let { order -> next.seriesKey?.let { putExtra(PlayerActivity.EXTRA_NEXT_URL, next.uri); putExtra(PlayerActivity.EXTRA_NEXT_PREFERRED_ORIGIN, next.uri); putExtra(PlayerActivity.EXTRA_NEXT_TITLE, next.title); putExtra(PlayerActivity.EXTRA_NEXT_SOURCE_ID, data.activeSourceId ?: next.sourceId); putExtra(PlayerActivity.EXTRA_NEXT_SERIES_ID, it); putExtra(PlayerActivity.EXTRA_NEXT_EPISODE_ID, next.id); putExtra(PlayerActivity.EXTRA_NEXT_EPISODE_ORDER, order) } }
            })
        }
        fun openOpen(item: MediaItem, next: MediaItem? = null, seriesId: String? = null) {
            val url = resolveDirectOrigin(item) ?: run { AlertDialog.Builder(activity).setTitle("Playback unavailable").setMessage(item.availabilityReason ?: "No approved direct origin is available.").setPositiveButton("Close", null).show(); return }
            AlertDialog.Builder(activity).setTitle("Rights before playback").setMessage("${item.attribution.attributionText}\n\n${item.attribution.licenseName}\n${item.attribution.restrictions.joinToString("\n")}").setNegativeButton("Cancel", null).setPositiveButton("Play direct") { _, _ -> activity.startActivity(Intent(activity, PlayerActivity::class.java).apply {
                putExtra(PlayerActivity.EXTRA_URL, url); putExtra(PlayerActivity.EXTRA_PREFERRED_ORIGIN, item.preferredOrigin); putExtra(PlayerActivity.EXTRA_TITLE, item.title); putExtra(PlayerActivity.EXTRA_SOURCE_ID, "QUDRA_OPEN"); putExtra(PlayerActivity.EXTRA_CATCH_UP, item.capabilities?.catchUp == true); putExtra(PlayerActivity.EXTRA_TIMESHIFT, item.capabilities?.timeshift == true)
                if (seriesId != null && item.episodeOrder != null) { putExtra(PlayerActivity.EXTRA_SERIES_ID, seriesId); putExtra(PlayerActivity.EXTRA_EPISODE_ID, item.sourceId); putExtra(PlayerActivity.EXTRA_EPISODE_ORDER, item.episodeOrder) }
                if (next != null && seriesId != null && next.episodeOrder != null && next.directOrigin != null && next.preferredOrigin != null) { putExtra(PlayerActivity.EXTRA_NEXT_URL, next.directOrigin.url); putExtra(PlayerActivity.EXTRA_NEXT_PREFERRED_ORIGIN, next.preferredOrigin); putExtra(PlayerActivity.EXTRA_NEXT_TITLE, next.title); putExtra(PlayerActivity.EXTRA_NEXT_SOURCE_ID, "QUDRA_OPEN"); putExtra(PlayerActivity.EXTRA_NEXT_SERIES_ID, seriesId); putExtra(PlayerActivity.EXTRA_NEXT_EPISODE_ID, next.sourceId); putExtra(PlayerActivity.EXTRA_NEXT_EPISODE_ORDER, next.episodeOrder) }
            }) }.show()
        }
        fun render(area: String) {
            content.removeAllViews()
            val active = data.activeSourceId != null
            if (active) {
                val kind = when (area) { "LIVE TV" -> LocalMediaKind.LIVE_TV; "MOVIES" -> LocalMediaKind.MOVIE; "SERIES" -> LocalMediaKind.SERIES; "RADIO" -> LocalMediaKind.RADIO; else -> null }
                if (kind != null) renderLocal(activity, content, repository, local, kind, { entry, next -> openLocal(entry, next) })
                return
            }
            when (area) {
                "LIVE TV" -> EmptyStates.add(activity, content, "LIVE TV", "QUDRA OPEN has no lawful production LIVE TV source.")
                "RADIO" -> EmptyStates.add(activity, content, "RADIO", "QUDRA OPEN has no lawful production RADIO source.")
                "MOVIES" -> { content.addView(UiStyle.title(activity, "Movies", 28f)); data.manifest.movies.forEach { item -> MediaCards.add(activity, content, item, { openOpen(item) }, { AttributionDialog.show(activity, it) }, local.isFavorite(item.sourceId)) { local.setFavorite(item.sourceId, !local.isFavorite(item.sourceId)); render(area) } } }
                "SERIES" -> { val allEpisodes = data.manifest.series.flatMap { it.episodes }; fun section(label: String, items: List<MediaItem>) { if (items.isNotEmpty()) { content.addView(UiStyle.title(activity, label, 22f)); items.forEach { item -> MediaCards.add(activity, content, item, { openOpen(item) }, { AttributionDialog.show(activity, it) }, local.isFavorite(item.sourceId)) { local.setFavorite(item.sourceId, !local.isFavorite(item.sourceId)); render(area) } } } }; section("Favorites", allEpisodes.filter { local.isFavorite(it.sourceId) }); section("Recently watched", local.recentlyWatched().mapNotNull { id -> allEpisodes.firstOrNull { it.sourceId == id } }); section("Continue watching", local.continueWatching().mapNotNull { id -> allEpisodes.firstOrNull { it.sourceId == id } }); data.manifest.series.forEach { series -> content.addView(UiStyle.title(activity, series.title, 24f)); val episodes = series.episodes.sortedWith(compareBy({ it.episodeOrder ?: Int.MAX_VALUE }, { it.episodeNumber ?: Int.MAX_VALUE }, { it.sourceId })); episodes.forEachIndexed { index, item -> MediaCards.add(activity, content, item, { openOpen(item, episodes.getOrNull(index + 1), series.seriesId) }, { AttributionDialog.show(activity, it) }, local.isFavorite(item.sourceId)) { local.setFavorite(item.sourceId, !local.isFavorite(item.sourceId)); render(area) } } } }
            }
        }
        HomeNavigationPolicy.primaryAreas.forEach { area -> val button = UiStyle.button(activity, area) { render(area) }; button.layoutParams = UiStyle.grow(button); navigation.addView(button) }
        root.addView(UiStyle.button(activity, "My List · Sources") { MyListSourceScreen.show(activity, repository, data.sourceConfigs, data.activeSourceId, ::reloadHome) })
        val utility = UiStyle.row(activity)
        root.addView(utility)
        utility.addView(UiStyle.button(activity, "Search") { SearchScreen.show(activity, repository, data.activeSourceId ?: "QUDRA_OPEN", data.manifest) })
        utility.addView(UiStyle.button(activity, "EPG") { if (data.activeSourceId == null) EmptyStates.dialog(activity, "EPG", "QUDRA OPEN does not publish an EPG.") else EpgScreen.show(activity, repository, data.activeSourceId) })
        utility.addView(UiStyle.button(activity, "Device info") { data.device?.let { DeviceInfoScreen.show(activity, it, data.access, data.sync, onBack = { show(activity, repository, data, local, onRePair) }) } ?: EmptyStates.dialog(activity, "Device info unavailable", "Device status requires a live QUDRA Cloud connection.") })
        utility.addView(UiStyle.button(activity, "Diagnostics") { DiagnosticsScreen.show(activity, data.diagnostics) { show(activity, repository, data, local, onRePair) } })
        utility.addView(UiStyle.button(activity, "Reset session") { repository.clearSession(); onRePair() })
        render("MOVIES")
    }

    private fun renderLocal(activity: Activity, content: LinearLayout, repository: QudraRepository, local: LocalPlaybackStateStore, kind: LocalMediaKind, open: (PlaylistEntry, PlaylistEntry?) -> Unit) {
        content.removeAllViews()
        val all = repository.localCatalogue(kind, limit = 200)
        fun nextFor(item: PlaylistEntry): PlaylistEntry? = item.seriesKey?.let { key -> all.filter { it.seriesKey == key && it.id != item.id }.sortedWith(compareBy({ it.seasonNumber ?: Int.MAX_VALUE }, { it.episodeNumber ?: Int.MAX_VALUE }, { it.id })).firstOrNull { localEpisodeOrder(it) == localEpisodeOrder(item)?.plus(1) } }
        fun section(title: String, items: List<PlaylistEntry>) { if (items.isNotEmpty()) { content.addView(UiStyle.title(activity, title, 22f)); items.forEach { item -> MediaCards.addLocal(activity, content, item, { open(item, nextFor(item)) }, local.isFavorite(item.id)) { local.setFavorite(item.id, !local.isFavorite(item.id)); renderLocal(activity, content, repository, local, kind, open) } } } }
        section("Favorites", all.filter { local.isFavorite(it.id) })
        val recent = local.recentlyWatched().mapNotNull { id -> all.firstOrNull { it.id == id } }
        section("Recently watched", recent)
        section("Continue watching", local.continueWatching().mapNotNull { id -> all.firstOrNull { it.id == id } })
        repository.localCategories(kind).forEach { category -> section(category, repository.localCatalogue(kind, category, limit = 200)) }
        if (content.childCount == 0) EmptyStates.add(activity, content, kind.name.replace('_', ' '), "No local entries are available for the active Personal Source.")
    }

    private fun localEpisodeOrder(entry: PlaylistEntry): Int? = entry.episodeNumber?.let { (entry.seasonNumber ?: 0) * 10_000 + it }
}
