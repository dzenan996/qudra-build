// @polsia:user-owned — explicit Device-local autoplay preference; no Account dependency.
package com.qudra.tv.player

import android.content.Context

class AutoplayPreferences(context: Context) {
    private val preferences = context.getSharedPreferences("qudra_tv_preferences", Context.MODE_PRIVATE)

    fun isEnabled(): Boolean = preferences.getBoolean(KEY_AUTOPLAY_NEXT, AutoplayPolicy.DEFAULT_ENABLED)

    fun setEnabled(enabled: Boolean) = preferences.edit().putBoolean(KEY_AUTOPLAY_NEXT, enabled).apply()

    private companion object {
        const val KEY_AUTOPLAY_NEXT = "autoplay_next_episode"
    }
}
