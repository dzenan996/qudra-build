// @polsia:user-owned — pure session replacement rules for JVM regression coverage.
package com.qudra.tv.security

data class RenewedSession(
    val deviceId: String,
    val keyVersion: Int,
    val expiresAt: String,
    val replacementToken: String?,
)

object SessionRenewal {
    fun apply(previous: StoredDeviceSession, renewed: RenewedSession): StoredDeviceSession {
        require(previous.deviceId == renewed.deviceId) { "Device authority mismatch" }
        require(renewed.keyVersion == previous.keyVersion) { "Device key version mismatch" }
        return StoredDeviceSession(
            deviceId = renewed.deviceId,
            keyVersion = renewed.keyVersion,
            token = renewed.replacementToken?.takeIf(String::isNotBlank) ?: previous.token,
            expiresAt = renewed.expiresAt,
        )
    }
}
