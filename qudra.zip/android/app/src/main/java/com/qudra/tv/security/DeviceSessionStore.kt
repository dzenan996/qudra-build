// @polsia:user-owned — minimal protected local device-session record.
package com.qudra.tv.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.time.Instant
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class StoredDeviceSession(val deviceId: String, val keyVersion: Int, val token: String, val expiresAt: String)

class DeviceSessionStore(context: Context) {
    private val preferences = context.getSharedPreferences("qudra_session", Context.MODE_PRIVATE)
    private val keyAlias = "qudra_tv_session_aes_v1"
    private val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    init {
        if (!keyStore.containsAlias(keyAlias)) {
            KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
                init(KeyGenParameterSpec.Builder(keyAlias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
                generateKey()
            }
        }
    }

    fun read(): StoredDeviceSession? {
        val deviceId = preferences.getString("device_id", null) ?: return null
        val encryptedToken = preferences.getString("token", null) ?: return null
        val expiry = preferences.getString("expires_at", null) ?: return null
        val token = runCatching { decrypt(encryptedToken) }.getOrNull() ?: run {
            clear()
            return null
        }
        val session = StoredDeviceSession(deviceId, preferences.getInt("key_version", 0), token, expiry)
        if (!SessionExpiry.isUsable(session.expiresAt, Instant.now())) {
            clear()
            return null
        }
        return session
    }

    fun write(session: StoredDeviceSession) {
        require(session.deviceId.isNotBlank() && session.keyVersion > 0 && session.token.isNotBlank())
        require(SessionExpiry.isUsable(session.expiresAt, Instant.now())) { "Cannot persist an expired device session" }
        preferences.edit().putString("device_id", session.deviceId).putInt("key_version", session.keyVersion)
            .putString("token", encrypt(session.token)).putString("expires_at", session.expiresAt).commit()
    }

    fun clear() { preferences.edit().clear().apply() }

    private fun secretKey(): SecretKey = keyStore.getKey(keyAlias, null) as SecretKey
    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        return Base64.encodeToString(cipher.iv + cipher.doFinal(value.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    }
    private fun decrypt(value: String): String {
        val bytes = Base64.decode(value, Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
        return cipher.doFinal(bytes.copyOfRange(12, bytes.size)).toString(Charsets.UTF_8)
    }
}

object SessionExpiry {
    fun isUsable(expiresAt: String, now: Instant): Boolean =
        runCatching { Instant.parse(expiresAt).isAfter(now) }.getOrDefault(false)
}
