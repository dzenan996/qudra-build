// @polsia:user-owned — native TV entry point with predictable pairing/home/back flow.
package com.qudra.tv

import android.app.Activity
import android.os.Bundle
import android.widget.ScrollView
import com.qudra.tv.data.QudraRepository
import com.qudra.tv.data.NativeFailure
import com.qudra.tv.local.LocalPlaybackStateStore
import com.qudra.tv.ui.UiStyle
import com.qudra.tv.ui.home.HomeScreen
import com.qudra.tv.ui.pairing.PairingScreen
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var repository: QudraRepository
    private lateinit var local: LocalPlaybackStateStore
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repository = QudraRepository(this)
        local = LocalPlaybackStateStore(this)
        if (repository.currentSession() == null) showPairing() else loadHome()
    }

    private fun showPairing() = PairingScreen.show(this, repository) { loadHome() }

    private fun loadHome() {
        val loading = UiStyle.column(this)
        loading.addView(UiStyle.title(this, "QUDRA", 38f))
        loading.addView(UiStyle.body(this, "Loading the server-issued device session and QUDRA OPEN manifest…"))
        setContentView(ScrollView(this).apply { addView(loading) })
        executor.execute {
            runCatching { repository.loadHome() }.onSuccess { data ->
                runOnUiThread { HomeScreen.show(this, repository, data, local) { showPairing() } }
            }.onFailure { error ->
                runOnUiThread {
                    val failed = UiStyle.column(this)
                    failed.addView(UiStyle.title(this, "QUDRA needs attention", 32f))
                    failed.addView(UiStyle.body(this, NativeFailure.from(error).message))
                    failed.addView(UiStyle.button(this, "Retry") { loadHome() })
                    if (NativeFailure.from(error).category == com.qudra.tv.data.NativeFailureCategory.AUTHORITY) {
                        failed.addView(UiStyle.button(this, "Pair this TV again") { repository.clearSession(); showPairing() })
                    }
                    setContentView(ScrollView(this).apply { addView(failed) })
                }
            }
        }
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
