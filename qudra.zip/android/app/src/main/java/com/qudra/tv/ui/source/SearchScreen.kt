// @polsia:user-owned — active-source-local search; never a provider or internet search.
package com.qudra.tv.ui.source

import android.app.Activity
import android.text.InputType
import android.widget.EditText
import android.widget.ScrollView
import com.qudra.tv.data.QudraRepository
import com.qudra.tv.data.api.OpenManifest
import com.qudra.tv.local.source.LocalMediaKind
import com.qudra.tv.ui.UiStyle

object SearchScreen {
    fun show(activity: Activity, repository: QudraRepository, sourceId: String, manifest: OpenManifest) {
        val root = UiStyle.column(activity).apply { setPadding(48, 28, 48, 28) }
        root.addView(UiStyle.title(activity, "Search", 32f))
        root.addView(UiStyle.body(activity, if (sourceId == "QUDRA_OPEN") "Searches QUDRA OPEN manifest metadata only." else "Searches the active Personal Source local catalogue only."))
        val query = EditText(activity).apply { hint = "Search titles or categories"; inputType = InputType.TYPE_CLASS_TEXT; setTextColor(UiStyle.text); setHintTextColor(UiStyle.muted) }
        root.addView(query)
        val results = UiStyle.column(activity)
        root.addView(UiStyle.button(activity, "Search") { results.removeAllViews(); val value = query.text.toString().trim(); if (value.isBlank()) results.addView(UiStyle.body(activity, "Enter a title or category.")) else { if (sourceId == "QUDRA_OPEN") { (manifest.movies + manifest.series.flatMap { it.episodes } + manifest.liveTv + manifest.radio).filter { it.title.contains(value, true) }.forEach { results.addView(UiStyle.body(activity, it.title)) } } else { listOf(LocalMediaKind.LIVE_TV, LocalMediaKind.MOVIE, LocalMediaKind.SERIES, LocalMediaKind.RADIO).flatMap { repository.localCatalogue(it, limit = 200) }.filter { it.title.contains(value, true) || it.originalCategory?.contains(value, true) == true }.forEach { results.addView(UiStyle.body(activity, it.title)) } }; if (results.childCount == 0) results.addView(UiStyle.body(activity, "No results in the active source.")) } })
        root.addView(results)
        root.addView(UiStyle.button(activity, "Back") { activity.finish() })
        activity.setContentView(ScrollView(activity).apply { addView(root) })
    }
}
