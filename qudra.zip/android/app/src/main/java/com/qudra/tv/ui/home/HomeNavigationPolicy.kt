// @polsia:user-owned — TV primary-area and source-switching navigation invariant.
package com.qudra.tv.ui.home

object HomeNavigationPolicy {
    val primaryAreas = listOf("LIVE TV", "MOVIES", "SERIES", "RADIO")
    const val sourceSwitchSurface = "MY LIST"
    const val hasCategoriesSubmenu = false
}
