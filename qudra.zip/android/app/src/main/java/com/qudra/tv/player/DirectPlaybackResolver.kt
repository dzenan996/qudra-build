// @polsia:user-owned — direct-origin-only playback selection.
package com.qudra.tv.player

import com.qudra.tv.data.api.MediaItem
import java.net.URI

fun resolveDirectOrigin(item: MediaItem): String? {
    val origin = item.directOrigin ?: return null
    if (!item.available || !origin.mediaOrigin || !item.preferredOrigin.equals(origin.url, ignoreCase = false)) return null
    return validateDirectOrigin(origin.url, item.preferredOrigin)
}

fun validateDirectOrigin(url: String, expectedPreferredOrigin: String?): String? {
    if (expectedPreferredOrigin.isNullOrBlank() || url != expectedPreferredOrigin) return null
    val parsed = runCatching { URI(url) }.getOrNull() ?: return null
    if (parsed.scheme != "https" || parsed.host.isNullOrBlank() || parsed.userInfo != null || Regex("token|secret|password|api[-_]?key|auth", RegexOption.IGNORE_CASE).containsMatchIn(parsed.rawQuery.orEmpty())) return null
    return url
}

fun formatSupportNote(item: MediaItem): String = when (item.directOrigin?.format?.container) {
    "MP4" -> "Preferred fixture: MP4 / H.264 / AAC."
    "MOV" -> "Device-test required: MOV / H.264 / AAC."
    "WEBM" -> "Compatibility risk: WebM / VP8 / Vorbis may vary by Android TV device."
    "OGG" -> "Compatibility risk: OGG / Theora / Vorbis may vary by Android TV device."
    else -> "Playback compatibility is not established for this format."
}
