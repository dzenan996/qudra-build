// @polsia:user-owned — bounded direct HTTPS download; credentials never enter URLs or logs.
package com.qudra.tv.local.source

import java.io.FilterInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

data class SourceResponse(val stream: InputStream, val contentType: String?, val contentLength: Long)

class SourceDownloadClient(private val maxBytes: Long = 50L * 1024L * 1024L) {
    fun open(url: String, sourceSecret: String? = null): SourceResponse {
        require(isSafeSourceUrl(url)) { "Personal Sources require a credential-free HTTPS URL" }
        var current = url
        var connection: HttpURLConnection? = null
        repeat(3) {
            connection = (URL(current).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15_000
                readTimeout = 30_000
                instanceFollowRedirects = false
                setRequestProperty("Accept", "application/x-mpegURL, audio/x-mpegurl, application/vnd.apple.mpegurl, application/xml, text/xml, video/mp2t, */*")
                sourceSecret?.takeIf(String::isNotBlank)?.let { setRequestProperty("Authorization", "Bearer $it") }
            }
            when (val response = connection!!.responseCode) {
                in 200..299 -> return response(connection!!)
                in 300..399 -> {
                    val next = connection!!.getHeaderField("Location")
                    connection!!.disconnect()
                    require(isSafeSourceUrl(next.orEmpty())) { "Source redirect is not a safe HTTPS origin" }
                    current = next!!
                }
                else -> { connection!!.disconnect(); throw IllegalStateException("Source request was rejected") }
            }
        }
        connection?.disconnect()
        throw IllegalStateException("Source redirect chain is too long")
    }

    private fun response(connection: HttpURLConnection): SourceResponse {
        val contentType = connection.contentType?.substringBefore(';')?.lowercase()
        if (contentType != null && contentType !in setOf("application/x-mpegurl", "application/vnd.apple.mpegurl", "audio/x-mpegurl", "text/plain", "application/xml", "text/xml", "video/mp2t", "application/octet-stream")) {
            connection.disconnect()
            throw IllegalArgumentException("Unsupported source format")
        }
        val length = connection.contentLengthLong
        require(length <= maxBytes || length < 0) { connection.disconnect(); "Source response is too large" }
        return SourceResponse(BoundedInputStream(connection.inputStream, maxBytes) { connection.disconnect() }, contentType, length)
    }

    private fun isSafeSourceUrl(value: String): Boolean = runCatching {
        val uri = URI(value)
        uri.scheme == "https" && !uri.host.isNullOrBlank() && uri.userInfo == null && !Regex("token|secret|password|api[-_]?key|auth", RegexOption.IGNORE_CASE).containsMatchIn(uri.rawQuery.orEmpty())
    }.getOrDefault(false)

    private class BoundedInputStream(source: InputStream, private val limit: Long, private val onClose: () -> Unit) : FilterInputStream(source) {
        private var readBytes = 0L
        override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
            val count = super.read(buffer, offset, length)
            if (count > 0) { readBytes += count; if (readBytes > limit) throw IllegalArgumentException("Source response is too large") }
            return count
        }
        override fun close() { runCatching { super.close() }; onClose() }
    }
}
