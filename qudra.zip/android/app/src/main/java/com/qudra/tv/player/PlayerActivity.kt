// @polsia:user-owned — Media3 direct-origin player; the control plane never sees media bytes.
package com.qudra.tv.player

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.qudra.tv.local.LocalPlaybackStateStore
import com.qudra.tv.ui.UiStyle

class PlayerActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var model: PlayerViewModel
    private lateinit var playerView: PlayerView
    private lateinit var title: String
    private lateinit var sourceId: String
    private lateinit var autoplayPreferences: AutoplayPreferences
    private var currentEpisode: EpisodeDescriptor? = null
    private var nextEpisode: EpisodeDescriptor? = null
    private var finalEpisodeHandled = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val requestedUrl = intent.getStringExtra(EXTRA_URL) ?: return finish()
        val url = validateDirectOrigin(requestedUrl, intent.getStringExtra(EXTRA_PREFERRED_ORIGIN)) ?: run {
            Toast.makeText(this, "Playback is limited to the manifest-approved HTTPS media origin.", Toast.LENGTH_LONG).show()
            return finish()
        }
        title = intent.getStringExtra(EXTRA_TITLE) ?: "QUDRA OPEN"
        sourceId = intent.getStringExtra(EXTRA_SOURCE_ID) ?: return finish()
        autoplayPreferences = AutoplayPreferences(this)
        currentEpisode = episodeFromIntent(EXTRA_SERIES_ID, EXTRA_EPISODE_ID, EXTRA_EPISODE_ORDER, EXTRA_URL, EXTRA_PREFERRED_ORIGIN)
        nextEpisode = episodeFromIntent(EXTRA_NEXT_SERIES_ID, EXTRA_NEXT_EPISODE_ID, EXTRA_NEXT_EPISODE_ORDER, EXTRA_NEXT_URL, EXTRA_NEXT_PREFERRED_ORIGIN)
        model = PlayerViewModel(LocalPlaybackStateStore(this), sourceId)
        val root = FrameLayout(this).apply { setBackgroundColor(UiStyle.background) }
        playerView = PlayerView(this).apply { useController = true; isFocusable = true; requestFocus() }
        root.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        root.addView(TextView(this).apply { text = title; textSize = 18f; setTextColor(UiStyle.text); setPadding(24, 18, 24, 18); gravity = Gravity.TOP }, FrameLayout.LayoutParams(-1, 72))
        setContentView(root)

        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaItem(ExoMediaItem.fromUri(url), model.resumePosition())
            exo.addListener(object : androidx.media3.common.Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    Toast.makeText(this@PlayerActivity, "Playback could not start from the approved direct media origin. Check the source and retry.", Toast.LENGTH_LONG).show()
                }
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == androidx.media3.common.Player.STATE_ENDED) playNextIfAllowed(exo)
                }
            })
            exo.prepare()
            exo.playWhenReady = true
        }
    }

    private fun playNextIfAllowed(exo: ExoPlayer) {
        if (finalEpisodeHandled) return
        model.save(exo.currentPosition, exo.duration)
        val current = currentEpisode ?: run { keepFinalEpisodeStopped(exo); return }
        val candidate = nextEpisode ?: run { keepFinalEpisodeStopped(exo); return }
        val next = AutoplayPolicy.next(current, listOf(candidate), autoplayPreferences.isEnabled())
            ?: run { keepFinalEpisodeStopped(exo); return }
        val safe = validateDirectOrigin(next.directOrigin, next.preferredOrigin)
            ?: run { keepFinalEpisodeStopped(exo); return }
        sourceId = next.sourceId
        title = intent.getStringExtra(EXTRA_NEXT_TITLE) ?: title
        model = PlayerViewModel(LocalPlaybackStateStore(this), sourceId)
        exo.setMediaItem(ExoMediaItem.fromUri(safe), model.resumePosition())
        currentEpisode = next
        nextEpisode = null
        exo.prepare()
        exo.play()
    }

    private fun keepFinalEpisodeStopped(exo: ExoPlayer) {
        finalEpisodeHandled = true
        exo.playWhenReady = false
    }

    private fun episodeFromIntent(seriesKey: String, episodeKey: String, orderKey: String, urlKey: String, originKey: String): EpisodeDescriptor? {
        val seriesId = intent.getStringExtra(seriesKey) ?: return null
        val episodeId = intent.getStringExtra(episodeKey) ?: return null
        val order = intent.getIntExtra(orderKey, -1)
        val direct = intent.getStringExtra(urlKey) ?: return null
        val preferred = intent.getStringExtra(originKey) ?: return null
        if (order < 0) return null
        return EpisodeDescriptor(seriesId, intent.getStringExtra(if (urlKey == EXTRA_URL) EXTRA_SOURCE_ID else EXTRA_NEXT_SOURCE_ID) ?: return null, episodeId, order, direct, preferred)
    }

    override fun onPause() {
        player?.let { model.save(it.currentPosition, it.duration) }
        super.onPause()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_URL = "qudra.direct_url"
        const val EXTRA_PREFERRED_ORIGIN = "qudra.preferred_origin"
        const val EXTRA_TITLE = "qudra.title"
        const val EXTRA_SOURCE_ID = "qudra.source_id"
        const val EXTRA_DURATION_SECONDS = "qudra.duration_seconds"
        const val EXTRA_NEXT_URL = "qudra.next_url"
        const val EXTRA_NEXT_PREFERRED_ORIGIN = "qudra.next_preferred_origin"
        const val EXTRA_NEXT_TITLE = "qudra.next_title"
        const val EXTRA_NEXT_SOURCE_ID = "qudra.next_source_id"
        const val EXTRA_SERIES_ID = "qudra.series_id"
        const val EXTRA_EPISODE_ID = "qudra.episode_id"
        const val EXTRA_EPISODE_ORDER = "qudra.episode_order"
        const val EXTRA_NEXT_SERIES_ID = "qudra.next_series_id"
        const val EXTRA_NEXT_EPISODE_ID = "qudra.next_episode_id"
        const val EXTRA_NEXT_EPISODE_ORDER = "qudra.next_episode_order"
        const val EXTRA_CATCH_UP = "qudra.catch_up"
        const val EXTRA_TIMESHIFT = "qudra.timeshift"
    }
}
