// @polsia:user-owned — local-only Personal Source and EPG models.
package com.qudra.tv.local.source

enum class LocalMediaKind { LIVE_TV, MOVIE, SERIES, RADIO }
enum class LocalSyncState { FRESH, STALE, FAILED, UNAVAILABLE }

data class PlaylistEntry(
    val id: String,
    val title: String,
    val uri: String,
    val kind: LocalMediaKind,
    val group: String?,
    val tvgId: String?,
    val logoUri: String?,
    val catchUpSupported: Boolean = false,
    val timeshiftSupported: Boolean = false,
    val originalCategory: String? = group,
    val tvgName: String? = null,
    val seasonNumber: Int? = null,
    val episodeNumber: Int? = null,
    val seriesKey: String? = null,
    val sourceId: String = "default",
)

data class EpgChannel(val id: String, val displayName: String)
data class EpgProgramme(val channelId: String, val title: String, val description: String?, val startEpochMillis: Long, val stopEpochMillis: Long)
data class LocalCapabilities(val epg: Boolean, val nowNext: Boolean, val fullSchedule: Boolean, val catchUp: Boolean, val timeshift: Boolean)
data class LocalSourceSnapshot(
    val generation: Long,
    val media: List<PlaylistEntry>,
    val channels: List<EpgChannel>,
    val programmes: List<EpgProgramme>,
    val timezone: String?,
    val utcOffsetMinutes: Int?,
    val state: LocalSyncState,
    val capabilities: LocalCapabilities,
    val lastKnownGood: Boolean = true,
)

data class EpgState(
    val state: LocalSyncState,
    val channels: List<EpgChannel>,
    val programmes: List<EpgProgramme>,
    val timezone: String?,
    val utcOffsetMinutes: Int?,
)
