// @polsia:user-owned — Android DTOs aligned with specs/qudra/v1/openapi.yaml T3B fields.
package com.qudra.tv.data.api

import org.json.JSONArray
import org.json.JSONObject

enum class QudraPlatform { ANDROID_TV }
enum class QudraProductFamily { TV }
enum class QudraAlgorithm { P256 }
enum class QudraDeviceStatus { UNPAIRED, PAIRING_PENDING, PAIRED, REVOKED }
enum class QudraMediaClass { LIVE_TV, MOVIE, SERIES, RADIO }
enum class QudraCompatibility { PREFERRED, SUPPORTED_WITH_DEVICE_TEST, COMPATIBILITY_RISK, UNSUITABLE_AS_PRIMARY_FIXTURE }

data class DeviceRegistration(
    val publicDeviceId: String,
    val platform: QudraPlatform = QudraPlatform.ANDROID_TV,
    val productFamily: QudraProductFamily = QudraProductFamily.TV,
    val algorithm: QudraAlgorithm = QudraAlgorithm.P256,
    val publicKey: String,
    val appVersion: String,
    val androidApiLevel: Int,
    val deviceModel: String,
) {
    fun toJson() = JSONObject().apply {
        put("publicDeviceId", publicDeviceId)
        put("platform", platform.name)
        put("productFamily", productFamily.name)
        put("algorithm", algorithm.name)
        put("publicKey", publicKey)
        put("appVersion", appVersion)
        put("androidApiLevel", androidApiLevel)
        put("deviceModel", deviceModel)
    }
}

data class BootstrapChallenge(
    val id: String,
    val deviceId: String,
    val keyVersion: Int,
    val expiresAt: String,
    val attemptCount: Int,
    val maxAttempts: Int,
    val nonce: String,
    val qr: PairingQr,
) {
    companion object {
        fun parse(json: JSONObject) = BootstrapChallenge(
            id = json.getString("id"),
            deviceId = json.getString("deviceId"),
            keyVersion = json.getInt("keyVersion"),
            expiresAt = json.getString("expiresAt"),
            attemptCount = json.getInt("attemptCount"),
            maxAttempts = json.getInt("maxAttempts"),
            nonce = json.getString("nonce"),
            qr = PairingQr.parse(json.getJSONObject("qr")),
        )
    }
}

data class BootstrapResult(
    val challengeId: String,
    val deviceId: String,
    val state: String,
    val sessionToken: String,
    val sessionExpiresAt: String,
) {
    companion object {
        fun parse(json: JSONObject) = BootstrapResult(
            challengeId = json.getString("challengeId"),
            deviceId = json.getString("deviceId"),
            state = json.getString("state"),
            sessionToken = json.getString("sessionToken"),
            sessionExpiresAt = json.getString("sessionExpiresAt"),
        )
    }
}

data class DeviceView(
    val id: String,
    val customerId: String,
    val publicDeviceId: String,
    val keyVersion: Int,
    val status: QudraDeviceStatus,
    val registeredAt: String,
    val publicKeyFingerprint: String,
) {
    companion object {
        fun parse(json: JSONObject) = DeviceView(
            id = json.getString("id"), customerId = json.getString("customerId"), publicDeviceId = json.getString("publicDeviceId"),
            keyVersion = json.getInt("keyVersion"), status = QudraDeviceStatus.valueOf(json.getString("status")), registeredAt = json.getString("registeredAt"),
            publicKeyFingerprint = json.getString("publicKeyFingerprint"),
        )
    }
}

data class DeviceSession(val deviceId: String, val keyVersion: Int, val expiresAt: String, val sessionToken: String?) {
    companion object { fun parse(json: JSONObject) = DeviceSession(json.getString("deviceId"), json.getInt("keyVersion"), json.getString("expiresAt"), json.optStringOrNull("sessionToken")) }
}

data class PairingChallenge(
    val id: String,
    val deviceId: String,
    val state: String,
    val expiresAt: String,
    val attemptCount: Int,
    val maxAttempts: Int,
    val pairingCode: String,
) {
    companion object {
        fun parse(json: JSONObject) = PairingChallenge(
            json.getString("id"), json.getString("deviceId"), json.getString("state"), json.getString("expiresAt"), json.getInt("attemptCount"), json.getInt("maxAttempts"),
            json.optStringOrNull("pairingCode") ?: throw QudraApiException("Pairing response omitted its proof response"),
        )
    }
}

data class PairingQr(val id: String, val representation: String, val expiresAt: String) {
    companion object { fun parse(json: JSONObject) = PairingQr(json.getString("id"), json.getString("representation"), json.getString("expiresAt")) }
}

data class PairingResult(val challengeId: String, val deviceId: String, val state: String, val sessionToken: String?, val sessionExpiresAt: String?) {
    companion object { fun parse(json: JSONObject) = PairingResult(json.getString("challengeId"), json.getString("deviceId"), json.getString("state"), json.optStringOrNull("sessionToken"), json.optStringOrNull("sessionExpiresAt")) }
}

data class AccessView(val deviceId: String, val serverTime: String, val trialActive: Boolean, val entitlementActive: Boolean, val personalSourceAllowed: Boolean) {
    companion object { fun parse(json: JSONObject) = AccessView(json.getString("deviceId"), json.getString("serverTime"), json.getBoolean("trialActive"), json.getBoolean("entitlementActive"), json.getBoolean("personalSourceAllowed")) }
}

data class Geography(val scope: String, val regions: List<String>, val restrictions: List<String>)
data class Artwork(val url: String?, val type: String, val rightsLicenseReference: String?, val requiredAttribution: String?, val status: String, val fallbackState: String)
data class Capabilities(val directPlayback: Boolean, val epg: Boolean, val nowNext: Boolean, val fullSchedule: Boolean, val catchUp: Boolean, val timeshift: Boolean, val recording: Boolean, val castCompatibilityKnown: Boolean)
data class SourceMetadata(val description: String?, val category: String?, val genres: List<String>, val releaseYear: Int?, val durationSeconds: Double?, val contentLanguage: String?)
data class StabilityEvidence(val checkedAt: String, val method: String, val notes: String)
data class LegalEvidence(val license: String, val licenseUrl: String, val permissionEvidenceUrl: String, val attribution: String, val geography: Geography, val rightsHolder: String, val verificationStatus: String, val verifiedAt: String, val verificationMethod: String, val stabilityEvidence: StabilityEvidence)
data class SourceHealth(val status: String, val checkedAt: String, val httpStatus: Int?, val contentType: String?, val rangeSupported: Boolean?, val stabilityEvidence: StabilityEvidence)
data class Availability(val status: String, val geography: Geography, val reason: String?)
data class OriginState(val availability: String, val lastValidatedAt: String?, val preferredOrigin: String?, val fallbackOrigin: DirectOrigin?, val unavailableReason: String?)

data class Attribution(
    val rightsHolder: String,
    val attributionText: String,
    val licenseName: String,
    val licenseUrl: String,
    val restrictions: List<String>,
    val rightsEvidenceUrl: String? = null,
    val geography: Geography? = null,
)

data class MediaFormat(
    val container: String,
    val mimeType: String,
    val videoCodec: String?,
    val audioCodec: String?,
    val width: Int? = null,
    val height: Int? = null,
    val frameRate: Double? = null,
    val durationSeconds: Double? = null,
    val contentLengthBytes: Long? = null,
    val rangeSupported: Boolean? = null,
)

data class DirectOrigin(val url: String, val format: MediaFormat, val webpageEvidenceUrl: String? = null, val mediaOrigin: Boolean = true)

data class MediaItem(
    val sourceId: String,
    val title: String,
    val mediaClass: QudraMediaClass,
    val description: String?,
    val attribution: Attribution,
    val compatibility: QudraCompatibility,
    val directOrigin: DirectOrigin?,
    val preferredOrigin: String?,
    val available: Boolean,
    val availabilityReason: String?,
    val durationSeconds: Double?,
    val episodeOrder: Int?,
    val productionDesignation: String? = null,
    val metadata: SourceMetadata? = null,
    val artwork: Artwork? = null,
    val capabilities: Capabilities? = null,
    val legalEvidence: LegalEvidence? = null,
    val webpageUrl: String? = null,
    val sourceHealth: SourceHealth? = null,
    val availability: Availability? = null,
    val originState: OriginState? = null,
    val replacementSourceId: String? = null,
    val fallbackSourceId: String? = null,
    val synopsis: String? = null,
    val episodeNumber: Int? = null,
    val controlPlaneProxiesBytes: Boolean = false,
)

data class Series(
    val seriesId: String,
    val title: String,
    val episodes: List<MediaItem>,
    val description: String? = null,
    val metadata: SourceMetadata? = null,
    val artwork: Artwork? = null,
    val attribution: Attribution? = null,
    val capabilities: Capabilities? = null,
    val compatibility: QudraCompatibility? = null,
    val legalEvidence: LegalEvidence? = null,
    val webpageUrl: String? = null,
    val sourceHealth: SourceHealth? = null,
    val availability: Availability? = null,
    val originState: OriginState? = null,
    val seasonNumber: Int? = null,
)

data class OpenManifest(
    val manifestVersion: String,
    val availableWithoutEntitlement: Boolean,
    val requiresPaidEntitlement: Boolean,
    val personalSourceConfig: Boolean,
    val controlPlaneProxiesBytes: Boolean,
    val movies: List<MediaItem>,
    val series: List<Series>,
    val liveTv: List<MediaItem>,
    val radio: List<MediaItem>,
    val manifestId: String = "",
    val title: String = "QUDRA OPEN",
    val permanent: Boolean = true,
    val generatedAt: String? = null,
    val mediaClasses: List<String> = listOf("LIVE_TV", "MOVIE", "SERIES", "RADIO"),
    val testOnlyLiveTv: List<MediaItem> = emptyList(),
    val testOnlyRadio: List<MediaItem> = emptyList(),
    val epgNowNext: Boolean = false,
    val epgFullSchedule: Boolean = false,
    val epgCatchUp: Boolean = false,
    val epgNotes: String = "No electronic programme guide is available.",
    internal val rawJson: String? = null,
) {
    companion object
    fun toJson(): JSONObject = rawJson?.let { JSONObject(it) } ?: JSONObject()
}

data class Diagnostic(val code: String, val state: String, val retryable: Boolean, val message: String, val observedAt: String)

enum class SourceSyncState { IDLE, REQUESTED, SYNCING, FRESH, STALE, FAILED, UNAVAILABLE }
enum class SourceFormat { M3U, M3U8, XMLTV }
enum class CapabilityState { UNKNOWN, SUPPORTED, UNSUPPORTED }

data class SourceSyncStatus(
    val id: String,
    val sourceConfigId: String?,
    val configVersion: Int,
    val state: SourceSyncState,
    val lastSuccessAt: String?,
    val failureCode: String?,
    val epg: CapabilityState,
    val catchUp: CapabilityState,
    val timeshift: CapabilityState,
    val format: SourceFormat? = null,
    val lastAttemptAt: String? = null,
    val staleSince: String? = null,
    val lastKnownGoodGeneration: String? = null,
    val liveCount: Int = 0,
    val movieCount: Int = 0,
    val seriesCount: Int = 0,
    val radioCount: Int = 0,
    val epgChannelCount: Int = 0,
    val epgProgrammeCount: Int = 0,
    val timezone: String? = null,
    val utcOffsetMinutes: Int? = null,
) {
    companion object {
        fun parse(json: JSONObject) = SourceSyncStatus(
            json.getString("id"), json.optStringOrNull("sourceConfigId"), json.getInt("configVersion"), SourceSyncState.valueOf(json.getString("state")), json.optStringOrNull("lastSuccessAt"), json.optStringOrNull("failureCode"),
            CapabilityState.valueOf(json.optJSONObject("capabilities")?.optString("epg", "UNKNOWN") ?: "UNKNOWN"), CapabilityState.valueOf(json.optJSONObject("capabilities")?.optString("catchUp", "UNKNOWN") ?: "UNKNOWN"), CapabilityState.valueOf(json.optJSONObject("capabilities")?.optString("timeshift", "UNKNOWN") ?: "UNKNOWN"),
            json.optStringOrNull("format")?.let { SourceFormat.valueOf(it) }, json.optStringOrNull("lastAttemptAt"), json.optStringOrNull("staleSince"), json.optStringOrNull("lastKnownGoodGeneration"), json.optJSONObject("counts")?.optInt("live", 0) ?: 0, json.optJSONObject("counts")?.optInt("movies", 0) ?: 0, json.optJSONObject("counts")?.optInt("series", 0) ?: 0, json.optJSONObject("counts")?.optInt("radio", 0) ?: 0, json.optJSONObject("counts")?.optInt("epgChannels", 0) ?: 0, json.optJSONObject("counts")?.optInt("epgProgrammes", 0) ?: 0, json.optStringOrNull("timezone"), json.optIntOrNull("utcOffsetMinutes"),
        )
    }
}

data class SourceCapability(val sourceConfigId: String, val state: SourceSyncState, val epg: CapabilityState, val catchUp: CapabilityState, val timeshift: CapabilityState)

data class SourceConfig(
    val id: String,
    val label: String,
    val endpointUrl: String?,
    val epgUrl: String?,
    val sourceTimezone: String?,
    val utcOffsetMinutes: Int?,
    val slot: Int?,
    val hasSecret: Boolean,
    val configVersion: Int,
) {
    companion object {
        fun parse(json: JSONObject) = SourceConfig(json.getString("id"), json.getString("label"), json.optStringOrNull("endpointUrl"), json.optStringOrNull("epgUrl"), json.optStringOrNull("sourceTimezone"), json.optIntOrNull("utcOffsetMinutes"), json.optIntOrNull("slot"), json.optBoolean("hasSecret"), json.optInt("configVersion", 1))
    }
}

data class ClaimResult(val challengeId: String, val deviceId: String, val customerId: String, val linked: Boolean) {
    companion object { fun parse(json: JSONObject) = ClaimResult(json.getString("challengeId"), json.getString("deviceId"), json.getString("customerId"), json.getBoolean("linked")) }
}

private fun JSONObject.optStringOrNull(name: String): String? = if (isNull(name)) null else optString(name).takeIf { it.isNotBlank() }
private fun JSONObject.optDoubleOrNull(name: String): Double? = if (isNull(name)) null else optDouble(name).takeIf { !it.isNaN() }
private fun JSONObject.optIntOrNull(name: String): Int? = if (isNull(name) || !has(name)) null else optInt(name)
private fun JSONObject.optLongOrNull(name: String): Long? = if (isNull(name) || !has(name)) null else optLong(name)
private fun JSONObject.optObject(name: String): JSONObject? = if (isNull(name)) null else optJSONObject(name)
private fun JSONArray.strings(): List<String> = (0 until length()).mapNotNull { optString(it).takeIf(String::isNotBlank) }

private fun JSONObject.parseGeography(name: String = "geography"): Geography {
    val value = optObject(name) ?: return Geography("UNKNOWN", emptyList(), emptyList())
    return Geography(value.optString("scope", "UNKNOWN"), value.optJSONArray("regions")?.strings().orEmpty(), value.optJSONArray("restrictions")?.strings().orEmpty())
}

private fun JSONObject.parseArtwork(): Artwork? = optObject("artwork")?.let { value ->
    Artwork(value.optStringOrNull("url"), value.optString("type", "NONE"), value.optStringOrNull("rightsLicenseReference"), value.optStringOrNull("requiredAttribution"), value.optString("status", "ABSENT"), value.optString("fallbackState", "NONE"))
}

private fun JSONObject.parseMetadata(): SourceMetadata {
    val value = optObject("metadata") ?: JSONObject()
    return SourceMetadata(value.optStringOrNull("description"), value.optStringOrNull("category"), value.optJSONArray("genres")?.strings().orEmpty(), value.optIntOrNull("releaseYear"), value.optDoubleOrNull("durationSeconds"), value.optStringOrNull("contentLanguage"))
}

private fun JSONObject.parseCapabilities(): Capabilities {
    val value = optObject("capabilities") ?: JSONObject()
    return Capabilities(value.optBoolean("directPlayback"), value.optBoolean("epg"), value.optBoolean("nowNext"), value.optBoolean("fullSchedule"), value.optBoolean("catchUp"), value.optBoolean("timeshift"), value.optBoolean("recording"), value.optBoolean("castCompatibilityKnown"))
}

private fun JSONObject.parseStability(): StabilityEvidence {
    val value = optObject("stabilityEvidence") ?: JSONObject()
    return StabilityEvidence(value.optString("checkedAt", ""), value.optString("method", "MANUAL_REVIEW"), value.optString("notes", "No additional stability evidence supplied."))
}

private fun JSONObject.parseLegalEvidence(): LegalEvidence? = optObject("legalEvidence")?.let { value ->
    LegalEvidence(value.optString("license"), value.optString("licenseUrl"), value.optString("permissionEvidenceUrl"), value.optString("attribution"), value.parseGeography(), value.optString("rightsHolder"), value.optString("verificationStatus"), value.optString("verifiedAt"), value.optString("verificationMethod"), value.parseStability())
}

private fun JSONObject.parseAttribution(): Attribution {
    val value = optObject("attribution") ?: JSONObject()
    return Attribution(value.optString("rightsHolder"), value.optString("attributionText"), value.optString("licenseName"), value.optString("licenseUrl"), value.optJSONArray("restrictions")?.strings().orEmpty(), value.optStringOrNull("rightsEvidenceUrl"), value.parseGeography())
}

private fun JSONObject.parseSourceHealth(): SourceHealth? = optObject("sourceHealth")?.let { value ->
    SourceHealth(value.optString("status", "UNKNOWN"), value.optString("checkedAt", ""), value.optIntOrNull("httpStatus"), value.optStringOrNull("contentType"), if (value.isNull("rangeSupported")) null else value.optBoolean("rangeSupported"), value.parseStability())
}

private fun JSONObject.parseAvailability(): Availability? = optObject("availability")?.let { value ->
    Availability(value.optString("status", "UNAVAILABLE"), value.parseGeography(), value.optStringOrNull("reason"))
}

private fun JSONObject.parseDirectOrigin(name: String = "directOrigin"): DirectOrigin? = optObject(name)?.let { value ->
    val format = value.optObject("format") ?: JSONObject()
    DirectOrigin(value.optString("url"), MediaFormat(format.optString("container"), format.optString("mimeType"), format.optStringOrNull("videoCodec"), format.optStringOrNull("audioCodec"), format.optIntOrNull("width"), format.optIntOrNull("height"), format.optDoubleOrNull("frameRate"), format.optDoubleOrNull("durationSeconds"), format.optLongOrNull("contentLengthBytes"), if (format.isNull("rangeSupported")) null else format.optBoolean("rangeSupported")), value.optStringOrNull("webpageEvidenceUrl"), value.optBoolean("mediaOrigin", true))
}

private fun JSONObject.parseOriginState(): OriginState? = optObject("originState")?.let { value ->
    OriginState(value.optString("availability", "UNAVAILABLE"), value.optStringOrNull("lastValidatedAt"), value.optStringOrNull("preferredOrigin"), value.parseDirectOrigin("fallbackOrigin"), value.optStringOrNull("unavailableReason"))
}

private fun JSONObject.parseItem(): MediaItem {
    val metadata = parseMetadata()
    val originState = parseOriginState()
    val availability = parseAvailability()
    return MediaItem(
        sourceId = getString("sourceId"), title = getString("title"), mediaClass = QudraMediaClass.valueOf(getString("mediaClass")), description = metadata.description,
        attribution = parseAttribution(), compatibility = QudraCompatibility.valueOf(optObject("compatibility")?.optString("classification") ?: "COMPATIBILITY_RISK"), directOrigin = parseDirectOrigin(), preferredOrigin = originState?.preferredOrigin,
        available = availability?.status == "AVAILABLE", availabilityReason = availability?.reason ?: originState?.unavailableReason, durationSeconds = metadata.durationSeconds, episodeOrder = optIntOrNull("episodeOrder"),
        productionDesignation = optStringOrNull("productionDesignation"), metadata = metadata, artwork = parseArtwork(), capabilities = parseCapabilities(), legalEvidence = parseLegalEvidence(), webpageUrl = optStringOrNull("webpageUrl"), sourceHealth = parseSourceHealth(),
        availability = availability, originState = originState, replacementSourceId = optObject("replacement")?.optStringOrNull("sourceId"), fallbackSourceId = optObject("fallback")?.optStringOrNull("sourceId"), synopsis = optStringOrNull("synopsis"), episodeNumber = optIntOrNull("episodeNumber"), controlPlaneProxiesBytes = optBoolean("controlPlaneProxiesBytes"),
    )
}

private fun JSONObject.parseSeries(): Series {
    val episodesJson = getJSONArray("episodes")
    return Series(
        seriesId = getString("seriesId"), title = getString("title"), episodes = (0 until episodesJson.length()).map { episodesJson.getJSONObject(it).parseItem() }, description = optStringOrNull("description"), metadata = parseMetadata(), artwork = parseArtwork(), attribution = parseAttribution(), capabilities = parseCapabilities(),
        compatibility = optObject("compatibility")?.optString("classification")?.let { QudraCompatibility.valueOf(it) }, legalEvidence = parseLegalEvidence(), webpageUrl = optStringOrNull("webpageUrl"), sourceHealth = parseSourceHealth(), availability = parseAvailability(), originState = parseOriginState(), seasonNumber = optObject("season")?.optIntOrNull("seasonNumber"),
    )
}

fun OpenManifest.Companion.parse(json: JSONObject): OpenManifest {
    val register = json.optJSONArray("sourceRegister") ?: JSONArray()
    val byId = (0 until register.length()).associateBy({ register.getJSONObject(it).getString("sourceId") }, { register.getJSONObject(it).parseItem() })
    val movieIds = json.optJSONArray("movies")?.strings().orEmpty()
    val seriesJson = json.optJSONArray("series") ?: JSONArray()
    val testOnly = json.optObject("testOnly")
    val epg = json.optObject("epg")
    return OpenManifest(
        manifestVersion = json.getString("manifestVersion"), availableWithoutEntitlement = json.getBoolean("availableWithoutEntitlement"), requiresPaidEntitlement = json.getBoolean("requiresPaidEntitlement"), personalSourceConfig = json.getBoolean("personalSourceConfig"), controlPlaneProxiesBytes = json.getBoolean("controlPlaneProxiesBytes"), movies = movieIds.mapNotNull(byId::get),
        series = (0 until seriesJson.length()).map { seriesJson.getJSONObject(it).parseSeries() }, liveTv = json.optJSONArray("liveTv")?.let { value -> (0 until value.length()).map { value.getJSONObject(it).parseItem() } }.orEmpty(), radio = json.optJSONArray("radio")?.let { value -> (0 until value.length()).map { value.getJSONObject(it).parseItem() } }.orEmpty(),
        manifestId = json.optString("manifestId"), title = json.optString("title", "QUDRA OPEN"), permanent = json.optBoolean("permanent", true), generatedAt = json.optStringOrNull("generatedAt"), mediaClasses = json.optJSONArray("mediaClasses")?.strings().orEmpty(), testOnlyLiveTv = testOnly?.optJSONArray("liveTv")?.let { value -> (0 until value.length()).map { value.getJSONObject(it).parseItem() } }.orEmpty(), testOnlyRadio = testOnly?.optJSONArray("radio")?.let { value -> (0 until value.length()).map { value.getJSONObject(it).parseItem() } }.orEmpty(), epgNowNext = epg?.optBoolean("nowNext") ?: false, epgFullSchedule = epg?.optBoolean("fullSchedule") ?: false, epgCatchUp = epg?.optBoolean("catchUp") ?: false, epgNotes = epg?.optString("notes", "No electronic programme guide is available.") ?: "No electronic programme guide is available.", rawJson = json.toString(),
    )
}

class QudraApiException(message: String, val statusCode: Int? = null) : Exception(message)

fun bootstrapCanonicalPayload(
    challengeId: String,
    nonce: String,
    deviceId: String,
    keyVersion: Int,
): String = "$challengeId:$nonce:$deviceId:$keyVersion"
