// @polsia:user-owned — optional in-activity session for TV transport controls.
package com.qudra.tv.player

import android.content.Context
import androidx.media3.common.Player
import androidx.media3.session.MediaSession

class MediaSessionCoordinator(context: Context, player: Player) {
    val session: MediaSession = MediaSession.Builder(context, player).setId("qudra-tv-foreground").build()
    fun release() = session.release()
}
