// @polsia:user-owned — client-safe diagnostic display only.
package com.qudra.tv.ui.home

import android.app.Activity
import android.widget.ScrollView
import com.qudra.tv.data.api.Diagnostic
import com.qudra.tv.ui.UiStyle

object DiagnosticsScreen {
    fun show(activity: Activity, diagnostics: List<Diagnostic>, onBack: () -> Unit) {
        val root = UiStyle.column(activity)
        root.addView(UiStyle.title(activity, "Diagnostics", 32f))
        root.addView(UiStyle.body(activity, "Only server-approved client-safe codes are shown. Session tokens, keys, credentials, and private media details are deliberately redacted."))
        if (diagnostics.isEmpty()) root.addView(UiStyle.body(activity, "No current diagnostic events."))
        diagnostics.forEach { item -> root.addView(UiStyle.body(activity, "${item.state} · ${item.code}${if (item.retryable) " · retryable" else ""}\n${item.message}\n${item.observedAt}")) }
        root.addView(UiStyle.button(activity, "Back to QUDRA") { onBack() })
        activity.setContentView(ScrollView(activity).apply { addView(root) })
    }
}
