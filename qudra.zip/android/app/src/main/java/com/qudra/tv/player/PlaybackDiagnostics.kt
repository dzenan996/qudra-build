// @polsia:user-owned — local redacted playback state taxonomy.
package com.qudra.tv.player

enum class PlaybackDiagnostic { LOADING, PLAYING, PAUSED, RETRYING, PLAYBACK_FAILURE, UNSUPPORTED_FORMAT, SELECTED_STREAM_UNAVAILABLE, CATCH_UP_UNSUPPORTED, TIMESHIFT_UNSUPPORTED }
