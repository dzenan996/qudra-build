// @polsia:user-owned — ordered authority, manifest, access, and diagnostics orchestration.
package com.qudra.tv.data

import android.content.Context
import android.os.Build
import com.qudra.tv.BuildConfig
import com.qudra.tv.data.api.AccessView
import com.qudra.tv.data.api.DeviceRegistration
import com.qudra.tv.data.api.DeviceView
import com.qudra.tv.data.api.Diagnostic
import com.qudra.tv.data.api.OpenManifest
import com.qudra.tv.data.api.PairingQr
import com.qudra.tv.data.api.QudraApiClient
import com.qudra.tv.data.api.QudraApiException
import com.qudra.tv.data.api.ProofHeaders
import com.qudra.tv.data.api.SourceConfig
import com.qudra.tv.data.api.SourceFormat
import com.qudra.tv.data.api.SourceSyncState
import com.qudra.tv.local.source.CatalogueStore
import com.qudra.tv.local.source.LocalMediaKind
import com.qudra.tv.local.source.SourceConfigStore
import com.qudra.tv.local.source.SourceDownloadClient
import com.qudra.tv.local.source.SourceImportCoordinator
import com.qudra.tv.local.source.EpgStore
import com.qudra.tv.security.SourceSecretStore
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.qudra.tv.data.api.bootstrapCanonicalPayload
import com.qudra.tv.security.DeviceIdentityStore
import com.qudra.tv.security.DeviceSessionStore
import com.qudra.tv.security.SessionRenewal
import com.qudra.tv.security.RenewedSession
import com.qudra.tv.security.StoredDeviceSession
import java.util.UUID

class PendingPairing internal constructor(
    val challengeId: String,
    val qr: PairingQr,
    val expiresAt: String,
    val attempts: Int,
    val maxAttempts: Int,
    internal val keyVersion: Int,
    internal val accountCookie: String,
    internal val response: String,
    internal val deviceId: String,
)
data class HomeData(
    val manifest: OpenManifest,
    val access: AccessView,
    val device: DeviceView?,
    val diagnostics: List<Diagnostic>,
    val fromCache: Boolean = false,
    val sourceConfigs: List<SourceConfig> = emptyList(),
    val activeSourceId: String? = null,
    val sync: List<com.qudra.tv.data.api.SourceSyncStatus> = emptyList(),
)

class PendingBootstrap internal constructor(
    val qr: PairingQr,
    val expiresAt: String,
    internal val nonce: String,
    internal val keyVersion: Int,
    internal val deviceId: String,
)

class QudraRepository(context: Context) {
    private val appContext = context.applicationContext
    private val identity = DeviceIdentityStore(context)
    private val sessions = DeviceSessionStore(context)
    private val openCache = OpenManifestCache(context)
    private val api = QudraApiClient(BuildConfig.QUDRA_API_BASE_URL)
    private val sourceStore = SourceConfigStore(context)
    private val sourceSecrets = SourceSecretStore(context)
    private val catalogue = CatalogueStore(appContext)
    private val epg = EpgStore(appContext)

    fun beginBootstrap(): PendingBootstrap {
        val registration = DeviceRegistration(
            publicDeviceId = identity.publicDeviceId,
            publicKey = identity.publicKeyPem,
            appVersion = BuildConfig.VERSION_NAME,
            androidApiLevel = Build.VERSION.SDK_INT,
            deviceModel = identity.deviceModel,
        )
        val challenge = api.createBootstrapChallenge(registration)
        require(challenge.deviceId.isNotBlank() && challenge.keyVersion > 0) {
            "Server did not return a valid Device binding"
        }
        require(challenge.qr.id == challenge.id && challenge.qr.representation == challenge.id) {
            "QR representation is not the opaque server challenge ID"
        }
        require(challenge.nonce.isNotBlank()) { "Server did not return a bootstrap nonce" }
        return PendingBootstrap(
            qr = challenge.qr,
            expiresAt = challenge.expiresAt,
            nonce = challenge.nonce,
            keyVersion = challenge.keyVersion,
            deviceId = challenge.deviceId,
        )
    }

    fun completeBootstrap(pending: PendingBootstrap) {
        val signature = identity.sign(
            bootstrapCanonicalPayload(
                challengeId = pending.qr.id,
                nonce = pending.nonce,
                deviceId = pending.deviceId,
                keyVersion = pending.keyVersion,
            ),
        )
        val result = api.completeBootstrapChallenge(pending.qr.id, pending.nonce, signature)
        require(result.state == "PAIRED" && result.deviceId == pending.deviceId) {
            "Bootstrap did not complete"
        }
        sessions.write(
            StoredDeviceSession(
                pending.deviceId,
                pending.keyVersion,
                result.sessionToken,
                result.sessionExpiresAt,
            ),
        )
    }

    @Deprecated("Use beginBootstrap; retained for optional account claim compatibility")
    fun beginPairing(email: String, password: String): PendingPairing {
        val accountCookie = api.signIn(email, password)
        val registration = DeviceRegistration(
            publicDeviceId = identity.publicDeviceId,
            publicKey = identity.publicKeyPem,
            appVersion = BuildConfig.VERSION_NAME,
            androidApiLevel = Build.VERSION.SDK_INT,
            deviceModel = identity.deviceModel,
        )
        val device = api.registerDevice(accountCookie, registration)
        require(device.publicDeviceId == identity.publicDeviceId) { "Server returned an unexpected device identity" }
        require(device.publicKeyFingerprint == identity.fingerprint) { "Server device key fingerprint mismatch" }

        val challengeNonce = UUID.randomUUID().toString()
        val proof = proof(device.id, device.keyVersion, challengeNonce)
        val challenge = api.createPairingChallenge(accountCookie, device.id, device.keyVersion, proof)
        val qr = api.getPairingQr(accountCookie, challenge.id, proof)
        require(isSafeQrPayload(qr) && qr.id == challenge.id && qr.representation == challenge.id) { "QR representation is not the server challenge ID" }

        return PendingPairing(challenge.id, qr, challenge.expiresAt, challenge.attemptCount, challenge.maxAttempts, device.keyVersion, accountCookie, challenge.pairingCode, device.id)
    }

    fun completePairing(pending: PendingPairing) {
        // The response secret is sent only to the existing account-authorized completion route.
        val result = api.completePairing(pending.accountCookie, pending.challengeId, pending.response)
        require(result.state == "PAIRED" && result.deviceId == pending.deviceId) { "Pairing did not complete" }
        val token = result.sessionToken ?: throw IllegalStateException("Pairing did not issue a device session")
        val expiry = result.sessionExpiresAt ?: throw IllegalStateException("Pairing did not issue a session expiry")
        sessions.write(StoredDeviceSession(pending.deviceId, pending.keyVersion, token, expiry))
    }

    fun loadHome(): HomeData {
        val session = requireSession()
        return try {
            val renewed = api.renewSession(session.token, session.deviceId)
            val activeSession = SessionRenewal.apply(
                session,
                RenewedSession(renewed.deviceId, renewed.keyVersion, renewed.expiresAt, renewed.sessionToken),
            )
            sessions.write(activeSession)
            val manifest = api.getManifest(activeSession.token)
            require(manifest.isSafeOpen()) { "QUDRA OPEN contract invariants were not satisfied" }
            openCache.save(manifest)
            val access = api.getAccess(activeSession.token, activeSession.deviceId)
            require(OpenEntitlementPolicy.isOpenAvailable(manifest, access)) { "QUDRA OPEN contract invariants were not satisfied" }
            val configs = api.getSourceConfigs(activeSession.token, activeSession.deviceId)
            sourceStore.save(configs)
            val active = api.getActiveSource(activeSession.token, activeSession.deviceId)
            if (active.first == "QUDRA_OPEN") sourceStore.fallBackToOpen() else sourceStore.setActive(active.second)
            HomeData(manifest, access, api.getDevice(activeSession.token, activeSession.deviceId), api.getDiagnostics(activeSession.token, activeSession.deviceId), sourceConfigs = configs, activeSourceId = active.second, sync = api.getSync(activeSession.token, activeSession.deviceId))
        } catch (error: Throwable) {
            if (error is QudraApiException && (error.statusCode == 401 || error.statusCode == 403 || error.statusCode == 409)) {
                sessions.clear()
                throw error
            }
            if (error is IllegalArgumentException && error.message == "Device key version mismatch") {
                sessions.clear()
                throw QudraApiException("Device key version mismatch", 409)
            }
            if (!isTemporaryCloudFailure(error)) throw error
            val cached = openCache.read()?.takeIf(OpenManifest::isSafeOpen)
                ?: throw QudraApiException("QUDRA OPEN manifest is unavailable", 503)
            HomeData(
                manifest = cached,
                access = AccessView(session.deviceId, "offline", trialActive = false, entitlementActive = false, personalSourceAllowed = false),
                device = null,
                diagnostics = emptyList(),
                fromCache = true,
                sourceConfigs = sourceStore.read(),
                activeSourceId = sourceStore.activeId(),
            )
        }
    }

    fun currentSession(): StoredDeviceSession? = sessions.read()
    fun clearSession() = sessions.clear()
    fun sourceConfigs(): List<SourceConfig> = sourceStore.read()
    fun activeSource(): SourceConfig? = sourceStore.active()
    fun createSource(label: String, endpointUrl: String?, epgUrl: String?, timezone: String?, offsetMinutes: Int?, secret: String?, slot: Int?): SourceConfig {
        val session = requireSession()
        require(sourceStore.read().size < 2) { "A TV may have at most two Personal Sources" }
        val config = api.createSource(session.token, session.deviceId, label, endpointUrl, epgUrl, timezone, offsetMinutes, secret, slot)
        if (!secret.isNullOrBlank()) sourceSecrets.put(config.id, secret)
        sourceStore.upsert(config)
        scheduleRefresh(config)
        return config
    }
    fun updateSource(config: SourceConfig, label: String, endpointUrl: String?, epgUrl: String?, timezone: String?, offsetMinutes: Int?, secret: String?, clearSecret: Boolean = false): SourceConfig {
        val session = requireSession(); val updated = api.updateSource(session.token, session.deviceId, config, label, endpointUrl, epgUrl, timezone, offsetMinutes, secret, clearSecret)
        if (clearSecret) sourceSecrets.remove(config.id) else if (!secret.isNullOrBlank()) sourceSecrets.put(config.id, secret)
        sourceStore.upsert(updated); return updated
    }
    fun deleteSource(config: SourceConfig) { val session = requireSession(); api.deleteSource(session.token, session.deviceId, config); sourceSecrets.remove(config.id); sourceStore.remove(config.id); if (sourceStore.activeId() == config.id) sourceStore.fallBackToOpen() }
    fun activateSource(config: SourceConfig?) { val session = requireSession(); if (config != null) require(sourceStore.read().any { it.id == config.id }); api.selectActiveSource(session.token, session.deviceId, config?.id); if (config == null) sourceStore.fallBackToOpen() else sourceStore.setActive(config.id) }
    fun refreshSource(config: SourceConfig, cancelled: () -> Boolean = { false }) {
        val session = requireSession()
        val access = api.getAccess(session.token, session.deviceId)
        require(access.personalSourceAllowed) { "Personal Source entitlement is not active" }
        val endpoint = config.endpointUrl ?: throw IllegalArgumentException("Source has no playlist URL")
        val hadLastKnownGood = listOf(LocalMediaKind.LIVE_TV, LocalMediaKind.MOVIE, LocalMediaKind.SERIES, LocalMediaKind.RADIO).sumOf { catalogue.count(it, config.id) } > 0
        val snapshot = try { SourceImportCoordinator(SourceDownloadClient(), catalogue, epg).importWithRetry(config.id, endpoint, config.epgUrl, config.sourceTimezone, config.utcOffsetMinutes, sourceSecrets.get(config.id), cancelled = cancelled) } catch (error: Throwable) {
            if (!hadLastKnownGood) { runCatching { api.selectActiveSource(session.token, session.deviceId, null) }; sourceStore.fallBackToOpen() }
            throw error
        }
        val counts = org.json.JSONObject().apply { put("live", snapshot.media.count { it.kind == LocalMediaKind.LIVE_TV }); put("movies", snapshot.media.count { it.kind == LocalMediaKind.MOVIE }); put("series", snapshot.media.count { it.kind == LocalMediaKind.SERIES }); put("radio", snapshot.media.count { it.kind == LocalMediaKind.RADIO }); put("epgChannels", snapshot.channels.size); put("epgProgrammes", snapshot.programmes.size) }
        val capabilities = org.json.JSONObject().apply { put("epg", if (snapshot.capabilities.epg) "SUPPORTED" else "UNSUPPORTED"); put("catchUp", if (snapshot.capabilities.catchUp) "SUPPORTED" else "UNSUPPORTED"); put("timeshift", if (snapshot.capabilities.timeshift) "SUPPORTED" else "UNSUPPORTED") }
        api.reportSync(session.token, session.deviceId, config.id, config.configVersion, SourceSyncState.FRESH, if (endpoint.endsWith(".m3u8", true)) SourceFormat.M3U8 else SourceFormat.M3U, counts, capabilities, config.sourceTimezone, config.utcOffsetMinutes, snapshot.generation.toString())
    }
    fun scheduleRefresh(config: SourceConfig) {
        val endpoint = config.endpointUrl ?: return
        val request = OneTimeWorkRequestBuilder<com.qudra.tv.local.source.SourceRefreshWorker>().setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).setInputData(Data.Builder().putString("sourceId", config.id).putString("playlistUrl", endpoint).putString("epgUrl", config.epgUrl).putString("timezone", config.sourceTimezone).putInt("offsetMinutes", config.utcOffsetMinutes ?: 0).build()).build()
        WorkManager.getInstance(appContext).enqueueUniqueWork("qudra-tv-refresh-${config.id}", ExistingWorkPolicy.REPLACE, request)
    }
    fun localCatalogue(kind: LocalMediaKind, category: String? = null, offset: Int = 0, limit: Int = 100) = catalogue.query(kind, category, offset, limit, sourceStore.activeId())
    fun localCategories(kind: LocalMediaKind) = catalogue.categories(kind, sourceStore.activeId())
    fun localEpg(sourceId: String) = epg.state(sourceId)
    fun localNowNext(sourceId: String, channelId: String) = epg.nowNext(sourceId, channelId)
    fun localGrid(sourceId: String, from: Long, until: Long, channelId: String? = null) = epg.grid(sourceId, from, until, channelId)

    private fun requireSession(): StoredDeviceSession = sessions.read() ?: throw QudraApiException("This TV must be paired before QUDRA OPEN can be loaded", 403)
    private fun proof(deviceId: String, keyVersion: Int, challenge: String): ProofHeaders = ProofHeaders(deviceId, keyVersion, challenge, identity.sign("$deviceId:$challenge:$keyVersion"), UUID.randomUUID().toString())
}

fun isSafeQrPayload(qr: PairingQr): Boolean =
    qr.id.isNotBlank() && qr.representation == qr.id && !qr.representation.contains("http", ignoreCase = true)

private fun OpenManifest.isSafeOpen(): Boolean =
    manifestVersion == "3.0.0-t3b" && permanent && availableWithoutEntitlement && !requiresPaidEntitlement && !personalSourceConfig && !controlPlaneProxiesBytes
