// @polsia:user-owned — source-scoped XMLTV generations with NOW/NEXT and grid queries.
package com.qudra.tv.local.source

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class EpgStore(context: Context) : SQLiteOpenHelper(context, "qudra_tv_epg.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE generations (id INTEGER PRIMARY KEY AUTOINCREMENT, source_id TEXT NOT NULL, state TEXT NOT NULL, timezone TEXT, offset_minutes INTEGER, updated_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE channels (generation_id INTEGER NOT NULL, id TEXT NOT NULL, display_name TEXT NOT NULL)")
        db.execSQL("CREATE TABLE programmes (generation_id INTEGER NOT NULL, channel_id TEXT NOT NULL, title TEXT NOT NULL, description TEXT, start_ms INTEGER NOT NULL, stop_ms INTEGER NOT NULL)")
        indexes(db)
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) { if (oldVersion < 2) { db.execSQL("ALTER TABLE channels ADD COLUMN generation_id INTEGER NOT NULL DEFAULT 0"); db.execSQL("ALTER TABLE programmes ADD COLUMN generation_id INTEGER NOT NULL DEFAULT 0"); db.execSQL("CREATE TABLE IF NOT EXISTS generations (id INTEGER PRIMARY KEY AUTOINCREMENT, source_id TEXT NOT NULL, state TEXT NOT NULL, timezone TEXT, offset_minutes INTEGER, updated_at INTEGER NOT NULL)"); indexes(db) } }
    private fun indexes(db: SQLiteDatabase) { db.execSQL("CREATE INDEX IF NOT EXISTS epg_now_next_idx ON programmes(generation_id, channel_id, start_ms, stop_ms)"); db.execSQL("CREATE INDEX IF NOT EXISTS epg_grid_idx ON programmes(generation_id, start_ms, stop_ms)") }
    fun replace(sourceId: String, snapshot: Pair<List<EpgChannel>, List<EpgProgramme>>, timezone: String? = null, offsetMinutes: Int? = null): Long {
        val db = writableDatabase
        db.beginTransaction()
        return try {
            db.update("generations", ContentValues().apply { put("state", "RETIRED") }, "source_id = ? AND state = ?", arrayOf(sourceId, "ACTIVE"))
            val generation = db.insertOrThrow("generations", null, ContentValues().apply { put("source_id", sourceId); put("state", "ACTIVE"); put("timezone", timezone); put("offset_minutes", offsetMinutes); put("updated_at", System.currentTimeMillis()) })
            snapshot.first.forEach { channel -> db.insertOrThrow("channels", null, ContentValues().apply { put("generation_id", generation); put("id", channel.id); put("display_name", channel.displayName) }) }
            snapshot.second.chunked(500).forEach { batch -> batch.forEach { programme -> db.insertOrThrow("programmes", null, ContentValues().apply { put("generation_id", generation); put("channel_id", programme.channelId); put("title", programme.title); put("description", programme.description); put("start_ms", programme.startEpochMillis); put("stop_ms", programme.stopEpochMillis) }) } }
            db.setTransactionSuccessful(); generation
        } finally { db.endTransaction() }
    }
    fun markStale(sourceId: String) { writableDatabase.update("generations", ContentValues().apply { put("state", "STALE") }, "source_id = ? AND state = ?", arrayOf(sourceId, "ACTIVE")) }
    fun nowNext(sourceId: String, channelId: String, now: Long = System.currentTimeMillis()): List<EpgProgramme> = query(sourceId, "channel_id = ? AND stop_ms >= ?", arrayOf(channelId, now.toString()), "start_ms ASC", "2")
    fun grid(sourceId: String, from: Long, until: Long, channelId: String? = null, limit: Int = 500): List<EpgProgramme> = query(sourceId, "stop_ms > ? AND start_ms < ?" + if (channelId == null) "" else " AND channel_id = ?", listOf(from.toString(), until.toString(), channelId).filterNotNull().toTypedArray(), "start_ms ASC", limit.toString())
    fun state(sourceId: String): EpgState {
        val generation = readableDatabase.query("generations", arrayOf("id", "state", "timezone", "offset_minutes"), "source_id = ?", arrayOf(sourceId), null, null, "updated_at DESC", "1").use { if (it.moveToFirst()) listOf(it.getLong(0), it.getString(1), it.getStringOrNull(2), it.getIntOrNull(3)) else null } ?: return EpgState(LocalSyncState.UNAVAILABLE, emptyList(), emptyList(), null, null)
        val channels = readableDatabase.query("channels", arrayOf("id", "display_name"), "generation_id = ?", arrayOf(generation[0].toString()), null, null, "display_name ASC", null).use { cursor -> buildList { while (cursor.moveToNext()) add(EpgChannel(cursor.getString(0), cursor.getString(1))) } }
        return EpgState(if (generation[1] == "ACTIVE") LocalSyncState.FRESH else LocalSyncState.STALE, channels, emptyList(), generation[2] as String?, generation[3] as Int?)
    }
    private fun query(sourceId: String, extra: String, args: Array<String>, order: String, limit: String): List<EpgProgramme> {
        val result = mutableListOf<EpgProgramme>(); val generation = readableDatabase.query("generations", arrayOf("id"), "source_id = ? AND state = ?", arrayOf(sourceId, "ACTIVE"), null, null, "updated_at DESC", "1").use { if (it.moveToFirst()) it.getLong(0) else return result }
        readableDatabase.query("programmes", arrayOf("channel_id", "title", "description", "start_ms", "stop_ms"), "generation_id = ? AND $extra", arrayOf(generation.toString()) + args, null, null, order, limit).use { cursor -> while (cursor.moveToNext()) result += EpgProgramme(cursor.getString(0), cursor.getString(1), cursor.getStringOrNull(2), cursor.getLong(3), cursor.getLong(4)) }; return result
    }
    private fun android.database.Cursor.getStringOrNull(index: Int): String? = if (isNull(index)) null else getString(index)
    private fun android.database.Cursor.getIntOrNull(index: Int): Int? = if (isNull(index)) null else getInt(index)
}
