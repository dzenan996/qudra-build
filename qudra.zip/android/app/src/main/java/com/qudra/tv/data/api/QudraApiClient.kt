// @polsia:user-owned — HTTPS-only REST client for QUDRA device-first and legacy routes.
package com.qudra.tv.data.api

import android.util.Base64
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class QudraApiClient(private val baseUrl: String) {
    init {
        require(baseUrl.startsWith("https://")) { "QUDRA cloud calls require HTTPS" }
    }

    private data class Response(val status: Int, val body: String, val cookies: String?)

    private fun request(
        method: String,
        path: String,
        body: JSONObject? = null,
        cookie: String? = null,
        headers: Map<String, String> = emptyMap(),
    ): Response {
        val connection = (URL(baseUrl.trimEnd('/') + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 12_000
            readTimeout = 20_000
            useCaches = false
            setRequestProperty("Accept", "application/json")
            cookie?.let { setRequestProperty("Cookie", it) }
            headers.forEach { (name, value) -> setRequestProperty(name, value) }
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
        }
        body?.let { connection.outputStream.use { stream -> stream.write(it.toString().toByteArray(Charsets.UTF_8)) } }
        val status = connection.responseCode
        val input = if (status in 200..299) connection.inputStream else connection.errorStream
        val responseBody = input?.use { stream -> BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText() } ?: ""
        val cookies = connection.headerFields.entries.firstOrNull { it.key?.equals("Set-Cookie", ignoreCase = true) == true }
            ?.value?.joinToString("; ") { it.substringBefore(';') }
        connection.disconnect()
        val response = Response(status, responseBody, cookies)
        if (status !in 200..299) {
            val message = runCatching { JSONObject(responseBody).optString("error") }.getOrNull().orEmpty()
            throw QudraApiException(message.ifBlank { "QUDRA request failed ($status)" }, status)
        }
        return response
    }

    fun signIn(email: String, password: String): String {
        val response = request("POST", "/api/auth/sign-in/email", JSONObject().apply {
            put("email", email)
            put("password", password)
        })
        return response.cookies ?: throw QudraApiException("Account session cookie was not issued")
    }

    fun createBootstrapChallenge(registration: DeviceRegistration): BootstrapChallenge =
        BootstrapChallenge.parse(JSONObject(request(
            "POST",
            "/api/qudra/bootstrap/challenges",
            registration.toJson(),
            headers = mapOf("x-request-id" to java.util.UUID.randomUUID().toString()),
        ).body))

    fun completeBootstrapChallenge(challengeId: String, nonce: String, proof: String): BootstrapResult =
        BootstrapResult.parse(JSONObject(request(
            "POST",
            "/api/qudra/bootstrap/challenges/$challengeId/complete",
            JSONObject().apply {
                put("nonce", nonce)
                put("proof", proof)
            },
        ).body))

    fun registerDevice(cookie: String, registration: DeviceRegistration): DeviceView =
        DeviceView.parse(JSONObject(request("POST", "/api/qudra/devices/registration", registration.toJson(), cookie).body))

    fun createPairingChallenge(cookie: String, deviceId: String, keyVersion: Int, proof: ProofHeaders): PairingChallenge =
        PairingChallenge.parse(JSONObject(request("POST", "/api/qudra/pairing/challenges", JSONObject().apply {
            put("deviceId", deviceId)
            put("idempotencyKey", proof.requestId)
        }, cookie, proof.asMap()).body))

    fun getPairingQr(cookie: String, challengeId: String, proof: ProofHeaders): PairingQr =
        PairingQr.parse(JSONObject(request("GET", "/api/qudra/pairing/challenges/$challengeId/qr", cookie = cookie, headers = proof.asMap()).body))

    fun completePairing(cookie: String, challengeId: String, response: String): PairingResult =
        PairingResult.parse(JSONObject(request("POST", "/api/qudra/pairing/challenges/$challengeId/complete", JSONObject().apply {
            put("response", response)
        }, cookie).body))

    fun getManifest(deviceSession: String): OpenManifest {
        val body = request("GET", "/api/qudra/open/manifest", cookie = null, headers = mapOf("x-qudra-device-session" to deviceSession)).body
        return try {
            OpenManifest.parse(JSONObject(body))
        } catch (_: Exception) {
            throw QudraApiException("QUDRA OPEN manifest could not be validated", 502)
        }
    }

    fun renewSession(deviceSession: String, deviceId: String): DeviceSession =
        DeviceSession.parse(JSONObject(request("POST", "/api/qudra/devices/$deviceId/session", headers = mapOf("x-qudra-device-session" to deviceSession)).body))

    fun getAccess(deviceSession: String, deviceId: String): AccessView =
        AccessView.parse(JSONObject(request("GET", "/api/qudra/devices/$deviceId/access/effective", headers = mapOf("x-qudra-device-session" to deviceSession)).body))

    fun getDevice(deviceSession: String, deviceId: String): DeviceView =
        DeviceView.parse(JSONObject(request("GET", "/api/qudra/devices/$deviceId", headers = mapOf("x-qudra-device-session" to deviceSession)).body))

    fun getDiagnostics(deviceSession: String, deviceId: String): List<Diagnostic> {
        val items = JSONObject(request("GET", "/api/qudra/devices/$deviceId/diagnostics/current", headers = mapOf("x-qudra-device-session" to deviceSession)).body).getJSONArray("items")
        return (0 until items.length()).map { index ->
            val item = items.getJSONObject(index)
            Diagnostic(item.getString("code"), item.optString("state", "UNKNOWN"), item.optBoolean("retryable"), item.getString("message"), item.getString("observedAt"))
        }
    }

    fun getSourceConfigs(deviceSession: String, deviceId: String): List<SourceConfig> {
        val items = JSONObject(request("GET", "/api/qudra/devices/$deviceId/source-configs", headers = mapOf("x-qudra-device-session" to deviceSession)).body).optJSONArray("items") ?: return emptyList()
        return (0 until items.length()).mapNotNull { runCatching { SourceConfig.parse(items.getJSONObject(it)) }.getOrNull() }.take(2)
    }

    fun createSource(deviceSession: String, deviceId: String, label: String, endpointUrl: String?, epgUrl: String?, timezone: String?, offsetMinutes: Int?, secret: String?, slot: Int?): SourceConfig {
        val body = JSONObject().apply { put("label", label); put("sourceType", "personal_source"); put("endpointUrl", endpointUrl); put("epgUrl", epgUrl); put("sourceTimezone", timezone); put("utcOffsetMinutes", offsetMinutes); put("secret", secret); put("slot", slot) }
        return SourceConfig.parse(JSONObject(request("POST", "/api/qudra/devices/$deviceId/source-configs", body, headers = mapOf("x-qudra-device-session" to deviceSession, "Idempotency-Key" to java.util.UUID.randomUUID().toString())).body))
    }

    fun updateSource(deviceSession: String, deviceId: String, config: SourceConfig, label: String, endpointUrl: String?, epgUrl: String?, timezone: String?, offsetMinutes: Int?, secret: String?, clearSecret: Boolean = false): SourceConfig {
        val body = JSONObject().apply { put("label", label); put("endpointUrl", endpointUrl); put("epgUrl", epgUrl); put("sourceTimezone", timezone); put("utcOffsetMinutes", offsetMinutes); put("configVersion", config.configVersion); put("secret", secret); put("clearSecret", clearSecret) }
        return SourceConfig.parse(JSONObject(request("PATCH", "/api/qudra/devices/$deviceId/source-configs/${config.id}", body, headers = mapOf("x-qudra-device-session" to deviceSession, "If-Match-Config-Version" to config.configVersion.toString(), "Idempotency-Key" to java.util.UUID.randomUUID().toString())).body))
    }

    fun deleteSource(deviceSession: String, deviceId: String, config: SourceConfig) { request("DELETE", "/api/qudra/devices/$deviceId/source-configs/${config.id}", cookie = null, headers = mapOf("x-qudra-device-session" to deviceSession, "If-Match-Config-Version" to config.configVersion.toString(), "Idempotency-Key" to java.util.UUID.randomUUID().toString())) }

    fun getActiveSource(deviceSession: String, deviceId: String): Pair<String, String?> {
        val json = JSONObject(request("GET", "/api/qudra/devices/$deviceId/active-source", headers = mapOf("x-qudra-device-session" to deviceSession)).body)
        return json.optString("kind", "QUDRA_OPEN") to json.optStringOrNull("sourceConfigId")
    }

    fun selectActiveSource(deviceSession: String, deviceId: String, sourceConfigId: String?) {
        request("PUT", "/api/qudra/devices/$deviceId/active-source", JSONObject().apply { put("kind", if (sourceConfigId == null) "QUDRA_OPEN" else "PERSONAL_SOURCE"); put("sourceConfigId", sourceConfigId) }, headers = mapOf("x-qudra-device-session" to deviceSession))
    }

    fun getSync(deviceSession: String, deviceId: String): List<SourceSyncStatus> {
        val items = JSONObject(request("GET", "/api/qudra/devices/$deviceId/sync", headers = mapOf("x-qudra-device-session" to deviceSession)).body).getJSONArray("items")
        return (0 until items.length()).map { SourceSyncStatus.parse(items.getJSONObject(it)) }
    }

    fun reportSync(deviceSession: String, deviceId: String, sourceConfigId: String, configVersion: Int, state: SourceSyncState, format: SourceFormat?, counts: JSONObject, capabilities: JSONObject, timezone: String?, offsetMinutes: Int?, generation: String?): SourceSyncStatus {
        val body = JSONObject().apply { put("sourceConfigId", sourceConfigId); put("configVersion", configVersion); put("state", state.name); put("format", format?.name); put("counts", counts); put("capabilities", capabilities); put("timezone", timezone); put("utcOffsetMinutes", offsetMinutes); put("lastKnownGoodGeneration", generation); put("lastAttemptAt", java.time.Instant.now().toString()); if (state == SourceSyncState.FRESH) put("lastSuccessAt", java.time.Instant.now().toString()); put("idempotencyKey", java.util.UUID.randomUUID().toString()) }
        return SourceSyncStatus.parse(JSONObject(request("POST", "/api/qudra/devices/$deviceId/source-configs/$sourceConfigId/sync", body, headers = mapOf("x-qudra-device-session" to deviceSession)).body))
    }

    fun getCapabilities(deviceSession: String, deviceId: String): List<SourceCapability> {
        val items = JSONObject(request("GET", "/api/qudra/devices/$deviceId/capabilities", headers = mapOf("x-qudra-device-session" to deviceSession)).body).getJSONArray("items")
        return (0 until items.length()).map { val item = items.getJSONObject(it); SourceCapability(item.getString("sourceConfigId"), SourceSyncState.valueOf(item.getString("state")), CapabilityState.valueOf(item.getString("epg")), CapabilityState.valueOf(item.getString("catchUp")), CapabilityState.valueOf(item.getString("timeshift"))) }
    }

    fun claimDevice(cookie: String, challengeId: String, response: String): ClaimResult = ClaimResult.parse(JSONObject(request("POST", "/api/qudra/claims", JSONObject().apply { put("challengeId", challengeId); put("response", response) }, cookie).body))
}

data class ProofHeaders(val deviceId: String, val keyVersion: Int, val challenge: String, val signature: String, val requestId: String) {
    fun asMap() = mapOf(
        "x-qudra-device-id" to deviceId,
        "x-qudra-key-version" to keyVersion.toString(),
        "x-qudra-challenge" to challenge,
        "x-qudra-proof" to signature,
        "x-request-id" to requestId,
    )
}

fun urlSafe(bytes: ByteArray): String = Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
