// @polsia:user-owned — bounded XMLTV parser for local EPG data.
package com.qudra.tv.local.source

import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.Reader
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

class XmlTvParser(private val maxProgrammes: Int = 200_000) {
    fun parse(reader: Reader, cancelled: () -> Boolean = { false }): Pair<List<EpgChannel>, List<EpgProgramme>> {
        val parser = XmlPullParserFactory.newInstance().newPullParser().apply { setInput(reader) }
        val channels = ArrayList<EpgChannel>()
        val programmes = ArrayList<EpgProgramme>()
        var channelId: String? = null
        var programmeChannel: String? = null
        var programmeStart = 0L
        var programmeStop = 0L
        var currentText = ""
        var activeText: String? = null
        var displayName = ""
        var programmeTitle = ""
        var description: String? = null
        while (parser.eventType != XmlPullParser.END_DOCUMENT) {
            if (cancelled()) throw InterruptedException("XMLTV import cancelled")
            when (parser.eventType) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "channel" -> { channelId = parser.getAttributeValue(null, "id"); displayName = "" }
                    "programme" -> {
                        programmeChannel = parser.getAttributeValue(null, "channel")
                        programmeStart = parseTime(parser.getAttributeValue(null, "start"))
                        programmeStop = parseTime(parser.getAttributeValue(null, "stop"))
                        programmeTitle = ""
                        description = null
                    }
                    "display-name", "title", "desc" -> { currentText = ""; activeText = parser.name }
                }
                XmlPullParser.TEXT -> if (activeText != null) currentText += parser.text
                XmlPullParser.END_TAG -> when (parser.name) {
                    "display-name" -> { displayName = currentText.trim(); activeText = null }
                    "title" -> { programmeTitle = currentText.trim(); activeText = null }
                    "desc" -> { description = currentText.trim().ifBlank { null }; activeText = null }
                    "channel" -> if (!channelId.isNullOrBlank() && displayName.isNotBlank()) channels += EpgChannel(channelId!!, displayName)
                    "programme" -> if (programmes.size < maxProgrammes && !programmeChannel.isNullOrBlank() && programmeTitle.isNotBlank() && programmeStart < programmeStop) programmes += EpgProgramme(programmeChannel!!, programmeTitle, description, programmeStart, programmeStop)
                }
            }
            parser.next()
        }
        return channels to programmes
    }

    private fun parseTime(value: String?): Long {
        if (value.isNullOrBlank()) return 0L
        val normalized = value.trim().replace(Regex("\\s+"), " ")
        val patterns = listOf("yyyyMMddHHmmss Z", "yyyyMMddHHmmss")
        for (pattern in patterns) runCatching {
            return SimpleDateFormat(pattern, Locale.ROOT).apply { timeZone = TimeZone.getTimeZone("UTC") }.parse(normalized)?.time ?: 0L
        }
        return 0L
    }
}
