// @polsia:user-owned — two local Personal Source slots; secrets never enter this record.
package com.qudra.tv.local.source

import android.content.Context
import com.qudra.tv.data.api.SourceConfig
import org.json.JSONArray
import org.json.JSONObject

class SourceConfigStore(context: Context) {
    private val prefs = context.getSharedPreferences("qudra_tv_sources", Context.MODE_PRIVATE)
    fun save(configs: List<SourceConfig>) { require(configs.size <= 2); prefs.edit().putString("configs", JSONArray(configs.sortedBy { it.slot ?: Int.MAX_VALUE }.take(2).map { it.toJson() }).toString()).apply() }
    fun read(): List<SourceConfig> = runCatching { JSONArray(prefs.getString("configs", "[]")) }.getOrNull()?.let { array -> (0 until array.length()).mapNotNull { index -> runCatching { SourceConfig.parse(array.getJSONObject(index)) }.getOrNull() }.take(2) }.orEmpty()
    fun upsert(config: SourceConfig) = save(read().filterNot { it.id == config.id } + config)
    fun remove(id: String) = save(read().filterNot { it.id == id })
    fun setActive(id: String?) = prefs.edit().putString("active", id).apply()
    fun activeId(): String? = prefs.getString("active", null)
    fun active(): SourceConfig? = read().firstOrNull { it.id == activeId() }
    fun fallBackToOpen() = setActive(null)
}

private fun SourceConfig.toJson() = JSONObject().apply { put("id", id); put("label", label); put("endpointUrl", endpointUrl); put("epgUrl", epgUrl); put("sourceTimezone", sourceTimezone); put("utcOffsetMinutes", utcOffsetMinutes); put("slot", slot); put("hasSecret", hasSecret); put("configVersion", configVersion) }
private fun JSONObject.optStringOrNull(name: String): String? = if (isNull(name)) null else optString(name).takeIf(String::isNotBlank)
private fun JSONObject.optIntOrNull(name: String): Int? = if (isNull(name) || !has(name)) null else optInt(name)
