// @polsia:user-owned — local VOD progress only; no server viewing history.
package com.qudra.tv.player

import com.qudra.tv.local.LocalPlaybackStateStore

class PlayerViewModel(private val local: LocalPlaybackStateStore, private val sourceId: String) {
    fun resumePosition(): Long = local.progress(sourceId)?.positionMs ?: 0L
    fun save(positionMs: Long, durationMs: Long) {
        if (durationMs > 0L) local.saveProgress(com.qudra.tv.local.PlaybackProgress(sourceId, positionMs, durationMs))
        local.markWatched(sourceId)
        local.cleanup()
    }
    fun nextEpisode(episodes: List<String>): String? = local.nextEpisode(episodes, sourceId)
}
