// @polsia:user-owned — write-only Personal Source setup; secrets are never rendered back.
package com.qudra.tv.ui.source

import android.app.Activity
import android.app.AlertDialog
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import com.qudra.tv.data.NativeFailure
import com.qudra.tv.data.QudraRepository

object PersonalSourceScreen {
    fun show(activity: Activity, repository: QudraRepository, onSaved: () -> Unit) {
        val form = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 8, 28, 0) }
        fun field(hint: String, secret: Boolean = false) = EditText(activity).apply { this.hint = hint; setTextColor(com.qudra.tv.ui.UiStyle.text); setHintTextColor(com.qudra.tv.ui.UiStyle.muted); if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val label = field("Label, e.g. Living room")
        val playlist = field("Playlist HTTPS URL (M3U/M3U8)")
        val epg = field("XMLTV HTTPS URL (optional)")
        val timezone = field("Timezone, e.g. Europe/Zagreb (optional)")
        val secret = field("Source secret (optional; write-only)", true)
        listOf(label, playlist, epg, timezone, secret).forEach { form.addView(it) }
        AlertDialog.Builder(activity).setTitle("Add Personal Source").setMessage("The TV downloads and parses the source directly. Credentials are sealed in Android Keystore and are never shown, logged, placed in URLs, or sent as catalogue data.").setView(form).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
            Thread {
                val result = runCatching { repository.createSource(label.text.toString().trim(), playlist.text.toString().trim().ifBlank { null }, epg.text.toString().trim().ifBlank { null }, timezone.text.toString().trim().ifBlank { null }, null, secret.text.toString().ifBlank { null }, null) }
                activity.runOnUiThread { result.onSuccess { config -> Thread { val refresh = runCatching { repository.refreshSource(config) }; activity.runOnUiThread { refresh.onSuccess { onSaved() }.onFailure { error -> AlertDialog.Builder(activity).setTitle("Source saved, refresh failed").setMessage(NativeFailure.from(error).message).setPositiveButton("Close", null).show() } } }.start() }.onFailure { error -> AlertDialog.Builder(activity).setTitle("Source was not saved").setMessage(NativeFailure.from(error).message).setPositiveButton("Close", null).show() } }
            }.start()
        }.show()
    }
}
