// @polsia:user-owned — QUDRA OPEN is permanent and separate from Personal Source access.
package com.qudra.tv.data

import com.qudra.tv.data.api.AccessView
import com.qudra.tv.data.api.OpenManifest

object OpenEntitlementPolicy {
    fun isOpenAvailable(manifest: OpenManifest, access: AccessView): Boolean =
        access.deviceId.isNotBlank() && manifest.availableWithoutEntitlement &&
            !manifest.requiresPaidEntitlement &&
            !manifest.personalSourceConfig &&
            !manifest.controlPlaneProxiesBytes

    fun personalSourceDenied(access: AccessView): Boolean = !access.personalSourceAllowed
}
