// @polsia:user-owned — P-256 device identity never exports its private key.
package com.qudra.tv.security

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.qudra.tv.data.api.urlSafe
import java.nio.charset.StandardCharsets
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.spec.ECGenParameterSpec

class DeviceIdentityStore(context: Context) {
    private val preferences = context.getSharedPreferences("qudra_identity", Context.MODE_PRIVATE)
    private val keyAlias = "qudra_tv_p256_v1"
    private val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    init {
        if (!keyStore.containsAlias(keyAlias)) {
            val generator = KeyPairGenerator.getInstance("EC", "AndroidKeyStore")
            generator.initialize(KeyGenParameterSpec.Builder(keyAlias, KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY)
                .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
                .setDigests(KeyProperties.DIGEST_SHA256)
                .build())
            generator.generateKeyPair()
        }
        val currentFingerprint = fingerprint
        if (preferences.getString("public_key_fingerprint", null) != currentFingerprint) {
            preferences.edit()
                .putString("public_device_id", "tv-${java.util.UUID.randomUUID()}")
                .putString("public_key_fingerprint", currentFingerprint)
                .commit()
        }
    }

    val publicDeviceId: String get() = preferences.getString("public_device_id", null) ?: error("Device identity metadata missing")
    val publicKeyPem: String get() = pem(keyStore.getCertificate(keyAlias).publicKey.encoded)
    val fingerprint: String get() = MessageDigest.getInstance("SHA-256").digest(publicKeyPem.toByteArray(StandardCharsets.UTF_8)).joinToString("") { "%02x".format(it) }
    val deviceModel: String get() = "${Build.MANUFACTURER} ${Build.MODEL}".take(128)

    fun sign(payload: String): String {
        val privateKey = keyStore.getKey(keyAlias, null) as? PrivateKey ?: error("Device private key unavailable")
        return Signature.getInstance("SHA256withECDSA").run {
            initSign(privateKey)
            update(payload.toByteArray(StandardCharsets.UTF_8))
            urlSafe(sign())
        }
    }

    private fun pem(encoded: ByteArray): String {
        val body = Base64.encodeToString(encoded, Base64.NO_WRAP)
        return "-----BEGIN PUBLIC KEY-----\n${body.chunked(64).joinToString("\n")}\n-----END PUBLIC KEY-----"
    }
}
