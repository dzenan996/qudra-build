// @polsia:user-owned — home data loader; cloud data enters through QudraRepository only.
package com.qudra.tv.ui.home

import com.qudra.tv.data.HomeData
import com.qudra.tv.data.QudraRepository
import java.util.concurrent.Executors

class HomeViewModel(private val repository: QudraRepository) {
    private val executor = Executors.newSingleThreadExecutor()
    fun load(onResult: (Result<HomeData>) -> Unit) { executor.execute { onResult(runCatching { repository.loadHome() }) } }
    fun close() = executor.shutdown()
}
