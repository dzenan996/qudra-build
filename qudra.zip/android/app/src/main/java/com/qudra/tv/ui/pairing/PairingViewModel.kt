// @polsia:user-owned — pairing state; server remains the authority for expiry and attempts.
package com.qudra.tv.ui.pairing

import com.qudra.tv.data.PendingBootstrap
import com.qudra.tv.data.QudraRepository

class PairingViewModel(private val repository: QudraRepository) {
    fun begin(): PendingBootstrap = repository.beginBootstrap()
    fun complete(pairing: PendingBootstrap) = repository.completeBootstrap(pairing)
}
