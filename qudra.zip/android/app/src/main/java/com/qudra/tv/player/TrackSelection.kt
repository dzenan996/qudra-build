// @polsia:user-owned — track controls are exposed only when Media3 reports tracks.
package com.qudra.tv.player

import androidx.media3.common.C
import androidx.media3.common.Player

data class TrackAvailability(val audio: Boolean, val subtitles: Boolean)
fun trackAvailability(player: Player) = TrackAvailability(player.currentTracks.groups.any { it.type == C.TRACK_TYPE_AUDIO }, player.currentTracks.groups.any { it.type == C.TRACK_TYPE_TEXT })
