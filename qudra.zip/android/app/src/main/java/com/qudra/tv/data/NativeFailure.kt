// @polsia:user-owned — stable, redacted native failure categories and copy.
package com.qudra.tv.data

import com.qudra.tv.data.api.QudraApiException
import java.io.IOException
import java.net.SocketTimeoutException

enum class NativeFailureCategory {
    INTERNET,
    CLOUD,
    AUTHORITY,
    PAIRING_EXPIRED,
    PAIRING_RATE_LIMITED,
    OPEN_MANIFEST,
    SOURCE,
    PLAYBACK,
    SOURCE_UNAVAILABLE,
    SOURCE_ACCESS_DENIED,
    INVALID_PLAYLIST,
    PARSE_FAILURE,
    EPG_UNAVAILABLE,
    EPG_STALE,
    UNSUPPORTED_FORMAT,
    SELECTED_STREAM_UNAVAILABLE,
    CATCH_UP_UNSUPPORTED,
    TIMESHIFT_UNSUPPORTED,
    PERSONAL_SOURCE_ENTITLEMENT,
    BOOTSTRAP_AUTHORITY,
    BOOTSTRAP_EXPIRED,
    BOOTSTRAP_REPLAYED,
    BOOTSTRAP_RATE_LIMITED,
    OPEN_AUTHORITY,
    UNKNOWN,
}

data class NativeFailure(val category: NativeFailureCategory, val message: String) {
    companion object {
        fun from(error: Throwable): NativeFailure {
            val api = error as? QudraApiException
            val category = when {
                api?.message?.contains("bootstrap", ignoreCase = true) == true && api.statusCode == 429 -> NativeFailureCategory.BOOTSTRAP_RATE_LIMITED
                api?.message?.contains("bootstrap", ignoreCase = true) == true && api.message.contains("expired", ignoreCase = true) -> NativeFailureCategory.BOOTSTRAP_EXPIRED
                api?.message?.contains("bootstrap", ignoreCase = true) == true && api.message.contains("replay", ignoreCase = true) -> NativeFailureCategory.BOOTSTRAP_REPLAYED
                api?.message?.contains("bootstrap", ignoreCase = true) == true -> NativeFailureCategory.BOOTSTRAP_AUTHORITY
                api?.message?.contains("personal source", ignoreCase = true) == true && api.statusCode == 403 -> NativeFailureCategory.PERSONAL_SOURCE_ENTITLEMENT
                api?.message?.contains("source", ignoreCase = true) == true && api.statusCode == 403 -> NativeFailureCategory.SOURCE_ACCESS_DENIED
                api?.message?.contains("playlist", ignoreCase = true) == true -> NativeFailureCategory.INVALID_PLAYLIST
                api?.message?.contains("source", ignoreCase = true) == true -> NativeFailureCategory.SOURCE_UNAVAILABLE
                api?.statusCode == 409 && api.message.contains("expired", ignoreCase = true) -> NativeFailureCategory.PAIRING_EXPIRED
                api?.statusCode == 401 || api?.statusCode == 403 || api?.statusCode == 409 -> NativeFailureCategory.AUTHORITY
                api?.statusCode == 410 -> NativeFailureCategory.PAIRING_EXPIRED
                api?.statusCode == 429 -> NativeFailureCategory.PAIRING_RATE_LIMITED
                api?.statusCode == 502 -> NativeFailureCategory.OPEN_MANIFEST
                api?.statusCode?.let { it in 500..599 } == true -> NativeFailureCategory.CLOUD
                error is SocketTimeoutException || error is IOException -> NativeFailureCategory.INTERNET
                else -> NativeFailureCategory.UNKNOWN
            }
            return NativeFailure(category, category.message())
        }

        fun bootstrapAuthority(): NativeFailure = NativeFailure(
            NativeFailureCategory.BOOTSTRAP_AUTHORITY,
            "This TV has a protected device identity, but the available server contract still requires an approved claim authority to register it. QUDRA OPEN remains fail-closed until the TV is claimed.",
        )

        private fun NativeFailureCategory.message(): String = when (this) {
            NativeFailureCategory.INTERNET -> "Internet unavailable. Check the TV connection and retry."
            NativeFailureCategory.CLOUD -> "QUDRA Cloud is temporarily unavailable. Retry, or use the last validated QUDRA OPEN catalog if one is available."
            NativeFailureCategory.AUTHORITY -> "This device session is no longer authorized. Pair the TV again."
            NativeFailureCategory.PAIRING_EXPIRED -> "The pairing challenge expired. Create a new pairing challenge."
            NativeFailureCategory.PAIRING_RATE_LIMITED -> "Pairing is temporarily rate-limited. Wait and try again."
            NativeFailureCategory.OPEN_MANIFEST -> "QUDRA OPEN is temporarily unavailable and no validated catalog is stored on this TV."
            NativeFailureCategory.SOURCE -> "This source is currently unavailable."
            NativeFailureCategory.PLAYBACK -> "Playback could not start from the approved direct media origin."
            NativeFailureCategory.SOURCE_UNAVAILABLE -> "The selected Personal Source is unavailable. QUDRA OPEN remains available."
            NativeFailureCategory.SOURCE_ACCESS_DENIED -> "The selected Personal Source denied access. Check its authorization without exposing its secret."
            NativeFailureCategory.INVALID_PLAYLIST -> "The Personal Source playlist is invalid or contains no usable entries."
            NativeFailureCategory.PARSE_FAILURE -> "The Device could not parse this source safely."
            NativeFailureCategory.EPG_UNAVAILABLE -> "No usable XMLTV guide is available for this source."
            NativeFailureCategory.EPG_STALE -> "The local EPG is stale; refresh the source to update it."
            NativeFailureCategory.UNSUPPORTED_FORMAT -> "This source format is not supported on this TV."
            NativeFailureCategory.SELECTED_STREAM_UNAVAILABLE -> "The selected stream is unavailable at its direct origin."
            NativeFailureCategory.CATCH_UP_UNSUPPORTED -> "Catch-up is not supported for this channel."
            NativeFailureCategory.TIMESHIFT_UNSUPPORTED -> "Timeshift is not supported for this channel."
            NativeFailureCategory.PERSONAL_SOURCE_ENTITLEMENT -> "Personal Sources require their own valid entitlement; QUDRA OPEN is still available."
            NativeFailureCategory.BOOTSTRAP_AUTHORITY -> "This TV's protected bootstrap proof was not accepted. Retry device bootstrap."
            NativeFailureCategory.BOOTSTRAP_EXPIRED -> "The device bootstrap challenge expired. Start bootstrap again."
            NativeFailureCategory.BOOTSTRAP_REPLAYED -> "The device bootstrap challenge was already used or rejected. Start bootstrap again."
            NativeFailureCategory.BOOTSTRAP_RATE_LIMITED -> "Device bootstrap is temporarily rate-limited. Wait and try again."
            NativeFailureCategory.OPEN_AUTHORITY -> "This device session is no longer authorized for QUDRA OPEN. Pair the TV again."
            NativeFailureCategory.UNKNOWN -> "QUDRA could not complete that request. Retry or pair the TV again."
        }
    }
}

fun classifyCloudFailure(error: Throwable): NativeFailure = NativeFailure.from(error)

fun isTemporaryCloudFailure(error: Throwable): Boolean {
    val api = error as? QudraApiException
    return error is IOException || api?.statusCode?.let { it in 500..599 } == true
}
