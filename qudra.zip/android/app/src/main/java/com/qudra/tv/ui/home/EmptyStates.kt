// @polsia:user-owned — honest unavailable areas, with no synthetic programming.
package com.qudra.tv.ui.home

import android.content.Context
import android.app.AlertDialog
import android.app.Activity
import android.widget.LinearLayout
import com.qudra.tv.ui.UiStyle

object EmptyStates {
    fun add(context: Context, parent: LinearLayout, area: String, reason: String) {
        parent.addView(UiStyle.title(context, area, 24f))
        parent.addView(UiStyle.body(context, reason, 19f))
        parent.addView(UiStyle.body(context, "QUDRA does not invent channels, radio stations, schedules, or provider packages. This area will remain quiet until a lawful production source is available."))
    }
    fun dialog(activity: Activity, title: String, reason: String) = AlertDialog.Builder(activity).setTitle(title).setMessage(reason).setPositiveButton("Close", null).show()
}
