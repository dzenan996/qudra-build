// @polsia:user-owned — accessible rights and license surface for each descriptor.
package com.qudra.tv.ui.home

import android.app.AlertDialog
import android.content.Context
import com.qudra.tv.data.api.MediaItem

object AttributionDialog {
    fun show(context: Context, item: MediaItem) {
        val restrictions = if (item.attribution.restrictions.isEmpty()) "None recorded." else item.attribution.restrictions.joinToString("\n") { "• $it" }
        AlertDialog.Builder(context)
            .setTitle(item.title)
            .setMessage("Rights holder\n${item.attribution.rightsHolder}\n\n${item.attribution.attributionText}\n\nLicense\n${item.attribution.licenseName}\n${item.attribution.licenseUrl}\n\nEvidence\n${item.attribution.rightsEvidenceUrl ?: "See the manifest rights record."}\n\nGeography\n${item.attribution.geography?.scope ?: "UNKNOWN"}\n\nRestrictions\n$restrictions")
            .setPositiveButton("Close", null)
            .show()
    }
}
