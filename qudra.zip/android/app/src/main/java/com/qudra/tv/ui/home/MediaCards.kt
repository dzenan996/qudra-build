// @polsia:user-owned — D-pad-sized media cards with explicit rights access.
package com.qudra.tv.ui.home

import android.content.Context
import android.graphics.Typeface
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.qudra.tv.data.api.MediaItem
import com.qudra.tv.local.source.PlaylistEntry
import com.qudra.tv.player.formatSupportNote
import com.qudra.tv.player.resolveDirectOrigin
import com.qudra.tv.ui.UiStyle

object MediaCards {
    fun add(context: Context, parent: LinearLayout, item: MediaItem, onPlay: (MediaItem) -> Unit, onInfo: (MediaItem) -> Unit, favorite: Boolean, onFavorite: () -> Unit) {
        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 18)
            setBackgroundColor(UiStyle.surfaceRaised)
            isFocusable = true
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 16) }
        }
        val title = TextView(context).apply {
            text = item.title
            textSize = 22f
            setTextColor(UiStyle.text)
            typeface = Typeface.DEFAULT_BOLD
        }
        card.addView(title)
        card.addView(UiStyle.body(context, item.attribution.licenseName + " · " + formatSupportNote(item)))
        item.availabilityReason?.let { card.addView(UiStyle.body(context, it)) }
        val actions = UiStyle.row(context)
        val play = UiStyle.button(context, if (resolveDirectOrigin(item) == null) "Unavailable" else "Play") { onPlay(item) }
        play.isEnabled = resolveDirectOrigin(item) != null
        val info = UiStyle.button(context, "Rights & attribution") { onInfo(item) }
        val list = UiStyle.button(context, if (favorite) "Remove from My List" else "Add to My List") { onFavorite() }
        actions.addView(play)
        actions.addView(info)
        actions.addView(list)
        card.addView(actions)
        parent.addView(card)
    }

    fun addLocal(context: Context, parent: LinearLayout, item: PlaylistEntry, onPlay: (PlaylistEntry) -> Unit, favorite: Boolean, onFavorite: () -> Unit) {
        val card = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 18, 22, 18); setBackgroundColor(UiStyle.surfaceRaised); isFocusable = true; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 16) } }
        card.addView(TextView(context).apply { text = item.title; textSize = 22f; setTextColor(UiStyle.text); typeface = Typeface.DEFAULT_BOLD })
        card.addView(UiStyle.body(context, listOfNotNull(item.originalCategory, if (item.catchUpSupported) "Catch-up" else null, if (item.timeshiftSupported) "Timeshift" else null).joinToString(" · ").ifBlank { "Personal Source" }))
        val actions = UiStyle.row(context); actions.addView(UiStyle.button(context, "Play") { onPlay(item) }); actions.addView(UiStyle.button(context, if (favorite) "Remove from My List" else "Add to My List") { onFavorite() }); card.addView(actions); parent.addView(card)
    }
}
