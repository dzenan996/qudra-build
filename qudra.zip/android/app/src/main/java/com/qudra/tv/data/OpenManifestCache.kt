// @polsia:user-owned — encrypted last-known-good QUDRA OPEN metadata cache.
package com.qudra.tv.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.qudra.tv.data.api.OpenManifest
import org.json.JSONObject
import java.security.KeyStore
import java.time.Duration
import java.time.Instant
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class OpenManifestCacheRecord(val manifestVersion: String, val storedAt: String, val payload: String)

object OpenManifestCachePolicy {
    const val MAX_AGE_HOURS = 24L

    fun canFallback(record: OpenManifestCacheRecord, now: Instant): Boolean {
        val stored = runCatching { Instant.parse(record.storedAt) }.getOrNull() ?: return false
        return record.manifestVersion.isNotBlank() &&
            Duration.between(stored, now).let { !it.isNegative && it.toHours() <= MAX_AGE_HOURS }
    }
}

class OpenManifestCache(context: Context) {
    private val preferences = context.getSharedPreferences("qudra_open_manifest_cache", Context.MODE_PRIVATE)
    private val keyAlias = "qudra_open_manifest_cache_aes_v1"
    private val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    init {
        if (!keyStore.containsAlias(keyAlias)) {
            KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
                init(KeyGenParameterSpec.Builder(keyAlias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .build())
                generateKey()
            }
        }
    }

    fun save(manifest: OpenManifest, now: Instant = Instant.now()) {
        val payload = manifest.toJson().toString()
        val record = OpenManifestCacheRecord(manifest.manifestVersion, now.toString(), encrypt(payload))
        preferences.edit()
            .putString("manifest_version", record.manifestVersion)
            .putString("stored_at", record.storedAt)
            .putString("payload", record.payload)
            .commit()
    }

    fun read(now: Instant = Instant.now()): OpenManifest? {
        val version = preferences.getString("manifest_version", null) ?: return null
        val storedAt = preferences.getString("stored_at", null) ?: return null
        val payload = preferences.getString("payload", null) ?: return null
        val record = OpenManifestCacheRecord(version, storedAt, payload)
        if (!OpenManifestCachePolicy.canFallback(record, now)) return null
        return runCatching { OpenManifest.parse(JSONObject(decrypt(payload))) }.getOrNull()
    }

    private fun secretKey(): SecretKey = keyStore.getKey(keyAlias, null) as SecretKey

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        return Base64.encodeToString(cipher.iv + cipher.doFinal(value.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    }

    private fun decrypt(value: String): String {
        val bytes = Base64.decode(value, Base64.NO_WRAP)
        require(bytes.size > 12)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
        return cipher.doFinal(bytes.copyOfRange(12, bytes.size)).toString(Charsets.UTF_8)
    }
}
