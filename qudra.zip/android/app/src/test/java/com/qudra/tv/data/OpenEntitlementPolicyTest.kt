// @polsia:user-owned — JVM regressions for trial expiry and Personal Source denial.
package com.qudra.tv.data

import com.qudra.tv.data.api.AccessView
import com.qudra.tv.data.api.OpenManifest
import org.junit.Assert.assertEquals
import org.junit.Test

class OpenEntitlementPolicyTest {
    private val manifest = OpenManifest("3.0.0-t3b", true, false, false, false, emptyList(), emptyList(), emptyList(), emptyList())

    @Test fun activeTrialKeepsOpenAvailable() {
        assertEquals(true, OpenEntitlementPolicy.isOpenAvailable(manifest, AccessView("d", "now", true, false, true)))
    }

    @Test fun expiredTrialAndNoPaidEntitlementStillKeepOpenAvailable() {
        assertEquals(true, OpenEntitlementPolicy.isOpenAvailable(manifest, AccessView("d", "now", false, false, false)))
        assertEquals(true, OpenEntitlementPolicy.personalSourceDenied(AccessView("d", "now", false, false, false)))
    }

    @Test fun paidOrPersonalSourceStateDoesNotChangeOpenContract() {
        assertEquals(true, OpenEntitlementPolicy.isOpenAvailable(manifest, AccessView("d", "now", false, true, true)))
    }
}
