// @polsia:user-owned — JVM coverage for truthful, redacted failure classification.
package com.qudra.tv.data

import com.qudra.tv.data.api.QudraApiException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test
import java.io.IOException

class NativeFailureTest {
    @Test fun authorityAndPairingFailuresAreDistinct() {
        assertEquals(NativeFailureCategory.AUTHORITY, NativeFailure.from(QudraApiException("secret token", 403)).category)
        assertEquals(NativeFailureCategory.PAIRING_EXPIRED, NativeFailure.from(QudraApiException("expired", 410)).category)
        assertEquals(NativeFailureCategory.PAIRING_RATE_LIMITED, NativeFailure.from(QudraApiException("rate", 429)).category)
    }

    @Test fun temporaryCloudFailuresCanUseOnlyTheCache() {
        assertEquals(true, isTemporaryCloudFailure(IOException("offline")))
        assertEquals(true, isTemporaryCloudFailure(QudraApiException("unavailable", 503)))
        assertEquals(false, isTemporaryCloudFailure(QudraApiException("forbidden", 403)))
        assertFalse(NativeFailure.from(QudraApiException("session_token=secret", 403)).message.contains("secret"))
    }
}
