// @polsia:user-owned — local parser regression coverage.
package com.qudra.tv.local.source

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.StringReader

class M3uParserTest {
    @Test fun parsesMediaClassesAndAttributesIncrementally() {
        val playlist = """#EXTM3U
#EXTINF:-1 tvg-id="news" group-title="Live TV" catchup="append" timeshift="1",News
https://example.invalid/news.m3u8
#EXTINF:-1 group-title="Radio",Radio
https://example.invalid/radio.mp3
"""
        val items = M3uParser().parse(StringReader(playlist))
        assertEquals(2, items.size)
        assertEquals(LocalMediaKind.LIVE_TV, items[0].kind)
        assertEquals(LocalMediaKind.RADIO, items[1].kind)
        assertEquals("news", items[0].tvgId)
        assertTrue(items[0].catchUpSupported)
        assertTrue(items[0].timeshiftSupported)
    }

    @Test fun enforcesEntryBoundAndKeepsStableSeriesMetadata() {
        val playlist = "#EXTM3U\n#EXTINF:-1 group-title=\"Series\" tvg-id=\"show\" episode-num=\"2-1\",Episode\nhttps://example.invalid/episode.m3u8\n"
        val item = M3uParser(maxEntries = 1).parse(StringReader(playlist)).single()
        assertEquals(LocalMediaKind.SERIES, item.kind)
        assertEquals(2, item.episodeNumber)
        assertEquals("show", item.seriesKey)
        assertTrue(runCatching { M3uParser(maxEntries = 0).parse(StringReader(playlist)) }.isFailure)
    }

    @Test fun cancellationRetainsBoundary() {
        var cancelled = false
        val result = runCatching { M3uParser().parse(StringReader("#EXTM3U\n#EXTINF:-1,One\nhttps://example.invalid/one")) { cancelled = true; cancelled } }
        assertTrue(result.isFailure)
    }
}
