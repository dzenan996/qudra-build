// @polsia:user-owned — JVM parity coverage for T3B metadata, attribution, and origin fields.
package com.qudra.tv.data.api

import org.json.JSONObject
import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class QudraDtosParityTest {
    @Test fun parsesBootstrapChallengeAndKeepsSecretsOutOfQrRepresentation() {
        val challenge = BootstrapChallenge.parse(JSONObject("""
            {"id":"challenge-1","deviceId":"device-1","kind":"BOOTSTRAP","keyVersion":1,
             "state":"PAIRING_PENDING","expiresAt":"2030-01-01T00:00:00Z","attemptCount":0,"maxAttempts":5,
             "nonce":"nonce-material-is-not-the-qr","qr":{"id":"challenge-1","representation":"challenge-1","expiresAt":"2030-01-01T00:00:00Z"}}
        """))
        assertEquals("challenge-1", challenge.qr.representation)
        assertFalse(challenge.qr.representation.contains("nonce"))
        assertEquals(5, challenge.maxAttempts)
    }

    @Test fun parsesCanonicalMetadataAndKeepsOpenEntitlementFree() {
        val item = JSONObject("""
            {"sourceId":"movie-sintel","title":"Sintel","mediaClass":"MOVIE","productionDesignation":"PRODUCTION",
             "metadata":{"description":"A short film","category":"Animation","genres":["Short film"],"releaseYear":null,"durationSeconds":888.06,"contentLanguage":null},
             "artwork":{"url":null,"type":"NONE","rightsLicenseReference":null,"requiredAttribution":null,"status":"ABSENT","fallbackState":"QUDRA_NEUTRAL_PLACEHOLDER"},
             "attribution":{"rightsHolder":"Blender Foundation","attributionText":"Film credit","licenseName":"CC BY 3.0","licenseUrl":"https://creativecommons.org/licenses/by/3.0/","rightsEvidenceUrl":"https://durian.blender.org/about/","geography":{"scope":"WORLDWIDE","regions":[],"restrictions":[]},"restrictions":[]},
             "capabilities":{"directPlayback":true,"epg":false,"nowNext":false,"fullSchedule":false,"catchUp":false,"timeshift":false,"recording":false,"castCompatibilityKnown":false},
             "compatibility":{"classification":"PREFERRED","notes":"MP4 fixture"},
             "legalEvidence":{"license":"CC BY 3.0","licenseUrl":"https://creativecommons.org/licenses/by/3.0/","permissionEvidenceUrl":"https://durian.blender.org/about/","attribution":"Film credit","geography":{"scope":"WORLDWIDE","regions":[],"restrictions":[]},"rightsHolder":"Blender Foundation","verificationStatus":"VERIFIED","verifiedAt":"2030-01-01T00:00:00Z","verificationMethod":"test","stabilityEvidence":{"checkedAt":"2030-01-01T00:00:00Z","method":"MANUAL_REVIEW","notes":"test"}},
             "webpageUrl":"https://durian.blender.org/about/","directOrigin":{"url":"https://media.example/sintel.mp4","mediaOrigin":true,"webpageEvidenceUrl":"https://durian.blender.org/download/","format":{"mimeType":"video/mp4","container":"MP4","videoCodec":"H.264","audioCodec":"AAC","width":2048,"height":872,"frameRate":24,"durationSeconds":888.06,"contentLengthBytes":1,"rangeSupported":true}},
             "sourceHealth":{"status":"HEALTHY","checkedAt":"2030-01-01T00:00:00Z","httpStatus":206,"contentType":"video/mp4","rangeSupported":true,"stabilityEvidence":{"checkedAt":"2030-01-01T00:00:00Z","method":"HEAD_RANGE_PROBE","notes":"test"}},
             "availability":{"status":"AVAILABLE","geography":{"scope":"WORLDWIDE","regions":[],"restrictions":[]},"reason":null},
             "originState":{"availability":"AVAILABLE","lastValidatedAt":"2030-01-01T00:00:00Z","preferredOrigin":"https://media.example/sintel.mp4","fallbackOrigin":null,"unavailableReason":null},"replacement":null,"fallback":null,"controlPlaneProxiesBytes":false}
        """")
        val root = JSONObject().apply {
            put("manifestVersion", "3.0.0-t3b").put("manifestId", "open").put("title", "QUDRA OPEN").put("permanent", true)
            put("availableWithoutEntitlement", true).put("requiresPaidEntitlement", false).put("personalSourceConfig", false).put("controlPlaneProxiesBytes", false)
            put("generatedAt", "2030-01-01T00:00:00Z").put("mediaClasses", JSONArray().put("LIVE_TV").put("MOVIE").put("SERIES").put("RADIO"))
            put("sourceRegister", JSONArray().put(item)).put("movies", JSONArray().put("movie-sintel")).put("liveTv", JSONArray()).put("radio", JSONArray()).put("series", JSONArray())
            put("testOnly", JSONObject().put("liveTv", JSONArray()).put("radio", JSONArray())).put("epg", JSONObject().put("nowNext", false).put("fullSchedule", false).put("catchUp", false).put("notes", "none"))
        }
        val manifest = OpenManifest.parse(root)
        assertTrue(manifest.availableWithoutEntitlement)
        assertFalse(manifest.requiresPaidEntitlement)
        assertEquals("Animation", manifest.movies.single().metadata?.category)
        assertEquals("https://durian.blender.org/about/", manifest.movies.single().attribution.rightsEvidenceUrl)
        assertTrue(manifest.movies.single().capabilities?.directPlayback == true)
        assertEquals("H.264", manifest.movies.single().directOrigin?.format?.videoCodec)
    }
}
