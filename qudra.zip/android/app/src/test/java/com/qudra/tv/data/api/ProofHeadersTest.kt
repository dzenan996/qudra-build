// @polsia:user-owned — JVM evidence that device proof headers carry no secret material.
package com.qudra.tv.data.api

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class ProofHeadersTest {
    @Test fun headersUseOpaqueDeviceContextAndSignature() {
        val headers = ProofHeaders("device-123", 1, "nonce", "signature", "request")
        assertEquals("device-123", headers.asMap()["x-qudra-device-id"])
        assertEquals("1", headers.asMap()["x-qudra-key-version"])
        assertEquals("signature", headers.asMap()["x-qudra-proof"])
        assertFalse(headers.asMap().values.any { it.contains("private") || it.contains("token") })
    }

    @Test fun bootstrapProofCanonicalizationIncludesChallengeNonceDeviceAndKeyVersion() {
        assertEquals(
            "challenge-1:nonce-1:device-123:4",
            bootstrapCanonicalPayload("challenge-1", "nonce-1", "device-123", 4),
        )
    }
}
