// @polsia:user-owned — JVM coverage for credential-free first-run bootstrap invariants.
package com.qudra.tv.data

import com.qudra.tv.data.api.PairingQr
import com.qudra.tv.data.api.bootstrapCanonicalPayload
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DeviceBootstrapTest {
    @Test fun proofBindsOpaqueChallengeNonceDeviceAndKeyVersion() {
        val payload = bootstrapCanonicalPayload("challenge-1", "nonce-1", "device-1", 7)
        assertEquals("challenge-1:nonce-1:device-1:7", payload)
        assertFalse(payload.contains("private"))
    }

    @Test fun qrContainsOnlyOpaqueChallengeRepresentation() {
        assertTrue(isSafeQrPayload(PairingQr("challenge-1", "challenge-1", "2030-01-01T00:00:00Z")))
        assertFalse(isSafeQrPayload(PairingQr("challenge-1", "challenge-1?nonce=secret", "2030-01-01T00:00:00Z")))
    }

    @Test fun publicIdIsNotProofMaterial() {
        val proof = bootstrapCanonicalPayload("challenge-1", "nonce-1", "server-device-id", 1)
        assertFalse(proof.contains("tv-public-id"))
    }
}
