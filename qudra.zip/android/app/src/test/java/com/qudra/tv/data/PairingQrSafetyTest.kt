// @polsia:user-owned — JVM coverage for opaque, non-credential QR payloads.
package com.qudra.tv.data

import com.qudra.tv.data.api.PairingQr
import org.junit.Assert.assertEquals
import org.junit.Test

class PairingQrSafetyTest {
    @Test fun onlyOpaqueChallengeIdIsAccepted() {
        assertEquals(true, isSafeQrPayload(PairingQr("challenge-1", "challenge-1", "2030-01-01T00:00:00Z")))
        assertEquals(false, isSafeQrPayload(PairingQr("challenge-1", "https://example.invalid/claim?token=secret", "2030-01-01T00:00:00Z")))
        assertEquals(false, isSafeQrPayload(PairingQr("challenge-1", "nonce=secret&session=token", "2030-01-01T00:00:00Z")))
        assertEquals(false, isSafeQrPayload(PairingQr("", "", "2030-01-01T00:00:00Z")))
    }
}
