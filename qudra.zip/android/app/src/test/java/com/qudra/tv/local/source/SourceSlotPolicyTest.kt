// @polsia:user-owned — T8 source switching and capability visibility policy tests.
package com.qudra.tv.local.source

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SourceSlotPolicyTest {
    @Test fun onlyTwoPersonalSourcesAreAllowedAndDeleteFallsBackToOpen() {
        assertTrue(SourceSlotPolicy.canAdd(0)); assertTrue(SourceSlotPolicy.canAdd(1)); assertFalse(SourceSlotPolicy.canAdd(2))
        assertEquals(null, SourceSlotPolicy.fallbackAfterDelete("source-1", "source-1"))
        assertEquals("source-2", SourceSlotPolicy.fallbackAfterDelete("source-2", "source-1"))
    }

    @Test fun capabilitiesNeverShowUnsupportedControls() {
        assertTrue(SourceSlotPolicy.showCatchUp(true)); assertFalse(SourceSlotPolicy.showCatchUp(false))
        assertTrue(SourceSlotPolicy.showTimeshift(true)); assertFalse(SourceSlotPolicy.showTimeshift(false))
        assertEquals(listOf("Movies", "Radio"), SourceSlotPolicy.orderedCategories(listOf("Radio", "", "Movies", "Radio")))
        assertEquals("episode-2", SourceSlotPolicy.nextEpisode(listOf("episode-1", "episode-2"), "episode-1"))
    }
}
