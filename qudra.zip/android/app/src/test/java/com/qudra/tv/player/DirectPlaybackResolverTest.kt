// @polsia:user-owned — JVM evidence for the direct-origin invariant.
package com.qudra.tv.player

import com.qudra.tv.data.api.Attribution
import com.qudra.tv.data.api.DirectOrigin
import com.qudra.tv.data.api.MediaFormat
import com.qudra.tv.data.api.MediaItem
import com.qudra.tv.data.api.QudraCompatibility
import com.qudra.tv.data.api.QudraMediaClass
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class DirectPlaybackResolverTest {
    private fun item(url: String, preferred: String? = url) = MediaItem(
        "sintel", "Sintel", QudraMediaClass.MOVIE, null,
        Attribution("Blender", "Film credit", "CC BY", "https://creativecommons.org", emptyList()),
        QudraCompatibility.PREFERRED, DirectOrigin(url, MediaFormat("MP4", "video/mp4", "H.264", "AAC")), preferred, true, null, 888.0, null,
    )

    @Test fun onlyTheManifestPreferredHttpsOriginIsReturned() {
        assertEquals("https://media.example/sintel.mp4", resolveDirectOrigin(item("https://media.example/sintel.mp4")))
        assertNull(resolveDirectOrigin(item("http://media.example/sintel.mp4")))
        assertNull(resolveDirectOrigin(item("https://media.example/sintel.mp4", "https://other.example/sintel.mp4")))
        assertNull(validateDirectOrigin("https://media.example/sintel.mp4", "https://other.example/sintel.mp4"))
        assertNull(validateDirectOrigin("https://user:secret@media.example/sintel.mp4", "https://user:secret@media.example/sintel.mp4"))
        assertNull(validateDirectOrigin("https://media.example/sintel.mp4?token=secret", "https://media.example/sintel.mp4?token=secret"))
    }
}
