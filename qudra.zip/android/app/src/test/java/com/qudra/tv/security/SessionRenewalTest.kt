// @polsia:user-owned — JVM coverage for replacement, rotation, expiry, and mismatch rules.
package com.qudra.tv.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import java.time.Instant

class SessionRenewalTest {
    private val previous = StoredDeviceSession("device-1", 3, "old-token", "2030-01-01T00:00:00Z")

    @Test fun replacementTokenIsPersistedForTheNewExpiry() {
        val next = SessionRenewal.apply(previous, RenewedSession("device-1", 3, "2030-01-02T00:00:00Z", "new-token"))
        assertEquals("new-token", next.token)
        assertEquals("2030-01-02T00:00:00Z", next.expiresAt)
    }

    @Test fun validRenewalWithoutReplacementKeepsTheExistingToken() {
        val next = SessionRenewal.apply(previous, RenewedSession("device-1", 3, "2030-01-02T00:00:00Z", null))
        assertEquals("old-token", next.token)
    }

    @Test fun deviceOrKeyMismatchCannotRotateTheStoredSession() {
        assertThrows(IllegalArgumentException::class.java) { SessionRenewal.apply(previous, RenewedSession("other", 3, previous.expiresAt, null)) }
        assertThrows(IllegalArgumentException::class.java) { SessionRenewal.apply(previous, RenewedSession(previous.deviceId, 4, previous.expiresAt, null)) }
    }

    @Test fun expiredAndMalformedRecordsAreNotUsable() {
        assertEquals(false, SessionExpiry.isUsable("2020-01-01T00:00:00Z", Instant.parse("2020-01-02T00:00:00Z")))
        assertEquals(false, SessionExpiry.isUsable("not-a-timestamp", Instant.now()))
    }
}
