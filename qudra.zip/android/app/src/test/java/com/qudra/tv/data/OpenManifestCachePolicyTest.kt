// @polsia:user-owned — JVM coverage for fresh, stale, and malformed cache records.
package com.qudra.tv.data

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.Instant

class OpenManifestCachePolicyTest {
    private val now = Instant.parse("2030-01-02T00:00:00Z")

    @Test fun freshValidatedRecordMayBeUsedDuringTemporaryCloudFailure() {
        assertEquals(true, OpenManifestCachePolicy.canFallback(OpenManifestCacheRecord("3.0.0-t3b", "2030-01-01T12:00:00Z", "encrypted"), now))
    }

    @Test fun staleOrMalformedRecordCannotBeUsed() {
        assertEquals(false, OpenManifestCachePolicy.canFallback(OpenManifestCacheRecord("3.0.0-t3b", "2029-12-31T00:00:00Z", "encrypted"), now))
        assertEquals(false, OpenManifestCachePolicy.canFallback(OpenManifestCacheRecord("", "2030-01-01T12:00:00Z", "encrypted"), now))
        assertEquals(false, OpenManifestCachePolicy.canFallback(OpenManifestCacheRecord("3.0.0-t3b", "not-a-time", "encrypted"), now))
    }
}
