// @polsia:user-owned — XMLTV mapping and NOW/NEXT input coverage.
package com.qudra.tv.local.source

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.StringReader

class XmlTvParserTest {
    @Test fun mapsChannelsAndProgrammeTimes() {
        val xml = """<?xml version="1.0"?><tv>
          <channel id="news"><display-name>News</display-name></channel>
          <programme start="20260101120000 +0000" stop="20260101130000 +0000" channel="news"><title>Noon</title><desc>Local guide</desc></programme>
        </tv>"""
        val (channels, programmes) = XmlTvParser().parse(StringReader(xml))
        assertEquals("news", channels.single().id)
        assertEquals("News", channels.single().displayName)
        assertEquals("Noon", programmes.single().title)
        assertEquals("Local guide", programmes.single().description)
        assertTrue(programmes.single().stopEpochMillis > programmes.single().startEpochMillis)
    }

    @Test fun boundsProgrammeStream() {
        val xml = "<tv><channel id=\"one\"><display-name>One</display-name></channel><programme start=\"20260101120000 +0000\" stop=\"20260101130000 +0000\" channel=\"one\"><title>A</title></programme><programme start=\"20260101130000 +0000\" stop=\"20260101140000 +0000\" channel=\"one\"><title>B</title></programme></tv>"
        assertEquals(1, XmlTvParser(maxProgrammes = 1).parse(StringReader(xml)).second.size)
    }
}
