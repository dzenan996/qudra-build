@echo off
setlocal
set "CACHE_ROOT=%GRADLE_USER_HOME%"
if "%CACHE_ROOT%"=="" set "CACHE_ROOT=%LOCALAPPDATA%\qudra-gradle"
set "DIST_DIR=%CACHE_ROOT%\wrapper\dists\gradle-8.9-bin"
set "GRADLE_BIN=%DIST_DIR%\gradle-8.9\bin\gradle.bat"
if not exist "%GRADLE_BIN%" (
  if not exist "%DIST_DIR%" mkdir "%DIST_DIR%"
  powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile '%DIST_DIR%\gradle-8.9-bin.zip'"
  powershell -NoProfile -Command "Expand-Archive -Force '%DIST_DIR%\gradle-8.9-bin.zip' '%DIST_DIR%'"
)
call "%GRADLE_BIN%" --project-dir "%~dp0" %*
