# QUDRA TV — T4 first vertical slice

This is an isolated native Android TV client under `android/`. It does not share web runtime code and does not proxy media bytes.

Pinned toolchain:

- Gradle 8.9 wrapper distribution
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- compile/target SDK 35, `minSdk 26` (Android TV Play exception currently allows
  target API 34+; this TV baseline therefore remains above the minimum)
- AndroidX Core 1.15.0, Lifecycle 2.8.7
- Media3 ExoPlayer/UI 1.5.1
- ZXing core 3.5.3 for the server-returned pairing representation

Configure the API origin at build time with `-PqudraApiBaseUrl=https://<deployed-app-origin>`. The default placeholder is deliberately not usable. Calls enforce HTTPS.

The first-run path is Device-first: the TV creates/loads a P-256 Android Keystore key, posts its public key and metadata to `/api/qudra/bootstrap/challenges`, signs the returned canonical challenge proof, and receives a server-issued 24-hour Device session. No email or password is required. The QR bitmap and visible code contain only the opaque challenge ID; the nonce, proof, private key, source credentials, and session token are never displayed or encoded. Account claim remains an optional later path.

Home contains exactly `LIVE TV`, `MOVIES`, `SERIES`, and `RADIO`. Movies and Caminandes metadata come from `/api/qudra/open/manifest`; LIVE TV and RADIO remain honest empty states. Favorites, recent items, and VOD progress are local to this installation. Media3 receives only the manifest's HTTPS preferred direct origin.

T5 adds a local-only Personal Source foundation: HTTPS M3U/M3U8 and optional XMLTV are downloaded and parsed on the Device into staged generations. A failed, cancelled, or unusable import retains the last-known-good generation. Cloud receives only aggregate sync counts, status, source config version, and truthful EPG/catch-up/timeshift capability flags; it never receives catalogue rows or viewing history.

The debug and release variants both use application ID `com.qudra.tv`; there is no debug suffix so sideloaded debug APKs exercise the preserved product identity. Validation requires an installed JDK 17, Android SDK 35, and emulator/device. Run, in order, `./gradlew testDebugUnitTest`, `./gradlew lint`, and `./gradlew assembleDebug`; `./gradlew connectedDebugAndroidTest` is optional instrumentation evidence when an emulator is available. Emulator/UI evidence must not be described as physical Android TV playback evidence. No APK is claimed unless `assembleDebug` succeeds.
