#!/usr/bin/env node

import { createHash } from 'node:crypto';

// Dynamic loading keeps this standalone read-only operator script out of the
// client import graph; it runs only in the server-side deployment workspace.
const prismaModuleName = ['@prisma', 'client'].join('/');
const { PrismaClient } = await import(prismaModuleName);

const prisma = new PrismaClient();
const digest = (value) => createHash('sha256').update(value).digest('hex').slice(0, 12);
const countBy = (rows, key) => {
  const counts = new Map();
  for (const row of rows) counts.set(key(row), (counts.get(key(row)) ?? 0) + 1);
  return [...counts.values()].filter((count) => count > 1);
};

try {
  const [devices, trials, sources, accounts, entitlements, pointers, activeSources] =
    await Promise.all([
      prisma.qudraDevice.findMany({
        select: { id: true, publicDeviceId: true, customerId: true },
      }),
      prisma.qudraTrial.findMany({
        select: { id: true, deviceId: true, customerId: true },
      }),
      prisma.qudraSourceConfig.findMany({
        select: { id: true, deviceId: true, slot: true, customerId: true },
      }),
      prisma.qudraAccount.findMany({
        select: { id: true, customerId: true, userId: true },
      }),
      prisma.qudraEntitlement.findMany({
        select: {
          id: true,
          deviceId: true,
          customerId: true,
          state: true,
          kind: true,
          expiresAt: true,
        },
      }),
      prisma.qudraDeviceCurrentEntitlement.findMany({
        select: { id: true, deviceId: true, entitlementId: true },
      }),
      prisma.qudraActiveSource.findMany({
        select: {
          id: true,
          deviceId: true,
          customerId: true,
          kind: true,
          activeSourceConfigId: true,
        },
      }),
    ]);

  const deviceIds = new Set(devices.map((row) => row.id));
  const entitlementById = new Map(entitlements.map((row) => [row.id, row]));
  const sourceById = new Map(sources.map((row) => [row.id, row]));
  const now = new Date();
  const report = {
    databaseAvailable: true,
    readOnly: true,
    generatedAt: now.toISOString(),
    counts: {
      devices: devices.length,
      trials: trials.length,
      sources: sources.length,
      accounts: accounts.length,
      entitlements: entitlements.length,
      currentEntitlementPointers: pointers.length,
      activeSources: activeSources.length,
    },
    nullOrInvalid: {
      devicesWithoutPublicDeviceId: devices.filter((row) => !row.publicDeviceId?.trim()).length,
      trialsWithoutDeviceId: trials.filter((row) => !row.deviceId).length,
      sourcesWithoutDeviceId: sources.filter((row) => !row.deviceId).length,
      sourcesWithoutSlot: sources.filter((row) => row.slot == null).length,
      sourcesWithInvalidSlot: sources.filter(
        (row) => row.slot != null && ![1, 2].includes(row.slot),
      ).length,
      accountsWithoutCustomerId: accounts.filter((row) => !row.customerId).length,
      entitlementsWithoutDeviceId: entitlements.filter((row) => !row.deviceId).length,
    },
    duplicates: {
      publicDeviceId: countBy(
        devices.filter((row) => row.publicDeviceId?.trim()),
        (row) => row.publicDeviceId,
      ),
      trialDeviceId: countBy(
        trials.filter((row) => row.deviceId),
        (row) => row.deviceId,
      ),
      sourceDeviceSlot: countBy(
        sources.filter((row) => row.deviceId && row.slot != null),
        (row) => `${row.deviceId}:${row.slot}`,
      ),
      accountCustomerId: countBy(accounts, (row) => row.customerId),
      accountUserId: countBy(
        accounts.filter((row) => row.userId),
        (row) => row.userId,
      ),
      activeEntitlementDeviceId: countBy(
        entitlements.filter((row) => row.deviceId && row.state === 'ACTIVE'),
        (row) => row.deviceId,
      ),
      activeSourceDeviceId: countBy(activeSources, (row) => row.deviceId),
    },
    currentEntitlement: {
      missingEntitlement: pointers.filter((row) => !entitlementById.has(row.entitlementId)).length,
      deviceMismatch: pointers.filter((row) => {
        const entitlement = entitlementById.get(row.entitlementId);
        return entitlement && entitlement.deviceId !== row.deviceId;
      }).length,
      customerMismatch: pointers.filter((row) => {
        const entitlement = entitlementById.get(row.entitlementId);
        const device = devices.find((candidate) => candidate.id === row.deviceId);
        return entitlement && device && entitlement.customerId !== device.customerId;
      }).length,
      notCurrentlyUsable: pointers.filter((row) => {
        const entitlement = entitlementById.get(row.entitlementId);
        return (
          !entitlement ||
          entitlement.state !== 'ACTIVE' ||
          (entitlement.kind !== 'LIFETIME' &&
            (!entitlement.expiresAt || entitlement.expiresAt.getTime() <= now.getTime()))
        );
      }).length,
    },
    activeSource: {
      missingDevice: activeSources.filter((row) => !deviceIds.has(row.deviceId)).length,
      customerMismatch: activeSources.filter((row) => {
        const device = devices.find((candidate) => candidate.id === row.deviceId);
        return device && device.customerId !== row.customerId;
      }).length,
      openWithPersonalSource: activeSources.filter(
        (row) => row.kind === 'QUDRA_OPEN' && row.activeSourceConfigId,
      ).length,
      personalWithoutSource: activeSources.filter(
        (row) => row.kind === 'PERSONAL_SOURCE' && !row.activeSourceConfigId,
      ).length,
      personalCrossDevice: activeSources.filter((row) => {
        const source = row.activeSourceConfigId ? sourceById.get(row.activeSourceConfigId) : null;
        return row.kind === 'PERSONAL_SOURCE' && source && source.deviceId !== row.deviceId;
      }).length,
      personalCustomerMismatch: activeSources.filter((row) => {
        const source = row.activeSourceConfigId ? sourceById.get(row.activeSourceConfigId) : null;
        return row.kind === 'PERSONAL_SOURCE' && source && source.customerId !== row.customerId;
      }).length,
    },
    sourceLimit: {
      devicesOverTwo: [...new Set(sources.map((row) => row.deviceId).filter(Boolean))].filter(
        (deviceId) => sources.filter((row) => row.deviceId === deviceId).length > 2,
      ).length,
    },
    disposableCleanup: {
      confirmed: false,
      rowsRemoved: 0,
      note: 'No rows were modified or deleted. Explicit disposable-data confirmation is required before cleanup.',
    },
    fingerprints: {
      duplicatePublicDeviceIds: devices
        .filter((row) => row.publicDeviceId?.trim())
        .map((row) => row.publicDeviceId)
        .filter((value, index, values) => values.indexOf(value) !== index)
        .filter((value, index, values) => values.indexOf(value) === index)
        .map(digest),
    },
  };

  process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
} catch (error) {
  process.stderr.write(
    `${JSON.stringify({
      databaseAvailable: false,
      readOnly: true,
      error: error instanceof Error ? error.message : 'Unknown database error',
      disposableCleanup: { confirmed: false, rowsRemoved: 0 },
    })}\n`,
  );
  process.exitCode = 0;
} finally {
  await prisma.$disconnect();
}
