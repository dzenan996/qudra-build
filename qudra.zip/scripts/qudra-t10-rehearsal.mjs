#!/usr/bin/env node

// @polsia:user-owned — read-only T10 staging/recovery rehearsal.
// It deliberately never prints DATABASE_URL, source ciphertext, or fixtures.
import { existsSync, readFileSync } from 'node:fs';

const result = (status, reason) => ({ status, reason });
const blocked = (reason) => result('blocked', reason);
const conditional = (reason) => result('conditional', reason);
const passed = (reason) => result('passed', reason);

function fixtureIsSafe() {
  const fixture = process.env.QUDRA_T10_FIXTURE;
  if (!fixture) return passed('No fixture supplied; no source secret material was loaded.');
  if (!existsSync(fixture)) return blocked('The requested fixture does not exist.');
  const text = readFileSync(fixture, 'utf8');
  if (/secretCiphertext|ciphertext|plaintext|password|bearer|privateKey/i.test(text))
    return blocked('Fixtures containing source secret material are rejected.');
  return passed('Fixture contains no known secret fields.');
}

const report = {
  databaseAvailable: Boolean(process.env.DATABASE_URL),
  snapshot: blocked('Owner/platform snapshot wrapper is not available in this sandbox.'),
  forwardSchema: conditional(
    'No migration file is authored in this repo; approved forward DDL remains platform-owned.',
  ),
  backfill: conditional('Read-only inventory is prepared; no backfill was executed.'),
  constraints: conditional(
    'Constraint readiness is reported from inventory; staged DDL is pending.',
  ),
  restore: blocked('pg_dump/pg_restore and an isolated restore target are unavailable.'),
  invariants: blocked('A live non-production database is required for invariant queries.'),
  fixture: fixtureIsSafe(),
};

if (!process.env.DATABASE_URL) {
  process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
  process.exit(0);
}

const prismaModuleName = ['@prisma', 'client'].join('/');
const { PrismaClient } = await import(prismaModuleName);
const prisma = new PrismaClient();

try {
  const [devices, trials, entitlements, pointers, partners, accounts, sources, audits] =
    await Promise.all([
      prisma.qudraDevice.findMany({
        select: { id: true, customerId: true, productFamily: true, keyVersion: true },
      }),
      prisma.qudraTrial.findMany({ select: { deviceId: true, startedAt: true, endsAt: true } }),
      prisma.qudraEntitlement.findMany({
        select: {
          id: true,
          deviceId: true,
          customerId: true,
          kind: true,
          state: true,
          expiresAt: true,
        },
      }),
      prisma.qudraDeviceCurrentEntitlement.findMany({
        select: { deviceId: true, entitlementId: true },
      }),
      prisma.qudraPartner.findMany({ select: { id: true, status: true } }),
      prisma.qudraAccount.findMany({ select: { id: true, customerId: true } }),
      prisma.qudraSourceConfig.findMany({
        select: { id: true, deviceId: true, customerId: true, slot: true, secretKeyVersion: true },
      }),
      prisma.qudraTrustedAuditEvent.count(),
    ]);
  const deviceById = new Map(devices.map((row) => [row.id, row]));
  const entitlementById = new Map(entitlements.map((row) => [row.id, row]));
  const pointerIssues = pointers.filter((pointer) => {
    const entitlement = entitlementById.get(pointer.entitlementId);
    const device = deviceById.get(pointer.deviceId);
    return (
      !entitlement ||
      !device ||
      entitlement.deviceId !== pointer.deviceId ||
      entitlement.customerId !== device.customerId
    );
  });
  const sourceCounts = new Map();
  for (const source of sources) {
    const key = source.deviceId ?? `missing:${source.id}`;
    sourceCounts.set(key, (sourceCounts.get(key) ?? 0) + 1);
  }
  const violations = {
    missingTrialDevice: trials.filter((row) => !row.deviceId || !deviceById.has(row.deviceId))
      .length,
    invalidPointers: pointerIssues.length,
    devicesOverTwoSources: [...sourceCounts.values()].filter((count) => count > 2).length,
    unversionedSourceSecrets: sources.filter(
      (row) => row.secretKeyVersion !== null && row.secretKeyVersion < 1,
    ).length,
    accountWithoutCustomer: accounts.filter((row) => !row.customerId).length,
  };
  const hasViolations = Object.values(violations).some((count) => count > 0);
  report.databaseAvailable = true;
  report.snapshot = blocked(
    'Snapshot wrapper is still Owner/platform-controlled; it was not fabricated here.',
  );
  report.backfill = conditional('Inventory completed; no data was changed or backfilled.');
  report.constraints = hasViolations
    ? conditional('Inventory found rows requiring staged duplicate/null review.')
    : conditional('Inventory is clean; platform-owned staged constraints are still pending.');
  report.restore = blocked('Restore target and pg_restore are unavailable in the sandbox.');
  report.invariants = hasViolations
    ? conditional(
        JSON.stringify({
          violations,
          counts: {
            devices: devices.length,
            trials: trials.length,
            entitlements: entitlements.length,
            pointers: pointers.length,
            partners: partners.length,
            audits,
          },
        }),
      )
    : conditional(
        JSON.stringify({
          violations,
          counts: {
            devices: devices.length,
            trials: trials.length,
            entitlements: entitlements.length,
            pointers: pointers.length,
            partners: partners.length,
            audits,
          },
        }),
      );
  report.inventory = {
    devices: devices.length,
    tvDevices: devices.filter((row) => row.productFamily === 'TV').length,
    mobileDevices: devices.filter((row) => row.productFamily === 'MOBILE').length,
    annualEntitlements: entitlements.filter((row) => row.kind === 'ANNUAL').length,
    lifetimeEntitlements: entitlements.filter((row) => row.kind === 'LIFETIME').length,
    activePartners: partners.filter((row) => row.status === 'ACTIVE').length,
    personalSourceRows: sources.length,
  };
} catch {
  report.databaseAvailable = false;
  report.invariants = blocked('The configured non-production database could not be queried.');
} finally {
  await prisma.$disconnect();
}

process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
