#!/usr/bin/env node

import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const fixture = JSON.parse(
  await readFile(resolve(root, 'specs/qudra/v1/fixtures/qudra-open-manifest.json'), 'utf8'),
);
const failures = [];
const conditional = [];
const sources = [
  ...fixture.sourceRegister,
  ...fixture.series.flatMap((series) => series.episodes),
  ...fixture.testOnly.liveTv,
  ...fixture.testOnly.radio,
];

const require = (condition, message) => {
  if (!condition) failures.push(message);
};

require(fixture.manifestVersion === '3.0.0-t3b', 'manifestVersion must be 3.0.0-t3b');
require(fixture.permanent === true, 'manifest must be permanent');
require(fixture.availableWithoutEntitlement === true, 'manifest must be entitlement-free');
require(fixture.requiresPaidEntitlement === false, 'manifest must not require paid entitlement');
require(fixture.personalSourceConfig ===
  false, 'manifest must be separate from Personal SourceConfig');
require(fixture.controlPlaneProxiesBytes === false, 'manifest must not proxy media bytes');
require(fixture.liveTv.length ===
  0, 'production LIVE_TV must remain empty without verified rights');
require(fixture.radio.length === 0, 'production RADIO must remain empty without verified rights');
require(fixture.epg.nowNext === false &&
  fixture.epg.fullSchedule === false &&
  fixture.epg.catchUp === false, 'QUDRA OPEN EPG capabilities must be explicitly disabled');
require(new Set(fixture.mediaClasses).size === 4, 'all four media classes must be declared');

const classifications = new Map([
  ['movie-big-buck-bunny', 'SUPPORTED_WITH_DEVICE_TEST'],
  ['movie-sintel', 'PREFERRED'],
  ['movie-tears-of-steel', 'SUPPORTED_WITH_DEVICE_TEST'],
  ['caminandes-llama-drama', 'UNSUITABLE_AS_PRIMARY_FIXTURE'],
  ['caminandes-gran-dillama', 'SUPPORTED_WITH_DEVICE_TEST'],
  ['caminandes-llamigos', 'SUPPORTED_WITH_DEVICE_TEST'],
]);
const productionOrigins = new Set();

for (const source of sources) {
  require(source.controlPlaneProxiesBytes ===
    false, `${source.sourceId}: bytes may not be proxied`);
  require(source.webpageUrl !==
    source.directOrigin?.url, `${source.sourceId}: webpage URL cannot be the media origin`);
  require(source.legalEvidence?.license, `${source.sourceId}: license evidence is required`);
  require(source.legalEvidence
    ?.permissionEvidenceUrl, `${source.sourceId}: permission evidence is required`);
  require(source.legalEvidence?.attribution, `${source.sourceId}: attribution is required`);
  require(source.legalEvidence?.geography, `${source.sourceId}: geography is required`);
  require(source.legalEvidence
    ?.verificationStatus, `${source.sourceId}: verification status is required`);
  require(source.metadata &&
    Array.isArray(source.metadata.genres), `${source.sourceId}: metadata is required`);
  require(source.artwork === null ||
    source.artwork.status === 'VERIFIED', `${source.sourceId}: artwork must be verified or absent`);
  if (source.artwork === null) {
    conditional.push(
      `${source.sourceId}: no verified artwork; future clients must use the neutral QUDRA placeholder.`,
    );
  }
  require(source.attribution
    ?.rightsHolder, `${source.sourceId}: attribution rights holder is required`);
  require(source.attribution?.attributionText, `${source.sourceId}: attribution text is required`);
  require(source.attribution
    ?.licenseName, `${source.sourceId}: attribution license name is required`);
  require(source.attribution
    ?.licenseUrl, `${source.sourceId}: attribution license URL is required`);
  require(source.attribution
    ?.rightsEvidenceUrl, `${source.sourceId}: attribution evidence URL is required`);
  require(source.attribution?.geography, `${source.sourceId}: attribution geography is required`);
  require(Array.isArray(
    source.attribution?.restrictions,
  ), `${source.sourceId}: attribution restrictions are required`);
  require(source.capabilities &&
    typeof source.capabilities.directPlayback ===
      'boolean', `${source.sourceId}: capabilities are required`);
  require(source.capabilities?.epg === false &&
    source.capabilities?.nowNext === false &&
    source.capabilities?.fullSchedule === false &&
    source.capabilities?.catchUp === false &&
    source.capabilities?.timeshift === false &&
    source.capabilities?.recording ===
      false, `${source.sourceId}: unsupported schedule/recording capabilities must remain false`);
  require(source.compatibility
    ?.classification, `${source.sourceId}: compatibility classification is required`);
  require(source.originState, `${source.sourceId}: explicit origin state is required`);
  require(source.originState?.availability ===
    source.availability.status, `${source.sourceId}: origin and availability state disagree`);
  if (source.originState?.availability === 'AVAILABLE') {
    require(source.originState
      .lastValidatedAt, `${source.sourceId}: available origin needs lastValidatedAt`);
    if (source.directOrigin)
      require(source.originState.preferredOrigin ===
        source.directOrigin.url, `${source.sourceId}: preferred origin must identify directOrigin`);
  } else {
    require(source.originState
      ?.unavailableReason, `${source.sourceId}: unavailable origin needs a reason`);
  }
  if (source.originState?.fallbackOrigin) {
    require(source.legalEvidence.verificationStatus ===
      'VERIFIED', `${source.sourceId}: fallback origin needs verified rights evidence`);
    require(source.originState.fallbackOrigin.mediaOrigin ===
      true, `${source.sourceId}: fallback must remain a direct media origin`);
    require(source.originState.fallbackOrigin.url !==
      source.webpageUrl, `${source.sourceId}: fallback origin cannot be a webpage`);
  }
  require(source.sourceHealth
    ?.stabilityEvidence, `${source.sourceId}: stability evidence is required`);
  if (source.productionDesignation === 'PRODUCTION') {
    require(source.legalEvidence.verificationStatus ===
      'VERIFIED', `${source.sourceId}: production source must be verified`);
    require(source.directOrigin?.mediaOrigin ===
      true, `${source.sourceId}: production source needs a direct media origin`);
    require(source.availability.status ===
      'AVAILABLE', `${source.sourceId}: production source must be available`);
    require(source.sourceHealth.status ===
      'HEALTHY', `${source.sourceId}: production source must be healthy`);
    require(source.directOrigin.url !==
      source.webpageUrl, `${source.sourceId}: direct origin must differ from evidence webpage`);
    productionOrigins.add(source.directOrigin.url);
    if (classifications.has(source.sourceId))
      require(source.compatibility.classification ===
        classifications.get(
          source.sourceId,
        ), `${source.sourceId}: compatibility classification is incorrect`);
  }
}

require(productionOrigins.size === 6, 'exactly six unique production direct origins are required');
require(fixture.sourceRegister.find((source) => source.sourceId === 'movie-sintel')?.compatibility
  .classification === 'PREFERRED', 'Sintel MP4/H.264/AAC must be the preferred fixture');
const tears = fixture.sourceRegister.find((source) => source.sourceId === 'movie-tears-of-steel');
require(tears?.attribution.restrictions.some((item) =>
  /actor|likeness|privacy/i.test(item),
), 'Tears of Steel actor/likeness restriction must remain visible');
const granDillama = fixture.sourceRegister.find(
  (source) => source.sourceId === 'caminandes-gran-dillama',
);
require(granDillama?.attribution.licenseName.includes(
  'CC BY-SA',
), 'Gran Dillama must retain CC BY-SA attribution');
const series = fixture.series.find((item) => item.seriesId === 'series-caminandes');
require(series?.description, 'Series description is required');
require(series?.season?.seasonNumber === 1 &&
  series?.season?.order === 1, 'Caminandes must have one ordered season');
for (const episode of series?.episodes ?? []) {
  require(episode.episodeOrder ===
    episode.episodeNumber, `${episode.sourceId}: flat episode order must equal episode number`);
}

if (process.env.QUDRA_OPEN_SKIP_NETWORK === '1') {
  conditional.push('Network origin checks skipped by QUDRA_OPEN_SKIP_NETWORK=1.');
} else {
  const origins = new Map(
    sources
      .filter((item) => item.productionDesignation === 'PRODUCTION')
      .map((item) => [item.directOrigin.url, item]),
  );
  for (const source of origins.values()) {
    try {
      const response = await fetch(source.directOrigin.url, {
        headers: { Range: 'bytes=0-1' },
        redirect: 'follow',
        signal: AbortSignal.timeout(15000),
      });
      const contentType = response.headers.get('content-type')?.split(';', 1)[0] ?? '';
      const acceptsRange =
        response.status === 206 || response.headers.get('accept-ranges') === 'bytes';
      await response.body?.cancel();
      if (response.status === 429 || response.status >= 500) {
        conditional.push(`${source.sourceId}: origin returned transient HTTP ${response.status}.`);
        continue;
      }
      require(response.ok, `${source.sourceId}: origin returned HTTP ${response.status}`);
      require(contentType ===
        source.directOrigin.format
          .mimeType, `${source.sourceId}: origin content type ${contentType} does not match ${source.directOrigin.format.mimeType}`);
      require(acceptsRange, `${source.sourceId}: origin did not demonstrate byte-range support`);
    } catch (error) {
      conditional.push(
        `${source.sourceId}: origin probe unavailable (${error instanceof Error ? error.message : String(error)}).`,
      );
    }
  }
}

if (failures.length) {
  process.stderr.write('QUDRA OPEN validation failed:\n');
  for (const failure of failures) process.stderr.write(`- ${failure}\n`);
  process.exitCode = 1;
} else {
  process.stdout.write(
    `QUDRA OPEN validation passed (${sources.length} registered descriptors).\n`,
  );
  for (const item of conditional) process.stdout.write(`CONDITIONAL: ${item}\n`);
}
