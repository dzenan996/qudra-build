# QUDRA T12 — završni izvještaj

Datum provjere: **2026-09-09 UTC**  
Opseg: završno zatvaranje T12; nema objave, Play submissiona, marketinga,
paymenta, novog taska ili vanjske poruke.

## Sažetak odluke

Web/control-plane kod je spreman za završni Owner pregled: account deletion i
javni privacy/Data Safety inventar su implementirani, QUDRA OPEN validator i
web gateovi prolaze, a stale aktivni brand više nije pronađen. Android native
toolchain, uređaji, Cast production registracija, signing i staging
infrastruktura nisu dostupni u ovom sandboxu. T12 preporuka zato ostaje
BLOCKED za Play/production.

## T12 promijenjene datoteke

- src/app/(setup)/page.tsx — aktivni naziv QUDRA OPEN i preciznija granica
  media-player software / licence po uređaju / Personal Sources.
- src/lib/nav.ts — QUDRA OPEN label i footer reachability za /privacy i
  /account-deletion.
- src/lib/auth-config.ts — Better Auth user.deleteUser.enabled i beforeDelete hook.
- src/lib/business/account-deletion.ts — idempotentni, user-scoped cleanup
  QUDRA account identityja i Partner membershipa.
- src/lib/contracts/account-deletion.ts — zajednički Zod status/request/result ugovor.
- src/app/api/account/route.ts — GET policy/status i zaštićeni DELETE handler.
- src/components/custom/account-deletion-panel.tsx — client deletion island.
- src/app/(custom)/account-deletion/page.tsx — javna deletion metadata stranica.
- src/lib/contracts/privacy.ts — zajednički privacy/Data Safety ugovor.
- src/app/api/privacy/route.ts — javni implementation-backed inventory API.
- src/components/custom/privacy-policy-panel.tsx — privacy client island.
- src/app/(custom)/privacy/page.tsx — javna privacy metadata stranica.
- src/app/(auth)/profile/page.tsx — link prema account deletionu.
- android-mobile/README.md — aktualni Mobile target/API blocker i Owner QA upute.
- android/README.md — TV target exception i postojeći QA kontekst.
- docs/company/qudra-t12-completion.md — ovaj report.

Nisu mijenjani framework-owned auth/core files, auth Prisma schema, QUDRA Prisma
schema, migrationi, layout.tsx, proxy.ts, next.config.ts, Cast ID,
applicationId ili production secret.

## 1–43 obavezne stavke

1. **Točne promijenjene datoteke:** navedene su u popisu iznad; nove su u
   user-owned app/api/components/business/contracts zonama.
2. **Brand sweep:** exact scan prolazi; nijedna provjerena stara brand-varijanta
   ni pogrešan casing nije ostao u aktivnom customer-facing copyju.
3. **Stale customer-facing itemi:** home badge/copy i nav label sada koriste
   QUDRA OPEN; legalna granica je eksplicitna.
4. **Povijesni vanjski artefakti:** postojeći T10/T11 reporti i ranije poslani
   email/social artefakti nisu retroaktivno mijenjani; Owner ih pregledava
   izvan repozitorija.
5. **Google Play nalazi:** od 2026-08-31 novi app/update cilja API 36+, uz
   Android TV iznimku API 34+. TV traži Leanback launcher i banner 320×180;
   distribucija traži AAB, screenshot, banner, Android TV opis i review.
   Data Safety traži točan form i privacy link. Account creation traži in-app
   deletion i funkcionalan web deletion resurs. Media playback traži
   mediaPlayback i FOREGROUND_SERVICE_MEDIA_PLAYBACK. Default Cast receiver ne
   traži registraciju; Styled/Custom traži Owner ID. Affected personal account
   gate traži 12 testera kroz 14 kontinuiranih dana.
6. **Target SDK:** Mobile compile/target 35 ostaje jer SDK 36/JDK/build dokaz
   nije dostupan; status je BLOCKED. TV compile/target 35 ostaje iznad TV
   minimuma.
7. **Privacy/Data inventory:** /privacy i /api/privacy mapiraju Account,
   Device/control-plane, source metadata, device-local secrets/catalogue,
   direct-origin/Cast i not-collected. Identity, lawful basis i retention su
   OWNER_ACTION_REQUIRED, nisu izmišljeni.
8. **Data Safety mapping:** svaki inventory item ima playDataSafety mapiranje;
   Owner finalno popunjava Play Console po stvarnom package/track stanju.
9. **Account deletion:** /account-deletion je javna funkcionalna stranica.
   DELETE /api/account traži Better Auth session, točnu potvrdu i po potrebi
   password/fresh re-auth. Better Auth briše User/Account/Session; QUDRA
   account userId se odvezuje, Partner membership deaktivira/pseudonimizira,
   a Customer/Device/license/ledger/audit se ne brišu tiho. Authenticated e2e
   nije testiran bez test accounta.
10. **QUDRA OPEN review:** validator prolazi za 13 descriptora uz network skip;
    liveTv i radio ostaju prazni, synthetic izvori nisu production, a external
    legal rights i live-origin review su Owner gate.
11. **OPEN itemi:** nijedan production item nije uklonjen ovim taskom; validator
    je izdao conditional artwork/network napomene.
12. **TV identity:** com.qudra.tv, namespace com.qudra.tv, versionCode 1,
    versionName 0.1.0-t4; release postoji, R8/minify je disabled, signing nije
    commitan; native compile je BLOCKED.
13. **Mobile identity:** com.qudra.mobile, namespace com.qudra.mobile,
    versionCode 1, versionName 0.1.0-t6; release postoji, R8/minify disabled,
    receiver ID/signing nisu commitani; native compile je BLOCKED.
14. **Cast:** CC1AD845 je samo debug fallback; release bez Owner propertyja i
    release s debug ID-em fail-closed. Registration i hardware test nisu izvedeni.
15. **Source encryption:** T10 abstraction/fail-closed behavior ostaje;
    QUDRA OPEN ne ovisi o provideru. Production provider/key-ring/rotation je
    Owner-controlled i BLOCKED.
16. **Staging DB:** nema nove schema/migration promjene. Snapshot, populated
    forward rollout, backfill, restore i concurrency rehearsal ostaju BLOCKED.
17. **Toolchain:** java, adb, unzip, sdkmanager i emulator nisu pronađeni;
    ANDROID_SDK_ROOT i ANDROID_HOME su prazni.
18. **Native tests/builds:** Android Gradle test, lint, assemble, release
    compile, AAB, install, launch i runtime nisu stvarno pokrenuti.
19. **QA package:** reprodukcijske naredbe, artifact paths i matrica su niže;
    nedokazane stavke ostaju BLOCKED/NOT TESTED.
20. **Reviewer flow:** pripremljen je opis da je QUDRA player, ne seller
    sadržaja; OPEN ne traži Account; Personal Sources su user-provided/
    authorized; licensing je software licensing; nema Cloud relay. Test accounti
    nisu fabricirani.
21. **Master matrix:** nalazi se niže. Master/Clarifications authoritative
    copyji nisu zasebno pronađeni; missing wording nije izmišljan.
22. **Security regression:** npm run test: 34 fileova/181 test; QUDRA OPEN
    validator PASS; git diff --check i stale-brand scan PASS. T10 coverage je
    uključena u postojeću unit suite.
23. **Documentation:** aktivni web copy i native README upute su osvježeni;
    korisni T10/T11 audit nije brisan.
24. **Secret scan:** nema private keya, keystorea, signing passworda, Cast
    production ID-a, Personal Source credentiala ili Stripe secreta.
25. **Recurring service:** nijedan novi recurring paid service nije uveden.
26. **Owner checklist:** nalazi se niže, po native QA/staging/Play/production.
27. **Prije native QA:** Android host, JDK 17, SDK 36 Mobile, TV SDK/tools,
    Gradle, adb, uređaj/emulator, staging origin i lawful fixturei.
28. **Prije staginga:** isolated Postgres, encrypted snapshot, forward DDL/
    backfill approval, restore target, invariant queries, auth secrets,
    source-envelope provider/key-ring i staging origin.
29. **Prije Playa:** oba AAB/release compile, signing, Cast ID, privacy/legal,
    Data Safety/app-content, deletion URL, listing/reviewer i track prerequisites.
30. **Prije produkcije:** signing, Cast ID, source key-ring, DB recovery,
    lawful evidence, legal/company/retention approvals i operational support.
31. **Code/web readiness:** CONDITIONAL PASS; implementation i web gateovi
    prolaze, Owner/legal i authenticated deletion acceptance ostaju.
32. **TV readiness:** BLOCKED zbog toolchain/build/runtime nedokaza.
33. **Mobile readiness:** BLOCKED zbog API 36 kompatibilnosti/build/runtime nedokaza.
34. **Cast readiness:** BLOCKED zbog receiver registration/ID i hardware QA.
35. **Staging readiness:** BLOCKED zbog snapshot/restore/populated DB rehearsala.
36. **Play readiness:** BLOCKED zbog native, signing, Data Safety/legal, Cast,
    store assets i testing gateova.
37. **Production readiness:** BLOCKED zbog production signing/provider/DB/legal/
    native evidence gateova.
38. **Payment:** ostaje neimplementiran i nije aktiviran.
39. **Recording/Cloud DVR:** ostaju neimplementirani.
40. **Provider/media marketplace:** nema directoryja, marketplacea ni commercial
    provider catalogue claimova.
41. **Media relay/proxy:** nema Cloud relay/proxy, restreama ni transcodea;
    playback/Cast ostaju direct-origin.
42. **Excluded actions:** Play nije objavljen, marketing nije poslan, payment
    nije aktiviran, servisi nisu kupljeni i production credentiali nisu izmišljeni.
43. **Overall:** BLOCKED za Play/production; CONDITIONAL PASS samo za code/web
    uz navedene Owner/legal i native uvjete.

## Master / Owner Clarifications compliance matrix

Svaki red ima točno jedan dopušteni status.

| Zahtjev | Status | Evidence | Owner korak |
|---|---|---|---|
| Authoritative Master/Clarifications copy | BLOCKED | Zasebni Master, T3A/T3B, T4C/T8/T9 fileovi nisu pronađeni | Dostaviti authoritative copy |
| Software player only | PASS | Home, native README i legal copy | Potvrditi store wording |
| Nema subscription/content sale | PASS | Home legal boundary; nema billing koda | Nema code action |
| Payment frozen | PASS | Nema payment modulea/routea | Nema code action |
| Nema provider marketplacea | PASS | Brand sweep i aktivni copy | Nema code action |
| QUDRA OPEN lawful/open | PASS | Open manifest + validator | Owner/legal rights review |
| Android TV / Google TV | NOT TESTED | TV tree/manifest postoje, runtime nema | Native QA |
| Mobile/tablet full player | NOT TESTED | Mobile tree postoji, runtime nema | Native QA |
| Točno četiri primary area | PASS | Native home/T11 baseline | Runtime potvrda |
| My List-only switching | PASS | Native source screen | Runtime potvrda |
| Favorites/Recent/Continue | NOT TESTED | Local-state code, bez runtimea | Native smoke |
| Autoplay Next Episode | NOT TESTED | Existing policy, bez runtimea | Native smoke |
| Account optional / Device-first | PASS | Bootstrap code + account contract | Native bootstrap |
| Cryptographic Device identity | PASS | T1/T2 code i security tests | Staging invariants |
| TV/Mobile odvojeni identityji | PASS | com.qudra.tv / com.qudra.mobile | Native + staging |
| Pairing/session lifecycle | PASS | T2 route/security tests | Device integration |
| Trial 168 h / reinstall | NOT TESTED | Domain/schema, nema runtime/staging | Owner QA |
| Annual/Lifetime entitlement | NOT TESTED | T1 domain/schema | Staging invariants |
| Entitlement states/replacement | PASS | T1/T7 tests i T10 evidence | Staging rehearsal |
| OPEN nakon Trial expiry | PASS | Open contract/policy tests | Native confirmation |
| Max 2 sourcea / OPEN exception | PASS | T1/T5 rules/tests | Staging query |
| Local catalogue/EPG parsing | NOT TESTED | Android code, nema toolchaina | Fixture QA |
| Secrets fail-closed | PASS | T10 source-secret/redaction tests | Production provisioning |
| Nema Cloud catalogue/EPG | PASS | Schema, privacy, T10/T11 | Owner legal review |
| Direct playback/XMLTV/EPG | NOT TESTED | Contracts/code, bez runtimea | Native fixture |
| Catch-up/Timeshift capability-driven | PASS | Contracts i Cast policy | Device QA |
| Nema Recording/Cloud DVR | PASS | Nema modela/routea/featurea | Nema code action |
| Mobile PiP/Radio/media controls | NOT TESTED | Manifest/service postoje, runtime nema | Mobile QA |
| Cast direct-origin/no relay | PASS | Cast code + T11 evidence | Hardware QA |
| Production Cast Owner-controlled | PASS | Release fail-closed property | Owner registracija |
| Partner tenant isolation | PASS | T7 authorization tests | Staging concurrency |
| Append-only ledger/atomic activation | PASS | T7 tests + T10 evidence | Staging rehearsal |
| Super Admin / 2FA | NOT TESTED | Admin guard postoji; 2FA status nije dokazan | Owner clarification + QA |
| View-as-Partner controls | NOT TESTED | Missing authoritative T8/T9 wording | Dostaviti clarification |
| My QUDRA/support/diagnostics | NOT TESTED | Existing API/UI, bez pune native provjere | Native/support QA |
| Privacy/Data Safety | CONDITIONAL PASS | /privacy, /api/privacy, shared schema | Owner/legal final answers |
| Account deletion | CONDITIONAL PASS | /account-deletion, API, Better Auth hook | Authenticated e2e + retention |
| Signing/version/package | BLOCKED | Static Gradle audit, nema keystorea | Owner signing/build |
| Current target API | BLOCKED | Mobile 35 vs API 36 requirement | SDK 36 migration |
| Reviewer/store access | BLOCKED | Copy prepared, nema AAB/listing | Owner Play Console |

## Službeni Google izvori provjereni 2026-09-09

- Android Developers — target API: https://developer.android.com/google/play/requirements/target-sdk
- Android TV checklist: https://developer.android.com/training/tv/publishing/checklist
- Android TV distribution: https://developer.android.com/training/tv/publishing/distribute
- Play Data Safety: https://support.google.com/googleplay/android-developer/answer/10787469
- Account deletion: https://support.google.com/googleplay/android-developer/answer/13327111?hl=en-EN
- Foreground service types: https://developer.android.com/develop/background-work/services/fgs/service-types
- Cast registration: https://developers.google.com/cast/docs/registration
- Android Cast sender: https://developers.google.com/cast/docs/android_sender/integrate
- Play testing: https://support.google.com/googleplay/android-developer/answer/14151465
- Permission declarations: https://support.google.com/googleplay/android-developer/answer/9214102
- Developer contact: https://support.google.com/googleplay/android-developer/answer/13628312?hl=en

## QUDRA OPEN legal/release bilješka

Manifest ostaje specs/qudra/v1/fixtures/qudra-open-manifest.json; rights-holder,
license, attribution, geography/restrictions i evidence polja nisu prepisivani.
Network-skip validator prošao je 13 descriptora. Production liveTv=[] i
radio=[]; EPG now/next/full/catch-up i recording ostaju false. Synthetic
sources nisu production. Artwork fallback ostaje neutralni QUDRA placeholder
prema validatoru. Ako Owner runtime legality/availability gate padne, item se
disablea uz audit/evidence history, bez unauthorized replacementa.

## Android QA package

Konačni T12 status: BLOCKED / NOT TESTED. Nema JDK-a, SDK-a, adb-a,
emulatora, unzipa ili sdkmanagera; nema APK/AAB-a, keystorea ili fizičkog
TV/Mobile/Cast uređaja.

Owner reprodukcijske naredbe:

    cd android
    ./gradlew testDebugUnitTest
    ./gradlew lint
    ./gradlew assembleDebug -PqudraApiBaseUrl=https://<staging-origin>
    ./gradlew compileReleaseKotlin compileReleaseJavaWithJavac
    ./gradlew bundleRelease -PqudraApiBaseUrl=https://<staging-origin>

    cd android-mobile
    ./gradlew testDebugUnitTest
    ./gradlew lint
    ./gradlew assembleDebug -PqudraApiBaseUrl=https://<staging-origin> -PqudraCastReceiverAppId=<owner-receiver-id>
    ./gradlew compileReleaseKotlin compileReleaseJavaWithJavac
    ./gradlew bundleRelease -PqudraApiBaseUrl=https://<staging-origin> -PqudraCastReceiverAppId=<owner-receiver-id>

    adb install -r <artifact-path>
    adb shell monkey -p com.qudra.tv 1
    adb shell monkey -p com.qudra.mobile 1

Attach only successful artifacts:
android/app/build/outputs/apk/debug/app-debug.apk,
android/app/build/outputs/bundle/release/app-release.aab,
android-mobile/app/build/outputs/apk/debug/app-debug.apk and
android-mobile/app/build/outputs/bundle/release/app-release.aab.
Test bootstrap, OPEN, Personal Sources, XMLTV/EPG, direct playback, autoplay,
Catch-up/Timeshift truthfulness, D-pad/focus, PiP, Radio/media controls,
audio/subtitles, entitlement and Cast direct-origin/unsupported-source failure.
No unexecuted item is PASS.

## Owner checklist

### REQUIRED BEFORE ANDROID NATIVE QA

- Owner/Android QA — host, JDK 17, SDK/platform/build-tools 36 for Mobile and
  compatible TV tools; blocks native QA/Mobile Play; external host.
- Owner/Android QA — Gradle network, adb, emulator or physical devices; blocks
  native QA; external QA.
- Owner/Product — staging origin and lawful Personal Source/XMLTV fixtures;
  blocks integration QA; external fixture/config.
- Owner/Cast — registered production receiver ID; blocks Cast release; external
  configuration.

### REQUIRED BEFORE STAGING

- Owner/DB admin — isolated Postgres, encrypted snapshot, restore target and
  invariant queries; blocks staging; external DB/QA.
- Owner/DB admin — forward DDL/backfill/constraint approval; blocks staging;
  external approval.
- Owner/Auth — Better Auth/internal service secrets; blocks staging; external
  secret.
- Owner/Security — source-envelope provider, key-ring, active version and
  rotation plan; blocks staging/production; external config.
- Owner/Support/legal — staging origin, company identity, lawful basis and
  retention decision; blocks staging/Play; external config/legal.

### REQUIRED BEFORE GOOGLE PLAY SUBMISSION

- Owner/Release — successful TV/Mobile AAB/release compile and signing reference;
  blocks Play; external release.
- Owner/Cast — production receiver registration/ID and hardware evidence; blocks
  Play; external config/QA.
- Owner/Legal — privacy URL, company identity, lawful basis, retention and
  deletion policy; blocks Play; external legal.
- Owner/Play admin — Data Safety, app-content, permission declarations,
  reviewer explanation and safe test access; blocks Play; external Play config.
- Owner/Store — listing, screenshots, TV banner and verified support contact;
  blocks Play; external assets/config.
- Owner/Play account — applicable track prerequisites, including 12/14-day closed
  test; blocks Play; external account/QA.

### REQUIRED BEFORE PRODUCTION

- Owner/Release — production signing and approved artifacts; blocks production.
- Owner/Security — production Cast ID and source encryption provider/key-ring;
  blocks production.
- Owner/DB admin — snapshot, forward migration, restore acceptance and
  invariants; blocks production.
- Owner/Legal — lawful origin evidence, company/legal/retention approvals;
  blocks production.
- Owner/Operations — support, monitoring and Play approval; blocks production.

## YES/NO A–N

- A. **YES** — aktivni customer-facing brandovi koriste QUDRA; QUDRA OPEN je normaliziran.
- B. **YES** — nema aktivnog starog product-name customer-facing templatea.
- C. **YES** — payment ostaje neimplementiran.
- D. **YES** — Account ostaje optional; Device-first OPEN ne ovisi o Accountu.
- E. **YES** — QUDRA OPEN ostaje entitlement-free.
- F. **YES** — Personal Source catalogue/EPG ostaju Device-local.
- G. **YES** — nijedan media byte nije predviđen kroz QUDRA Cloud.
- H. **YES** — production Personal Source path ostaje fail-closed; provider provisioning je Owner blocker.
- I. **YES** — production Cast receiver ID ostaje Owner-controlled i fail-closed.
- J. **YES** — TV i Mobile ostaju odvojeno licencirani Devices.
- K. **YES** — aktualni Play zahtjevi provjereni su iz službenih izvora unutar T12.
- L. **NO** — Android TV native runtime nije stvarno validiran.
- M. **NO** — Android Mobile native runtime nije stvarno validiran.
- N. **NO** — Google Play submission nije spreman bez vanjske Owner radnje.

## Release decisions A–G

| Odluka | Status | Razlog |
|---|---|---|
| A. CODE/WEB CONTROL-PLANE READINESS | CONDITIONAL PASS | Web/API, tests, build/lint i policy surface prolaze; Owner/legal i authenticated deletion acceptance ostaju. |
| B. ANDROID TV NATIVE READINESS | BLOCKED | Nema JDK/SDK/build/runtime dokaza. |
| C. ANDROID MOBILE NATIVE READINESS | BLOCKED | Target 35 je ispod aktualnog API 36 submission requirementa; kompatibilnost i runtime nisu dokazani. |
| D. CAST PRODUCTION READINESS | BLOCKED | Fail-closed kod postoji, ali receiver registration/ID i hardware QA nedostaju. |
| E. STAGING READINESS | BLOCKED | Nema snapshot/restore/populated DB rehearsala. |
| F. GOOGLE PLAY SUBMISSION READINESS | BLOCKED | Native, signing, Data Safety/legal, Cast, listing i track gates nisu zatvoreni. |
| G. PRODUCTION READINESS | BLOCKED | Signing, provider/key-ring, DB recovery, lawful/legal i native evidence nisu zatvoreni. |

Payment, Recording/Cloud DVR, provider/media marketplace, media relay/proxy,
restream, transcode, production credentials, Play publication, marketing,
outreach, social deletion i kupnja servisa nisu izvršeni. Nakon ovog reporta
T12 staje.
