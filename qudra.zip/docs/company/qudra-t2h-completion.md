# QUDRA T2H completion report

Date: 2026-09-08

Recommendation: **CONDITIONAL PASS**

The exact path list below is authoritative for this run:

- `.env.example`
- `docs/company/qudra-t2-completion.md`
- `docs/company/qudra-t2h-completion.md`
- `docs/company/qudra-t2h-migration-review.md`
- `prisma/schema/qudra-t1.prisma`
- `scripts/qudra-t2h-preflight.mjs`
- `specs/qudra/v1/domain.md`
- `specs/qudra/v1/fixtures/t1-fixtures.json`
- `specs/qudra/v1/openapi.yaml`
- `specs/qudra/v1/state-machines.md`
- `src/app/api/qudra/devices/[deviceId]/active-source/route.ts`
- `src/app/api/qudra/devices/[deviceId]/session/route.ts`
- `src/app/api/qudra/pairing/challenges/route.ts`
- `src/lib/business/qudra/access.ts`
- `src/lib/business/qudra/audit.ts`
- `src/lib/business/qudra/authority.ts`
- `src/lib/business/qudra/device-keys.ts`
- `src/lib/business/qudra/device-session.ts`
- `src/lib/business/qudra/diagnostics.ts`
- `src/lib/business/qudra/domain.ts`
- `src/lib/business/qudra/entitlement.ts`
- `src/lib/business/qudra/pairing.ts`
- `src/lib/business/qudra/replacement.ts`
- `src/lib/business/qudra/sources.ts`
- `src/lib/business/qudra/trial.ts`
- `src/lib/contracts/generated/qudra.ts`
- `src/lib/contracts/qudra-device-session.ts`
- `src/lib/contracts/qudra-pairing.ts`
- `src/lib/env.ts`
- `tests/unit/qudra-t1-contract.test.ts`
- `tests/unit/qudra-t2-routes.test.ts`
- `tests/unit/qudra-t2-schema.test.ts`
- `tests/unit/qudra-t2h-hardening.test.ts`

No Prisma migration was added or edited. `prisma/migrations/**` remains
framework-owned; the reviewed production migration and recovery plan is in
`qudra-t2h-migration-review.md`.

## Changed files

- `prisma/schema/qudra-t1.prisma` and `prisma/schema/qudra-t2.prisma`: additive
  Device/account/trial/source/entitlement shape, pairing idempotency, Device
  sessions, rate windows, and current key/pointer constraints. The
  populated-table uniqueness/requiredness changes remain staged in the platform
  migration review.
- `src/lib/business/qudra/authority.ts`, `pairing.ts`, `device-session.ts`,
  `device-keys.ts`, `audit.ts`, `diagnostics.ts`, `entitlement.ts`,
  `access.ts`, and `sources.ts`: authority, pairing, session, current-state,
  source, and trusted-write hardening.
- `src/app/api/qudra/pairing/**`, internal QUDRA handlers, and
  `src/app/api/qudra/devices/[deviceId]/session/route.ts`: route wiring and
  server-only boundaries.
- `src/lib/contracts/qudra-pairing.ts`, new `qudra-device-session.ts`,
  `specs/qudra/v1/openapi.yaml`, and regenerated
  `src/lib/contracts/generated/qudra.ts`.
- `src/lib/env.ts` slot and `.env.example` for server-only scoped service
  credentials and configurable throttle ceilings.
- `scripts/qudra-t2h-preflight.mjs`, this report, and
  `docs/company/qudra-t2h-migration-review.md`.
- Updated QUDRA schema/contract tests.

Exact test/route additions are `src/lib/business/qudra/device-session.ts`,
`src/lib/contracts/qudra-device-session.ts`,
`src/app/api/qudra/devices/[deviceId]/session/route.ts`,
`scripts/qudra-t2h-preflight.mjs`,
`docs/company/qudra-t2h-migration-review.md`, and
`tests/unit/qudra-t2h-hardening.test.ts`. No Prisma migration was added or
edited; `.polsia/installed.json`, auth files, and framework-owned migrations
were unchanged.

No migration file was added or edited. The platform-owned migration path and
non-production rehearsal requirement are documented in the migration review.

## Acceptance details

The disposable preflight found zero Devices, Trials, SourceConfigs, Accounts,
Entitlements, current-entitlement pointers, or ActiveSource rows. Every
requested null/invalid class, duplicate public ID, duplicate trial, duplicate
source slot, duplicate Account link, pointer mismatch, active-source mismatch,
and over-two-source count was zero. No row was modified or deleted; disposable
cleanup remains unconfirmed.

The schema keeps existing populated-table fields additive: `publicDeviceId`,
Trial `deviceId`, Entitlement `deviceId`, and SourceConfig `deviceId`/`slot`
remain compatible with historical rows, with lookup indexes. New session and
rate-window records have durable uniqueness, while existing DeviceKey,
diagnostic, active-source, and current-entitlement pointer uniqueness is
preserved. Service logic limits slots to 1/2 and enforces same-Device Personal
Source references and QUDRA_OPEN fallback. Public-ID, one-trial, one-account,
and `(deviceId, slot)` database constraints remain pending the staged,
platform-owned backfill and validation described in the migration review.

Historical entitlements are retained. Activation replaces prior ACTIVE rows and
upserts the current pointer; current selection requires same Device/Customer,
ACTIVE state, and either LIFETIME or an expiry later than authoritative time.
Replacement is same-Customer-only and preserves the successor link.

Pairing is fixed at 600,000 ms with five attempts, one pending challenge per
Device, rotation invalidation, durable five-per-Device/hour and configurable
request-source throttles, committed failed attempts, one concurrent winner,
replay rejection, and idempotent retries. QR contains only the opaque challenge
ID and expiry. Device authority is current-key cryptographic proof plus a
24-hour digest-only Device-bound session; key rotation and revocation invalidate
sessions. Internal service records are server-only, scoped, optionally
expiring, constant-time compared, and rotatable. Personal Source remains
envelope-only/fail-closed without production KMS; QUDRA OPEN remains isolated.

## Control-plane result

- `publicDeviceId` remains required and is indexed; QUDRA Account, Trial, and
  SourceConfig relationship constraints are enforced in service code pending
  the reviewed platform migration. The intended final state is zero-or-one
  Account per Customer/User, one Trial per Device, and required SourceConfig
  Device/slot with unique `(deviceId, slot)`; service validation permits only
  slots 1/2 now.
- Historical Entitlements remain. Activation replaces prior active rows,
  assigns one current pointer transactionally, and reads require a same-Device,
  same-Customer usable ACTIVE entitlement with future annual expiry or valid
  LIFETIME state.
- Pairing lifetime is fixed at 600,000 ms, max five attempts, one pending
  challenge per Device, rotation invalidates pending challenges, completion
  claims an attempt atomically, success is permanently consumed, retries are
  idempotent, and QR returns only the opaque challenge id.
- Device sessions store only a digest, expire after 24 hours, are bound to the
  current Device key version, and are revoked on key rotation/revocation.
  Public IDs and MAC-like submitted identifiers are never authority.
- Internal credentials are server-only JSON service records with identity,
  scopes, optional expiry, constant-time comparison, and scope checks. Trusted
  audit/diagnostic/entitlement/replacement writes derive the actor and reject
  ordinary client authority.
- Personal Source writes remain envelope-only and fail closed without an
  approved envelope/KMS provider. QUDRA OPEN is isolated, entitlement-free,
  and active-source deletion falls back to QUDRA_OPEN. No parser or production
  KMS was added.

## Validation and blockers

- `node --env-file=.env scripts/qudra-t2h-preflight.mjs`: passed; zero rows,
  zero findings, read-only, zero cleanup.
- `npx prisma validate`: passed.
- `npx prisma db push`: passed against the disposable database without
  `--accept-data-loss`; Prisma Client regenerated.
- `npm run generate:qudra`: passed; generated contract refreshed from OpenAPI.
- `npm test -- --run`: passed, 16 files and 140 tests.
- `npm run typecheck`: passed.
- `bash .agents/verify.sh`: build passed and lint passed.
- Runtime smoke: `/health` 200, diagnostic codes 200, and unauthenticated
  registration/internal-audit/pairing creation 403; the dev server stopped
  cleanly without application errors.

The verify ownership pre-check was skipped because its temporary `git add`
cannot write the sandbox's read-only `.git/index`. The working-tree content of
the better-auth contribution fence in `src/lib/env.ts` is restored exactly to
the protected baseline; QUDRA variables are in the surrounding shared slots.

This remains conditional because the platform owner must approve and rehearse
the populated production forward migration/recovery plan and source-slot
database check, and an approved envelope/KMS provider is required before
staging real Personal Source credentials. Production service credentials must
be supplied through the deployment vault. No recurring paid infrastructure was
introduced. No T4–T7 or excluded Android UI/player, payment, Partner/Admin,
Cast, Timeshift, Recording, provider directory, commercial media,
relay/proxy/restream/transcoding, marketing, recurring infrastructure, or full
M3U/XMLTV parsing work was added.
