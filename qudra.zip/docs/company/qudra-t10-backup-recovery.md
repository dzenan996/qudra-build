# QUDRA T10 — backup i recovery procedura

Procedura je namijenjena control-plane Postgres bazi i izvodi se samo nad odobrenim non-production/staging targetom prije production authorizationa.

## Snapshot

1. Owner/platform backup service radi konzistentni Postgres snapshot ili `pg_dump --format=custom` tijekom najavljenog write freeze/serializable prozora.
2. Backup manifest bilježi schema fingerprint, timestamp, row counts i checksum artefakta. `DATABASE_URL` se čita iz secret storea i nikad se ne ispisuje.
3. U backup ulaze Device identity/key-version metadata, trials, entitlements, Partner membership/scope, credit account + append-only ledger, activations, replacement lineage, audit metadata i odobrene config reference vrijednosti.
4. Ne uključuju se Personal Source plaintext credentials, source ciphertext u operator outputu, device-local catalogue/EPG/media rows ili media byteovi. Ako ciphertext mora biti dio control-plane retentiona, ostaje vault/backed encrypted column bez dekripcije u exportu.
5. Retention, encryption-at-rest, access log i deletion schedule određuje Owner/platform backup service. T10 ne kupuje niti aktivira novi recurring servis.

## Restore rehearsal

1. Restore snapshot u izolirani non-production Postgres; nikad preko production targeta.
2. Pokrenuti `node scripts/qudra-t10-rehearsal.mjs` i zapisati `databaseAvailable`, `snapshot`, `forwardSchema`, `backfill`, `constraints`, `restore` i `invariants` rezultate.
3. Pokrenuti Prisma schema validation/generate i read-only inventory. Provjeriti representative TV/Mobile Devices, 168-hour trials, annual/lifetime entitlement stateove, Partner scopes/credits/activations, replacement lineage i audit records.
4. Provjeriti da se current entitlement pointer slaže s Device/customerom, da Device ima najviše dva Personal Source slota, da QUDRA OPEN nije vezan uz source config i da source metadata nema customer-visible secrets.
5. Prihvat restorea zahtijeva jednak ili očekivan broj canonical rows, nula ownership/pointer violations, uspješan schema validation i dokumentirani RTO/RPO rezultat Ownera.

U ovom sandboxu nema `pg_dump`, `pg_restore`, Owner snapshot wrappera ni garantirane populated `DATABASE_URL` baze, zato snapshot/restore nisu proglašeni passed. Reproducible procedure i read-only runner su pripremljeni; stvarni backup action ostaje Owner-controlled.
