# QUDRA T2H migration review

Date: 2026-09-08

## Preflight

`node --env-file=.env scripts/qudra-t2h-preflight.mjs` was run before the
schema change against the disposable database. It was read-only. The database
contained zero Devices, Trials, SourceConfigs, Accounts, Entitlements,
current-entitlement pointers, or ActiveSource rows. Every requested null,
duplicate, pointer, active-source, and over-two-source finding was zero. No
row was deleted or modified; disposable cleanup confirmation was not supplied
and therefore remains `confirmed: false`.

## Forward-only rollout reviewed

The intended production rollout is staged:

1. Snapshot and inventory the populated QUDRA tables, retaining historical
   entitlements and an immutable export/checksum outside the application.
2. Stop writes for the affected control-plane operations, or take an
   equivalent serializable maintenance window.
3. Backfill missing Device relationships only from an independently verified
   Device-to-customer mapping. Reject ambiguous rows; do not guess or merge
   real customer data.
4. Resolve duplicate public IDs, Device trials, account links, and source
   slots by an owner-approved mapping. Only explicitly disposable development
   or test rows may be removed, and every removed ID must be recorded in the
   operator's change record.
5. Validate customer/device ownership, current-entitlement pointers, usable
   entitlement state, and same-Device ActiveSource references.
6. Add `NOT NULL`, unique, and `(deviceId, slot)` constraints, plus a database
   check for source slots `1` or `2`, in a forward-only platform migration.
7. Re-run the inventory and constraint validation, then release writes.

This repository intentionally contains no executable migration file: the
template owns `prisma/migrations/**` and deploys the schema with `prisma db
push`. The checked-in additive Prisma schema is validated and applied to the
empty non-production database with plain `npx prisma db push` (without
`--accept-data-loss`). That is not evidence that a populated production rollout
is safe. A platform owner must approve and execute the staged migration above,
including the source-slot check and production backfill.

## Recovery and rollback rehearsal

Before staging, rehearse on a non-production clone: restore the preflight
snapshot, apply the forward DDL, run all invariant queries, exercise Device
registration/pairing/entitlement/source fallback, and restore the snapshot to
confirm recovery. Rollback is restore-based for constraints and backfills;
application rollback alone must not attempt to recreate deleted or merged
rows. Production remains blocked until this rehearsal and owner approval are
recorded.
