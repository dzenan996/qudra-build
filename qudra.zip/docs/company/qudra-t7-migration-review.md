# QUDRA T7 — pregled forward rollouta

Ovaj dokument je pregled rollouta, a ne izvršna migracija. T7 koristi schema-only
model templatea: u repozitoriju nema novih Prisma migration SQL datoteka.

## Redoslijed i kontrole

1. U non-production kopiji pokrenuti `npx prisma validate`, `npx prisma generate`
   i `npx prisma db push`, bez `--accept-data-loss`.
2. Prije rollouta napraviti snapshot baze i inventuru postojećih T1–T6 tablica,
   posebno Customer, Device, Entitlement, Trial i audit zapisa.
3. Novi T7 modeli kreiraju se prazni. Svaki owner-approved backfill partner
   membershipa, scopea ili kredita mora imati zaseban plan i idempotentni dry-run.
4. Constraint rehearsal provjerava membership uniqueness, activation idempotency,
   ledger operation key i jedan credit account po Partneru.
5. Nakon restore-based recovery probe provjeriti da su Customer/Device scalar
   reference, append-only ledger i audit feed čitljivi bez Personal Source tajni.

## Odluka

Rollout je forward-only i additive. `migrations created: none in repo; platform
forward rollout reviewed`. Produkcijski rollout zahtijeva owner-approved snapshot,
backfill i restore dokaz prije uključivanja novih Partner operacija.
