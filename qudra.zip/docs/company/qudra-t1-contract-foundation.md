# QUDRA T1R contract foundation

T1R is the linked revision of the T1 contract/schema foundation. It is
deliberately limited to contract, domain, schema, fixtures, generated types,
tests, and documentation. No runtime route, production authentication,
payment, media service, parser, player, or T2-T7 work is included.

## Canonical files

- [OpenAPI 3.1 contract](../../specs/qudra/v1/openapi.yaml)
- [Domain decisions](../../specs/qudra/v1/domain.md)
- [State machines](../../specs/qudra/v1/state-machines.md)
- [T1 fixtures](../../specs/qudra/v1/fixtures/t1-fixtures.json)
- [Prisma foundation schema](../../prisma/schema/qudra-t1.prisma)
- [Generated TypeScript](../../src/lib/contracts/generated/qudra.ts)
- [Contract tests](../../tests/unit/qudra-t1-contract.test.ts)

## Locked foundation

Customer is the durable owner; an optional Customer Account may manage multiple
Devices without combining their licenses. Device is the commercial unit.
Internal device id is separate from the unique opaque publicDeviceId required
by the API for new Devices; legacy rows retain nullable storage during the
additive backfill period.
ANDROID_TV, ANDROID_PHONE, and ANDROID_TABLET are classified into TV or
MOBILE, with optional non-secret app/API/model metadata.

Trial, Entitlement, and personal SourceConfig are each device-owned. One trial
and one entitlement are represented per Device; at most two personal sources
is an application invariant. QUDRA OPEN is a permanent separate manifest.
Active source state supports QUDRA OPEN or a same-device personal source and
falls back to QUDRA OPEN on deletion. No personal catalogue rows exist.

Trials use exactly 168 elapsed hours. Entitlements support annual/lifetime,
direct/partner provenance, all five commercial states, validation metadata, a
72-hour initial offline-grace target, and immutable replacement linkage.
Replacement is same-Customer only, standard once per 12 months, with earlier
cases reserved for a future Super Admin exception. Pairing and recovery are
bounded at five attempts; QR is the same pairing challenge; publicDeviceId
alone cannot recover a device.

OpenAPI descriptions identify Device, Account/Customer, future Partner, future
Super Admin, and internal-service boundaries. Bearer security is a placeholder,
not production auth. Diagnostic reads are current/latest and authorized;
trusted diagnostic and audit appends are internal-only. Audit metadata is
redacted and follows the canonical event catalogue.

## Schema policy and pre-T2 decisions

The Prisma setup remains schema-only: _base.prisma is unchanged and no
migrations are added. T1R preserves legacy enum values and columns and keeps
new device ownership fields nullable where existing rows require additive
compatibility. The existing account, public-device, trial, entitlement, and
source-config tables do not receive new uniqueness constraints in this one-shot
revision because `prisma db push` rejects them on populated tables. Their
one-account/one-device contract invariants remain authoritative, but a reviewed
backfill/deduplication migration is required before database enforcement; T1R
does not replace that with a race-prone runtime check. New foundation tables
retain safe uniqueness.

Before T2, confirm the authoritative Master Specification identifiers and
wording, the production authentication/authority model, key/envelope/KMS
format, recovery evidence policy, Super Admin workflow, diagnostic retention
and probe ownership, audit tamper-evidence sink, and downstream Kotlin
generator/version. Also decide operational replacement timing and entitlement
renewal/idempotency semantics. None is silently implemented by T1R.

## Recommendation

**CONDITIONAL PASS for T1R foundation scope**: the disposable deployment
database now accepts `prisma db push` without data-loss warnings. Promotion
still requires the staged backfill/uniqueness work above before claiming
database-enforced one-account/one-device cardinality, plus the pre-T2 decisions.
