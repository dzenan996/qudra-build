# QUDRA T10 — staging readiness inventory

Staging konfiguracija mora biti unesena kroz platform secret/config sloj. Nijedna stvarna tajna nije commitana u repo.

| Vrijednost | Klasifikacija | Pravilo spremnosti |
| --- | --- | --- |
| `DATABASE_URL` | required environment value | Private non-production Postgres URL; TLS i izolirani restore target. |
| `NEXT_PUBLIC_APP_URL` | required environment value | Staging origin; ne koristiti production origin. |
| `BETTER_AUTH_SECRET` | Owner-controlled secret/account | Strong vault secret; ne rotirati bez session plana. |
| `BETTER_AUTH_URL` | required environment value | Isti staging auth origin. |
| `BETTER_AUTH_TRUSTED_ORIGINS` | optional feature configuration | Samo odobreni staging/API origins. |
| `QUDRA_INTERNAL_SERVICE_CREDENTIALS` | Owner-controlled secret/account | JSON service records sa scopeovima, expiryjem i rotacijom; nikad browser/Android. |
| `QUDRA_SOURCE_ENVELOPE_PROVIDER` | required environment value | Approved provider adapter; production bez provider konfiguracije fail-closed. |
| `QUDRA_SOURCE_ENVELOPE_KEY_RING` | Owner-controlled secret/account | JSON version → base64url 32-byte key; vault-only, nikad log/fixture. |
| `QUDRA_SOURCE_ENVELOPE_ACTIVE_KEY_VERSION` | required environment value | Postojeća aktivna verzija koja je prisutna u key-ringu. |
| `QUDRA_PAIRING_DEVICE_RATE_LIMIT_PER_HOUR` | safe default | Default 5; Owner može postaviti strožu vrijednost. |
| `QUDRA_PAIRING_SOURCE_RATE_LIMIT_PER_HOUR` | safe default | Default 20; Owner može postaviti strožu vrijednost. |
| `QUDRA_BOOTSTRAP_FINGERPRINT_RATE_LIMIT_PER_HOUR` | safe default | Default 5; abuse ceiling za fingerprint. |
| `QUDRA_BOOTSTRAP_SOURCE_RATE_LIMIT_PER_HOUR` | safe default | Default 20; abuse ceiling za source window. |
| `QUDRA_ANDROID_API_ORIGIN` | required environment value | Android build input koji pokazuje na staging control-plane origin. |
| `QUDRA_CAST_RECEIVER_ID` | optional feature configuration | Samo dependency reference; Cast receiver registracija nije T10 implementacija. |
| `POLSIA_COMPANY_EMAIL` | required environment value | Postojeći support/contact recipient je `qudra@polsia.app`; ne fabricirati drugi domain. |
| `QUDRA_SIGNING_KEY_REFERENCE` | optional feature configuration | Placeholder samo ako Owner uvede signing; stvarni key ostaje Owner-controlled. |
| `NEXT_PUBLIC_API_URL` | optional feature configuration | Prazno za same-origin API; external origin samo uz CSP/platform approval. |

T10 ne uvodi payment, email servis, AI, R2, Cast servis ni drugi recurring paid dependency. `QUDRA OPEN` ne ovisi o source encryption provideru; credential-bearing Personal Source write/open ovisi o njemu.
