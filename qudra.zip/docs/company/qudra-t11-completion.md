# QUDRA T11 — završni izvještaj

Preporuka: **CONDITIONAL PASS**. T11 native/Cast code closure je pripremljen i web/security regresija je zelena, ali Android build, instalacija, runtime i fizički Cast nisu validirani jer sandbox nema JDK, `unzip`, Android SDK, `adb`, emulator ni Cast uređaj. `BLOCKED` i `NOT TESTED` u nastavku nisu preimenovani u `PASS`.

## Obaveznih 50 stavki

1. **Promijenjene datoteke:** `android-mobile/README.md`; `android-mobile/app/build.gradle.kts`; `android-mobile/gradle/libs.versions.toml`; `android-mobile/app/src/main/java/com/qudra/mobile/cast/CastCapabilityDetector.kt`; `android-mobile/app/src/main/java/com/qudra/mobile/cast/CastSessionCoordinator.kt`; `android-mobile/app/src/main/java/com/qudra/mobile/cast/QudraCastOptionsProvider.kt`; `android-mobile/app/src/main/java/com/qudra/mobile/ui/HomeScreen.kt`; `android-mobile/app/src/main/res/values/strings.xml`; `android-mobile/app/src/test/java/com/qudra/mobile/cast/CastCapabilityDetectorTest.kt`; ovaj report `docs/company/qudra-t11-completion.md`.
2. **Dostupan toolchain:** `java`, `javac`, `adb`, `unzip`, `sdkmanager` i `emulator` nisu pronađeni; `ANDROID_SDK_ROOT` i `ANDROID_HOME` su prazni. Gradle wrapper nije mogao preuzeti/raspakirati distribuciju.
3. **TV Gradle:** `BLOCKED` — `android/./gradlew testDebugUnitTest` završio je na `unzip: not found` prije Gradlea.
4. **TV unit test:** `BLOCKED` — JDK/Gradle wrapper nisu dostupni.
5. **TV lint:** `BLOCKED` — JDK/Gradle wrapper nisu dostupni.
6. **TV assembleDebug/release compile:** `BLOCKED` — `android/./gradlew assembleDebug -PqudraApiBaseUrl=https://staging.invalid` nije mogao pokrenuti wrapper; release compile/bundle nije izvršen.
7. **TV APK/AAB:** `NOT TESTED` — nema generiranog APK-a ili AAB-a, pa nema putanje ni veličine.
8. **Mobile Gradle:** `BLOCKED` — `android-mobile/./gradlew testDebugUnitTest` završio je na `unzip: not found` prije Gradlea.
9. **Mobile unit test:** `BLOCKED` — JDK/Gradle wrapper nisu dostupni.
10. **Mobile lint:** `BLOCKED` — JDK/Gradle wrapper nisu dostupni.
11. **Mobile assembleDebug/release compile:** `BLOCKED` — debug assemble i `compileReleaseKotlin compileReleaseJavaWithJavac` nisu mogli pokrenuti wrapper; release bundle nije izvršen.
12. **Mobile APK/AAB:** `NOT TESTED` — nema generiranog APK-a ili AAB-a, pa nema putanje ni veličine.
13. **Pronađeni i popravljeni defekti:** Mobile je dobio `media3-exoplayer-hls`; release Cast receiver ID više nema fallback; debug fallback `CC1AD845` je eksplicitno razvojni; Cast provjerava `remoteMediaClient` i asinkroni `load` rezultat; lokalni credential-free kompatibilni `PlaylistEntry` sada ima Cast akciju; dodane su regresije za lokalni Cast policy.
14. **TV runtime okruženje:** `NOT TESTED` — nema TV emulatora ili uređaja.
15. **Stvarno testirani TV scenariji:** `NOT TESTED` — nisu izvođeni bootstrap, QUDRA OPEN, izvori, playback, EPG, D-pad, lifecycle ili entitlement scenariji.
16. **Mobile runtime okruženje:** `NOT TESTED` — nema Android phone/tablet emulatora ili uređaja.
17. **Stvarno testirani Mobile scenariji:** `NOT TESTED` — nisu izvođeni bootstrap, Home područja, My List, source lifecycle, playback, PiP, media controls, session ili Cast scenariji.
18. **Personal Source fixture:** `NOT TESTED` — nema Android JVM/instrumentation pokretanja; statički kod odbija credential-bearing URI-je i capability-dependent catch-up/timeshift Cast.
19. **XMLTV/EPG:** `NOT TESTED` — postojeći parser/store nisu mijenjani; Android test nije pokrenut zbog toolchain blockera.
20. **Catch-up:** `NOT TESTED` — bez device runtimea; Cast policy ga izričito odbija kada je capability označen.
21. **Timeshift:** `NOT TESTED` — bez device runtimea; Cast policy ga izričito odbija kada je capability označen.
22. **TV autoplay:** `NOT TESTED` — nema TV builda ili runtimea.
23. **Mobile autoplay:** `NOT TESTED` — nema Mobile builda ili runtimea; postojeći kod zadržava autoplay policy i final-episode stop.
24. **PiP:** `NOT TESTED` — nema Mobile uređaja/emulatora; postojeća granica ne ulazi u PiP za Radio.
25. **Radio/background/media-session:** `NOT TESTED` — nema device runtimea; postojeći Mobile `PlaybackService` i MediaSession nisu mijenjani.
26. **D-pad/focus:** `NOT TESTED` — nema TV uređaja/emulatora.
27. **Audio/subtitles:** `NOT TESTED` — nema player runtimea.
28. **Točna Cast production arhitektura:** Mobile sender šalje direktni HTTPS origin kroz Google Cast session u receiver; media bytes ne prolaze kroz QUDRA Cloud. Sender šalje samo URL/MIME za odobreni source, bez credentiala, headera ili tokena.
29. **Same-local-network/Wi‑Fi:** Google Cast discovery/session ostaju framework granica. QUDRA provjerava samo aktivnu Cast session i dokazivi Wi‑Fi/Ethernet transport; ne tvrdi dokaz istog SSID-a, subneta ili jače mrežne sigurnosti.
30. **Development vs production receiver ID:** debug bez propertyja koristi jasno označeni `CC1AD845`; release bez Owner propertyja koristi prazan ID i provider fail-closed; release eksplicitno odbija i razvojni ID.
31. **Potrebna Owner akcija:** registrirati production receiver u Google Cast Developer Console i predati ga pri release buildu kroz `-PqudraCastReceiverAppId=<owner-receiver-id>`; stvarni ID nije izmišljen niti commitan.
32. **Stvarno testirani Cast scenariji:** `NOT TESTED` — nema Cast-capable hardwarea. Code/static closure pokriva direct-origin QUDRA OPEN, lokalni kompatibilni source, session/media-client provjeru i async rezultat.
33. **Unsupported Cast ponašanje:** `PASS` za statički/unit-level policy namjeru — HTTP, userinfo, secret/token query, nepoznati source capability, catch-up, timeshift i nepodržani container vraćaju točno `This source cannot be Cast.`; fizički receiver reject nije testiran.
34. **Receiver ne treba QUDRA TV licencu:** `PASS` za implementacijsku granicu — Cast receiver prima sender media request i ne dobiva QUDRA entitlement; stvarni runtime nije testiran.
35. **Nema Cloud media relaya:** `PASS` za code/static inspection — `MediaInfo` se gradi izravno iz source URI-ja; nije uveden proxy, relay, restream ni transcode.
36. **APK secret/config inspection:** `NOT TESTED` — APK nije generiran. Static inspection potvrđuje da se production receiver ID ne nalazi u resourceu; `CC1AD845` ostaje samo debug fallback/guard i ne koristi se za release fallback.
37. **Release signing readiness:** `BLOCKED` — signing nije pokretan i keystore nije dostupan. Owner mora osigurati odobren signing reference/keystore izvan repozitorija; tajne nisu fabricirane.
38. **Reproducibilne vanjske naredbe:** na Android-capable hostu s JDK 17, SDK/platform/build-tools 35, `adb`, emulatorom i mrežom:
    - TV: `cd android && ./gradlew testDebugUnitTest && ./gradlew lint && ./gradlew assembleDebug -PqudraApiBaseUrl=https://<staging-origin>`
    - TV release compile: `cd android && ./gradlew compileReleaseKotlin compileReleaseJavaWithJavac`; bundle samo uz dopušten signing konfiguraciju: `./gradlew bundleRelease -PqudraApiBaseUrl=https://<staging-origin>`.
    - Mobile: `cd android-mobile && ./gradlew testDebugUnitTest && ./gradlew lint && ./gradlew assembleDebug -PqudraApiBaseUrl=https://<staging-origin> -PqudraCastReceiverAppId=<owner-receiver-id>`
    - Mobile release compile: `cd android-mobile && ./gradlew compileReleaseKotlin compileReleaseJavaWithJavac`; bundle samo uz dopušten signing konfiguraciju: `./gradlew bundleRelease -PqudraApiBaseUrl=https://<staging-origin> -PqudraCastReceiverAppId=<owner-receiver-id>`.
    - Device smoke: `adb install -r app/build/outputs/apk/debug/app-debug.apk`; TV `adb shell monkey -p com.qudra.tv 1`; Mobile `adb shell monkey -p com.qudra.mobile 1`.
39. **TV acceptance matrix:**

    | Stavka | Status | Dokaz/napomena |
    |---|---|---|
    | Build | `BLOCKED` | Nema JDK/Gradle wrapper alata. |
    | Install/launch | `NOT TESTED` | Nema APK-a ni `adb`. |
    | Device bootstrap | `NOT TESTED` | Nema emulatora/uređaja. |
    | QUDRA OPEN | `NOT TESTED` | Web validator nije TV runtime dokaz. |
    | Personal Sources | `NOT TESTED` | Nema TV runtimea. |
    | My List | `NOT TESTED` | Nema TV runtimea. |
    | Live | `NOT TESTED` | Nema TV runtimea. |
    | Movies | `NOT TESTED` | Nema TV runtimea. |
    | Series/autoplay | `NOT TESTED` | Nema TV runtimea. |
    | Radio | `NOT TESTED` | Nema TV runtimea. |
    | XMLTV/EPG | `NOT TESTED` | Nema TV runtimea. |
    | Catch-up | `NOT TESTED` | Nema TV runtimea. |
    | Timeshift | `NOT TESTED` | Nema TV runtimea. |
    | Audio/subtitles | `NOT TESTED` | Nema TV runtimea. |
    | D-pad/focus | `NOT TESTED` | Nema TV runtimea. |
    | Lifecycle | `NOT TESTED` | Nema TV runtimea. |
    | Trial/entitlement | `NOT TESTED` | Nema TV runtimea. |

40. **Mobile acceptance matrix:**

    | Stavka | Status | Dokaz/napomena |
    |---|---|---|
    | Build | `BLOCKED` | Nema JDK/Gradle wrapper alata. |
    | Install/launch | `NOT TESTED` | Nema APK-a ni `adb`. |
    | Device bootstrap | `NOT TESTED` | Nema emulatora/uređaja. |
    | QUDRA OPEN | `NOT TESTED` | Web validator nije Mobile runtime dokaz. |
    | Personal Sources | `NOT TESTED` | Nema Mobile runtimea. |
    | My List | `NOT TESTED` | Nema Mobile runtimea. |
    | Live | `NOT TESTED` | Nema Mobile runtimea. |
    | Movies | `NOT TESTED` | Nema Mobile runtimea. |
    | Series/autoplay | `NOT TESTED` | Nema Mobile runtimea. |
    | Radio/background playback | `NOT TESTED` | Nema Mobile runtimea. |
    | XMLTV/EPG | `NOT TESTED` | Nema Mobile runtimea. |
    | Catch-up | `NOT TESTED` | Nema Mobile runtimea. |
    | Timeshift | `NOT TESTED` | Nema Mobile runtimea. |
    | PiP | `NOT TESTED` | Nema Mobile runtimea. |
    | Android media controls | `NOT TESTED` | Nema Mobile runtimea. |
    | Audio/subtitles | `NOT TESTED` | Nema Mobile runtimea. |
    | Portrait/landscape | `NOT TESTED` | Nema Mobile runtimea. |
    | Lifecycle | `NOT TESTED` | Nema Mobile runtimea. |
    | Trial/entitlement | `NOT TESTED` | Nema Mobile runtimea. |
    | Cast | `NOT TESTED` | Nema Cast hardwarea. |

41. **Repository/web/security testovi:** `PASS` — `QUDRA_OPEN_SKIP_NETWORK=1 npm run validate:qudra-open` prošao za 13 descriptora; `npm run test` prošao: 34 test datoteke, 181 test; `bash .agents/verify.sh` dao je build i lint green; `git diff --check` je prošao. T10 rehearsal je `BLOCKED` za DB snapshot/invariant dijelove jer nema live non-production DB; fixture bez tajni je prošao.
42. **Blocked/not-tested stavke:** Android toolchain, oba native Gradle lanca, APK/AAB, install/launch, TV/Mobile runtime, instrumentation, Cast hardware session, APK inspection i release signing ostaju `BLOCKED` ili `NOT TESTED` kako je navedeno; verify ownership pre-check je prijavljen kao skipped zbog `git add` neuspjeha u sandboxu.
43. **Recurring cost/service:** nema novog recurring paid servisa, Cast brokera, relay infrastrukture ili drugog runtime servisa.
44. **Blockers before T12:** T12 se ne pokreće u ovom tasku. Prije bilo kakvog sljedećeg taska potreban je Android-capable host i Owner Cast/signing input; to nije novi T12 task niti follow-up pokrenut ovdje.
45. **Blockers before staging/production:** Android build mora proći na hostu s JDK/SDK/toolchainom; production receiver mora biti registriran i predan kroz build property; release signing i fizički TV/Mobile/Cast smoke moraju imati Owner/QA dokaz; mrežni i lawful fixture endpointi moraju biti dostupni.
46. **Payment:** NIJE implementiran.
47. **Recording:** NIJE implementiran.
48. **Provider/media marketplace:** NIJE implementiran.
49. **Isključene funkcionalnosti:** payment/checkout/Google Play Billing, Play Store publication, recording/DVR, provider marketplace, commercial media packages, Cloud media relay/restream/transcode, remote Cast broker, internet-control servis, T12 i unrelated backend/schema redesign nisu uvedeni.
50. **Preporuka:** **CONDITIONAL PASS** — kodna T11 priprema i dostupne web/static provjere su završene, ali native build/runtime/Cast production acceptance ostaje blokiran nedostupnim toolchainom, uređajima i Owner konfiguracijama.

## Obavezne YES/NO tvrdnje

- A. Android TV uspješno kompilira: **NO — nije dokazivo; build je BLOCKED.**
- B. Android Mobile uspješno kompilira: **NO — nije dokazivo; build je BLOCKED.**
- C. TV APK je generiran: **NO.**
- D. Mobile APK je generiran: **NO.**
- E. TV runtime je stvarno izvršen: **NO.**
- F. Mobile runtime je stvarno izvršen: **NO.**
- G. Autoplay Next Episode je ON by default na oba: **YES — postojeće autoplay preference/policy granice nisu mijenjane; runtime potvrda je NOT TESTED.**
- H. Cast media zaobilazi QUDRA Cloud: **YES — direct-origin code path, bez relay/proxy sloja.**
- I. Cast receiver ne treba zasebnu QUDRA TV licencu samo za primanje: **YES — receiver path ne prenosi QUDRA entitlement.**
- J. Production Cast receiver ID je Owner-controlled/configurable: **YES — release property je obavezan i release fallback je fail-closed.**
- K. Personal Source secrets fail-closed u produkciji: **YES — Cast path odbija credential-bearing URI/header/token model; production receiver config nema secret fallback.**
- L. Payment ostaje neimplementiran: **YES.**

## Frozen product boundaries

Ostaju četiri primarna media područja (`LIVE TV`, `MOVIES`, `SERIES`, `RADIO`), My List-only source switching, najviše dva Personal Sourcea po Deviceu, trajni entitlement-free QUDRA OPEN, optional Account, odvojeni TV/Mobile identityji, Device-local catalogue/EPG, direct-source playback i capability-driven Catch-up/Timeshift. Payment ostaje zamrznut.
