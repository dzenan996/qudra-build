# QUDRA T2 completion report

> Historical T2 foundation report. T2H hardening supersedes its deferred
> constraint, pairing-lifetime, and internal-credential decisions; see
> `qudra-t2h-completion.md` and `qudra-t2h-migration-review.md` for the final
> control-plane status.

Date: 2026-09-08

Recommendation: **CONDITIONAL PASS**

The T2 control-plane foundation is implemented. The conditional recommendation
is intentional: the sandbox did not contain a separate QUDRA Master
Specification/Owner Clarifications file, so the locked rules in the task brief
and accepted T1R artifacts were used; the production pairing lifetime, KMS
envelope adapter, and internal-service credential contract still require owner
and platform confirmation.

## Changed files and module

- Installed `better-auth` 0.8.0 through the Polsia module installer. Its
  governed auth schema, migrations, catch-all route, server/client helpers,
  sign-in/sign-up/profile flow, and auth nav were installed without hand edits.
  `auth-config.ts` keeps email/password enabled.
- Extended `prisma/schema/qudra-t1.prisma` additively and added
  `prisma/schema/qudra-t2.prisma`.
- Updated `specs/qudra/v1/openapi.yaml` to the T2 contract and regenerated
  `src/lib/contracts/generated/qudra.ts` with `npm run generate:qudra`.
- Added the ten shared Zod contracts under `src/lib/contracts/qudra-*.ts`.
- Added server-only services under `src/lib/business/qudra/` for authority,
  identity/keys, pairing, recovery, trial, entitlement, replacement, sources
  and envelope metadata, access, diagnostics, audit, pure invariants, and
  route helpers.
- Added the complete T2 `/api/qudra/**` handler inventory from the execution
  plan.
- Added four T2 unit suites and updated stale T1/llms expectations to match the
  now-versioned T2 contract and existing QUDRA brand seed.

## Schema, constraints, and migration status

Final constraints include non-null `QudraDevice.publicDeviceId`, required
Device platform/product family, scalar optional `QudraAccount.userId`, indexed
Device/trial and Device/source-slot lookups, historical `QudraDeviceKey` unique
`(deviceId, version)`, and `QudraDeviceCurrentEntitlement` unique Device and
entitlement pointers. The three uniqueness constraints on existing T1 tables
(`publicDeviceId`, `QudraTrial.deviceId`, and `(deviceId, slot)`) are deliberately
deferred until a reviewed production deduplication/backfill; service checks are
the interim guard and do not claim to replace a database invariant.
Historical entitlement rows remain available; the pointer is cleared on every
non-active transition. The current-usable rule is ACTIVE plus future annual
expiry or LIFETIME.

No app migration files or raw SQL were added; this template is schema-only.
The previous disposable preflight showed the uniqueness warnings and the deploy
gate rejected the unapproved constraint change. This revision does not pass
`--accept-data-loss` and does not add those constraints. Plain `npx prisma db
push` now succeeds against the disposable database. A production rollout still
needs reviewed public-ID/source-slot/trial deduplication and backfill before
those three constraints can be staged safely.

## Runtime and authorization

Better Auth session authority resolves to the authenticated user and its
QUDRA Account mapping. The module's `role: 'admin'` (bootstrapped only from
`POLSIA_OWNER_EMAIL`) is treated as the current Super Admin authority only; it
is not exposed as a Partner or general customer permission. Device authority
requires a non-revoked stored public key, matching key version, and verified
proof-of-possession. Internal routes require a configured, scoped
`QUDRA_INTERNAL_SERVICE_CREDENTIALS` record and fail closed when it is absent.
Submitted Customer/Account/Device/public IDs never grant authority.

Routes cover registration, Device reads/revocation/key rotation, Account-scoped
Device listing, pairing create/complete/QR/cancel, bounded recovery,
device-scoped trial and exception decisions, effective access, internal
entitlement activation/transitions and same-Customer replacement, redacted
source configuration and active-source state, diagnostic registry/current
reads and trusted writes, and redacted audit reads/trusted writes.

Pairing stores only a digest, returns only an opaque challenge representation,
enforces single-use, Device binding, replay/expiry handling, five attempts, and
the fixed 10-minute lifetime. Durable rate limits and challenge rotation are
server-side; the lifetime is not deployment-configurable.

Trials start once on the server and use exactly 168 elapsed hours, with the
boundary expired. Entitlements support annual 365-day and lifetime terms,
DIRECT/PARTNER provenance, all five states, 72-hour grace metadata,
revalidation metadata, monotonic versions, and transactional current-pointer
maintenance. Replacement is same-Customer only, preserves predecessor
entitlement linkage, enforces the standard 12-month interval, and requires
Super Admin exception authority for an earlier replacement.

Personal sources are capped at two slots, are Device-scoped, redact secret
metadata on reads, reject cross-Device selection, and atomically fall back to
QUDRA_OPEN when the active personal source is deleted. No plaintext secret,
private key, media catalogue, EPG, viewing history, relay, proxy, or playback
route was added. The source write path accepts only approved envelope metadata;
no local or hardcoded encryption fallback exists.

Diagnostics upsert one current row per Device/category for internet,
qudra_cloud, entitlement, source, playlist_epg, and playback. Audit appends are
allowlisted, trusted-only, metadata-redacted, and cover the T2 transition
catalogue without logging sensitive material.

## Validation

- `npx prisma validate` — passed.
- `npx prisma generate` — passed.
- `npm run generate:qudra` — passed.
- `npx prisma db push` — passed against the disposable database without
  `--accept-data-loss`.
- `npm run test` — passed: 13 files, 122 tests.
- `npm run typecheck` — passed.
- `bash .agents/verify.sh` — build and lint passed. Its ownership pre-check was
  skipped because this sandbox disallows the script's temporary git staging
  operation.
- Runtime smoke test — `/health` 200, diagnostic registry 200, unauthenticated
  registration 403, and unauthenticated internal audit write 403. The dev
  server was stopped cleanly; no application runtime errors were observed.

## Remaining decisions and exclusions

Owner/platform confirmation remains required for the pairing lifetime value,
the approved envelope-encryption/KMS provider and key-reference format, and
the production internal-service credential injection. No recurring paid
service or infrastructure was introduced.

Explicitly excluded: T3 QUDRA OPEN playback, Android TV/Mobile players, full My
Qudra UI, Partner/Admin panels and credits, payments/checkout/Google Play
Billing, commercial provider/catalogue data, full M3U/XMLTV parsing, Cast,
Cloud DVR, video relay/proxy/transcoding, marketing/outreach/recruitment, and
new recurring paid infrastructure.
