# QUDRA T10 — forward-only pregled migracije

Ovaj dokument je pripremljen za populated staging bazu. Repo je schema-only i nema novu Prisma migration datoteku; platforma/Owner mora odobriti i izvršiti forward DDL izvan app-owned commita. Destructive reset, `prisma migrate reset` i brisanje redaka nisu prihvatljivi rollout koraci.

## Redoslijed

1. Zabilježiti Owner/platform snapshot i checksum/export manifest prije write-freezea. Snapshot ne smije sadržavati Personal Source secret plaintext, a export mora biti enkriptiran izvan aplikacijskog loga.
2. Otvoriti kratki write freeze ili serializable window za Device, trial, entitlement, Partner credit i activation mutacije. Read-only inventory iz `scripts/qudra-t10-rehearsal.mjs` mora biti bez nepoznatih duplicate/null klasa.
3. Pokrenuti duplicate/null provjere za public Device ID, trial po Deviceu, source slot, Account ownership, active entitlement, current pointer i active source. `scripts/qudra-t2h-preflight.mjs` ostaje read-only.
4. Backfill raditi prije constraints: zadržati najstariji canonical row prema Owner-approved pravilu, popuniti nullable reference vrijednosti samo iz provjerenog parenta i zapisati broj pregledanih/izmijenjenih redaka.
5. Validirati ownership: Device/customer, trial/device, entitlement/device/customer, current pointer/device, active source/device/customer, source slot 1–2 i Partner scope/tenant.
6. Dodati odobrene indekse i constraints tek nakon backfilla. Postojeći populated-table uniqueness ostaje staged: ne dodavati `@@unique` u ovaj deploy bez deduplikacije i platformskog DDL plana.
7. Deployati samo additive forward promjene; zadržati old-row compatibility. Nakon validacije može se planirati zaseban Owner-approved cleanup, ali T10 ne briše niti preimenuje podatke.
8. Ponoviti inventory i invariant queries nakon DDL-a, zatim restore snapshot-a u izolirani non-production target i ponovno `prisma validate`/schema provjeru.

## T10 ograničenja

- Nema `prisma/migrations/**` promjene u ovom repozitoriju.
- Nema novog T10 modela ni additive schema polja jer postojeći modeli nose potreban pairing, session, credit, activation i current-entitlement metadata.
- Personal Source catalogue, EPG, media byteovi i source credential plaintext nisu dio control-plane snapshot backfilla.
- `polsia.toml` start ostaje framework-verificirani `prisma db push --accept-data-loss`; Owner/platform mora prije staginga odlučiti o sigurnom forward migration mehanizmu za populated production podatke.
- Ako inventory pokaže duplicate/null redove, status je `CONDITIONAL`, a constraint rollout se zaustavlja dok Owner ne odobri backfill plan.
