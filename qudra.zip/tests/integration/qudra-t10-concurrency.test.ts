// @polsia:user-owned — DB-dependent T10 rehearsal contract.
import { existsSync, readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

describe('QUDRA T10 concurrency rehearsal', () => {
  it('is explicitly blocked without a disposable non-production database', () => {
    const runner = readFileSync('scripts/qudra-t10-rehearsal.mjs', 'utf8');
    expect(runner).toContain('databaseAvailable');
    expect(runner).toContain('Owner/platform snapshot wrapper');
    expect(runner).toContain('pg_restore');
    expect(existsSync('prisma/migrations/20260603000000_t10.sql')).toBe(false);
    if (!process.env.DATABASE_URL) expect(runner).toContain('process.exit(0)');
  });
});
