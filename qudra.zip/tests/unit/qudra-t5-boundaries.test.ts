// @polsia:user-owned — negative boundary scans for excluded T5 surfaces.
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';

const root = process.cwd();
const read = (path: string) => readFileSync(resolve(root, path), 'utf8');
describe('T5 boundaries', () => {
  it('keeps the schema metadata-only', () => {
    const schema = read('prisma/schema/qudra-t5.prisma');
    expect(schema).not.toMatch(/model Qudra(Channel|Movie|Series|Programme|Viewing|Epg)/i);
    expect(schema).toContain('lastKnownGoodGeneration');
  });
  it('keeps direct-origin and no-cloud-catalogue rules visible', () => {
    const sync = read('src/lib/business/qudra/sync.ts');
    const android = read(
      'android/app/src/main/java/com/qudra/tv/local/source/SourceImportCoordinator.kt',
    );
    expect(sync).not.toMatch(/mediaBytes|viewingHistory|catalogueRows/i);
    expect(android).toContain('last-known-good');
    expect(read('src/lib/business/qudra/source-secrets.ts')).toContain('aes-256-gcm');
  });
});
