// @polsia:user-owned — QUDRA T1R contract, schema, fixture, and state-machine tests.

import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';
import type { components } from '@/lib/contracts/generated/qudra';
import fixture from '../../specs/qudra/v1/fixtures/t1-fixtures.json';

type Fixture = components['schemas']['T1ContractFixture'];

// JSON modules widen literal enum/const values; these assertions exercise the
// checked-in fixture against the generated OpenAPI shape at runtime.
const typedFixture = fixture as unknown as Fixture;
const root = process.cwd();
const spec = readFileSync(resolve(root, 'specs/qudra/v1/openapi.yaml'), 'utf8');
const schema = readFileSync(resolve(root, 'prisma/schema/qudra-t1.prisma'), 'utf8');
const t2Schema = readFileSync(resolve(root, 'prisma/schema/qudra-t2.prisma'), 'utf8');
const serializedFixture = JSON.stringify(typedFixture);

const canonicalAuditEvents = [
  'device.registered',
  'device.revoked',
  'device.key_rotated',
  'pairing.created',
  'pairing.completed',
  'pairing.expired',
  'pairing.replay_rejected',
  'recovery.requested',
  'recovery.approved',
  'recovery.rejected',
  'trial.started',
  'trial.expired',
  'trial.exception_requested',
  'trial.exception_approved',
  'trial.exception_rejected',
  'entitlement.activated',
  'entitlement.expired',
  'entitlement.suspended',
  'entitlement.revoked',
  'entitlement.replaced',
  'source_config.created',
  'source_config.updated',
  'source_config.deleted',
  'source_config.secret_changed',
  'active_source.changed',
] as const;

describe('QUDRA T1R contract boundaries', () => {
  it('is versioned OpenAPI and has no runtime commerce or media-proxy surface', () => {
    expect(spec).toContain('openapi: 3.1.0');
    expect(spec).toContain('version: 3.0.0-t3b');
    expect(spec).toContain('/v1/devices/{deviceId}/revoke:');
    expect(spec).toContain('/v1/devices/{deviceId}/key-rotation:');
    expect(spec).not.toContain('/v1/devices/{deviceId}:\n    post:');
    expect(spec).not.toMatch(/\/v1\/(payments?|checkout|billing|proxy|playback)/);
    expect(spec).toContain('controlPlaneProxiesBytes: { type: boolean, const: false }');
    expect(spec).toContain('QudraOpenLegacySummary');
  });

  it('makes authorization and trusted append boundaries explicit', () => {
    expect(spec).toContain('customerId is a routing context value and is not authorization proof');
    expect(spec).toContain('A caller-supplied deviceId is only context');
    expect(spec).toContain('publicDeviceId alone can never recover a Device');
    expect(spec).toContain('verified Super Admin action');
    expect(spec).toContain('/v1/internal/audit-events:');
    expect(spec).toContain('operationId: appendAuditEvent');
    expect(spec).toContain('security: [{ internalServiceBearer: [] }]');
    expect(spec).not.toContain('/v1/audit-events:');
  });

  it('keeps the generated artifact type-only and reproducible from OpenAPI', () => {
    const generated = readFileSync(resolve(root, 'src/lib/contracts/generated/qudra.ts'), 'utf8');
    expect(generated).toContain('DO NOT EDIT: regenerate from specs/qudra/v1/openapi.yaml.');
    expect(generated).toContain('export interface components');
    expect(generated).toContain('T1ContractFixture');
    expect(generated).toContain('QudraOpenLegacySummary');
    expect(generated).not.toContain("from 'prisma'");
    expect(generated).not.toContain("from '@/lib/db'");
    expect(generated).not.toContain('const fixture');
  });

  it('keeps T1 schema-only with no catalogue models or migration additions', () => {
    expect(schema).toContain('model QudraCustomer');
    expect(schema).toContain('model QudraDevice');
    expect(schema).toContain('model QudraTrialExceptionRequest');
    expect(schema).toContain('model QudraActiveSource');
    expect(schema).toContain('model QudraDiagnostic');
    expect(schema).toMatch(/publicDeviceId\s+String\s+@db\.VarChar\(256\)/);
    expect(schema).not.toMatch(/publicDeviceId\s+String\s+@unique/);
    expect(schema).toMatch(/model QudraSourceConfig[\s\S]*deviceId\s+String/);
    expect(schema).toContain('enum QudraActivationChannel');
    expect(schema).toMatch(/factorRef\s+String/);
    expect(schema).toMatch(/action\s+String/);
    expect(schema).toContain('REVOKED');
    expect(schema).toContain('DENIED');
    expect(schema).toContain('accounts            QudraAccount[]');
    expect(t2Schema).toContain('model QudraDeviceKey');
    expect(t2Schema).toContain('model QudraDeviceCurrentEntitlement');
    expect(schema).not.toContain('@@unique([deviceId, sourceKey])');
    expect(schema).not.toContain('replacedEntitlementId String?                 @unique');
    expect(schema).not.toMatch(/model Qudra(Channel|Movie|Series|Epg|Viewing)/);
    expect(schema).not.toContain('datasource ');
    expect(schema).not.toContain('generator ');
  });
});

describe('QUDRA T1R ownership and commercial boundaries', () => {
  it('separates Customer, optional Account, and independently licensed Devices', () => {
    expect(
      typedFixture.accounts.filter((item) => item.customerId === 'cus_t1r_primary'),
    ).toHaveLength(1);
    expect(
      typedFixture.accounts.filter((item) => item.customerId === 'cus_t1r_other'),
    ).toHaveLength(0);
    expect(
      typedFixture.devices.filter((item) => item.customerId === 'cus_t1r_primary'),
    ).toHaveLength(5);
    expect(new Set(typedFixture.devices.map((item) => item.platform))).toEqual(
      new Set(['ANDROID_TV', 'ANDROID_PHONE', 'ANDROID_TABLET']),
    );
    expect(new Set(typedFixture.devices.map((item) => item.productFamily))).toEqual(
      new Set(['TV', 'MOBILE']),
    );
    expect(typedFixture.devices.every((item) => item.id !== item.publicDeviceId)).toBe(true);
  });

  it('has exactly one trial and entitlement fixture per Device, without cross-device combination', () => {
    const trialDeviceIds = typedFixture.trials.map((item) => item.deviceId);
    const entitlementDeviceIds = typedFixture.entitlements.map((item) => item.deviceId);
    expect(new Set(trialDeviceIds).size).toBe(trialDeviceIds.length);
    expect(new Set(entitlementDeviceIds).size).toBe(entitlementDeviceIds.length);
    expect(
      typedFixture.entitlements.every((item) => {
        const device = typedFixture.devices.find((candidate) => candidate.id === item.deviceId);
        return device?.customerId === item.customerId;
      }),
    ).toBe(true);
    expect(typedFixture.entitlements.map((item) => item.state).sort()).toEqual([
      'active',
      'active',
      'expired',
      'replaced',
      'revoked',
      'suspended',
    ]);
    expect(typedFixture.entitlements.map((item) => item.kind)).toEqual(
      expect.arrayContaining(['annual', 'lifetime']),
    );
    expect(typedFixture.entitlements.map((item) => item.provenance)).toEqual(
      expect.arrayContaining(['direct', 'partner']),
    );
  });

  it('caps personal sources at two and keeps QUDRA OPEN separate with deletion fallback', () => {
    const sourceCounts = new Map<string, number>();
    for (const source of typedFixture.sourceConfigs) {
      sourceCounts.set(source.deviceId, (sourceCounts.get(source.deviceId) ?? 0) + 1);
      expect(source.sourceType).toBe('personal_source');
    }
    expect([...sourceCounts.values()].every((count) => count <= 2)).toBe(true);
    expect(
      typedFixture.sourceConfigs.filter((item) => item.deviceId === 'dev_t1r_tv'),
    ).toHaveLength(2);
    expect(typedFixture.qudraOpen.permanent).toBe(true);
    expect(typedFixture.qudraOpen.availableWithoutEntitlement).toBe(true);
    expect(typedFixture.activeSources.find((item) => item.deviceId === 'dev_t1r_tv')?.kind).toBe(
      'PERSONAL_SOURCE',
    );
    expect(
      typedFixture.activeSources.every((item) => item.fallbackOnDeletion === 'QUDRA_OPEN'),
    ).toBe(true);
    expect(serializedFixture).not.toContain('channelCatalogue');
    expect(serializedFixture).not.toContain('viewingCatalogue');
  });
});

describe('QUDRA T1R trial, replacement, pairing, and redaction rules', () => {
  it('uses the exact 168 elapsed-hour trial boundary and no reinstall reset', () => {
    const trial = typedFixture.trials.find((item) => item.deviceId === 'dev_t1r_tv');
    expect(trial?.startedAt).toBe('2026-01-01T00:00:00Z');
    expect(trial?.endsAt).toBe('2026-01-08T00:00:00Z');
    expect(Date.parse(trial?.endsAt ?? '') - Date.parse(trial?.startedAt ?? '')).toBe(
      168 * 60 * 60 * 1000,
    );
    const boundary = typedFixture.accessCases.find((item) => item.label.includes('boundary'));
    expect(boundary?.trialState).toBe('expired');
    expect(boundary?.personalSourcePlayback).toBe('denied_entitlement_required');
    expect(typedFixture.trials.every((item) => item.reinstallResets === false)).toBe(true);
    expect(typedFixture.policies.trialHours).toBe(168);
  });

  it('covers trial exception statuses and reserves approval for Super Admin authority', () => {
    expect(new Set(typedFixture.trialExceptions.map((item) => item.status))).toEqual(
      new Set(['pending', 'approved']),
    );
    const approved = typedFixture.trialExceptions.find((item) => item.status === 'approved');
    expect(approved?.decidedBy).toContain('super-admin');
    expect(spec).toContain('verified Super Admin action');
    expect(spec).toContain('decision and reason are auditable');
  });

  it('links same-Customer replacement and successor entitlement immutably', () => {
    const replacement = typedFixture.replacements[0];
    if (!replacement) {
      throw new Error('replacement fixture is required');
    }
    const oldDevice = typedFixture.devices.find((item) => item.id === replacement.oldDeviceId);
    const newDevice = typedFixture.devices.find((item) => item.id === replacement.newDeviceId);
    const successor = typedFixture.entitlements.find(
      (item) => item.deviceId === replacement.newDeviceId,
    );
    expect(oldDevice?.customerId).toBe(replacement.customerId);
    expect(newDevice?.customerId).toBe(replacement.customerId);
    expect(successor?.replacedEntitlementId).toBe('ent_t1r_old_replaced');
    expect(replacement.standardIntervalMonths).toBe(12);
    expect(replacement.earlierRequiresSuperAdminException).toBe(true);
    const domain = readFileSync(resolve(root, 'specs/qudra/v1/domain.md'), 'utf8');
    expect(domain).toContain('Cross-Customer transfer is forbidden');
    expect(spec).toContain('new key version supersedes and revokes');
  });

  it('keeps pairing and recovery bounded, single-use, and QR-safe', () => {
    expect(typedFixture.pairing.every((challenge) => challenge.state !== 'paired')).toBe(true);
    expect(typedFixture.pairing.every((challenge) => challenge.maxAttempts === 5)).toBe(true);
    expect(typedFixture.pairing.every((challenge) => challenge.attemptCount <= 5)).toBe(true);
    expect(typedFixture.pairingQr.id).toBe('pair_t1r_pending');
    expect(typedFixture.pairingQr.representation).not.toMatch(/https?:|username|password|secret/i);
    expect(typedFixture.recovery.every((challenge) => challenge.maxAttempts === 5)).toBe(true);
    expect(spec).toContain('QR representation of the same pending challenge');
    expect(spec).toContain('publicDeviceId alone can never recover');
  });

  it('redacts source secrets and audit metadata', () => {
    expect(typedFixture.sourceConfigs.filter((item) => item.hasSecret)).not.toHaveLength(0);
    expect(serializedFixture).not.toContain('secretCiphertext');
    expect(serializedFixture).not.toContain('PLAINTEXT');
    expect(serializedFixture).not.toContain('privateKey');
    expect(typedFixture.audit.every((event) => event.metadata.secret === '[redacted]')).toBe(true);
    expect(spec).toContain('secrets, credentials, private keys, and ciphertext are forbidden');
  });
});

describe('QUDRA T1R diagnostics, audit catalogue, and state machines', () => {
  it('covers all diagnostic categories and a current/latest read boundary', () => {
    expect(new Set(typedFixture.diagnostics.map((item) => item.category))).toEqual(
      new Set(['internet', 'qudra_cloud', 'entitlement', 'source', 'playlist_epg', 'playback']),
    );
    expect(new Set(typedFixture.diagnosticCodes.map((item) => item.category))).toEqual(
      new Set(['internet', 'qudra_cloud', 'entitlement', 'source', 'playlist_epg', 'playback']),
    );
    expect(spec).toContain('/v1/devices/{deviceId}/diagnostics/current:');
    expect(spec).toContain('latest/current diagnostic');
    expect(typedFixture.diagnosticCodes.some((item) => item.code === 'source.access_failed')).toBe(
      true,
    );
    expect(
      typedFixture.diagnosticCodes.some((item) =>
        item.description.includes('subscription expired'),
      ),
    ).toBe(false);
  });

  it('includes every canonical append-only audit event exactly in the fixture', () => {
    const actual = new Set(typedFixture.audit.map((event) => event.eventType));
    expect(actual).toEqual(new Set(canonicalAuditEvents));
    expect(typedFixture.audit).toHaveLength(canonicalAuditEvents.length);
    expect(spec).toContain('Internal-service-only append to the immutable audit log');
    const deviceAuditSection = spec.slice(
      spec.indexOf('/v1/devices/{deviceId}/audit-events:'),
      spec.indexOf('/v1/internal/audit-events:'),
    );
    expect(deviceAuditSection).not.toContain('\n    post:');
  });

  it('documents server-authoritative transitions and separates connectivity from entitlement', () => {
    const stateMachines = readFileSync(resolve(root, 'specs/qudra/v1/state-machines.md'), 'utf8');
    expect(stateMachines).toContain('168 elapsed hours');
    expect(stateMachines).toContain('active -> expired | suspended | revoked | replaced');
    expect(stateMachines).toContain('offline connectivity is not an entitlement state');
    expect(stateMachines).toContain('QUDRA_OPEN <-> PERSONAL_SOURCE');
    expect(stateMachines).toContain('publicDeviceId by itself is never sufficient');
  });
});
