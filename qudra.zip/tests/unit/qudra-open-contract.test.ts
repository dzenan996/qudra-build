// @polsia:user-owned — QUDRA OPEN contract, rights register, and fixture tests.
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';
import { parseQudraOpenManifest, resolveQudraOpenPlayback } from '@/lib/business/qudra/open';
import { QudraOpenManifest } from '@/lib/contracts/qudra-open';
import fixture from '../../specs/qudra/v1/fixtures/qudra-open-manifest.json';

const manifest = parseQudraOpenManifest(fixture);

describe('QUDRA OPEN contract and fixture', () => {
  it('parses a versioned permanent manifest with all four media classes', () => {
    expect(QudraOpenManifest.parse(fixture).manifestVersion).toBe('3.0.0-t3b');
    expect(manifest.mediaClasses).toEqual(['LIVE_TV', 'MOVIE', 'SERIES', 'RADIO']);
    expect(manifest.permanent).toBe(true);
    expect(manifest.availableWithoutEntitlement).toBe(true);
    expect(manifest.requiresPaidEntitlement).toBe(false);
    expect(manifest.personalSourceConfig).toBe(false);
    expect(manifest.controlPlaneProxiesBytes).toBe(false);
  });

  it('requires complete rights evidence and separates webpages from media origins', () => {
    const sources = [
      ...manifest.sourceRegister,
      ...manifest.series.flatMap((series) => series.episodes),
      ...manifest.testOnly.liveTv,
      ...manifest.testOnly.radio,
    ];
    expect(sources.length).toBeGreaterThanOrEqual(8);
    for (const source of sources) {
      expect(source.legalEvidence.license).toBeTruthy();
      expect(source.legalEvidence.permissionEvidenceUrl).toMatch(/^https?:/);
      expect(source.legalEvidence.attribution).toBeTruthy();
      expect(source.legalEvidence.geography).toBeTruthy();
      expect(source.legalEvidence.verificationStatus).toBeTruthy();
      expect(source.legalEvidence.stabilityEvidence.notes).toBeTruthy();
      if (source.directOrigin) {
        expect(source.directOrigin.mediaOrigin).toBe(true);
        expect(source.directOrigin.url).not.toBe(source.webpageUrl);
        expect(source.directOrigin.format.mimeType).toBe(source.sourceHealth.contentType);
        expect(source.directOrigin.format.rangeSupported).toBe(true);
      }
      expect(source.controlPlaneProxiesBytes).toBe(false);
    }
  });

  it('keeps lawful production films and series separate from empty LIVE_TV/RADIO slots', () => {
    expect(manifest.movies).toEqual([
      'movie-big-buck-bunny',
      'movie-sintel',
      'movie-tears-of-steel',
    ]);
    expect(manifest.liveTv).toHaveLength(0);
    expect(manifest.radio).toHaveLength(0);
    expect(manifest.series).toHaveLength(1);
    expect(manifest.series[0]?.episodes).toHaveLength(3);
    expect(
      manifest.sourceRegister.filter((source) => source.productionDesignation === 'PRODUCTION'),
    ).toHaveLength(6);
    expect(
      manifest.testOnly.liveTv.every((source) => source.productionDesignation === 'TEST_ONLY'),
    ).toBe(true);
    expect(
      manifest.testOnly.radio.every((source) => source.productionDesignation === 'TEST_ONLY'),
    ).toBe(true);
  });

  it('records explicit EPG/NOW-NEXT/full-schedule/catch-up and health state', () => {
    expect(manifest.epg).toEqual({
      nowNext: false,
      fullSchedule: false,
      catchUp: false,
      notes: expect.any(String),
    });
    expect(manifest.sourceRegister.every((source) => source.sourceHealth.checkedAt)).toBe(true);
    expect(manifest.testOnly.liveTv[0]?.availability.status).toBe('UNAVAILABLE');
    expect(manifest.testOnly.radio[0]?.availability.status).toBe('UNAVAILABLE');
  });

  it('records metadata, neutral artwork fallback, attribution, capabilities, and readiness classifications', () => {
    const sintel = manifest.sourceRegister.find((source) => source.sourceId === 'movie-sintel');
    const tears = manifest.sourceRegister.find(
      (source) => source.sourceId === 'movie-tears-of-steel',
    );
    const granDillama = manifest.sourceRegister.find(
      (source) => source.sourceId === 'caminandes-gran-dillama',
    );
    expect(sintel?.metadata.durationSeconds).toBe(888.06);
    expect(sintel?.artwork).toBeNull();
    expect(sintel?.attribution.licenseName).toBe('CC BY 3.0');
    expect(sintel?.capabilities).toMatchObject({
      directPlayback: true,
      epg: false,
      catchUp: false,
      recording: false,
    });
    expect(sintel?.compatibility.classification).toBe('PREFERRED');
    expect(tears?.attribution.restrictions.join(' ')).toMatch(/actor|likeness|privacy/i);
    expect(granDillama?.attribution.licenseName).toContain('CC BY-SA');
    expect(granDillama?.attribution.licenseName).not.toBe('CC BY 3.0');
  });

  it('models one Caminandes season and keeps flat episode order equivalent', () => {
    const series = manifest.series[0];
    expect(series?.description).toBeTruthy();
    expect(series?.season).toMatchObject({ seasonNumber: 1, order: 1 });
    expect(series?.episodes.map((episode) => episode.episodeOrder)).toEqual([1, 2, 3]);
    expect(
      series?.episodes.every((episode) => episode.episodeOrder === episode.episodeNumber),
    ).toBe(true);
  });

  it('records all six origin classifications and explicit origin failure state', () => {
    const expected = new Map([
      ['movie-big-buck-bunny', 'SUPPORTED_WITH_DEVICE_TEST'],
      ['movie-sintel', 'PREFERRED'],
      ['movie-tears-of-steel', 'SUPPORTED_WITH_DEVICE_TEST'],
      ['caminandes-llama-drama', 'UNSUITABLE_AS_PRIMARY_FIXTURE'],
      ['caminandes-gran-dillama', 'SUPPORTED_WITH_DEVICE_TEST'],
      ['caminandes-llamigos', 'SUPPORTED_WITH_DEVICE_TEST'],
    ]);
    for (const [sourceId, classification] of expected) {
      const source = manifest.sourceRegister.find((candidate) => candidate.sourceId === sourceId);
      expect(source?.compatibility.classification).toBe(classification);
      expect(source?.originState.preferredOrigin).toBe(source?.directOrigin?.url);
    }
    const unavailable = manifest.testOnly.liveTv[0];
    expect(unavailable?.originState).toMatchObject({
      availability: 'UNAVAILABLE',
      preferredOrigin: null,
      fallbackOrigin: null,
    });
    expect(unavailable?.originState.unavailableReason).toBeTruthy();
  });

  it('selects an explicit lawful direct fallback when the preferred origin is unhealthy', () => {
    const source = manifest.sourceRegister.find(
      (candidate) => candidate.sourceId === 'movie-sintel',
    );
    if (!source?.directOrigin) throw new Error('Sintel direct origin is required');
    const fallbackManifest = QudraOpenManifest.parse({
      ...manifest,
      sourceRegister: manifest.sourceRegister.map((candidate) =>
        candidate.sourceId === source.sourceId
          ? {
              ...candidate,
              sourceHealth: { ...candidate.sourceHealth, status: 'UNAVAILABLE' },
              originState: { ...candidate.originState, fallbackOrigin: source.directOrigin },
            }
          : candidate,
      ),
    });
    expect(resolveQudraOpenPlayback(fallbackManifest, source.sourceId)).toMatchObject({
      status: 'AVAILABLE',
      resolution: 'FALLBACK',
      directOrigin: source.directOrigin,
    });
  });

  it('resolves direct playback, replacement, and explicit unavailable fallback without bytes', () => {
    const direct = resolveQudraOpenPlayback(manifest, 'movie-big-buck-bunny');
    expect(direct.status).toBe('AVAILABLE');
    if (direct.status === 'AVAILABLE') expect(direct.resolution).toBe('DIRECT');

    const replacementManifest = QudraOpenManifest.parse({
      ...manifest,
      testOnly: {
        ...manifest.testOnly,
        liveTv: manifest.testOnly.liveTv.map((source) => ({
          ...source,
          replacement: { sourceId: 'movie-big-buck-bunny', reason: 'fixture replacement' },
        })),
      },
    });
    const replacement = resolveQudraOpenPlayback(replacementManifest, 'test-live-tv-synthetic');
    expect(replacement).toMatchObject({
      status: 'AVAILABLE',
      resolution: 'REPLACEMENT',
      sourceId: 'movie-big-buck-bunny',
    });
    expect(resolveQudraOpenPlayback(manifest, 'missing-source').status).toBe('UNAVAILABLE');

    const unavailableManifest = QudraOpenManifest.parse({
      ...manifest,
      sourceRegister: manifest.sourceRegister.map((source) =>
        source.sourceId === 'movie-sintel'
          ? {
              ...source,
              availability: {
                ...source.availability,
                status: 'UNAVAILABLE',
                reason: 'Origin failed validation.',
              },
              sourceHealth: { ...source.sourceHealth, status: 'UNAVAILABLE' },
              directOrigin: null,
              originState: {
                ...source.originState,
                availability: 'UNAVAILABLE',
                preferredOrigin: null,
                unavailableReason: 'Origin failed validation.',
              },
            }
          : source,
      ),
    });
    expect(resolveQudraOpenPlayback(unavailableManifest, 'movie-sintel')).toMatchObject({
      status: 'UNAVAILABLE',
      reason: 'Origin failed validation.',
    });

    const source = readFileSync(resolve(process.cwd(), 'src/lib/business/qudra/open.ts'), 'utf8');
    expect(source).not.toMatch(/fetch|ReadableStream|Buffer|transcod|relay|proxy/i);
  });
});
