// @polsia:user-owned — QUDRA T10 core invariant regressions.
import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import {
  ANNUAL_LICENSE_DURATION_MS,
  entitlementIsUsable,
  TRIAL_DURATION_MS,
  trialEndsAt,
} from '@/lib/business/qudra/domain';

describe('QUDRA T10 server-time invariants', () => {
  it('keeps 168-hour trials, 365-day annual licenses, and lifetime semantics', () => {
    expect(TRIAL_DURATION_MS).toBe(168 * 60 * 60 * 1000);
    expect(ANNUAL_LICENSE_DURATION_MS).toBe(365 * 24 * 60 * 60 * 1000);
    const started = new Date('2026-01-01T00:00:00.000Z');
    expect(trialEndsAt(started).toISOString()).toBe('2026-01-08T00:00:00.000Z');
    expect(entitlementIsUsable({ state: 'ACTIVE', kind: 'LIFETIME', expiresAt: null })).toBe(true);
    expect(entitlementIsUsable({ state: 'ACTIVE', kind: 'ANNUAL', expiresAt: new Date(0) })).toBe(
      false,
    );
  });

  it('keeps Device identity, source slots, current pointer, and append-only ledger markers', () => {
    const t1 = `${readFileSync('prisma/schema/qudra-t1.prisma', 'utf8')}\n${readFileSync('prisma/schema/qudra-t2.prisma', 'utf8')}`;
    const t7 = readFileSync('prisma/schema/qudra-t7.prisma', 'utf8');
    const activation = readFileSync('src/lib/business/qudra/partner-activation.ts', 'utf8');
    const replacement = readFileSync('src/lib/business/qudra/replacement.ts', 'utf8');
    expect(t1).toContain('productFamily');
    expect(t1).toContain('keyVersion');
    expect(t1).toContain('QudraDeviceCurrentEntitlement');
    expect(t7).toContain('operationKey   String                       @unique');
    expect(activation).toContain('partnerId_idempotencyKey');
    expect(activation).toContain('balance: { gte: PARTNER_ACTIVATION_CREDITS }');
    expect(replacement).toContain('oldDevice.customerId !== newDevice.customerId');
    expect(replacement).toContain('replaceDeviceInTransaction');
  });

  it('keeps QUDRA OPEN independent of Personal Source encryption', () => {
    const sources = readFileSync('src/lib/business/qudra/sources.ts', 'utf8');
    const secret = readFileSync('src/lib/business/qudra/source-secrets.ts', 'utf8');
    expect(sources).toContain("kind: 'QUDRA_OPEN'");
    expect(secret).toContain('QUDRA OPEN');
    expect(secret).not.toMatch(/plaintext fallback|storePlaintext/i);
  });
});
