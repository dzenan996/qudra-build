// @polsia:user-owned — QUDRA T2 schema and exclusion checks.
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';

const root = process.cwd();
const t1 = readFileSync(resolve(root, 'prisma/schema/qudra-t1.prisma'), 'utf8');
const t2 = readFileSync(resolve(root, 'prisma/schema/qudra-t2.prisma'), 'utf8');

describe('QUDRA T2 schema', () => {
  it('keeps populated-table identity additive and separates platform from product family', () => {
    expect(t1).toMatch(/publicDeviceId\s+String\s+@db\.VarChar\(256\)/);
    expect(t1).not.toMatch(/publicDeviceId\s+String\s+@unique/);
    expect(t1).toMatch(/platform\s+QudraDevicePlatform/);
    expect(t1).toMatch(/productFamily\s+QudraProductFamily/);
    expect(t1).toMatch(/customerId\s+String\s*\n\s+userId\s+String\?/);
    expect(t1).toMatch(/model QudraTrial[\s\S]*deviceId\s+String\?/);
    expect(t1).toMatch(/model QudraSourceConfig[\s\S]*deviceId\s+String\?[\s\S]*slot\s+Int\?/);
    expect(t1).toContain('@@index([deviceId, slot])');
    expect(t1).toContain('@@index([publicDeviceId])');
  });
  it('retains key history and one current entitlement pointer', () => {
    expect(t2).toContain('@@unique([deviceId, version])');
    expect(t2).toContain('deviceId       String           @unique');
    expect(t2).toContain('entitlementId  String           @unique');
    expect(t1).toContain('model QudraDeviceSession');
    expect(t1).toContain('model QudraPairingRateWindow');
  });
  it('has no media, relay, catalogue, EPG, or viewing models/routes', () => {
    expect(t1).not.toMatch(/model Qudra(Channel|Movie|Series|Epg|Viewing)/);
    expect(existsSync(resolve(root, 'src/app/api/qudra/playback'))).toBe(false);
    expect(existsSync(resolve(root, 'src/app/api/qudra/media'))).toBe(false);
  });
});
