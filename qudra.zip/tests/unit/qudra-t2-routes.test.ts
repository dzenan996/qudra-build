// @polsia:user-owned — QUDRA T2 route inventory and contract-boundary tests.
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';

const root = process.cwd();
const route = (path: string) => resolve(root, 'src/app/api/qudra', path, 'route.ts');
const routes = [
  'bootstrap/challenges',
  'bootstrap/challenges/[challengeId]/complete',
  'devices/registration',
  'devices/[deviceId]',
  'devices/[deviceId]/revoke',
  'devices/[deviceId]/key-rotation',
  'devices/[deviceId]/session',
  'accounts/[accountId]/devices',
  'pairing/challenges',
  'pairing/challenges/[challengeId]/complete',
  'pairing/challenges/[challengeId]/qr',
  'pairing/challenges/[challengeId]/cancel',
  'recovery/challenges',
  'recovery/challenges/[challengeId]/decision',
  'devices/[deviceId]/trial',
  'devices/[deviceId]/trial-exception-requests',
  'trial-exception-requests/[requestId]/decision',
  'devices/[deviceId]/access/effective',
  'internal/entitlements/activate',
  'internal/entitlements/[entitlementId]/transition',
  'internal/device-replacements',
  'devices/[deviceId]/source-configs',
  'devices/[deviceId]/source-configs/[sourceConfigId]',
  'devices/[deviceId]/active-source',
  'devices/[deviceId]/diagnostics/current',
  'diagnostic-codes',
  'internal/diagnostics',
  'devices/[deviceId]/audit-events',
  'internal/audit-events',
];

describe('QUDRA T2 routes', () => {
  it('ships every control-plane handler and keeps each on server-only', () => {
    for (const path of routes) {
      expect(existsSync(route(path)), path).toBe(true);
      expect(readFileSync(route(path), 'utf8').startsWith("import 'server-only';"), path).toBe(
        true,
      );
    }
  });
  it('has no playback, media relay, proxy, or catalogue route path', () => {
    const api = resolve(root, 'src/app/api/qudra');
    expect(readFileSync(resolve(api, 'diagnostic-codes/route.ts'), 'utf8')).not.toMatch(
      /playback|proxy|relay/i,
    );
    expect(routes.some((path) => /playback|media|proxy|catalog|epg/i.test(path))).toBe(false);
  });
});
