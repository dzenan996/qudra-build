// @polsia:user-owned — T5 shared zod contract boundaries.
import { describe, expect, it } from 'vitest';
import { QudraSourceWrite } from '@/lib/contracts/qudra-source';
import { QudraSyncReport } from '@/lib/contracts/qudra-sync';

describe('T5 contracts', () => {
  it('accepts URL-based source metadata and write-only secret input', () => {
    expect(
      QudraSourceWrite.safeParse({
        label: 'TV',
        sourceType: 'personal_source',
        endpointUrl: 'https://example.invalid/list.m3u',
        epgUrl: 'https://example.invalid/guide.xml',
        secret: 'write-only',
      }).success,
    ).toBe(true);
    expect(
      QudraSourceWrite.safeParse({
        label: 'TV',
        sourceType: 'personal_source',
        endpointUrl: 'not-a-url',
      }).success,
    ).toBe(false);
  });
  it('accepts aggregate sync metadata but has no catalogue fields', () => {
    const parsed = QudraSyncReport.safeParse({
      configVersion: 1,
      state: 'FRESH',
      counts: { live: 2, movies: 0, series: 0, radio: 0, epgChannels: 2, epgProgrammes: 20 },
      capabilities: { epg: 'SUPPORTED', catchUp: 'UNSUPPORTED', timeshift: 'UNKNOWN' },
    });
    expect(parsed.success).toBe(true);
    expect(JSON.stringify(QudraSyncReport.shape)).not.toMatch(
      /channelCatalogue|viewingHistory|programmeRows/i,
    );
  });
});
