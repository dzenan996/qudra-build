// @polsia:user-owned — QUDRA T2 domain invariant tests.
import { describe, expect, it } from 'vitest';
import {
  ENTITLEMENT_GRACE_MS,
  entitlementIsUsable,
  redactSource,
  trialEndsAt,
  trialIsActive,
  validateEnvelopeSecret,
} from '@/lib/business/qudra/domain';

describe('QUDRA T2 domain invariants', () => {
  it('uses exactly 168 elapsed hours and expires at the boundary', () => {
    const started = new Date('2026-01-01T00:00:00.000Z');
    const ended = trialEndsAt(started);
    expect(ended.toISOString()).toBe('2026-01-08T00:00:00.000Z');
    expect(trialIsActive(started, ended, new Date('2026-01-07T23:59:59.999Z'))).toBe(true);
    expect(trialIsActive(started, ended, ended)).toBe(false);
  });
  it('applies Device-scoped annual/lifetime usable rules and 72-hour grace metadata', () => {
    const now = new Date('2026-01-01T00:00:00.000Z');
    expect(ENTITLEMENT_GRACE_MS).toBe(72 * 60 * 60 * 1000);
    expect(
      entitlementIsUsable(
        { state: 'ACTIVE', kind: 'ANNUAL', expiresAt: new Date('2026-01-02T00:00:00.000Z') },
        now,
      ),
    ).toBe(true);
    expect(entitlementIsUsable({ state: 'ACTIVE', kind: 'ANNUAL', expiresAt: now }, now)).toBe(
      false,
    );
    expect(entitlementIsUsable({ state: 'ACTIVE', kind: 'LIFETIME', expiresAt: null }, now)).toBe(
      true,
    );
    expect(
      entitlementIsUsable({ state: 'SUSPENDED', kind: 'LIFETIME', expiresAt: null }, now),
    ).toBe(false);
  });
  it('redacts source secrets and accepts only envelope metadata', () => {
    const source = redactSource({
      id: 's',
      deviceId: 'd',
      label: 'Personal',
      sourceType: 'personal_source',
      endpointUrl: null,
      slot: 1,
      secretCiphertext: 'cipher',
      secretKeyReference: 'kms/key',
      secretKeyVersion: 4,
      configVersion: 1,
    });
    expect(source).toMatchObject({
      hasSecret: true,
      secretStorage: { redacted: true, keyReference: 'kms/key', keyVersion: 4 },
    });
    expect(JSON.stringify(source)).not.toContain('cipher');
    expect(
      validateEnvelopeSecret({ ciphertext: 'cipher', keyReference: 'kms/key', keyVersion: 1 })
        .keyReference,
    ).toBe('kms/key');
  });
});
