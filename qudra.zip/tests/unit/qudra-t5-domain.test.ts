// @polsia:user-owned — T5 domain and invariant coverage.
import { describe, expect, it } from 'vitest';
import {
  ENTITLEMENT_GRACE_MS,
  entitlementIsUsable,
  trialEndsAt,
  trialIsActive,
} from '@/lib/business/qudra/domain';

describe('QUDRA T5 domain invariants', () => {
  it('retains exact 168-hour trial and 72-hour grace metadata', () => {
    const start = new Date('2026-01-01T00:00:00.000Z');
    expect(trialEndsAt(start).getTime() - start.getTime()).toBe(168 * 60 * 60 * 1000);
    expect(trialIsActive(start, trialEndsAt(start), trialEndsAt(start))).toBe(false);
    expect(ENTITLEMENT_GRACE_MS).toBe(72 * 60 * 60 * 1000);
  });
  it('keeps QUDRA OPEN available while Personal Source access expires', () => {
    expect(entitlementIsUsable({ state: 'EXPIRED', kind: 'ANNUAL', expiresAt: new Date() })).toBe(
      false,
    );
  });
});
