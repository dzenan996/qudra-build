// @polsia:user-owned
import fs from 'node:fs';
import { describe, expect, it } from 'vitest';

describe('QUDRA T7 boundaries', () => {
  it('does not expose Personal Source secret columns in control-plane projections', () => {
    for (const file of [
      'src/lib/business/qudra/admin-control-plane.ts',
      'src/app/api/admin/diagnostics/route.ts',
      'src/app/api/admin/devices/route.ts',
    ])
      expect(fs.readFileSync(file, 'utf8')).not.toContain('secretCiphertext');
  });
  it('keeps payment, media relay and marketplace out of T7 routes', () => {
    const source = fs.readFileSync('src/lib/business/qudra/partner-activation.ts', 'utf8');
    expect(source).not.toMatch(/stripe|paypal|restream|transcod|marketplace/i);
  });
});
