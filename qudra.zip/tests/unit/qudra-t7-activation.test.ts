// @polsia:user-owned
import { describe, expect, it } from 'vitest';
import { PARTNER_ACTIVATION_CREDITS } from '@/lib/business/qudra/domain';
import { QudraPartnerActivationInput } from '@/lib/contracts/qudra-t7-activation';

describe('QUDRA T7 activation', () => {
  it('requires idempotency and separates Annual/Lifetime payloads', () => {
    expect(
      QudraPartnerActivationInput.safeParse({ customerId: 'c', deviceId: 'd', kind: 'ANNUAL' })
        .success,
    ).toBe(false);
    expect(
      QudraPartnerActivationInput.safeParse({
        customerId: 'c',
        deviceId: 'd',
        kind: 'LIFETIME',
        idempotencyKey: 'stable-key-1',
      }).success,
    ).toBe(true);
    expect(PARTNER_ACTIVATION_CREDITS).toBe(1);
  });
  it('uses a conditional credit update and unique activation key in the service', async () => {
    const source = await import('node:fs').then((fs) =>
      fs.readFileSync('src/lib/business/qudra/partner-activation.ts', 'utf8'),
    );
    expect(source).toContain('balance: { gte: PARTNER_ACTIVATION_CREDITS }');
    expect(source).toContain('partnerId_idempotencyKey');
  });
});
