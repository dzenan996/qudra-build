// @polsia:user-owned — EPG/catch-up capability boundary tests.
import { describe, expect, it } from 'vitest';
import { QudraEpgSnapshot } from '@/lib/contracts/qudra-epg';

describe('T5 EPG foundation', () => {
  it('models XMLTV NOW/NEXT/grid metadata and stale state', () => {
    const snapshot = QudraEpgSnapshot.parse({
      format: 'XMLTV',
      timezone: 'Europe/Zagreb',
      utcOffsetMinutes: 120,
      state: 'STALE',
      channelCount: 1,
      programmeCount: 2,
      nowNext: true,
      fullSchedule: true,
      mappings: [{ sourceChannelId: 'one', displayName: 'One', xmltvId: 'one' }],
    });
    expect(snapshot.state).toBe('STALE');
    expect(snapshot.fullSchedule).toBe(true);
  });
});
