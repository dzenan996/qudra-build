// @polsia:user-owned — QUDRA T2H hardening regression coverage.
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';

const root = process.cwd();
const read = (path: string) => readFileSync(resolve(root, path), 'utf8');
const schema = `${read('prisma/schema/qudra-t1.prisma')}\n${read('prisma/schema/qudra-t2.prisma')}`;
const pairing = read('src/lib/business/qudra/pairing.ts');
const authority = read('src/lib/business/qudra/authority.ts');
const sessions = read('src/lib/business/qudra/device-session.ts');
const openapi = read('specs/qudra/v1/openapi.yaml');
const migrationReview = read('docs/company/qudra-t2h-migration-review.md');

describe('QUDRA T2H strict invariants', () => {
  it('keeps populated-table schema changes additive and records staged constraints', () => {
    expect(schema).toMatch(/publicDeviceId\s+String\s+@db\.VarChar\(256\)/);
    expect(schema).not.toMatch(/publicDeviceId\s+String\s+@unique/);
    expect(schema).toMatch(/model QudraTrial[\s\S]*deviceId\s+String\?/);
    expect(schema).not.toContain('@@unique([deviceId, slot])');
    expect(schema).toMatch(/model QudraAccount[\s\S]*customerId\s+String\s*\n\s+userId\s+String\?/);
    expect(migrationReview).toContain('platform migration');
    expect(migrationReview).toContain('No\nrow was deleted or modified');
    expect(schema).toMatch(/model QudraDeviceSession/);
    expect(schema).toMatch(/model QudraPairingRateWindow/);
    expect(schema).toContain('@@unique([deviceId, version])');
    expect(schema).toContain('@@unique([deviceId, category])');
  });

  it('has a read-only preflight for every requested duplicate/null class', () => {
    const preflight = read('scripts/qudra-t2h-preflight.mjs');
    expect(preflight).toContain('databaseAvailable');
    expect(preflight).toContain('publicDeviceId');
    expect(preflight).toContain('trialDeviceId');
    expect(preflight).toContain('sourceDeviceSlot');
    expect(preflight).toContain('currentEntitlement');
    expect(preflight).toContain('activeSource');
    expect(preflight).toContain('rowsRemoved: 0');
    expect(preflight).not.toMatch(/prisma\.[^\n]*(delete|update|create)\(/);
  });
});

describe('QUDRA T2H pairing and authority', () => {
  it('fixes lifetime, rotation, idempotency, throttling, and atomic attempts', () => {
    expect(pairing).toContain('PAIRING_LIFETIME_MS = 10 * 60 * 1000');
    expect(pairing).toContain('PAIRING_MAX_ATTEMPTS = 5');
    expect(pairing).toContain("state: 'PAIRING_PENDING'");
    expect(pairing).toContain("data: { state: 'REVOKED' }");
    expect(pairing).toContain('updateMany({');
    expect(pairing).toContain('attemptCount: { increment: 1 }');
    expect(pairing).toContain('idempotencyKey');
    expect(pairing).toContain('pairing.rate_limited');
    expect(pairing).toContain('representation: challenge.id');
    expect(pairing).not.toMatch(/sourceUrl|secretCiphertext|privateKey/);
    expect(pairing).toContain("kind: 'BOOTSTRAP'");
    expect(pairing).toContain('constantTimeStringEqual');
    expect(pairing).toContain('bootstrapProofPayload');
    expect(pairing).toContain('QUDRA_BOOTSTRAP_FINGERPRINT_RATE_LIMIT_PER_HOUR');
  });

  it('uses scoped service identity and Device-bound sessions', () => {
    expect(authority).toContain('QUDRA_INTERNAL_SERVICE_CREDENTIALS');
    expect(authority).toContain('expiresAt');
    expect(authority).toContain('scopes');
    expect(authority).not.toContain('QUDRA_INTERNAL_SERVICE_TOKEN');
    expect(sessions).toContain('tokenDigest');
    expect(sessions).toContain('session.keyVersion !== session.device.keyVersion');
    expect(read('src/lib/business/qudra/device-keys.ts')).toContain(
      'qudraDeviceSession.updateMany',
    );
  });
});

describe('QUDRA T2H contract and scope boundaries', () => {
  it('documents fixed pairing and session semantics in OpenAPI', () => {
    expect(openapi).toContain('600-second');
    expect(openapi).toContain('five new challenges');
    expect(openapi).toMatch(/approved My Qudra ownership\/claim\s+authority/);
    expect(openapi).toContain('DeviceSession');
    expect(openapi).toContain('scoped-service-credential');
    expect(openapi).toContain('pairing.rate_limited');
  });

  it('keeps Personal Source fail-closed and excludes forbidden product surfaces', () => {
    expect(read('src/lib/business/qudra/source-secrets.ts')).toMatch(
      /never accepts a[\s\S]*plaintext source secret/,
    );
    const all = [
      read('prisma/schema/qudra-t1.prisma'),
      read('prisma/schema/qudra-t2.prisma'),
      read('src/lib/business/qudra/domain.ts'),
      read('src/app/api/qudra/diagnostic-codes/route.ts'),
    ].join('\n');
    expect(all).not.toMatch(/stripe|checkout|payment|restream|transcod|media relay/i);
    expect(all).not.toMatch(/model Qudra(Channel|Movie|Series|Epg|Viewing)/);
  });
});
