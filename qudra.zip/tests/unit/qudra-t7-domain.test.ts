// @polsia:user-owned
import { describe, expect, it } from 'vitest';
import {
  ANNUAL_LICENSE_DURATION_MS,
  entitlementIsUsable,
  PARTNER_ACTIVATION_CREDITS,
  PARTNER_BRANDING_FIELDS,
  safeMetadata,
  TRIAL_DURATION_MS,
  trialEndsAt,
} from '@/lib/business/qudra/domain';

describe('QUDRA T7 domain invariants', () => {
  it('keeps one credit, exact annual duration and 168 hour trial', () => {
    expect(PARTNER_ACTIVATION_CREDITS).toBe(1);
    expect(ANNUAL_LICENSE_DURATION_MS).toBe(365 * 24 * 60 * 60 * 1000);
    expect(TRIAL_DURATION_MS).toBe(168 * 60 * 60 * 1000);
    const start = new Date('2026-01-01T00:00:00.000Z');
    expect(trialEndsAt(start).getTime() - start.getTime()).toBe(TRIAL_DURATION_MS);
  });
  it('allows only bounded branding and safe metadata', () => {
    expect(PARTNER_BRANDING_FIELDS).toEqual([
      'displayName',
      'logoUrl',
      'supportEmail',
      'supportPhone',
    ]);
    expect(safeMetadata({ token: 'x', supportEmail: 'qudra@polsia.app', note: 'ok' })).toEqual({
      supportEmail: 'qudra@polsia.app',
      note: 'ok',
    });
  });
  it('keeps Lifetime open and Annual time-bounded', () => {
    expect(entitlementIsUsable({ state: 'ACTIVE', kind: 'LIFETIME', expiresAt: null })).toBe(true);
    expect(
      entitlementIsUsable({
        state: 'ACTIVE',
        kind: 'ANNUAL',
        expiresAt: new Date(Date.now() + 1000),
      }),
    ).toBe(true);
    expect(
      entitlementIsUsable({
        state: 'ACTIVE',
        kind: 'ANNUAL',
        expiresAt: new Date(Date.now() - 1000),
      }),
    ).toBe(false);
  });
});
