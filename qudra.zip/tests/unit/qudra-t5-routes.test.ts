// @polsia:user-owned — T5 route inventory and server-only boundary tests.
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';

const root = process.cwd();
const paths = [
  'me',
  'claims',
  'devices/[deviceId]/sync',
  'devices/[deviceId]/source-configs/[sourceConfigId]/sync',
  'devices/[deviceId]/capabilities',
];
describe('T5 routes', () => {
  it('ships each metadata/control handler as server-only', () => {
    for (const path of paths) {
      const file = resolve(root, 'src/app/api/qudra', path, 'route.ts');
      expect(existsSync(file), path).toBe(true);
      expect(readFileSync(file, 'utf8').startsWith("import 'server-only';"), path).toBe(true);
    }
  });
  it('does not add media proxy or catalogue routes', () => {
    expect(paths.some((path) => /media|proxy|catalogue|playback/i.test(path))).toBe(false);
  });
});
