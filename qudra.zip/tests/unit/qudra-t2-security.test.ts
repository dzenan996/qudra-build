// @polsia:user-owned — QUDRA T2 authority, bounded-attempt, and redaction tests.
import { describe, expect, it } from 'vitest';
import { AUDIT_ACTIONS, safeMetadata } from '@/lib/business/qudra/domain';

describe('QUDRA T2 security boundaries', () => {
  it('never keeps sensitive audit metadata', () => {
    const result = safeMetadata({
      source: 'device',
      secret: 'hidden',
      privateKey: 'hidden',
      challengeResponse: 'hidden',
      safe: 'ok',
    });
    expect(result).toEqual({ source: 'device', safe: 'ok' });
  });
  it('allowlists trusted audit actions and excludes arbitrary writes', () => {
    expect(AUDIT_ACTIONS.has('device.registered')).toBe(true);
    expect(AUDIT_ACTIONS.has('arbitrary.client.event')).toBe(false);
    expect(AUDIT_ACTIONS.has('source_config.secret_changed')).toBe(true);
  });
  it('keeps the canonical pairing/recovery attempt ceiling in the contracts', async () => {
    const pairing = await import('@/lib/contracts/qudra-pairing');
    const recovery = await import('@/lib/contracts/qudra-recovery');
    expect(pairing.QudraPairingChallenge.shape.maxAttempts.value).toBe(5);
    expect(recovery.QudraRecoveryChallenge.shape.maxAttempts.value).toBe(5);
    expect(
      recovery.QudraRecoveryCreate.safeParse({ deviceId: 'd', evidenceCategory: 'ACCOUNT' })
        .success,
    ).toBe(true);
  });
});
