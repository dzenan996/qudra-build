// @polsia:user-owned
import fs from 'node:fs';
import { describe, expect, it } from 'vitest';

describe('QUDRA T7 authorization', () => {
  it('accepts only an authenticated Super Admin authority', () => {
    const source = fs.readFileSync('src/lib/business/qudra/authority.ts', 'utf8');
    expect(source).toContain('authority.isSuperAdmin');
    expect(source).toContain('Super Admin authority required');
  });
  it('keeps isolation rules explicit in the Partner service', async () => {
    const source = fs.readFileSync('src/lib/business/qudra/partner.ts', 'utf8');
    expect(source).toContain('partnerId');
    expect(source).toContain("status: 'ACTIVE'");
  });
});
