// @polsia:user-owned — QUDRA T10 redaction, provider, and authorization regressions.
import { readdirSync, readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { redact, redactError, redactMetadata, redactUrl } from '@/lib/business/qudra/redaction';

const read = (path: string) => readFileSync(path, 'utf8');

describe('QUDRA T10 central redaction', () => {
  it('redacts nested secrets, URLs, Error causes, and bearer material', () => {
    const value = redact({
      password: 'p-123',
      nested: [
        { authorization: 'Bearer top-secret', sourceUrl: 'https://u:p@example.test/x?token=t' },
      ],
      error: new Error('failed with secret=very-secret', { cause: { privateKey: 'pem' } }),
      safe: 'visible',
    });
    const text = JSON.stringify(value);
    expect(text).not.toContain('p-123');
    expect(text).not.toContain('top-secret');
    expect(text).not.toContain('very-secret');
    expect(text).not.toContain('pem');
    expect(text).toContain('visible');
    expect(JSON.stringify(redactError(new Error('Bearer hidden')))).not.toContain('hidden');
  });

  it('sanitizes source URL credentials and secret query keys', () => {
    const safe = redactUrl('https://user:password@example.test/playlist?token=secret&lang=hr');
    expect(safe).toBe('https://example.test/playlist?lang=hr');
    expect(redactMetadata({ challenge: 'nonce', ok: 'yes' })).toEqual({ ok: 'yes' });
  });
});

describe('QUDRA T10 authority and non-disclosure', () => {
  it('keeps the provider fail-closed and prevents raw account projections', () => {
    const provider = read('src/lib/business/qudra/source-secrets.ts');
    const account = read('src/lib/business/qudra/account.ts');
    const authority = read('src/lib/business/qudra/authority.ts');
    expect(provider).toContain('SourceSecretEnvelopeProvider');
    expect(provider).toContain('QUDRA_SOURCE_ENVELOPE_PROVIDER');
    expect(provider).toContain("process.env.NODE_ENV === 'production'");
    expect(provider).toContain("'Source secret provider is unavailable', 503");
    expect(account).toContain('sources.map(redactSource)');
    expect(account).not.toContain('endpointUrl: source.endpointUrl');
    expect(authority).not.toContain("headers.get('authorization')");
    expect(authority).toContain("process.env.NODE_ENV === 'test'");
  });

  it('places a Super Admin guard at every admin route boundary', () => {
    const routes = readdirSync('src/app/api/admin', { recursive: true })
      .filter((file) => String(file).endsWith('route.ts'))
      .map((file) => read(`src/app/api/admin/${String(file)}`));
    expect(routes.length).toBeGreaterThan(10);
    for (const route of routes) expect(route).toContain('requireSuperAdminApi');
  });

  it('keeps pairing QR payload and Personal Source Cloud exclusions explicit', () => {
    const pairing = read('src/lib/business/qudra/pairing.ts');
    const schema = read('prisma/schema/qudra-t1.prisma');
    expect(pairing).toContain('representation: challenge.id');
    expect(pairing).not.toContain('sourceUrl');
    expect(schema).not.toMatch(/model Qudra(Channel|Movie|Series|Epg|Viewing)/);
  });
});
