// @polsia:user-owned
import fs from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';

const root = process.cwd();
const schema = fs.readFileSync(path.join(root, 'prisma/schema/qudra-t7.prisma'), 'utf8');
describe('QUDRA T7 schema', () => {
  it('contains the additive Partner, scope, ledger, activation and request models', () => {
    for (const model of [
      'QudraPartner',
      'QudraPartnerMembership',
      'QudraPartnerCustomerScope',
      'QudraPartnerCreditAccount',
      'QudraPartnerCreditLedgerEntry',
      'QudraPartnerActivation',
      'QudraPartnerReplacementRequest',
      'QudraTrustedAuditEvent',
    ])
      expect(schema).toContain(`model ${model}`);
    expect(schema).toContain('@@unique([partnerId, idempotencyKey])');
    expect(schema).toContain('@@unique([partnerId, userId])');
  });
  it('has no payment, provider marketplace or media transport model', () => {
    expect(schema.toLowerCase()).not.toMatch(
      /stripe|paypal|paddle|payment|marketplace|restream|transcode|media package/,
    );
    expect(fs.existsSync(path.join(root, 'prisma/migrations/20260603000000_t7.sql'))).toBe(false);
  });
});
