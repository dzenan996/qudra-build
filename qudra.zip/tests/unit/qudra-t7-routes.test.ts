// @polsia:user-owned
import fs from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';

const routeFiles = fs
  .readdirSync(path.join(process.cwd(), 'src/app/api'), { recursive: true })
  .filter((file) => String(file).includes('admin') || String(file).includes('partner'))
  .filter((file) => String(file).endsWith('route.ts'))
  .map((file) => path.join(process.cwd(), 'src/app/api', String(file)));
describe('QUDRA T7 route boundaries', () => {
  it('marks every new admin/Partner handler server-only', () => {
    expect(routeFiles.length).toBeGreaterThan(10);
    for (const file of routeFiles)
      expect(fs.readFileSync(file, 'utf8').startsWith("import 'server-only';")).toBe(true);
  });
  it('does not add Server Actions or client server imports', () => {
    for (const file of routeFiles) {
      const source = fs.readFileSync(file, 'utf8');
      expect(source).not.toContain("'use server'");
      expect(source).not.toContain("'use client'");
    }
  });
});
