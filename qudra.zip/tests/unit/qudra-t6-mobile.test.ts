// @polsia:user-owned — T6 web contract and device-boundary regression coverage.
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';
import { QudraBootstrapChallengeCreate } from '@/lib/contracts/qudra-bootstrap';

const root = process.cwd();
const read = (path: string) => readFileSync(resolve(root, path), 'utf8');

describe('T6 Mobile bootstrap contract', () => {
  const base = {
    publicDeviceId: 'mobile-public-1',
    algorithm: 'P256' as const,
    publicKey: 'x'.repeat(64),
  };

  it('accepts phone and tablet Mobile registrations', () => {
    expect(
      QudraBootstrapChallengeCreate.safeParse({
        ...base,
        platform: 'ANDROID_PHONE',
        productFamily: 'MOBILE',
      }).success,
    ).toBe(true);
    expect(
      QudraBootstrapChallengeCreate.safeParse({
        ...base,
        platform: 'ANDROID_TABLET',
        productFamily: 'MOBILE',
      }).success,
    ).toBe(true);
  });

  it('retains TV/Mobile family separation and P-256 proof inputs', () => {
    expect(
      QudraBootstrapChallengeCreate.safeParse({
        ...base,
        platform: 'ANDROID_TV',
        productFamily: 'MOBILE',
      }).success,
    ).toBe(false);
    expect(
      QudraBootstrapChallengeCreate.safeParse({
        ...base,
        platform: 'ANDROID_PHONE',
        productFamily: 'TV',
      }).success,
    ).toBe(false);
    expect(read('src/lib/business/qudra/device-identity.ts')).toContain(
      'Mobile platforms require MOBILE family',
    );
    expect(read('src/lib/business/qudra/pairing.ts')).toContain(
      'validatePlatformFamily(input.platform, input.productFamily)',
    );
  });
});
