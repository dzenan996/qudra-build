// @polsia:user-owned — AES-GCM envelope and fail-closed secret tests.
import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

describe('QUDRA source envelope', () => {
  it('uses authenticated encryption and versioned key-ring metadata', () => {
    const source = readFileSync('src/lib/business/qudra/source-secrets.ts', 'utf8');
    expect(source).toContain('aes-256-gcm');
    expect(source).toContain('QUDRA_SOURCE_ENVELOPE_KEY_RING');
    expect(source).toContain('getAuthTag');
    expect(source).toContain('setAuthTag');
  });
  it('fails closed without an owner key ring', () => {
    const source = readFileSync('src/lib/business/qudra/source-secrets.ts', 'utf8');
    expect(source).toContain(
      "throw new QudraAuthorizationError('Source secret provider is unavailable', 503)",
    );
  });
});
