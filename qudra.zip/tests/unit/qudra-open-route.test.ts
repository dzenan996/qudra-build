// @vitest-environment node
// @polsia:user-owned — QUDRA OPEN route boundary tests.
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('server-only', () => ({}));
const mocks = vi.hoisted(() => ({
  routeAuthority: vi.fn(),
  unauthorized: vi.fn(() =>
    Response.json({ error: 'Verified authority required' }, { status: 403 }),
  ),
}));
vi.mock('@/lib/business/qudra/route-helpers', () => mocks);

import { GET } from '@/app/api/qudra/open/manifest/route';

describe('QUDRA OPEN manifest route', () => {
  beforeEach(() => vi.clearAllMocks());

  it('rejects an unauthorised read at the existing verified-authority boundary', async () => {
    mocks.routeAuthority.mockResolvedValue(null);
    const response = await GET(new Request('http://test/api/qudra/open/manifest'));
    expect(response.status).toBe(403);
    expect(mocks.unauthorized).toHaveBeenCalledOnce();
  });

  it('returns the checked-in manifest for verified authority without entitlement lookup', async () => {
    mocks.routeAuthority.mockResolvedValue({ kind: 'test', testId: 'qudra-open-test' });
    const response = await GET(new Request('http://test/api/qudra/open/manifest'));
    expect(response.status).toBe(200);
    const body = await response.json();
    expect(body.manifestVersion).toBe('3.0.0-t3b');
    expect(body.availableWithoutEntitlement).toBe(true);
    expect(body.controlPlaneProxiesBytes).toBe(false);
    expect(body.liveTv).toEqual([]);
    expect(body.radio).toEqual([]);
    expect(
      body.sourceRegister.find((source: { sourceId: string }) => source.sourceId === 'movie-sintel')
        .compatibility.classification,
    ).toBe('PREFERRED');
  });

  it('has no media-byte or proxy behavior in the boundary handler', () => {
    const source = readFileSync(
      resolve(process.cwd(), 'src/app/api/qudra/open/manifest/route.ts'),
      'utf8',
    );
    expect(source).not.toMatch(/prisma|fetch|stream|buffer|relay|transcod|media bytes/i);
    expect(source).toContain("import 'server-only';");
    expect(source).toContain('QudraOpenManifest.parse');
  });
});
