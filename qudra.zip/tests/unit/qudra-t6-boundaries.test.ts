// @polsia:user-owned — T6 negative scans for catalogue, relay, and entitlement cloning.
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';

const read = (path: string) => readFileSync(resolve(process.cwd(), path), 'utf8');

describe('T6 direct-origin and local-data boundaries', () => {
  it('keeps Mobile media and Personal Source data local/direct', () => {
    const mobile = read('android-mobile/README.md');
    const resolver = read(
      'android-mobile/app/src/main/java/com/qudra/mobile/player/DirectPlaybackResolver.kt',
    );
    const store = read(
      'android-mobile/app/src/main/java/com/qudra/mobile/local/source/CatalogueStore.kt',
    );
    const cast = read(
      'android-mobile/app/src/main/java/com/qudra/mobile/cast/CastSessionCoordinator.kt',
    );
    expect(mobile).toContain('there is no media relay');
    expect(resolver).toContain('https');
    expect(resolver).not.toContain('proxy');
    expect(store).toContain('local generations');
    expect(cast).toContain('direct source origin');
    expect(cast).not.toMatch(/entitlement.*transfer|token.*metadata/i);
  });

  it('keeps the TV app package and Mobile app package separate', () => {
    expect(read('android/app/build.gradle.kts')).toContain('applicationId = "com.qudra.tv"');
    expect(read('android-mobile/app/build.gradle.kts')).toContain(
      'applicationId = "com.qudra.mobile"',
    );
    expect(read('android-mobile/app/src/main/AndroidManifest.xml')).not.toContain('leanback');
  });
});
