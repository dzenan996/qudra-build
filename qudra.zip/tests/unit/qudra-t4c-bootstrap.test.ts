// @polsia:user-owned — T4C bootstrap contract and authority-boundary regression coverage.
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';

const root = process.cwd();
const read = (path: string) => readFileSync(resolve(root, path), 'utf8');

describe('QUDRA T4C anonymous bootstrap', () => {
  it('ships only anonymous bootstrap handlers and keeps them server-only', () => {
    const challengeRoute = read('src/app/api/qudra/bootstrap/challenges/route.ts');
    const completeRoute = read(
      'src/app/api/qudra/bootstrap/challenges/[challengeId]/complete/route.ts',
    );
    expect(challengeRoute.startsWith("import 'server-only';")).toBe(true);
    expect(completeRoute.startsWith("import 'server-only';")).toBe(true);
    expect(challengeRoute).not.toContain('routeAuthority');
    expect(completeRoute).not.toContain('routeAuthority');
  });

  it('binds bootstrap to protected key material, not public metadata', () => {
    const identity = read('src/lib/business/qudra/device-identity.ts');
    const pairing = read('src/lib/business/qudra/pairing.ts');
    const contract = read('src/lib/contracts/qudra-bootstrap.ts');
    expect(identity).toContain('publicKeyFingerprint');
    expect(identity).toContain('candidate.publicKey === input.publicKey');
    expect(identity).toContain('publicDeviceId: input.publicDeviceId');
    expect(pairing).toContain('bootstrapProofPayload');
    expect(pairing).toContain('constantTimeStringEqual');
    expect(pairing).toContain("challenge.kind !== 'BOOTSTRAP'");
    expect(contract).toContain('nonce');
    expect(contract).toContain('qr: QudraBootstrapQr');
  });

  it('documents 600-second, five-attempt, replay-safe, account-free completion', () => {
    const schema = read('prisma/schema/qudra-t1.prisma');
    const spec = read('specs/qudra/v1/openapi.yaml');
    expect(schema).toContain('enum QudraChallengeKind');
    expect(schema).toContain('kind              QudraChallengeKind');
    expect(schema).toContain('keyVersion        Int');
    expect(spec).toContain('/v1/bootstrap/challenges:');
    expect(spec).toContain('600-second');
    expect(spec).toContain('does not require an Account or entitlement');
    expect(spec).toContain('challengeId:nonce:deviceId:keyVersion');
    expect(spec).toContain('opaque');
    expect(spec).toContain('challenge ID');
  });

  it('keeps the OPEN boundary and direct-origin rule visible', () => {
    const access = read('src/lib/business/qudra/access.ts');
    const openRoute = read('src/app/api/qudra/open/manifest/route.ts');
    expect(access).toContain('qudraOpen: true');
    expect(access).toContain('personalSourceAllowed');
    expect(openRoute).toContain('entitlement-free');
    expect(openRoute).toContain('origin-to-device');
  });
});
