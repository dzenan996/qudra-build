// @polsia:user-owned
import { describe, expect, it } from 'vitest';
import { ANNUAL_LICENSE_DURATION_MS, TRIAL_DURATION_MS } from '@/lib/business/qudra/domain';

describe('QUDRA T7 requests', () => {
  it('preserves same-Customer replacement and Super Admin exception controls', async () => {
    const source = await import('node:fs').then((fs) =>
      fs.readFileSync('src/lib/business/qudra/replacement.ts', 'utf8'),
    );
    expect(source).toContain('oldDevice.customerId !== newDevice.customerId');
    expect(source).toContain('REPLACEMENT_INTERVAL_MS');
    expect(source).toContain('superAdminException');
    expect(ANNUAL_LICENSE_DURATION_MS).toBe(365 * 24 * 60 * 60 * 1000);
    expect(TRIAL_DURATION_MS).toBe(168 * 60 * 60 * 1000);
  });
});
