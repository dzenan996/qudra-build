# QUDRA T1R state machines

The server is authoritative. Clients display server state and timestamps; they
never authorize transitions from local clocks or caller-supplied ownership IDs.

The T2H schema carries the reviewed one-device uniqueness constraints. A
populated production rollout remains staged: inventory and backfill precede
constraint application, as documented in the migration review.

## Device and key lifecycle

```
unpaired -> pairing_pending -> paired
pairing_pending -> cancelled | expired | replayed
unpaired | pairing_pending | paired -> revoked
```

Key rotation is valid only for a non-revoked legitimate Device:

```
key(version n, active) -> key(version n, revoked) + key(version n+1, active)
```

The Device identity and valid Device entitlement remain the same. A revoked
Device has no silent revival path.

## Pairing and recovery

Pairing creates one short-lived challenge with expiry, replay protection,
rotation/cancellation, single-use semantics, and maxAttempts = 5.
pairing_pending -> paired requires a valid response for the current key
version. Any consumed, expired, cancelled, replayed, or exhausted challenge is
terminal. QR encodes that same challenge and is unusable after consumption.

Recovery is separate and bounded:

```
pending -> approved | rejected | expired | cancelled | replayed
```

Recovery has maxAttempts = 5. It requires abstract evidence from an optional
Account, Partner Customer record, or Super Admin/support verification.
publicDeviceId by itself is never sufficient.

## Trial

```
not_started --server start--> active
active --now < startedAt + 168h--> active
active --now >= startedAt + 168h--> expired
```

startedAt is server-recorded once and endsAt is exactly 168 elapsed hours
later. Active means strictly before endsAt; the boundary instant is expired.
Reinstall does not restart the trial. A TrialExceptionRequest is a separate
audited review flow:

```
pending -> approved | rejected | cancelled
```

Only future Super Admin authority can approve/reset; T1 provides no runtime
anti-abuse implementation.

## Entitlement and access

Entitlement states are:

```
active -> expired | suspended | revoked | replaced
suspended -> active | revoked | replaced
```

Annual expires exactly 365 days after successful activation. Lifetime has no
commercial expiry while valid. DIRECT and PARTNER are provenance, not payment
state. Validation fields (lastValidatedAt, graceUntil, revalidationRequired,
entitlementVersion) describe revalidation; the initial offline grace target is
72 hours and offline connectivity is not an entitlement state.

Effective access is calculated per Device. Personal source playback is allowed
while that Device's trial is active or its Device entitlement is active. After
trial expiry it is denied without that Device entitlement. QUDRA OPEN remains
available in every commercial state.

## Source selection

```
QUDRA_OPEN <-> PERSONAL_SOURCE
PERSONAL_SOURCE --selected source deleted--> QUDRA_OPEN
```

PERSONAL_SOURCE must reference one of at most two SourceConfigs on the same
Device. QUDRA OPEN is permanent and separate; it is never a SourceConfig row.
Deleting a selected personal source performs the fallback atomically from the
contract perspective.

## Replacement and audit

Replacement is old Device -> new Device within one Customer only. The old
entitlement may become REPLACED, and the successor on the new Device holds an
immutable replaced-entitlement reference. Standard replacement is once per 12
months for the same Customer/User; earlier replacement needs a future Super
Admin exception. Every trusted transition is recorded using the canonical
append-only event catalogue in domain.md; ordinary clients cannot append
trusted administrative events.
