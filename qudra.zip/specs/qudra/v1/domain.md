# QUDRA T1R domain contract

T1R is a contract, domain, schema, fixture, and documentation foundation for
Android TV, Android Mobile, Cloud, and Web. It is not a product UI, production
authentication system, payment path, media catalogue, parser, relay, or player.
The OpenAPI document is the language-neutral source; generated TypeScript is a
compile-time convenience.

## Ownership and device identity

Customer is the durable ownership boundary. A Customer conceptually has zero or
one optional opaque Account, and an Account may manage multiple Devices.
Account association never combines licenses: every trial, entitlement, source,
and active-source state is evaluated for exactly one Device.

Each new Device has a separate internal database id and a unique opaque,
non-secret publicDeviceId for wire/path references. The T2H schema requires
that value; a populated production database must be backfilled and validated
before the same constraint is applied there. publicDeviceId, platform, product family, app version,
Android API level, and model are metadata, not cryptographic identity. The
minimum platform set is ANDROID_TV,
ANDROID_PHONE, and ANDROID_TABLET; product family remains TV or MOBILE so
licensing stays separate. Cryptographic identity is the server-held public-key
identity and version. Private keys never enter the API, Prisma, fixtures, audit
metadata, or logs.

## Device-owned commercial unit

QudraTrial, QudraEntitlement, and QudraSourceConfig each carry both customerId
and deviceId. The foundation has one trial and one entitlement per Device, and
at most two personal SourceConfigs per Device. Prisma expresses one-trial and
source-slot uniqueness; the slot range and same-Device active-source
relationship remain transactionally enforced conditional checks. A populated
production database still needs the staged backfill/deduplication migration
described in the T2H migration review.

Legacy entitlements retain their channel and recovery rows retain factorRef.
New contract writes use deviceId and the DIRECT/PARTNER provenance/evidence
fields; production backfill rejects ambiguous ownership rather than guessing.

QUDRA OPEN is a permanent, separate contract/manifest. It is never a
SourceConfig row, does not count toward the two-source limit, and does not
depend on a personal entitlement. T1 stores no personal channels, movies,
series, EPG, or viewing catalogue.

Device active-source state is either QUDRA_OPEN or PERSONAL_SOURCE. The latter
must reference a SourceConfig on the same Device. My List changes this state.
Deleting the active personal source automatically selects QUDRA OPEN. Source
secrets are write-only at the API boundary and are represented in storage only
as envelope-encrypted ciphertext plus key reference/version; reads and audits
expose redaction metadata, never secret material.

## Trial and entitlement

The server records startedAt once. endsAt is exactly startedAt plus 168 elapsed
hours; a trial is active strictly before endsAt and expired at or after it.
Reinstall cannot automatically restart a Device Trial. A
TrialExceptionRequest records device/customer ownership, requester, reason,
status, timestamps, decision authority, and decision reason. Only a future
Super Admin may approve/reset; approval and rejection are auditable. T1 adds
no runtime anti-abuse service.

An Entitlement is tied to one Device and keeps ANNUAL/LIFETIME plus
DIRECT/PARTNER activation provenance independent of payment. Its states are
ACTIVE, EXPIRED, SUSPENDED, REVOKED, and REPLACED. Annual expiry is exactly
365 days after successful activation. Lifetime has no commercial expiry while
valid, but may be suspended, revoked, or replaced. Validation metadata
includes lastValidatedAt, graceUntil, revalidationRequired, and
entitlementVersion; the initial offline-grace target is 72 hours. Offline
connectivity is not a commercial entitlement state.

## Replacement and key rotation

Replacement links an old Device to a new Device only within the same Customer.
A prior entitlement may become REPLACED; the successor on the new Device
immutably references it. Cross-Customer transfer is forbidden. Standard
replacement is once per 12 months for the same Customer/User; an earlier
replacement needs a future Super Admin exception.

Key rotation creates a new key version, revokes the old key, retains the same
legitimate Device identity, and retains any valid entitlement on that Device.
Rotation is not license transfer. A revoked Device cannot be silently revived.

## Pairing, recovery, and authorization

Pairing is one short-lived, single-use, rate-limited challenge with canonical
maxAttempts: 5, fixed 600-second expiry, replay rejection, rotation, and cancellation. QR is
only another representation of that challenge. It contains no URL, username,
password, source secret, or private key and is unusable after consumption.
Recovery also has a maximum of five attempts and requires abstract evidence
from an optional Account, Partner Customer record, or Super Admin/support
verification. publicDeviceId alone can never recover a Device.

The bearer schemes in OpenAPI are placeholders; T1 does not install or
implement production auth. Operation descriptions distinguish Device,
Account/Customer, future Partner, future Super Admin, and internal-service
boundaries. Caller-supplied customer/device IDs are context only. Revocation,
key rotation, trial decisions, diagnostics append, and audit append have
explicit actions/boundaries rather than trusting ordinary retrieval/update
requests.

## Diagnostics, audit, and non-goals

Diagnostic categories are stable: internet, qudra_cloud, entitlement, source,
playlist_epg, and playback. A current/latest read is available for later
Device Info and My Qudra use and is tied to authenticated Device or Customer
authority. The registry covers reachability, access, availability,
trial/entitlement, playlist/EPG, and playback. Codes use generic source/access
failures and never assert provider subscription expiry unless technically
established.

Audit is append-only conceptually and internal-service-only for trusted append.
Reads are redacted and authorized. Internal service credentials are server-only,
rotatable records with optional expiry and explicit scopes for audit, diagnostics,
entitlement, device, source, trial, access, and pairing operations. The canonical event catalogue is:
device.registered, device.revoked, device.key_rotated, pairing.created,
pairing.completed, pairing.expired, pairing.cancelled, pairing.rate_limited,
pairing.replay_rejected,
recovery.requested, recovery.approved, recovery.rejected, trial.started,
trial.expired, trial.exception_requested, trial.exception_approved,
trial.exception_rejected, entitlement.activated, entitlement.expired,
entitlement.suspended, entitlement.revoked, entitlement.replaced,
source_config.created, source_config.updated, source_config.deleted,
source_config.secret_changed, and active_source.changed. Metadata is limited
to redacted safe fields; secrets, credentials, private keys, and ciphertext
are forbidden.

T1R does not add production auth, checkout, payment, Partner credits,
commercial media, provider directories, video proxying, full M3U parsing,
Android player/runtime services, recurring infrastructure, or T2-T7 work.
